sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common"
], function (Controller, JSONModel, History, oPPCCommon, BusyDialog) {
	"use strict";
	var SONo;
	var oi18n;
	var gSOItemDetailHeaderView;
	return Controller.extend("com.arteriatech.sf.salesorder.sfsalesorder.controller.DetailPageHeader", {

		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gSOItemDetailHeaderView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSOItemDetailHeaderView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
		},

		setSOItemDetailHeader: function (oData, oComponent) {
			var oSOItemModel = new sap.ui.model.json.JSONModel();
			oSOItemModel.setData(oData);
			// SOItemHeaderData = oData;
			SONo = oData.SONo;
			oComponent.setModel(oSOItemModel, "SOItemDetailHeader");
		},
		setSODocumentFlow: function (oData, oComponent) {
			// var oSalesDocflowItemsModel = new sap.ui.model.json.JSONModel();
			// oSalesDocflowItemsModel.setData(oData.results);
			// gSOItemDetailHeaderView.setModel(oSalesDocflowItemsModel, "SalesDocflowItems");

			if (gSOItemDetailHeaderView.getModel("device").getProperty("/system/phone")) {
				this.onBCTableInit(oData.results);
			} else {
				this.setTreeTabelData(oData.results, oComponent);
			}
			// this.setTreeTabelData(oData.SalesDocflowItems.results);
		},
		clearModel: function () {
			this.setEmptyHeaderData("SOItemDetailHeader");
			// this.setEmptyHeaderData("SalesDocflowItems");
		},
		setEmptyHeaderData: function (fModelName) {
			var oTempData = gSOItemDetailHeaderView.getModel(fModelName).getData();
			for (var propName in oTempData) {
				if ((typeof oTempData[propName] === "object" && oTempData[propName] instanceof Date === true) || oTempData[propName] === null) {
					oTempData[propName] = new Date();
				} else {
					oTempData[propName] = "";
				}
			}
			gSOItemDetailHeaderView.getModel(fModelName).setProperty("/", oTempData);
		},
		gotoSOHeader: function (oEvent) {
			var path = "";
			var oModelContext = gSOItemDetailHeaderView.getModel("SOItemDetailHeader");
			/**
			 * Check for the Multi-Origin of the service
			 * If true pass Multi-Origin Property in the routing
			 */
			if (oPPCCommon.isMultiOrigin(oModelContext)) {
				var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
				path = "SOs(SONo='" + SONo + "'," +
					SAPMultiOriginPropertyName + "='" + oModelContext.getProperty("/" + SAPMultiOriginPropertyName) + "')";
			} else {
				path = "SOs(SONo='" + SONo + "')";
			}
			this.router.navTo("sodetail", {
				contextPath: path
			}, false);
		},
		/*---------------------------------------Tree Table-----------------------------------------------------*/

		setTreeTabelData: function (aSOItemServicesData, oComponent) {
			aSOItemServicesData.sort(function (a, b) {
				return a.PreSalesDocType.localeCompare(b.PreSalesDocType);
			});

			if (aSOItemServicesData.length > 0) {
				var aTreeService = new Array();

				aTreeService[0] = {
					SalesDocCat: aSOItemServicesData[0].SalesDocCat,
					SalesDocNo: aSOItemServicesData[0].SalesDocNo,
					ItemNo: aSOItemServicesData[0].ItemNo,
					SalesDocCatDesc: aSOItemServicesData[0].SalesDocCatDesc,
					PreSalesDocType: aSOItemServicesData[0].PreSalesDocType,
					PreSalesDocNo: aSOItemServicesData[0].PreSalesDocNo,
					PreSalesDocItemNo: aSOItemServicesData[0].PreSalesDocItemNo,
					PreSalesDocCatDesc: aSOItemServicesData[0].PreSalesDocCatDesc,
					LoginID: aSOItemServicesData[0].LoginID,
					Qty: aSOItemServicesData[0].Qty,
					UOM: aSOItemServicesData[0].UOM,
					NetValue: aSOItemServicesData[0].NetValue,
					Currency: aSOItemServicesData[0].Currency,
					Material: aSOItemServicesData[0].Material,
					MaterialDesc: aSOItemServicesData[0].MaterialDesc,
					StatusId: aSOItemServicesData[0].StatusId,
					Status: aSOItemServicesData[0].Status,
					CreatedBy: aSOItemServicesData[0].CreatedBy,
					CreatedOn: aSOItemServicesData[0].CreatedOn,
					CreatedAt: aSOItemServicesData[0].CreatedAt,
					Category: "Sales Order"
				};

				var j = 0,
					k = 0;
				for (var i = 0; i < aSOItemServicesData.length; i++) {
					if (aSOItemServicesData[i].PreSalesDocType === "J") {
						aTreeService[0][j] = {
							SalesDocCat: aSOItemServicesData[i].SalesDocCat,
							SalesDocNo: aSOItemServicesData[i].PreSalesDocNo,
							ItemNo: aSOItemServicesData[i].PreSalesDocItemNo,
							SalesDocCatDesc: aSOItemServicesData[i].SalesDocCatDesc,
							PreSalesDocType: aSOItemServicesData[i].PreSalesDocType,
							PreSalesDocNo: aSOItemServicesData[i].PreSalesDocNo,
							PreSalesDocItemNo: aSOItemServicesData[i].PreSalesDocItemNo,
							PreSalesDocCatDesc: aSOItemServicesData[i].PreSalesDocCatDesc,
							LoginID: aSOItemServicesData[i].LoginID,
							Qty: aSOItemServicesData[i].Qty,
							UOM: aSOItemServicesData[i].UOM,
							NetValue: aSOItemServicesData[i].NetValue,
							Currency: aSOItemServicesData[i].Currency,
							Material: aSOItemServicesData[i].Material,
							MaterialDesc: aSOItemServicesData[i].MaterialDesc,
							StatusId: aSOItemServicesData[i].StatusId,
							Status: aSOItemServicesData[i].Status,
							CreatedBy: aSOItemServicesData[i].CreatedBy,
							CreatedOn: aSOItemServicesData[i].CreatedOn,
							CreatedAt: aSOItemServicesData[i].CreatedAt,
							Category: aSOItemServicesData[i].PreSalesDocCatDesc
						};
						j++;
					}
					if (aSOItemServicesData[i].PreSalesDocType === "M") {
						aTreeService[0][0][k] = {
							SalesDocCat: aSOItemServicesData[i].SalesDocCat,
							SalesDocNo: aSOItemServicesData[i].PreSalesDocNo,
							ItemNo: aSOItemServicesData[i].ItemNo,
							SalesDocCatDesc: aSOItemServicesData[i].SalesDocCatDesc,
							PreSalesDocType: aSOItemServicesData[i].PreSalesDocType,
							PreSalesDocNo: aSOItemServicesData[i].PreSalesDocNo,
							PreSalesDocItemNo: aSOItemServicesData[i].PreSalesDocItemNo,
							PreSalesDocCatDesc: aSOItemServicesData[i].PreSalesDocCatDesc,
							LoginID: aSOItemServicesData[i].LoginID,
							Qty: aSOItemServicesData[i].Qty,
							UOM: aSOItemServicesData[i].UOM,
							NetValue: aSOItemServicesData[i].NetValue,
							Currency: aSOItemServicesData[i].Currency,
							Material: aSOItemServicesData[i].Material,
							MaterialDesc: aSOItemServicesData[i].MaterialDesc,
							StatusId: aSOItemServicesData[i].StatusId,
							Status: aSOItemServicesData[i].Status,
							CreatedBy: aSOItemServicesData[i].CreatedBy,
							CreatedOn: aSOItemServicesData[i].CreatedOn,
							CreatedAt: aSOItemServicesData[i].CreatedAt,
							Category: aSOItemServicesData[i].PreSalesDocCatDesc
						};
						k++;
					}
				}
				var oTable = gSOItemDetailHeaderView.byId("SOItemServicesTreeTable");
				var oModel = new sap.ui.model.json.JSONModel();
				oModel.setData(aTreeService);
				oComponent.setModel(oModel, "SalesDocflowItems");
			}
		},
		/*----------------------------------------Bread Crum Table-----------------------------------------------*/
		onBCTableInit: function (aSOItemServicesData) {

			this.sCollection = "",
				this.aCrumbs = ["Services", "SubServices", "SubServices1"],
				this.mInitialOrderState = {
					products: {},
					inService: true,
					count: 0,
					hasCounts: false
				};

			var aTexpService = new Array();
			for (var i = 0; i < aSOItemServicesData.length; i++) {
				var aSubService = [];
				if (aSOItemServicesData[i].IsOutline) {
					aSubService = this.getSubservice(aSOItemServicesData[i], aSOItemServicesData, []);
					aTexpService.push({
						PONumber: aSOItemServicesData[i].PONumber,
						POItemNumber: aSOItemServicesData[i].POItemNumber,
						PackageNumber: aSOItemServicesData[i].PackageNumber,
						IntLineNumber: aSOItemServicesData[i].IntLineNumber,
						LoginID: aSOItemServicesData[i].LoginID,
						IsOutline: aSOItemServicesData[i].IsOutline,
						OutlineLevel: aSOItemServicesData[i].OutlineLevel,
						OutlineNumber: aSOItemServicesData[i].OutlineNumber,
						SubPackageNumber: aSOItemServicesData[i].SubPackageNumber,
						SrvItemNumber: aSOItemServicesData[i].SrvItemNumber,
						Description: aSOItemServicesData[i].Description,
						Quantity: aSOItemServicesData[i].Quantity,
						UOM: aSOItemServicesData[i].UOM,
						GrossPrice: aSOItemServicesData[i].GrossPrice,
						PriceUnit: aSOItemServicesData[i].PriceUnit,
						NetValue: aSOItemServicesData[i].NetValue,
						Currency: aSOItemServicesData[i].Currency,
						SubServices: aSubService
					});
				}
			}

			var aServiceSubService = {
				Services: aTexpService
			};

			var oModel = new sap.ui.model.json.JSONModel(aServiceSubService);
			gSOItemDetailHeaderView.setModel(oModel);
			gSOItemDetailHeaderView.setModel(new sap.ui.model.json.JSONModel(this.mInitialOrderState), "Order");

			if (!this.oTemplate) {
				this.oTemplate = sap.ui.xmlfragment("com.arteriatech.pps.pomat.view.Row");
			}
			this._oTable = gSOItemDetailHeaderView.byId("SOItemServiceTable");

			var sPath = this._getInitialPath();
			this._setAggregation(sPath);

		},
		formatItemStatusIcon: function (val) {
			var img;
			if (val === "B") {
				img = "sap-icon://status-in-process";
				return img;
			} else if (val === "C") {
				img = "sap-icon://home";
				return img;
			} else if (val === "D") {
				img = "sap-icon://status-error";
				return img;
			} else if (val === "A") {
				img = "sap-icon://task";
				return img;
			} else if (val === "F") {
				img = "sap-icon://message-warning";
				return img;
			}
		},
		formatItemStatusColor: function (val) {
			var img;
			if (val === "B") {
				img = "Warning";
				return img;
			} else if (val === "C") {
				img = "Success";
				return img;
			} else if (val === "D") {
				img = "Error";
				return img;
			} else if (val === "A") {
				img = "Error";
				return img;
			} else if (val === "F") {
				img = "Success";
				return img;
			}
		}
	});
});