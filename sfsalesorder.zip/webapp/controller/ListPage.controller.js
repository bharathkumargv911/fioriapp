sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.arteriatech.sf.salesorder.sfsalesorder.controller.ListPage", {

		onInit: function () {
			this.onInitHookUp();
		},
		onInitHookUp: function() {
			gListPageView = this.getView();
		}
	});

});