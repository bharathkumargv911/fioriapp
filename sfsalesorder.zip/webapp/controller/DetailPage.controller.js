sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"sap/m/BusyDialog",
	"sap/m/MessageBox"
], function (Controller, JSONModel, History, oPPCCommon, oSSCommon, oBusyDialog,MessageBox) {
	"use strict";
	var oi18n, oUtilsI18n;
	var Device = sap.ui.Device;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oProductCommon, oCommonValueHelp;
	var product = "PD";
	var contextPath = "";
	var gSOItemDetailHeaderView;

	return Controller.extend("com.arteriatech.sf.salesorder.sfsalesorder.controller.DetailPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.sf.so2.view.ItemDetailPage
		 */
		onInit: function () {
			this.onInitialHookUps();
			//oBusyDialog.open();
		},
		onInitialHookUps: function () {
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			//		oUtilsI18n = this._oComponent.getModel("ssutili18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.router.attachRouteMatched(this.onRouteMatched, this);
			this.setDefaultSettings();
		},
		setDefaultSettings: function () {
			var oViewSettingModel = new sap.ui.model.json.JSONModel();
			this.viewSettingData = {
				ItemView: true,
				EditView: false,
				SaveBtn: false,
				EditBtn: true,
				ReviewBtn: false,
				CancelBtn: false
			};
			oViewSettingModel.setData(this.viewSettingData);
			this.getView().setModel(oViewSettingModel, "LocalViewSettingItem");
		},
		onRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") !== "DetailPage") {
				return;
			}
			//oBusyDialog.open();
			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oHistory.getDirection() !== "Backwards") {
				//if(gLoadItemDetails)
				// {
				//				gLoadItemDetails = false;
				contextPath = oEvent.getParameter("arguments").contextPath;
				var that = this;
				that.getView().setBusy(true);
				setTimeout(function () {
					that.getView().setBusy(false);
					that.getSOItemDetails();
				}, 4000);

				that.getSODocumentFlow();
				// }
			} else {
				//oBusyDialog.close();
			}

		},
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				this.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = this.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},
		getCurrentLoggedUser: function (mParameter, callBack) {
			var bASync = true;
			var sLoginID = "";
			var href = window.location.href;
			if (!(location.href.indexOf("testService.html") > -1)) {
				var mRequestData = {};
				mRequestData.Application = "PD";
				mRequestData.Object = mParameter.sServiceName + "_" + (Math.random().toFixed(2) * 100).toFixed(0);
				mRequestData.Method = mParameter.sRequestType;
				mRequestData.FmName = "";
				mRequestData.IsTestRun = "";
				var sUrl = "/sap/fiori/exideflpplugin1/sap/opu/odata/ARTEC/PUGW_UTILS/GetLoginID/";
				if (location.href.indexOf("webidetesting") > -1) {
					sUrl = "/sap/opu/odata/ARTEC/PUGW_UTILS/GetLoginID/";
				}
				$.ajax({
					url: sUrl,
					jsonpCallback: 'getJSON',
					contentType: "text/plain",
					async: false,
					data: mRequestData,
					success: function (data, textStatus, jqXHR) {
						sLoginID = "";

						if (callBack) {
							callBack(sLoginID);
						}
					},
					error: function (xhr, status, e) {

						setTimeout(function () {
							sap.m.MessageToast.show("Your session has expired, please login again");
						}, 5);
					}
				});
			} else {
				sLoginID = "";
				if (callBack) {
					callBack(sLoginID);
				}
			}
			return sLoginID;
		},
		getSOItemDetails: function () {
			var that = this;
			gSOItemDetailHeaderView = this.getView();
			//		var SOItemDetailsFilters = new Array();
			//		SOItemDetailsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SOItemDetailsFilters, "LoginID", sap.ui.model.FilterOperator.EQ, new Array(["CFA_USR01"]), false, false, false);

			var odataModel = gSOItemDetailHeaderView.getModel("SFGW_SLS");
			odataModel.attachRequestSent(function () {
				// that.getView().setBusy(true);
			});
			odataModel.attachRequestCompleted(function () {
				//  that.getView().setBusy(false);
				//gsfpoBusyDialog.close();
			});
			odataModel.setHeaders({
				"x-arteria-loginid": this.getCurrentUsers("SOItemDetails", "read")
			});
			odataModel.read("/" + contextPath, {
				success: function (oData) {
					oData.SONo = parseFloat(oData.SONo) + "";
					that.setSOItemDetails(oData);
				},
				error: function (error) {
					//				oBusyDialog.close();
					that.handleoDataError(error);
				}
			});
		},
		setSOItemDetails: function (oData) {
			sap.ui.controller("com.arteriatech.sf.salesorder.sfsalesorder.controller.DetailPageHeader").setSOItemDetailHeader(oData, this._oComponent);
		},
		getSODocumentFlow: function () {
			var that = this;
			gSOItemDetailHeaderView = this.getView();
			//		var SOItemDetailsFilters = new Array();
			//		SOItemDetailsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SOItemDetailsFilters, "LoginID", sap.ui.model.FilterOperator.EQ, new Array(["CFA_USR01"]), false, false, false);

			var odataModel = gSOItemDetailHeaderView.getModel("SFGW_SLS");
			/*odataModel.attachRequestSent(
				function(){
					oBusyDialog.open();
				});  
		odataModel.attachRequestCompleted(function(){oBusyDialog.close();}); */
			odataModel.setHeaders({
				"x-arteria-loginid": this.getCurrentUsers("SalesDocflowItems", "read")
			});
			var SODocumentFlowFilters = [];
			SODocumentFlowFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SODocumentFlowFilters, "SalesDocNo", "", [oPPCCommon
				.getPropertyValueFromContextPath(
					contextPath, "SONo")
			], false, false, false);
			SODocumentFlowFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SODocumentFlowFilters, "ItemNo", "", [oPPCCommon.getPropertyValueFromContextPath(
				contextPath, "ItemNo")], false, false, false);
			// SODocumentFlowFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SODocumentFlowFilters, "SalesDocCat", "", ['C'], false, false, false);
			SODocumentFlowFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SODocumentFlowFilters, "LoginID", "", [this.getCurrentUsers(
				"SalesDocflowItems", "read")], false, false, false);

			odataModel.read("/SalesDocflowItems", {
				filters: SODocumentFlowFilters,
				success: function (oData) {
					that.setSODocumentFlow(oData);
				},
				error: function (error) {
					//				oBusyDialog.close();
					that.handleoDataError(error);
				}
			});
		},
		setSODocumentFlow: function (oData) {
			sap.ui.controller("com.arteriatech.sf.salesorder.sfsalesorder.controller.DetailPageHeader").setSODocumentFlow(oData, this._oComponent);
		},
		handleoDataError: function (error) {
			var message = oPPCCommon.parseoDataErrorMessage(error);
			if (message.trim() === "Not Found") {
				sap.ui.controller("com.arteriatech.sf.salesorder.sfsalesorder.controller.DetailPageHeader").clearModel();
				this.router.navTo("NoMatching");
			} else {
				var that = this;
				oPPCCommon.dialogErrorMessage(error, oUtilsI18n.getText("common.Dialog.Error.ServiceError.Header"), function () {
					that.backToList();
				});
			}
		},
		onEdit: function () {
			this.getView().getModel("LocalViewSettingItem").setProperty("/ItemView", false);
			this.getView().getModel("LocalViewSettingItem").setProperty("/EditView", true);
			this.getView().getModel("LocalViewSettingItem").setProperty("/EditBtn", false);
			this.getView().getModel("LocalViewSettingItem").setProperty("/ReviewBtn", true);
			this.getView().getModel("LocalViewSettingItem").setProperty("/CancelBtn", true);
		},
		onReview: function () {
			this.getView().getModel("LocalViewSettingItem").setProperty("/ItemView", true);
			this.getView().getModel("LocalViewSettingItem").setProperty("/EditView", false);
			this.getView().getModel("LocalViewSettingItem").setProperty("/SaveBtn", true);
			this.getView().getModel("LocalViewSettingItem").setProperty("/ReviewBtn", false);
			this.getView().getModel("LocalViewSettingItem").setProperty("/CancelBtn", true);
		},
		onCancel: function () {
			var that = this;
			var dialog = new sap.m.Dialog({
				id: "cancel",
				title: "Warning",
				type: 'Message',
				state: "Warning",
				icon: "sap-icon://alert",
				content: new sap.m.Text({
					text: "Updated Items will get Deleted. Is this ok?"
				}),

				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function () {
						that.onBack();
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		onSave: function () {
			var that = this;
			var dialog = new sap.m.Dialog({
				id: "cancel",
				title: "Warning",
				type: 'Message',
				state: "Warning",
				content: new sap.m.Text({
					text: "Do you want to save the updated items?"
				}),

				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function () {
						that.onSaveBtn();
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		onSaveBtn:function(){
			debugger;
			var that = this;
			var oServiceModel = that.getView().getModel("SOItemDetailHeader").getData();
            var oData = {};
            oData.Quantity = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/Quantity");
            oData.DelvQty = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/DelvQty");
            oData.OpenQty = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/OpenQty");
            oData.UnitPrice = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/UnitPrice");
            oData.SOPriceUnit = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/SOPriceUnit");
            oData.DiscountPer = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/DiscountPer");
            oData.Discount = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/Discount");
            oData.Freight = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/Freight");
            oData.Tax = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/Tax");
            oData.GrossAmount = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/GrossAmount");
            oData.NetAmount = that.getOwnerComponent().getModel("SOItemDetailHeader").getProperty("/NetAmount");
            var oModel = that.getView().getModel("SFGW_SLS");
            oModel.update("/SOItems(ID='"+oServiceModel.SONo+"', '"+oServiceModel.ItemNo+"')",oData,{
            	
                success:function(data,status){
                    if (status.statusCode === "204"){
                        var oSuccessMessageDialog = new sap.m.Dialog({
                            title: "Success",
                            type: "Message",
                            state: "Success",
                            content: new sap.m.Text({
                                text: "Record Updated Successfully"
                            }),
                            beginButton: new sap.m.Button({
                                text: "OK",
                                press: function () {
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/ReviewBtn", false);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/SaveBtn", false);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/EditBtn", true);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/CancelBtn",false);
                                    oSuccessMessageDialog.close();
                                }.bind(that)
                            })
                        });
                        oSuccessMessageDialog.open();
                    }
                    else {
                        // MessageBox.warning("Please check Again")
                    }
                },error:function(data,status){
                    //MessageBox.warning("Please check Again")
                    // MessageBox.error("Record Not Created, Please check Again!!")
                    if (data.statusCode === "400"){
                        var oSuccessMessageDialog = new sap.m.Dialog({
                            title: "Error",
                            type: "Message",
                            state: "Error",
                            content: new sap.m.Text({
                                text: "Please add all properties"
                            }),
                            beginButton: new sap.m.Button({
                                text: "OK",
                                press: function () {
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/ReviewBtn", true);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/EditView", true);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/ItemView", false);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/SaveBtn", false);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/EditBtn", false);
                                    that.getView().getModel("LocalViewSettingItem").setProperty("/CancelBtn",true);
                                    oSuccessMessageDialog.close();
                                }.bind(that)
                            })
                        })
                        oSuccessMessageDialog.open();
                    }
                }
 
            });	
		},
		onBack: function () {
			if (this.getView().getModel("LocalViewSettingItem").getProperty("/ReviewBtn") || this.getView().getModel("LocalViewSettingItem").getProperty(
					"/SaveBtn")) {
				this.getView().getModel("LocalViewSettingItem").setProperty("/ItemView", true);
				this.getView().getModel("LocalViewSettingItem").setProperty("/EditView", false);
				this.getView().getModel("LocalViewSettingItem").setProperty("/SaveBtn", false);
				this.getView().getModel("LocalViewSettingItem").setProperty("/EditBtn", true);
				this.getView().getModel("LocalViewSettingItem").setProperty("/ReviewBtn", false);
				this.getView().getModel("LocalViewSettingItem").setProperty("/CancelBtn", false);
			} else {
				const oRouter = this.getOwnerComponent().getRouter();
				oRouter.navTo("ListPage", {}, true);
			}
		},
		onPrintPress: function () {
			var oDataModel = this.getView().getModel("SFGW_SLS");
			//window.open("/sap/opu/odata/ARTEC/PCGW_UTILS/Print?service="+oDataModel.sServiceUrl+"/"+contextPath+"/$value&application=PD");
			// 			window.open("/sap/opu/odata/ARTEC/PCGW_UTILS/Print?service=" + oDataModel.sServiceUrl + "/SOItemDetails(SONo='" + gSOItemDetailHeaderView.getModel("SOItemDetails").getProperty('/SONo') + "',ItemNo='000000')/$value&application=PD");
			oPPCCommon.PrintPDF({
				sServiceUrl: oDataModel.sServiceUrl + "/SOItemDetails(SONo='" + gSOItemDetailHeaderView.getModel("SOItemDetailHeader").getProperty(
					"/SONo") + "',ItemNo='000000')/$value",
				sApplication: "PD"
			});
			//window.open("/sap/opu/odata/ARTEC/PCGW_UTILS/Print?service="+oDataModel.sServiceUrl+"/"+contextPath+"/$value");
		}
	});
});