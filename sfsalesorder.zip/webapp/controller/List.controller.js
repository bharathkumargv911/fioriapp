sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"com/arteriatech/ss/utils/js/UserMapping",
	"com/arteriatech/ss/utils/js/Common",
	"sap/m/MessageToast",
	"sap/ui/export/Spreadsheet",
	"sap/ui/core/format/DateFormat",
	"sap/ui/core/format/NumberFormat"

], function (Controller, JSONModel, History, oSSCommon, oPPCCommon, oSSCommonValueHelp, oProductUserMapping, SSCommen, MessageToast,
	Spreadsheet, DateFormat, NumberFormat) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oSSCommon;
	var SSCommen;
	var oSSCommonValueHelp;
	var Device = sap.ui.Device;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oProductCommon, oProductUserMapping, oCommonValueHelp;
	var product = "PD";
	var BusyDialog = sap.m.BusyDialog;
	return Controller.extend("com.arteriatech.sf.salesorder.sfsalesorder.controller.List", {
		onInit: function () {
			this.onInitHookUp();
			this.setDefaultSettings();
		},
		onInitHookUp: function () {
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			if (product === "PPS") {
				oProductCommon = com.arteriatech.pps.utils.js.Common;
				oCommonValueHelp = com.arteriatech.pps.utils.js.CommonValueHelp;
				oProductUserMapping = com.arteriatech.pps.utils.js.UserMapping;
			} else if (product === "PD") {
				oProductCommon = com.arteriatech.ss.utils.js.Common;
				oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
				oProductUserMapping = com.arteriatech.ss.utils.js.UserMapping;
			} else if (product === "CL") {
				oProductCommon = com.arteriatech.cl.utils.js.Common;
				oCommonValueHelp = com.arteriatech.cl.utils.js.CommonValueHelp;
				oProductUserMapping = com.arteriatech.cl.utils.js.UserMapping;
			}
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			//Router Initialisation
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//Attach event for routing on view patter matched 
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.setValuehelpPropety();
			this.setMaterialsModel();
			if (this.onInitHookUp_Exit) {
				this.onInitHookUp_Exit();
			}
		},
		onRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") !== "ListPage" && oEvent.getParameter("name") !== "SearchListPage") {
				return;
			}
			gListPageView.setBusy(true);
			var selectedCustomer = "";
			var oDataModel = this.getView().getModel("PUGW");
			oProductCommon.setODataModel(oDataModel);
			var that = this;
			this.sInpuType = "DD";
			this.getView().byId("FilterBar").setBusy(true);
			this.getDateDDValues();

			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oHistory.getDirection() !== "Backwards") {
				this.onReset();
				if (oEvent.getParameter("name") === "SearchListPage") {
					this.contextPath = oEvent.getParameter("arguments").contextPath;
					this.getCustomerInputType(function (customerInputType) {
						that.sCustomerInpuType = customerInputType;
						//that.getParametersFromContext(that.contextPath);
					});
				} else {
					if (sap.ui.Device.system.phone) {
						this.onSearch();
					} else {
						this.getCustomerInputType(function (customerInputType) {
							that.sCustomerInpuType = customerInputType;
							that.getCustomers("", function () {
								that.getView().byId("FilterBar").setBusy(false);
								gListPageView.setBusy(false);
							});
						});
					}
				}
			} else if (oEvent.getParameter("name") === "ListPage") {
				this.onReset();
				selectedCustomer = "";
				this.setDefaultSettings();
				this.getCustomerInputType(function (customerInputType) {
					that.sCustomerInpuType = customerInputType;
					that.getCustomers(selectedCustomer, function () {
						that.getView().byId("FilterBar").setBusy(false);
						gListPageView.setBusy(false);
					});
				});
			} else {
				this.contextPath = oEvent.getParameter("arguments").contextPath;
				var customer = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "CustomerNo");

				this.getCustomerInputType(function (customerInputType) {
					that.sCustomerInpuType = customerInputType;
					//that.getParametersFromContext(that.contextPath);
					that.getCustomers("", function () {
						gListPageView.setBusy(false);
					});
				});
			}

		},
		getCustomerInputType: function (appCallBack) {
			var oDataModel = this._oComponent.getModel("PUGW");
			oDataModel.setHeaders({
				"x-arteria-loginid": this.getCurrentUsers("UserProfiles", "read")
			});
			oDataModel.read("/UserProfiles(Application='PD')", {
				success: function (oData) {
					var sRoleCatID = "";
					if (oData.results) {
						oData = oPPCCommon.formatItemsOData({
							oData: oData
						});
						sRoleCatID = oData[0].RoleCatID;
					} else if (oData) {
						sRoleCatID = oData.RoleCatID;
					}
					var inputType = "DD";
					appCallBack(inputType, oData);
				},
				error: function (error) {
				}
			});
		},

		onReset: function () {
			var aValueHelpIDs = []; 
			this.clearTokens(aValueHelpIDs);
			if (this.getView().getModel("ListItems") !== undefined) {
				this.getView().getModel("ListItems").setProperty("/", {});
				this.resetUITable();
			}

			if (this.onReset_Exit) {
				this.onReset_Exit();
			}
		},
		resetUITable: function () {
			oPPCCommon.clearUITable(this.getView(), "UISOTable", "ListItems");

			if (this.resetUITable_Exit) {
				this.resetUITable_Exit();
			}
		},

		clearTokens: function (mParameters) {
			for (var i = 0; i < mParameters.length; i++) {
				this.getView().byId(mParameters[i]).removeAllTokens();
			}
		},

		setDefaultSettings: function () {
			var oViewSettingModel = new sap.ui.model.json.JSONModel();
			this.viewSettingData = {
				CustomerDD: false,
				CustomerVH: false,
				CustomerMC: false,
				tableRowCount: 0
			};
			oViewSettingModel.setData(this.viewSettingData);
			this.getView().setModel(oViewSettingModel, "LocalViewSetting");

			this.setSOTableTitle(0);
			this.setCustomerInputVisibility();
		},

		/*------------------------------------------Extracting Value from Contextpath------------------------*/
		getParametersFromContext: function (contextPath) {
			debugger;
			var that = this;
			this.iTotalValueHelps = 4;
			var customer = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "CustomerNo");
			var dSODate = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "OrderDate");
			var sONo = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SONo");
			var orderType = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "OrderType");
			var material = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "Material");
			var status = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "StatusID");
			var delvStatus = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "DelvStatusID");

			if (this.sCustomerInpuType === "VH") {
				// this.iTotalValueHelps++;
				if (customer !== "") {
					var sCustomerFilters = new Array();
					sCustomerFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputCustomerNo", sCustomerFilters, "CustomerNo", sap.ui.model
						.FilterOperator.EQ, customer.split(";"), true, false, false);
					var oModelData = this._oComponent.getModel("SFGW_MST");
					oSSCommon.createTokens(oModelData, "Customers", sCustomerFilters, "CustomerNo", "Name", this.getView().byId(
						"inputCustomerNo"), function () {
						that.callService();
					});
				} else {
					that.getCustomers(customer);
					that.callService();
				}
			} else {
				that.getCustomers(customer);
				that.callService();
			}

			if (sONo !== "") {
				var sSONoFilters = [];
				sSONoFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputSONo", sSONoFilters, "SONo", sap.ui.model.FilterOperator
					.EQ, sONo.split(";"), true, false, false);
				var oModelData = this._oComponent.getModel("SFGW_SLS");
				oSSCommon.createTokens(oModelData, "SOs", sSONoFilters, "SONo", "SONo", this.getView().byId("inputSONo"), function () {
					that.callService();
				});
			} else {
				that.callService();
			}
			that.getView().byId("inputSODate").setSelectedKey(dSODate);
			if (dSODate !== "") {

				var SODateFrom = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SOFromDate");
				var SODateTo = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SOToDate");
				this.SODate = {
					FromDate: new Date(SODateFrom),
					ToDate: new Date(SODateTo)
				};
				that.callService();
				if (dSODate === "SD") {
					oSSCommon.setMaunalSelectedDate(this, SODateFrom, SODateTo, "SODateViewSetting", "inputSODate", dSODate, oi18n);
				}
			} else {
				this.SODate = {
					FromDate: null,
					ToDate: null
				};

				that.callService();
			}
			if (material !== "") {
				var sMaterialFilters = [];
				sMaterialFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputMaterial", sMaterialFilters, "MaterialNo", sap.ui.model
					.FilterOperator
					.EQ, material.split(";"), true, false, false);
				var oModelData = this._oComponent.getModel("SFGW_MST");
				oSSCommon.createTokens(oModelData, "Materials", sMaterialFilters, "MaterialNo", "MaterialDesc", this.getView().byId(
						"inputMaterial"),
					function () {
						that.callService();
					});
			} else {
				that.callService();
			}
		},
		/*-----------------------------------------Search event on Go from Filterbar-------------------------*/
		onSearch: function (oEvent) {
			var oView = this.getView();
			this.validateSOItemsMandatory();
			if (oPPCCommon.doErrMessageExist()) {
				this.getView().setBusy(true);
				if (this.getView().byId("inputMaterial").getValueState() === "None" && this.getView().byId("inputSONo").getValueState() === "None") {
					this.getView().byId("inputSONo").getValue();
					var contextPath = this.prepareContext();
					// this.getView().setBusy(true);
					if (this.contextPath !== undefined && this.contextPath === contextPath) {
						var that = this;
						this.getSalesOrders();
					} else {
						this._oRouter.navTo("SearchListPage", {
							contextPath: contextPath
						}, false);
						this.getSalesOrders();
					}
				} else {
					if (oView.getModel("SOItems") !== undefined) {
						oView.getModel("SOItems").setProperty("/", {});
						this.setSOTableTitle(0);
					}

				}
			} else {
				var message = oPPCCommon.getMsgsFromMsgMgr();
				oPPCCommon.displayMsg_MsgBox(this.getView(), message, "error");
			}
		},
		prepareContext: function () {
			var customerNo = this.getSelectedCustomerCode();
			var orderDate = this.getView().byId("inputSODate").getSelectedKey();

			var aSONo = oPPCCommon.getKeysFromTokens(this.getView(), "inputSONo");

			var sOrderType = oPPCCommon.getKeysFromMultiCombo(this.getView(), "inputOrderType");
			var aMaterial = oPPCCommon.getKeysFromTokens(this.getView(), "inputMaterial");
			var sStatus = oPPCCommon.getKeysFromMultiCombo(this.getView(), "inputStatus");
			var sDelvStatus = oPPCCommon.getKeysFromMultiCombo(this.getView(), "inputDelvStatus");
			var contextPath = "(CustomerNo=" + customerNo + ",SONo=" + aSONo + ",OrderType=" + sOrderType + ",Material=" + aMaterial +
				",StatusID=" +
				sStatus + ",DelvStatusID=" + sDelvStatus + ",OrderDate=" + orderDate + ",SOFromDate=" + this.SODate.FromDate + ",SOToDate=" +
				this.SODate.ToDate + ")";
			if (this.prepareContext_Exit) {
				contextPath = this.prepareContext_Exit(contextPath);
			}
			return contextPath;
		},
		getSalesOrders: function () {
			var oView = this.getView();
			var messageArea = this.getView().byId("MessageAreaId");
			var that = this;
			var SOItemsListModel = this._oComponent.getModel("SFGW_SLS");
			SOItemsListModel.setHeaders({
				"x-arteria-loginid": this.getCurrentUsers("SOItems", "read")
			});
			SOItemsListModel.read("/SOItems", {
				filters: that.prepareSOItemsODataFilter(),
				success: function (oData) {
					if (oData.results.length > 0) {
						that.setTableRowCount(oData.results.length);
						that.setSOitemsData(oData);
						var aDefaultSorter = [];
						var SONo = new sap.ui.model.Sorter("SONo", true);
						aDefaultSorter.push(SONo);
						var ItemNo = new sap.ui.model.Sorter("ItemNo", false);
						aDefaultSorter.push(ItemNo);
						oView.setBusy(false);

					} else {
						that.setNodataFound();
					}
				},
				error: function (error) {
					that.setNodataFound();
					oPPCCommon.dialogErrorMessage(error, oUtilsI18n.getText("common.Dialog.Error.ServiceError.Header"));
				}
			});
		},

		setNodataFound: function () {
			var oView = this.getView();
			/** Clear Model of the view */
			if (oView.getModel("SOItems") !== undefined) {
				oView.getModel("SOItems").setProperty("/", {});
			}

			oView.byId("SOTable").setNoDataText(oUtilsI18n.getText("common.NoResultsFound"));
			oView.byId("UISOTable").setNoData(oUtilsI18n.getText("common.NoResultsFound"));
			oView.setBusy(false);

			this.setSOTableTitle(0);
		},

		checkValueState: function () {
			return true; //Delete this line
		},

		validateMandatory: function () {
			//ToAdd Validations for Mandatory and add error to Messagemanager
			if (this.validateMandatory_Exit) {
				this.validateMandatory_Exit();
			}
		},
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				this.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = this.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},
		getCustomerscust: function (oCustomerModel, RoleID, UserType, busyDialog, view, requestCompleted, appType, bSF) {
			if (view.getModel("SSGW_MST")) {
				oCustomerModel = view.getModel("SSGW_MST");
			}
			var serviceName = "Customers";
			if (view.getModel("SSGW_MST")) {
				serviceName = "UserChannelPartners";
			}
			if (bSF) {
				var oMetadata = oPPCCommon.xmlToJson(oPPCCommon.stringToXML(view.getModel("SFGW_MST").oMetadata.sMetadataBody));
				var oEntityType = oPPCCommon.getEntityType(oMetadata, "UserCustomer", null)
				if (oEntityType !== undefined && oEntityType !== null && oEntityType !== "") {
					serviceName = "UserCustomers";
					oCustomerModel = view.getModel("SFGW_MST");
				}
			}
			var aCustomers = new Array();
			var aCustomerFilters = new Array();
			this.getCurrentLoggedUser({
				sServiceName: serviceName,
				sRequestType: "read"
			}, function (LoginID) {
				aCustomerFilters = oPPCCommon.setODataModelReadFilter("", "", aCustomerFilters, "LoginID", "", [LoginID], false, false, false);
				oCustomerModel.read("/" + serviceName, {
					filters: aCustomerFilters,
					success: function (oData) {
						if (oData.results.length > 0) {
							if (UserType === "2") {
								if (oData.results.length != 1)

								{
									if (appType === "create") {
										aCustomers.push({
											CustomerNo: "",
											Name: "(None)"
										});
									} else {
										aCustomers.push({
											CustomerNo: "",
											Name: "(All)"
										});
									}

								}
								for (var i = 0; i < oData.results.length; i++) {
									if (bSF) {
										aCustomers.push({
											CustomerNo: oData.results[i].CustomerNo,
											Name: oData.results[i].Name,
											Seperator: " - ",
											CPGUID: oData.results[i].CustomerNo,
											CPUID: oData.results[i].CustomerNo,
											CPTypeID: "",
											CPTypeDesc: ""

										});
									} else if (view.getModel("SSGW_MST")) {
										aCustomers.push({
											CustomerNo: oData.results[i].CPNo,
											Name: oData.results[i].Name,
											Seperator: " - ",
											CPGUID: oData.results[i].CPGUID,
											CPUID: oData.results[i].CPUID,
											CPTypeID: oData.results[i].CPTypeID,
											CPTypeDesc: oData.results[i].CPTypeDesc
										});
									} else {
										aCustomers.push({
											CustomerNo: oData.results[i].CustomerNo,
											Name: oData.results[i].Name,
											Seperator: " - ",
											CPGUID: oData.results[i].CustomerNo,
											CPUID: oData.results[i].CustomerNo,
											CPTypeID: "",
											CPTypeDesc: ""
										});
									}
								}
								//requestCompleted(aCustomers);
								var oCustomersModel = new sap.ui.model.json.JSONModel();
								oCustomersModel.setData(aCustomers);
								if (aCustomers.length > 0) {
									view.setModel(oCustomersModel, "Customers");
									if (view.byId("customer")) {
										view.byId("customer").setSelectedKey(aCustomers[0].CustomerNo);
										view.byId("customer").setTooltip(aCustomers[0].Name);
									}
								}
							} else {
								aCustomers = oData.results;
							}
							requestCompleted(aCustomers, oData.results);
						}
					},
					error: function (error) {
						// 				busyDialog.close();
					}
				});
			});
		},
		getCurrentLoggedUser: function (mParameter, callBack) {
			var bASync = true;
			var sLoginID = "";
			var href = window.location.href;
			if (!(location.href.indexOf("testService.html") > -1)) {
				var mRequestData = {};
				mRequestData.Application = "PD";
				mRequestData.Object = mParameter.sServiceName + "_" + (Math.random().toFixed(2) * 100).toFixed(0);
				mRequestData.Method = mParameter.sRequestType;
				mRequestData.FmName = "";
				mRequestData.IsTestRun = "";
				var sUrl = "/sap/fiori/exideflpplugin1/sap/opu/odata/ARTEC/PUGW_UTILS/GetLoginID/";
				if (location.href.indexOf("webidetesting") > -1) {
					sUrl = "/sap/opu/odata/ARTEC/PUGW_UTILS/GetLoginID/";
				}
				$.ajax({
					url: sUrl,
					jsonpCallback: 'getJSON',
					contentType: "text/plain",
					async: false,
					data: mRequestData,
					success: function (data, textStatus, jqXHR) {
						sLoginID = "";

						if (callBack) {
							callBack(sLoginID);
						}
					},
					error: function (xhr, status, e) {

						setTimeout(function () {
							sap.m.MessageToast.show("Your session has expired, please login again");
						}, 5);
					}
				});
			} else {
				sLoginID = "";
				if (callBack) {
					callBack(sLoginID);
				}
			}
			return sLoginID;
		},

		/*-------------------------------------Customer/Customer Related Functions---------------------------*/
		getCustomers: function (customer, requestCompleted) {

			var that = this;
			that.setCustomerInputVisibility();
			if (this.sCustomerInputType !== "VH") {
				var oCustomerModel = this._oComponent.getModel("SFGW_MST");
				this.getCustomerscust(oCustomerModel, "000002", "2", BusyDialog, this.getView(), function (aCustomerData) {

					if (that.sCustomerInpuType === "DD") {
						that.getView().byId("customer").setSelectedKey(customer);
					} else if (that.sCustomerInpuType === "MC") {
						if (aCustomerData.length > 1) {
							aCustomerData.splice(0, 1);
							that.getView().getModel("Customers").setProperty("/", aCustomerData);
						}
						that.getView().byId("customerMultiCombo").setSelectedKeys(customer.split(";"));
					}
					that.getCustomerName();
					// that.setCustomerColumnVisibility();
					that.setDropdowns(customer);
					if (requestCompleted) {
						requestCompleted(aCustomerData);
					}
				}, "", true);
			} else {
				that.setDropdowns(customer);
				if (requestCompleted) {
					requestCompleted();
				}
				this.getDropDowns();
				//<To Add DD logic from Vendor/Customer>
				if (requestCompleted) {
					requestCompleted();
				}
			}
		},

		setDropdowns: function () {
			this.setOrderTypeDD();
			this.setStatusDD();
			this.setDelvStatusDD();

		},
		setCustomerInputVisibility: function () {
			if (this.sCustomerInpuType === "DD") {
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerDD", true);
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerVH", false);
			} else if (this.sCustomerInpuType === "VH") {
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerVH", true);
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerDD", false);
			}
			if (this.setCustomerInputVisibility_Exit) {
				this.setCustomerInputVisibility_Exit();
			}
		},
		callService: function () {
			this.iTotalValueHelps--;
			if (this.iTotalValueHelps === 0) {
				this.getView().byId("FilterBar").setBusy(false);
				gListPageView.setBusy(false);
				this.getSalesOrders();
			}
		},
		getCustomerName: function () {
			if (this.getView().byId("customer").getSelectedItem() != null) {
				if (this.getView().byId("customer").getSelectedItem().getText().split("-").length > 1) {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInF4", false);
					return this.getView().byId("customer").getSelectedItem().getText().split("-")[1].trim();
				} else {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInF4", true);
					return this.getView().byId("customer").getSelectedItem().getText().split("-")[0].trim();
				}
			}
		},
		setCustomerColumnVisiblility: function () {
			if (this.getView().byId("customer").getSelectedItem() != null) {
				if (this.getView().byId("customer").getSelectedItem().getText().split("-").length > 1) {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInResult", false);
				} else {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInResult", true);
				}
			}
		},

		getSelectedCustomerCode: function () {
			var customerCode;
			if (this.sCustomerInpuType === "DD") {
				customerCode = this.getView().byId("customer").getSelectedKey();
			} else if (this.sCustomerInpuType === "MC") {
				var aCustomer = this.getView().byId("partnerMultiCombo").getSelectedKeys();
				if (aCustomer.length > 0) {
					customerCode = aCustomer[0];
					for (var i = 1; i < aCustomer.length; i++) {
						if (aCustomer[i] !== "") {
							customerCode += ";" + aCustomer[i];
						}
					}
				}
			} else if (this.sCustomerInpuType === "VH") {
				customerCode = oPPCCommon.getKeysFromTokens(this.getView(), "inputCustomerF4");
			}

			return customerCode;
		},
		getAllSelectedCustomerName: function () {
			var customerName = "";
			if (this.sCustomerInpuType === "DD") {
				customerName = this.getCustomerName();
			} else if (this.sCustomerInpuType === "MC") {
				var aCustomer = this.getView().byId("partnerMultiCombo").getSelectedItems();
				if (aCustomer.length > 0) {
					customerName = aCustomer[0].getText().split(" - ")[1] + " (" + aCustomer[0].getText().split(" - ")[0] + ")";
					for (var i = 1; i < aCustomer.length; i++) {
						customerName += "; " + aCustomer[i].getText().split(" - ")[1] + " (" + aCustomer[i].getText().split(" - ")[0] + ")";
					}
				}
			} else if (this.sCustomerInpuType === "VH") {
				customerName = oPPCCommon.getTextFromTokens(this.getView(), "inputCustomerF4");
			}

			if (customerName === "") {
				customerName = "(All)";
			}
			return customerName;
		},

		/*------------------------------------Get Drop downs--------------------------------*/
		getDropDowns: function () {
			if (this.getDropDowns_Exit) {
				this.getDropDowns_Exit();
			}
		},
		/*------------------------------------------Value Help----------------------------------------*/
		/*--------Add Validator--------------*/
		setValuehelpPropety: function () {
			var that = this;
			this._oComponent.AppContext = new Object();
			// Initialize the valueHelp key-value set 

			this.SOTokenInput = this.getView().byId("inputSONo");
			this.aSOKeys = ["SONo", "SONo"];
			//Customer F4
			this.oCustomerTokenInput = this.getView().byId("inputCustomerF4");
			this.aCustomerKeys = ["CustomerNo", "Name"];
			var sCustomerPreviousEnteredValue;
			this.oCustomerTokenInput.addValidator(function (args) {
				if (sCustomerPreviousEnteredValue !== args.text) {
					var oDataModel = that._oComponent.getModel("PSGW_MST");
					args.text = args.text.toUpperCase();
					var F4Filters = new Array();
					var fCustomerNo = new sap.ui.model.Filter("CustomerNo", sap.ui.model.FilterOperator.EQ, args.text);
					F4Filters.push(fCustomerNo);
					oProductCommon.getTokenForInput(args, oDataModel, "Customers", F4Filters, "CustomerNo", "Name", that.oCustomerTokenInput,
						"Customer",
						function (oToken, IsSuccess) {
							if (IsSuccess) {
								sCustomerPreviousEnteredValue = "";
							}

						});
				}
				this.MaterialTokenInput = this.getView().byId("inputMaterial");
				this.aMaterialKeys = ["MaterialNo", "MaterialDesc"];
			});
			if (this.setValuehelpPropety_Exit) {
				this.setValuehelpPropety_Exit();
			}
		},
		CustomerF4: function () {
			oSSCommonValueHelp.inputCustomerF4({
				oController: this,
				oi18n: oi18n,
				oUtilsI18n: oUtilsI18n,
				controlID: "inputCustomerF4",
				title: oi18n.getText("List.ValueHelp.CustomerF4.header"),
				customerIDLabel: oi18n.getText("List.ValueHelp.CustomerF4.customerF4"),
				customerNameLabel: oi18n.getText("List.ValueHelp.CustomerF4.name")
			});

		},

		//Order Date Defined
		getDateDDValues: function () {
			var sDateRange = SSCommen.getProductFeatureValue({
				Types: "DTRNGCHK"
			});
			if (sDateRange === "") {
				sDateRange = "-30";
			}
			this.SODateDifference = sDateRange;
			this.PreviousSelectedKeySODate = this.SODateDifference;
			var oneMonthBackDate = oPPCCommon.getCurrentDate();
			oneMonthBackDate.setDate(oneMonthBackDate.getDate() + parseInt(this.SODateDifference));
			this.SODate = {
				FromDate: oneMonthBackDate,
				ToDate: oPPCCommon.getCurrentDate()
			};
			/*for SO Date*/
			if (this.getView().getModel("SODateViewSetting")) {
				this.getView().getModel("SODateViewSetting").setProperty("/", {});
			}
			var oDataDate = [{
				DateKey: "",
				DateDesc: "Any"
			}, {
				DateKey: "0",
				DateDesc: "Today"
			}, {
				DateKey: "-1",
				DateDesc: "Today and Yesterday"
			}, {
				DateKey: "-7",
				DateDesc: "Last Seven Days"
			}, {
				DateKey: "-30",
				DateDesc: "Last One Month"
			}, {
				DateKey: "MS",
				DateDesc: "Manual Selection"
			}];
			oPPCCommon.getDateDropDownValue(oDataDate, this, "inputSODate", "SODateViewSetting", this.SODateDifference);
		},
		onSODateSelectionChanged: function (oEvent) {
			var that = this;
			var oDateSelect = oEvent.getSource();
			var sSelectedKey = oEvent.getParameter("selectedItem").getKey();
			oSSCommon.openManualDateSelectionDialog(this, sSelectedKey, oDateSelect, this.PreviousSelectedKeySODate, "SODateViewSetting",
				oi18n,
				"inputSODate",
				function (date) {
					that.SODate.FromDate = date.fromDate;
					that.SODate.ToDate = date.toDate;
				});
			this.PreviousSelectedKeySODate = oEvent.getParameter("selectedItem").getKey();
			if (oEvent.getParameter("selectedItem").getKey() !== "MS") {
				this.PreviousSelectedKeySODate = oEvent.getParameter("selectedItem").getKey();
			}
		},

		//Order Type defined
		setOrderTypeDD: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oOrderTypeFilter = new Array();
			oOrderTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oOrderTypeFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"SOTYP"
			], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oOrderTypeFilter, "Types", "TypesName", BusyDialog, this.getView(),
				"OrderTypeDD",
				"",
				function (oData) {
					if (that.contextPath) {
						var sOrderType = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "OrderType");
						if (sOrderType) {
							that.getView().byId("inputOrderType").setSelectedKeys(sOrderType.split(";"));
						}
					}
				});
		},
		//Order Number Defined
		SONoF4: function () {
			var that = this;
			var oView = this.getView();
			var validState = true;
			var messageArea = this.getView().byId("MessageAreaId");
			messageArea.setText("");
			if (validState) {
				oSSCommonValueHelp.SONoF4({
						oController: this,
						oi18n: oi18n,
						//controlID: this.SOTokenInput,
						oUtilsI18n: oUtilsI18n,
						sCustomerCode: that.getSelectedCustomerCode(),
						sCustomerName: that.getAllSelectedCustomerName()
					},
					function () {

						that.getView().byId("inputSONo").setValue("");
						that.getView().byId("inputSODate").setSelectedKey("");
						that.SODate.FromDate = null;
						that.SODate.ToDate = null;

					});

			} else {
				//errorPopUp(messageArea);
			}
		},

		//Set Status 
		setStatusDD: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator
				.EQ, ["SOITST"], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", BusyDialog, this.getView(),
				"StatusDD", "",
				function () {
					if (that.contextPath) {
						var sStatusID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "StatusID");
						if (sStatusID)
							that.getView().byId("inputStatus").setSelectedKeys(sStatusID.split(";"));
					}
					// that.callService();
				});
		},

		//Set Delivery Status

		setDelvStatusDD: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator
				.EQ, ["DELVST"], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", BusyDialog, this.getView(),
				"DelvStatusDD", "");
		},

		//Set Material Number

		MaterialF4: function () {
			var customer = this.getView().byId("customer").getSelectedKey();
			var validState = true;
			var messageArea = this.getView().byId("MessageAreaId");
			messageArea.setText("");
			this.MaterialTokenInput = this.getView().byId("inputMaterial");
			this.aMaterialKeys = ["MaterialNo", "MaterialDesc"];
			//if(!this.handleValidation("customer","MessageAreaId","Customer","DD")){validState = false};
			if (validState) {
				oSSCommonValueHelp.MaterialF4({
					oController: this,
					oi18n: oi18n,
					oUtilsI18n: oUtilsI18n,
					sCpParentNo: this.getSelectedCustomerCode(),
					sCpParentName: this.getAllSelectedCustomerName()

				});
			} else {
				//errorPopUp(messageArea);
			}
		},
		setMaterialsModel: function () {
			var that = this;
			var SFGW_MSTModel = this._oComponent.getModel("SFGW_MST");
			SFGW_MSTModel.attachRequestSent(function () {
				//	BusyDialog.open();
			});
			SFGW_MSTModel.attachRequestCompleted(function () {
				//	BusyDialog.close();
			});
			var aMaterialF4Filter = new Array();
			aMaterialF4Filter = oPPCCommon.setODataModelReadFilter("", "", aMaterialF4Filter, "LoginID", "", [
				that.getCurrentUsers("Materials", "read")
			], false, false, false);

			SFGW_MSTModel.read("/Materials", {
				filters: aMaterialF4Filter,
				urlParameters: {
					"$select": "MaterialNo,MaterialDesc,BaseUom"
				},
				success: function (oData) {
					var MaterialsModel = new sap.ui.model.json.JSONModel();
					MaterialsModel.setData(oData.results);
					that._oComponent.setModel(MaterialsModel, "MaterialSuggestorModel");
				},
				error: function (error) {
					//alert(error);
				}
			});
		},
		prepareSOItemsODataFilter: function () {
			var SOItemsFilters = new Array();

			if (this.sCustomerInpuType === "DD") {
				SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SOItemsFilters, "CustomerNo", sap.ui.model.FilterOperator.EQ, [
					this.getView().byId("customer").getSelectedKey()
				], false, false, false);
			} else if (this.sCustomerInpuType === "VH") {
				SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputCustomerNo", SOItemsFilters, "CustomerNo", "", "", true,
					true, false);
			}
			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputSONo", SOItemsFilters, "SONo", "", "", true, true, false);

			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SOItemsFilters, "OrderDate", sap.ui.model.FilterOperator.BT, [
				this.SODate.FromDate, this.SODate.ToDate
			], false, false, false);
			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputOrderType", SOItemsFilters, "OrderType", sap.ui.model.FilterOperator
				.EQ, this.getView().byId("inputOrderType").getSelectedKeys(), true, false, false);
			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputStatus", SOItemsFilters, "StatusID", sap.ui.model.FilterOperator
				.EQ, this.getView().byId("inputStatus").getSelectedKeys(), true, false, false);
			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputDelvStatus", SOItemsFilters, "DelvStatusID", sap.ui.model
				.FilterOperator
				.EQ, this.getView().byId("inputDelvStatus").getSelectedKeys(), true, false, false);
			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputMaterial", SOItemsFilters, "Material", "", "", true, true,
				false);
			SOItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", SOItemsFilters, "LoginID", sap.ui.model.FilterOperator.EQ, [
				this.getCurrentUsers("SOItems", "read")
			], false, false, false);

			if (this.prepareSOItemsODataFilter_Exit) {
				SOItemsFilters = this.prepareSOItemsODataFilter_Exit(SOItemsFilters);
			}
			return SOItemsFilters;
		},

		setSOitemsData: function (oData) {

			var that = this;
			var oView = this.getView();
			var dData = oData;
			var iTotal = 0;
			var iUnit = 0;
			var oQty = 0;
			for (var i = 0; i < oData.results.length; i++) {
				oData.results[i].Quantity = parseFloat(oData.results[i].Quantity);
				oData.results[i].DeliveredQty = parseFloat(oData.results[i].DeliveredQty);
				oData.results[i].OpenQty = parseFloat(oData.results[i].OpenQty);
				oData.results[i].UnitPrice = parseFloat(oData.results[i].UnitPrice);
				oData.results[i].NetAmount = parseFloat(oData.results[i].NetAmount);
				iTotal += oData.results[i].NetAmount;
				iUnit += oData.results[i].UnitPrice;
				oQty += oData.results[i].Quantity;
			}
			var obj = {
				Quantity: oQty.toLocaleString("en-IN"),
				UnitPrice: iUnit.toLocaleString("en-IN"),
				NetAmount: iTotal.toLocaleString("en-IN")
			}
			var ooModel = new sap.ui.model.json.JSONModel();
			ooModel.setData(obj);
			this._oComponent.setModel(ooModel, "TotalModel");
			var oSOItemsModel = new sap.ui.model.json.JSONModel();
			oSOItemsModel.setData(oData.results);
			oSOItemsModel.setSizeLimit(oData.results.length);
			/** Set Model to the view */
			this._oComponent.setModel(oSOItemsModel, "SOItems");

			if (this.getListType() === "SOList") {
				if (oData.results.length > 0) {
					that.setSOTableTitle(oData.results.length);
				}
			} else {
				if (oData.results.length <= 0) {
					oView.byId("SOTable").setNoDataText(oUtilsI18n.getText("common.NoResultsFound"));
					oView.byId("UISOTable").setNoData(oUtilsI18n.getText("common.NoResultsFound"));

				}
				that.setSOTableTitle(oData.results.length);
			}

		},
		setSOTableTitle: function (dataCount) {

			if (dataCount > 0) {
				this.getView().byId("SOTableTitle").setText(oi18n.getText("List.Table.SO.header") + dataCount);
				this.getView().byId("UISOTableTitle").setText(oi18n.getText("List.Table.SO.tableHeader") + dataCount);

			} else {
				this.getView().byId("SOTableTitle").setText(oi18n.getText("List.Table.SO.tableHeader"));
				this.getView().byId("UISOTableTitle").setText(oi18n.getText("List.Table.SO.tableHeader"));

			}
		},
		getListType: function () {
			if (this.ListType !== null && this.ListType !== undefined && this.ListType.trim() === "SOList") {
				return "SOList";
			} else {
				return "";
			}
		},
		setTableRowCount: function (fItemsCount) {
			if (fItemsCount < 10) {
				this.getView().getModel("LocalViewSetting").setProperty("/tableRowCount", fItemsCount);
			} else {
				this.getView().getModel("LocalViewSetting").setProperty("/tableRowCount", 10);
			}
		},

		/*-------------------------------Validation Functions-----------------------------------------------------*/
		validateSOItemsMandatory: function (messageArea) {
			if (this.getView().byId("inputSODate").getSelectedKey() === "" && this.getView().byId("inputSONo").getTokens().length === 0) {
				this.byId("inputSONo").setValueState(sap.ui.core.ValueState.Error);
				var msg = oi18n.getText("List.FilterBar.Validation.dateSONumber", [this.getView().byId("SONo").getLabel(), this.getView().byId(
					"fiOrderDate").getLabel()]);
				this.byId("inputSONo").setValueStateText(msg);
				var msgObj = oPPCCommon.addMsg_MsgMgr(msg, "error", "FG_SONumberAndSODate");
			} else {
				if (this.byId("inputSONo").getValue() === "") {
					this.byId("inputSONo").setValueState(sap.ui.core.ValueState.None);
				}
			}
		},

		/*------------------------------------------Table Filter, Sorter & Export to EXCEL-------------------------------------*/
		handleViewSettingsDialogButtonPressed: function (oEvent) {
			if (!this.ListDialog) {
				this.ListDialog = sap.ui.xmlfragment("com.arteriatech.sf.so2.util.Dialog", this);
			}
			var oModel = this.getView().getModel("<ToAdd Model Name> Eg: PSGW_PUR");
			this.ListDialog.setModel(oModel, "<ToAdd Model Name> Eg: PSGW_PUR");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.ListDialog);
			this.ListDialog.open();
		},
		sortAndFilterTable: function (oEvent) {
			var oView = this.getView();
			var that = this;
			var table = this.getView().byId("SOTable");
			//ToAdd custom filters if any in XML
			var oCustomFilter;
			//Eg: oCustomFilter = new sap.ui.model.Filter("PurDocType", sap.ui.model.FilterOperator.EQ, "PO");
			oPPCCommon.sortAndFilterTable(table, oEvent, function (count, aDefaultSorter) {
				oView.getModel("LocalViewSetting").setProperty("/ListItemsCount", count);
				if (count <= 0) {
					oView.byId("SOTable").setNoDataText(oUtilsI18n.getText("common.NoResultsFound"));
				} else {
					oPPCCommon.setGroupInTable(oView, "SOTable", "", true, "", "", aDefaultSorter);
					if (that.sCustomerInpuType === "DD") {
						if (that.getView().byId("partner").getSelectedKey() === "") {
							oPPCCommon.setGroupInTable(oView, "SOTable", "CustomerNo", true, "Customer", "CustomerName", aDefaultSorter);
						}
					} else if (that.sCustomerInpuType === "MC") {
						if (that.getView().byId("partnerMultiCombo").getSelectedKeys().length !== 1) {
							oPPCCommon.setGroupInTable(oView, "SOTable", "CustomerNo", true, "Customer", "CustomerName", aDefaultSorter);
						}
					} else if (that.sCustomerInpuType === "VH") {
						if (that.getView().byId("inputCustomerF4").getTokens().length !== 1) {
							oPPCCommon.setGroupInTable(oView, "SOTable", "CustomerNo", true, "Customer", "CustomerName", aDefaultSorter);
						}
					}
				}
			}, oCustomFilter);
		},
		exportToExcel: function () {
			if (Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SOTable"),
					uiTable: this.getView().byId("UISOTable")
				});
			}
			var table = this.getView().byId("SOTable");
			var oModel = this.getView().getModel("SOItems");
			oPPCCommon.exportToExcel(table, oModel);
		},
		getSODetails: function (oEvent) {
			var path = "";
			var oModelContext = oEvent.getSource().getBindingContext("SOItems");
			/**
			 * Check for the Multi-Origin of the service
			 * If true pass Multi-Origin Property in the routing
			 */
			if (oPPCCommon.isMultiOrigin(oModelContext)) {
				var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
				path = "SOs(SONo='" + oModelContext.getProperty("SONo") + "'," +
					SAPMultiOriginPropertyName + "='" + oModelContext.getProperty(SAPMultiOriginPropertyName) + "')";
			} else {
				path = "SOs(SONo='" + oModelContext.getProperty("SONo") + "')";
			}
		},
		toSOItemDetail: function (oEvent) {
			var path = "";
			var oModelContext = oEvent.getSource().getBindingContext("SOItems");
			if (oPPCCommon.isMultiOrigin(oModelContext)) {
				var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
				path = "SOItemDetails(SONo='" + oModelContext.getProperty("SONo") + "',ItemNo='" + oModelContext.getProperty("ItemNo") + "'," +
					SAPMultiOriginPropertyName + "='" + oModelContext.getProperty(SAPMultiOriginPropertyName) + "')";
			} else {
				path = "SOItemDetails(SONo='" + oModelContext.getProperty("SONo") + "',ItemNo='" + oModelContext.getProperty("ItemNo") + "')";
			}
			this._oRouter.navTo("DetailPage", {
				contextPath: path
			}, false);
		},

		/*----------------------------------------------Navigation-------------------------------------------------------*/
		gotoDetails: function (oEvent) {
			var path = "";
			var oModelContext = oEvent.getSource().getBindingContext("POItems");
			this._oRouter.navTo("DetailPage", {
				contextPath: path
			}, true);
		},
		formatStatusImage: function (val) {
			var img;
			if (val === "B") {
				img = "sap-icon://status-in-process";
				return img;
			} else if (val === "C") {
				img = "sap-icon://home";
				return img;
			} else if (val === "D") {
				img = "sap-icon://status-error";
				return img;
			} else if (val === "A") {
				img = "sap-icon://task";
				return img;
			} else if (val === "F") {
				img = "sap-icon://message-warning";
				return img;
			}
		},
		formatStatusState: function (val) {
				var img;
				if (val === "B") {
					img = "Warning";
					return img;
				} else if (val === "C") {
					img = "Success";
					return img;
				} else if (val === "D") {
					img = "Error";
					return img;
				} else if (val === "A") {
					img = "Error";
					return img;
				} else if (val === "F") {
					img = "Success";
					return img;
				}
			}
	});

});