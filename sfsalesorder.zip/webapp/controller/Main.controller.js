jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
sap.ui.controller("com.arteriatech.sf.salesorder.sfsalesorder.controller.Main", {
	onInit: function() {
		this.onInitHookUp();
	},
	onInitHookUp: function() {
		this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
		var oDataModel = this._oComponent.getModel("PCGW");
		var oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
		oPPCCommon.initMsgMangerObjects();

		if (sap.ui.Device.support.touch === false) {
			this.getView().addStyleClass("sapUiSizeCompact");
		}

		if (this.onInitHookUp_Exit) {
			this.onInitHookUp();
		}
	}
});