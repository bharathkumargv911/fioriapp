sap.ui.define([
	"com/arteriatech/sf/salesorder/sfsalesorder/test/unit/controller/Main.controller"
], function () {
	"use strict";
});