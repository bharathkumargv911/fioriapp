var goi18n;
var goUtilsI18n;
var gListView;
var gList;
var gListReview;
var gObjectPageLayout;
var gUploadAttachments;
var gDocumentID;
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/arteriatech/pc/survey/pcsurveyupd/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.arteriatech.pc.survey.pcsurveyupd.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			jQuery.sap.registerModulePath("com.arteriatech.ppc.utils", "/sap/bc/ui5_ui5/ARTEC/PPCUTIL/utils/");
			jQuery.sap.registerModulePath("com.arteriatech.ss.utils", "/sap/bc/ui5_ui5/ARTEC/SSUTIL/utils/");
			jQuery.sap.registerModulePath("com.arteriatech.comn.flpplugin", "/sap/bc/ui5_ui5/ARTEC/FLPPLUGIN/");

			sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
			var Device = sap.ui.Device;
			var DeviceModel = new sap.ui.model.json.JSONModel(Device);
			DeviceModel.setDefaultBindingMode("OneWay");
			this.setModel(DeviceModel, "device");

			this.getRouter().initialize();
		}
	});
});