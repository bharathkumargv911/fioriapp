sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ss/utils/js/UserMapping",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"sap/m/MessageBox",
	"com/arteriatech/pc/survey/pcsurveyupd/util/jszip",
	"com/arteriatech/pc/survey/pcsurveyupd/util/XLSX"
], function (Controller, JSONModel, History, oPPCCommon, oSSCommon, oSSUserMapping, oSSCommonValueHelp, MessageBox) {
	"use strict";
	var oi18n = "",
		oUtilsI18n = "";
	var Device = sap.ui.Device;
	var busyDialog = new sap.m.BusyDialog();
	var aItems = [];
	return Controller.extend("com.arteriatech.pc.survey.pcsurveyupd.controller.List", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.pc.survey.pcsurveyupd.view.List
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gList = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gList));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//Attach event for routing on view patter matched 

			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			oPPCCommon.initMsgMangerObjects();
			this.clearModel();
			this.setItemModel();
			this.getSurvey();
		},

		clearModel: function () {
			var oViewSettingModel = new sap.ui.model.json.JSONModel({});
			//--------------------------------------------------for remark

			this._oComponent.setModel(oViewSettingModel, "CPConfigUploads");
			this._oComponent.getModel("CPConfigUploads").setProperty("/", {});

		},
		setItemModel: function () {
			var oItemModel = new sap.ui.model.json.JSONModel();
			oItemModel.setData(this.CPConfigUploads);
			this._oComponent.setModel(oItemModel, "CPConfigUploads");
			// this.getView().getModel("LocalViewSetting").setProperty("/SOItemTableCount", this.CPConfigUploads.length);
		},
		onRouteMatched: function (oEvent) {
			if (oEvent.getParameter("name") !== "cpuploadlist" && oEvent.getParameter("name") !== "searchcpuploadlist" && oEvent.getParameter(
					"name") !== "cpuploadlistapp" && oEvent.getParameter("name") !== "searchcpuploadlistapp") {
				return;
			}
			var that = this;
			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oHistory.getDirection() !== "Backwards") {
				that.setDefaultSettings();
				if (oEvent.getParameter("name") === "searchcpuploadlist" || oEvent.getParameter("name") === "searchcpuploadlistapp") {
					this.contextPath = oEvent.getParameter("arguments").contextPath;
				}
			} else if (oEvent.getParameter("name") === "cpuploadlist" || oEvent.getParameter("name") === "cpuploadlistapp") {
				that.setDefaultSettings();
				this.getView().setBusy(true);
			} else {
				this.getView().setBusy(false);
			}
		},
		setDefaultSettings: function () {
			var that = this;
			/**
			 * All view related local settings should be mapped in a Model and is called LocalViewSetting
			 */
			var oViewSettingModel = new JSONModel();
			var viewSettingData = {
				// ChannelPartnersCount: 0,
				CustomerDD: false,
				CustomerVH: false,
				downlaodBtn: false,
				messageLength: 0,
				DetailMode: true,
				ReviewMode: false,
				ErrorCount: 0,
				TableCount: 0,
				reviewButton: false,
				erroLogPage: false,
				SaveButton: "Save",
				UploadCommon: false,
				AllColumnVisible: false,
				AppTitle: "Survey Upload",
				AggregatorID: "",
				ErrorVisible: false,
				XCMNUploadVisible: false,
				SurveyVisible: true,
				SurveyQuesVisible: false,
				SurveyQuesOptionVisible: false,
				ExportSurveyVis: false,
				UploadImage: false,
				SurveyGeoVisible: false,
				CopyButtonEnabled: false,
				UploadPageVisible: true
			};
			oViewSettingModel.setData(viewSettingData);
			that._oComponent.setModel(oViewSettingModel, "LocalViewSetting");
			if (oPPCCommon.getFLPTileAction().split("&")[0] === "Common") {
				// if (true) {
				this.getView().getModel("LocalViewSetting").setProperty("/UploadCommon", false);
				this.getView().getModel("LocalViewSetting").setProperty("/AllColumnVisible", true);
				this.getView().getModel("LocalViewSetting").setProperty("/XCMNUploadVisible", true);
				this.getView().getModel("LocalViewSetting").setProperty("/AppTitle", "Survey Upload");
			} else {
				this.getView().getModel("LocalViewSetting").setProperty("/XCMNUploadVisible", false);
				this.getView().getModel("LocalViewSetting").setProperty("/UploadCommon", false);
				this.getView().getModel("LocalViewSetting").setProperty("/AllColumnVisible", true);
				this.getView().getModel("LocalViewSetting").setProperty("/AppTitle", "Survey Upload");
			}
		},
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},

		getSurvey: function () {
			var that = this;
			busyDialog.open();
			var CPConfigListModel = that._oComponent.getModel("PCGWHANA");
			var entityName = "/Surveys";
			CPConfigListModel.read(entityName, {
				success: function (oData) {
					busyDialog.close();
					oData = oPPCCommon.formatItemsOData({
						oData: oData
					});
					if (oData.length > 0) {
						oData.unshift({
							SurveyGUID: "",
							SurveyDesc: "(Select Survey)"
						});
						var CPConfigModel = new sap.ui.model.json.JSONModel();
						CPConfigModel.setData(oData);
						that._oComponent.setModel(CPConfigModel, "SurveyModelDD");
					}
				},
				error: function (error) {
					busyDialog.close();
					that.getView().setBusy(false);
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					that.setNodataFound();
					oPPCCommon.dialogErrorMessage(error, oUtilsI18n.getText("common.Dialog.Error.ServiceError.Header"));
				}
			});
		},

		onExportSurvey: function () {
			var that = this;
			busyDialog.open();
			var CPConfigListModel;
			var oPayForFilter = new Array();
			if (oPPCCommon.getFLPTileAction().split("&")[0] === "Common") {
				CPConfigListModel = that._oComponent.getModel("PCGWHANA");
			} else {
				CPConfigListModel = that._oComponent.getModel("PCGWHANA");
			}
			var entityName;
			if (gList.byId("SelectGroupID").getSelectedIndex() === 1) {
				entityName = "/Surveys";
			} else {
				entityName = "/SurveyHdr";
			}
			var sSurveyGuid = that.getView().byId("idSurvey").getSelectedKey();

			oPayForFilter = oPPCCommon.setODataModelReadFilter(that.getView(), "", oPayForFilter, "SurveyGUID", sap.ui.model.FilterOperator
				.EQ, [sSurveyGuid], false, false, false);

			CPConfigListModel.read(entityName, {
				filters: oPayForFilter,
				success: function (oData) {
					busyDialog.close();
					oData = oPPCCommon.formatItemsOData({
						oData: oData
					});
					if (oData.length > 0) {
						var CPConfigModel = new sap.ui.model.json.JSONModel();
						CPConfigModel.setData(oData);
						that._oComponent.setModel(CPConfigModel, "SurveyModel");
						that.exportToExcelCPUpload();
					}
				},
				error: function (error) {
					busyDialog.close();
					that.getView().setBusy(false);
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					that.setNodataFound();
					oPPCCommon.dialogErrorMessage(error, oUtilsI18n.getText("common.Dialog.Error.ServiceError.Header"));
				}
			});
		},

		exportToExcelCPUpload: function (oEvent) {
			var that = this;
			if (gList.byId("SelectGroupID").getSelectedIndex() === 1) {
				if (Device.system.desktop) {
					oPPCCommon.copyAndApplySortingFilteringFromUITable({
						thisController: this,
						mTable: this.getView().byId("SurveyTable"),
						uiTable: this.getView().byId("UICPConfigTable")
					});
				}
				var table = this.getView().byId("SurveyTable");
				var oModel = this.getView().getModel("SurveyModel");
				oPPCCommon.exportToExcel(table, oModel);
			} else {
				if (Device.system.desktop) {
					oPPCCommon.copyAndApplySortingFilteringFromUITable({
						thisController: this,
						mTable: this.getView().byId("SurveyQuesTable"),
						uiTable: this.getView().byId("UICPConfigTable")
					});
				}
				var table = this.getView().byId("SurveyQuesTable");
				var oModel = this.getView().getModel("SurveyModel");
				oPPCCommon.exportToExcel(table, oModel);

			}
		},

		onDownloadLink: function () {
			if (gList.byId("SelectGroupID").getSelectedIndex() === 0) {
				window.open("/csv/SurveyUpload.xlsx");
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 1) {
				window.open("/csv/SurveyQuestionUpload.xlsx");
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 2) {
				window.open("/csv/SurveyQuestionOptionUpload.xlsx");
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 4) {
				window.open("/csv/SurveyGeoUpload.xlsx");
			}

			// if (location.href.indexOf("ondemand.com") > -1) {
			// 	window.open("/csv/SurveyUpload.xlsx");
			// } else if (location.href.indexOf("bc/ui5_ui5") > -1 || location.href.indexOf("co.in") > -1) {
			// 	window.open("/csv/SurveyUpload.xlsx");
			// }
		},

		setNodataFound: function () {
			var oView = this.getView();
			/** Clear Model of the view */
			if (oView.getModel("ChannelPartners1") !== undefined) {
				oView.getModel("ChannelPartners1").setProperty("/", {});
			}
			MessageBox.error(
				"No Results Found", {
					styleClass: "sapUiSizeCompact"
				}
			);
			oView.setBusy(false);
			if (this.setNodataFound_Exit) {
				this.setNodataFound_Exit();
			}
		},

		handleUploadComplete: function (e) {
			oPPCCommon.removeAllMsgs();
			var that = this;
			var oFileUploader = that.getView().byId("fileUploader"); // get the sap.ui.unified.FileUploader
			var file = oFileUploader.getFocusDomRef().files[0]; // get the file from the FileUploader control
			var selFile = false;
			if (gList.byId("SelectGroupID").getSelectedIndex() === 0 && file.name.includes("SurveyUpload")) {
				selFile = true;
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 1 && file.name.includes("SurveyQuestionUpload")) {
				selFile = true;
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 2 && file.name.includes("SurveyQuestionOptionUpload")) {
				selFile = true;
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 4 && file.name.includes("SurveyGeoUpload")) {
				selFile = true;
			}

			if (file && window.FileReader && selFile) {
				var reader = new FileReader();
				reader.onload = function (e) {
					var data = e.target.result;
					var excelsheet = XLSX.read(data, {
						type: "binary"
					});
					excelsheet.SheetNames.forEach(function (sheetName) {
						var oExcelRow = XLSX.utils.sheet_to_row_object_array(excelsheet.Sheets[excelsheet.SheetNames[0]]); // this is the required data in Object format
						var sJSONData = JSON.stringify(oExcelRow); // this is the required data in String format
						var oROsModel = new sap.ui.model.json.JSONModel();
						oROsModel.setData(oExcelRow);
						that.getView().setModel(oROsModel, "InvoiceItemsupload");
					});
					aItems = that.getView().getModel("InvoiceItemsupload").getData();
				};
				reader.readAsBinaryString(file);
			} else {
				var oDialog = this._oDialog('Please select valid xlsx format file');
				oDialog.open();
			}
		},

		rowDataManipulation: function (fHeadersLen, fStrCSV, fi, faCurrentLine) {
			var temp = fStrCSV.split("\n")[fi];
			for (var h = 0; h < fHeadersLen; h++) {
				var rowValue = "";
				if (temp.indexOf('"') >= 0 && temp.indexOf('"') < temp.indexOf(',')) {
					var indexValue = temp.indexOf('"');
					temp = temp.replace('"', "");
					var indexValueEnd = temp.substring(indexValue).indexOf('"');
					rowValue = temp.substring(indexValue, indexValue + indexValueEnd);
					temp = temp.replace(temp.substring(indexValue, indexValue + indexValueEnd + 2), "");
				} else {
					if (temp.indexOf(",") === 0) {
						//temp = temp.replace(',', "");
					}
					var indexEnd = temp.substring(indexValue).indexOf(',');
					if (fHeadersLen - 1 === h) {
						rowValue = temp;
					} else {
						rowValue = temp.substring(0, indexEnd);
						temp = temp.replace(temp.substring(0, indexEnd + 1), "");
					}
				}
				faCurrentLine.push(rowValue);
			}
			return faCurrentLine;
		},

		handleTypeMissmatch: function (oEvent) {
			var dialog = this._oDialog('Please Select XLSX File Format');
			dialog.open();
			aItems = [];
			this.getView().getModel("CPConfigUploads").setProperty("/", {});
			this.getView().getModel("LocalViewSetting").setProperty("/tableCount", "(" + aItems.length + ")");
		},
		formatDate: function (fdate) {
			if (fdate) {
				var oformatDate = new Date(fdate);
				oformatDate = oPPCCommon.addHoursAndMinutesToDate({
					dDate: oformatDate
				});
				return oformatDate;
			} else {
				return null;
			}
		},

		handleUploadPress: function () {
			var that = this;
			this._TempSOItemDetails = [];
			this.getView().getModel("CPConfigUploads").setProperty("/", []);
			var sSourceID = "";
			var oFileField = this.getView().byId("fileUploader");
			var fileLength = oFileField.oFileUpload.files.length;
			var allowedExtensions = /(xlsx)$/i;
			var loginID = this.getCurrentUsers("CPConfigUploads", "create");
			var validExts = ".xlsx";
			var oFileName = this.getView().byId("fileUploader").getValue().split("(")[0];
			var fileExt = oFileName.substring(oFileName.lastIndexOf('.'));
			if (fileLength > 0) {
				if (this.getView().byId("fileUploader").getValue().lastIndexOf(".xlsx") !== -1) {
					// Condition Statement for validating file =  records
					if (aItems.length > 0) {
						var aValidItems = [];
						for (var i = 0; i < aItems.length; i++) {
							if (aItems[i].DistributorCode !== undefined && aItems[i].DistributorCode !== "" && aItems[i].DistributorCode !== null) {
								aItems[i].CPGuid = aItems[i].DistributorCode.trim();
							}
							// aItems[i].CPName = aItems[i].DistributorName;
							if (aItems[i].LoginID !== undefined && aItems[i].LoginID !== "" && aItems[i].LoginID !== null) {
								aItems[i].LoginID = aItems[i].LoginID.trim();
							}
							if (aItems[i].CustomerCodeConversion !== undefined) {
								aItems[i].ConfigAttribute1 = aItems[i].CustomerCodeConversion;
							}
							if (aItems[i].MaterialCodeConversion !== undefined) {
								aItems[i].ConfigAttribute2 = aItems[i].MaterialCodeConversion;
							}
							if (aItems[i].ValidFrom) {
								aItems[i].ValidFrom = that.formatDate(aItems[i].ValidFrom);
							}
							if (aItems[i].ValidTo) {
								aItems[i].ValidTo = that.formatDate(aItems[i].ValidTo);
							}
							// aItems[i].EInvoiceCutOverDate = that.formatDate(aItems[i].EInvoiceCutOverDate);
							// aItems[i].ConfigurationDate = that.formatDate(aItems[i].SRCutoffDate);
							// aItems[i].PurchaseInvDate = that.formatDate(aItems[i].PurchaseInvDate);
							// aItems[i].PaymentDate = that.formatDate(aItems[i].PaymentDate);
						}
						// Set JSON model to component with alias name [alias name as Odata collection name]
						that.getView().getModel("LocalViewSetting").setProperty("/reviewButton", true);
						that.getView().getModel("LocalViewSetting").setProperty("/erroLogPage", false);
						this._oComponent.getModel("CPConfigUploads").setProperty("/", aItems);
						that.getView().getModel("LocalViewSetting").setProperty("/ErrorVisible", false);
						this._oComponent.getModel("LocalViewSetting").setProperty("/TableCount", aItems.length);
						this._oComponent.getModel("LocalViewSetting").setProperty("/ListItemsCount", aItems.length);
						this.setItemNo();
					} else {
						// Calling dialog box function to alert
						var oDialog = this._oDialog('Please enter valid xlsx format file');
						// Alert dialog box open
						oDialog.open();
					}
				} else {
					// Calling dialog box function to alert
					var oDialog = this._oDialog('Invalid File!');
					// Alert dialog box open
					oDialog.open();
				}
			} else {
				var oDialog = this._oDialog('Please Select file');
				oDialog.open();
			}
		},

		setItemNo: function () {
			var itemNo = 10;
			var countOfM = 0;
			var count = 0;
			var aItem = this.getView().getModel("CPConfigUploads").getProperty("/");
			for (var j = 0; j < aItem.length; j++) {
				countOfM = j + 1;
				itemNo = countOfM;
				itemNo = itemNo.toString();
				aItem[j].ItemNo = itemNo;
			}
			this.getView().getModel("CPConfigUploads").setProperty("/", aItem);
		},
		_oDialog: function (text) {
			var dialog = new sap.m.Dialog({
				title: 'Warning',
				type: 'Message',
				state: 'Warning',
				content: new sap.m.Text({
					text: text
				}),
				beginButton: new sap.m.Button({
					text: 'OK',
					press: function () {
						dialog.close();
					}
				}),

				afterClose: function () {
					// Opening Dialog box
					dialog.destroy();
				}
			});
			// returning dialopg box
			return dialog;
		},

		onSelect: function () {
			var that = this;
			that.getView().getModel("LocalViewSetting").setProperty("/UploadPageVisible", true);
			if (that._oComponent.getModel("CPConfigUploads")) {
				that._oComponent.getModel("CPConfigUploads").setProperty("/", []);
				that.getView().byId("fileUploader").setValue("");
				that.getView().getModel("LocalViewSetting").setProperty("/erroLogPage", false);
				that.getView().getModel("LocalViewSetting").setProperty("/reviewButton", false);
				that._oComponent.getModel("LocalViewSetting").setProperty("/TableCount", 0);
				that._oComponent.getModel("LocalViewSetting").setProperty("/ListItemsCount", 2);
			}
			if (gList.byId("SelectGroupID").getSelectedIndex() === 0) {
				that.getView().getModel("LocalViewSetting").setProperty("/SaveButton", "Save");
				that.getView().getModel("LocalViewSetting").setProperty("/UploadExcel", true);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyGeoVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/ExportSurveyVis", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyVisible", true);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesOptionVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadImage", false);
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 1) {
				that.getSurvey();
				that.getView().byId("exportSurvey").setText("Download Survey");
				that.getView().getModel("LocalViewSetting").setProperty("/ExportSurveyVis", true);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadExcel", true);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyGeoVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SaveButton", "Save");
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesVisible", true);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesOptionVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadImage", false);
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 2) {
				that.getSurvey();
				that.getView().byId("exportSurvey").setText("Download Survey Questions");
				that.getView().getModel("LocalViewSetting").setProperty("/UploadExcel", true);
				that.getView().getModel("LocalViewSetting").setProperty("/ExportSurveyVis", true);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyGeoVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SaveButton", "Save");
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesOptionVisible", true);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadImage", false);
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 3) {
				that.getView().byId("exportSurvey").setText("Upload Image");
				that.getView().getModel("LocalViewSetting").setProperty("/UploadPageVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadExcel", false);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadImage", true);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyGeoVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/ExportSurveyVis", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SaveButton", "Save");
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesOptionVisible", false);
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 4) {
				that.getView().byId("exportSurvey").setText("Upload Image");
				that.getView().getModel("LocalViewSetting").setProperty("/UploadExcel", false);
				that.getView().getModel("LocalViewSetting").setProperty("/UploadImage", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyGeoVisible", true);
				that.getView().getModel("LocalViewSetting").setProperty("/ExportSurveyVis", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SaveButton", "Save");
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesVisible", false);
				that.getView().getModel("LocalViewSetting").setProperty("/SurveyQuesOptionVisible", false);
			}
		},

	});

});