sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common"
], function (Controller,oPPCCommon,oPPSCommon) {
	"use strict";

	return Controller.extend("com.arteriatech.pc.survey.pcsurveyupd.controller.Main", {
		onInit: function () {
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			goi18n = this._oComponent.getModel("i18n").getResourceBundle();
			goUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			// oPPCCommon.initMsgMangerObjects();

			if (sap.ui.Device.support.touch === false) {
				this.getView().addStyleClass("sapUiSizeCompact");
			}
			if (this.onInitHookUp_Exit) {
				this.onInitHookUp();
			}
		}
	});
});