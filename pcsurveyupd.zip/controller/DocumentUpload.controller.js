sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/Common",
], function (Controller, oCommonValueHelp) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oProductCommon, oCommonValueHelp;
	var oi18n = "",
		oUtilsI18n = "";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var vIndex = 0;
	var busyDialog = new sap.m.BusyDialog();
	var ContractUploadFileList = [];
	var aDialog;
	var aFlag;
	var oUtilsI18n;
	var DocumentStore;
	var oDialog = new sap.m.BusyDialog();
	var indexOfPattern;
	var vMaximumFileSize;
	var SchemeGUID;
	var DuplicateAttachements = [];

	return Controller.extend("com.arteriatech.pc.survey.pcsurveyupd.controller.DocumentUpload", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.sf.prsctform.view.PstDocument
		 */
		onInit: function () {
			this.onInitHookUp();
		},

		onInitHookUp: function () {
			this._oView = this.getView();
			gUploadAttachments = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			// this.DynamicSideContent = this.getView().byId("ObjectPageLayout_ID_Crt");
			oProductCommon = com.arteriatech.ss.utils.js.Common;;
			oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;

			//i18n
			this.setDocumentAttachDD();
			this.getDocumentTypes();
			this.setDocumentModel();
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

		},
		setDocumentModel: function () {
			var that = this;
			var json = new sap.ui.model.json.JSONModel({
				"ObjectKey": "",
				"Source": "",
				"ApplicationID": "PD",
				"ObjectTypeID": "",
				"DocumentTypeID": "",
				"FileName": "",
				"MimeType": "image/png",
				"DocumentSize": "",
				"Param1": "",
				"Param2": "",
				"Param3": "",
				"StatusID": "",
				"FileContent": ""
			});
			that.getView().setModel(json, "BRDocument");
		},

		setDocumentAttachDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGWHANA");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"PSTATT"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "AggregatorID", sap.ui.model.FilterOperator.EQ, [
				"AGGRMDT"
			], false, false, false);

			oModelData.read("/ConfigTypsetTypeValues", {
				filters: oStatusFilter,
				success: function (oData) {
					busyDialog.close();
					if (oData.results.length > 1) {
						oData.results.unshift({
							Types: "",
							TypesName: "(Select)"
						});
						for (var i = 1; i < oData.results.length; i++) {
							oData.results[i].Seperator = "-";
							oData.results[i].TypesName = oData.results[i].Typesname;
						}
					}
					var json = new sap.ui.model.json.JSONModel(oData.results);
					gUploadAttachments.setModel(json, "DocumentAttachDD");

				},
				error: function () {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel([]);
					gUploadAttachments.setModel(json, "DocumentAttachDD");

				}
			});

			if (this.setProspctStatusDD_Exit) {
				this.setProspctStatusDD_Exit();
			}
		},
		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oProductCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},

		selectDocumentType: function (oEvent) {
			var that = this;
			// that.DynamicSideContent = gCPDetailView.byId("ObjectPageLayout_ID_Crt");
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(gObjectPageLayout);
			if (oPPCCommon.doErrMessageExist()) {
				// that.validateRequiredAttatchments();
				if (oPPCCommon.doErrMessageExist()) {
					var oPanel = new sap.m.Panel();
					that._oComponent.getModel("LocalViewSetting").setProperty("/DocType", "");
					var DocTypeHBox = new sap.m.HBox();
					DocTypeHBox.addStyleClass("sapUiTinyMarginTop");
					// //var FileChooser=new sap.m.HBox();
					var VBox = new sap.m.VBox();
					var Text = new sap.m.Text({
						text: ""
					});

					var UploadCollection = new sap.m.UploadCollection({
						// width: "100%",
						// fileType: ["jpg", "png", "jpeg", "bmp"],
						fileType: ["png", "jpeg"],
						mimeType: "image/png",
						maximumFilenameLength: 55,
						maximumFileSize: 6,
						multiple: false,
						sameFilenameAllowed: false,
						instantUpload: false,
						showSeparators: "All",
						noDataText: oUtilsI18n.getText("common.NoAttachments"),
						change: function (oEvent) {
							that.uploadOnChange(oEvent);
						},
						fileDeleted: function (oEvent) {
							that.onFileDeleted(oEvent);
						},
						filenameLengthExceed: function (oEvent) {
							that.onFilenameLengthExceed(oEvent);
						},
						fileSizeExceed: function (oEvent) {
							that.onFileSizeExceed(oEvent);
						},
						typeMissmatch: function (oEvent) {
							that.onTypeMissmatch(oEvent);
						},
						beforeUploadStarts: function (oEvent) {
							// that.onBeforeUploadStarts(oEvent);
						},
						uploadComplete: function (oEvent) {
							that.onUploadComplete(oEvent);
						},
						uploadUrl: "/sap/opu/odata/ARTEC/SSGW_MM/MaterialDocDocuments"
					});
					// DocTypeHBox.addItem(DocTypeLabel);
					DocTypeHBox.addItem(this.DocType);
					// if (DocumentStore === "A") {
					VBox.addItem(DocTypeHBox);
					// 	VBox.addItem(Text);
					// }
					VBox.addItem(UploadCollection);
					VBox.addStyleClass("sapUiTinyMargin");
					oPanel.addContent(VBox);
					that.dialog = new sap.m.Dialog({
						title: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.Title"),
						type: 'Standard',
						// width: "50%",
						// height: "50%",
						resizable: true,
						contentWidth: "50%",
						contentHeight: "50%",
						state: 'None',
						icon: 'sap-icon://attachment',
						draggable: true,
						content: oPanel,
						buttons: [
							// new sap.m.Button({
							// 	text: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.Title"),
							// 	press: function (oEvent) {
							// 		oPPCCommon.removeAllMsgs();
							// 		that.dialog.close();
							// 		// if (that.validateContractAttachments(UploadCollection)) {
							// 		that.postBPDeclarationData(oEvent);
							// 		// 	that.dialog.close();
							// 		// } else {
							// 		// 	var message = oPPCCommon.getMsgsFromMsgMgr();
							// 		// 	oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
							// 		// }
							// 	}
							// }),
							new sap.m.Button({
								text: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.Button.Cancel"),
								press: function () {
									//that.getInvoiceContractDocumentss(that._oComponent);
									that.dialog.close();
								}
							})
						],
						afterClose: function () {
							//that.dialog.destroy();
						}
					});
					aDialog = that.dialog;
					that.dialog.open();
					if (sap.ui.Device.support.touch === false) {
						that.dialog.addStyleClass("sapUiSizeCompact");
					}
				} else {
					this._oComponent.getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData().length);
					oPPCCommon.showMessagePopover(gObjectPageLayout);
				}
			} else {
				this._oComponent.getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);
				oPPCCommon.showMessagePopover(gObjectPageLayout);
			}
		},
		getMimeType: function (FileType) {
			var that = this;
			var mimeType;
			if (FileType) {
				FileType = FileType.toLowerCase();
			}
			if (FileType == "png") {
				mimeType = "image/png";
			} else if (FileType == "jpeg" || FileType == "jpg") {
				mimeType = "image/jpeg";
			}
			// if (FileType == "csv") {
			// 	mimeType = "text/csv";
			// } else if (FileType == "doc") {
			// 	mimeType = "application/msword";
			// } else if (FileType == "docx") {
			// 	mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
			// } else if (FileType == "gif") {
			// 	mimeType = "image/gif";
			// } else if (FileType == "jpeg" || FileType == "jpg") {
			// 	mimeType = "image/jpeg";
			// } else if (FileType == "png") {
			// 	mimeType = "image/png";
			// } else if (FileType == "png") {
			// 	mimeType = "image/png";
			// } else if (FileType == "txt") {
			// 	mimeType = "text/plain";
			// } else if (FileType == "xls") {
			// 	mimeType = "application/vnd.ms-excel";
			// } else if (FileType == "xlsx") {
			// 	mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
			// }
			return mimeType;
		},
		uploadOnChange: function (oEvent) {
			var that = this;
			var fileDetails = oEvent.getParameters("file").files[0];
			sap.ui.getCore().fileUploadArr = [];
			// 	var oDocumentModel = new sap.ui.model.json.JSONModel();
			// oDocumentModel.setData(oData);
			// that.getVIew().setModel(oDocumentModel, "Documents");
			if (fileDetails) {
				var mimeDet = fileDetails.type,
					fileName = fileDetails.name,
					size = fileDetails.size,
					fileType = fileName.split(".")[fileName.split(".").length - 1];
				var MimeTypes = that.getMimeType(fileType);
				if (MimeTypes) {
					that.getView().getModel("BRDocument").setProperty("/FileType", MimeTypes);
					DuplicateAttachements.push(fileName);
					// Calling method....
					this.base64coonversionMethod(mimeDet, fileName, size, fileDetails, "001");
				} else {
					var Filemsg = "File Type is not Supported";
					oPPCCommon.displayMsg_MsgBox(that.getView(), Filemsg, "error");
				}

			} else {
				sap.ui.getCore().fileUploadArr = [];
			}
		},
		base64coonversionMethod: function (fileMime, fileName, size, fileDetails, DocNum) {
			var that = this;
			if (!FileReader.prototype.readAsBinaryString) {
				FileReader.prototype.readAsBinaryString = function (fileData) {
					var binary = "";
					var reader = new FileReader();
					reader.onload = function (e) {
						var bytes = new Uint8Array(reader.result);
						var length = bytes.byteLength;
						for (var i = 0; i < length; i++) {
							binary += String.fromCharCode(bytes[i]);
						}
						var base64ConversionRes = btoa(binary);

					};
					reader.readAsArrayBuffer(fileData);
				};
			}
			var reader = new FileReader();
			reader.onload = function (readerEvt) {
				var binaryString = readerEvt.target.result;
				that.base64ConversionRes = btoa(binaryString);
				// that.getView().getModel("BRDocument").setProperty("/0/ProcessReference1", that.base64ConversionRes);
				oPPCCommon.removeAllMsgs();
				oPPCCommon.fileSizeFormatter();
				// that.validateDuplicatefiles(fileName);
				// if (oPPCCommon.doErrMessageExist()) {
				that.getView().getModel("BRDocument").setProperty("/ProcessReference1", that.base64ConversionRes);
				that.postBPDeclarationData(fileMime, fileName, size, that.base64ConversionRes);
				// } else {
				// 	this._oComponent.getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				// 		.getData()
				// 		.length);
				// }
				// sap.ui.getCore().fileUploadArr.push({
				// 	"DocumentType": DocNum,
				// 	"MimeType": fileMime,
				// 	"FileName": fileName,
				// 	"Content": that.base64ConversionRes,

				// });
			};
			reader.readAsBinaryString(fileDetails);
		},

		validateRequiredAttatchments: function () {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var AttatchmentType = that._oComponent.getModel("LocalViewSetting").getProperty("/DocumentType");
			if (AttatchmentType) {
				if (that._oComponent.getModel("DocumentLinks")) {
					var RequiredAttatchement = that._oComponent.getModel("DocumentLinks").getProperty("/");
					for (var j = 0; j < RequiredAttatchement.length; j++) {
						if (AttatchmentType === RequiredAttatchement[j].DocumentTypeID) {
							var msg = AttatchmentType + " " + "already uploaded";
							oPPCCommon.addMsg_MsgMgr(msg, "error");
						}
					}
				}
			} else {
				var msg1 = "Please select Document Attatchement Type";
				this._oComponent.getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);
				oPPCCommon.addMsg_MsgMgr(msg1, "error");
			}
		},
		validateDuplicateRequestAttatchement: function (AttatchmentType) {
			var that = this;
			if (that._oComponent.getModel("DocumentLinks")) {
				var RequiredAttatchement = that._oComponent.getModel("DocumentLinks").getProperty("/");
				for (var j = 0; j < RequiredAttatchement.length; j++) {
					if (AttatchmentType === RequiredAttatchement[j].DocumentTypeID) {
						var msg = AttatchmentType + " " + "already uploaded";
						oPPCCommon.addMsg_MsgMgr(msg, "error");
					}
				}

			}

		},
		validateDuplicatefiles: function (fileName) {
			var that = this;
			for (var j = 0; j < DuplicateAttachements.length; j++) {
				if (fileName === DuplicateAttachements[j]) {
					var msg = "Selected image is Duplicate. Please check";

					oPPCCommon.addMsg_MsgMgr(msg, "error");
				}
			}
		},

		onChangeAttachment: function (oEvent) {
			var that = this;
			// var AttatchmentType = oEvent.getSource().getSelectedKey();
			var DocumentTypes = that.getView().getModel("DoumentTypes").getProperty("/");
			for (var j = 0; j < DocumentTypes.length; j++) {
				if ("SRV_IMG" === DocumentTypes[j].DocumentType) {
					that.getView().getModel("BRDocument").setProperty("/ObjectTypeID", DocumentTypes[j].ObjectType);
					that.getView().getModel("BRDocument").setProperty("/DocumentTypeID", DocumentTypes[j].DocumentType);
					that.getRepConfigTypes(DocumentTypes[j].DocumentRepositoryGUID);
				}
			}
			// that.validateDuplicateRequestAttatchement(AttatchmentType);
		},

		getDocumentTypes: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGWHANA");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "AggregatorID", sap.ui.model.FilterOperator.EQ, [
				"AGGRBIL"
			], false, false, false);

			oModelData.read("/DocumentTypes", {
				filters: oStatusFilter,
				success: function (oData) {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(json, "DoumentTypes");
					that.onChangeAttachment();
				},
				error: function () {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel([]);
					that.getView().setModel(json, "DoumentTypes");

				}
			});

			if (this.setSourceDD_Exit) {
				this.setSourceDD_Exit();
			}

		},
		getRepConfigTypes: function (DocumentTypeConfigGUID) {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGWHANA");
			var oStatusFilter = new Array();
			// oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "AggregatorID", sap.ui.model.FilterOperator.EQ, [
			// 	"AGGRMDT"
			// ], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ID", sap.ui.model.FilterOperator.EQ, [
				DocumentTypeConfigGUID
			], false, false, false);

			oModelData.read("/DocumentRepConfigs", {
				filters: oStatusFilter,
				success: function (oData) {
					// busyDialog.close();
					that.getView().getModel("BRDocument").setProperty("/DocumentRepositoryGUID", oData.results[0].ID);
					// that.getView().getModel("BRDocument").setProperty("/ObjectKey", gWarrantyNo);
					that.getView().getModel("BRDocument").setProperty("/Source", oData.results[0].SourceID);
					var json = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(json, "DocumentRepConfigsTypes");

				},
				error: function () {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel([]);
					that.getView().setModel(json, "DocumentRepConfigsTypes");

				}
			});

			if (this.setSourceDD_Exit) {
				this.setSourceDD_Exit();
			}

		},
		onFileSizeExceed: function (oEvent) {
			sap.m.MessageToast.show("Please select less than 6 mb file");
			if (this.onFileSizeExceed_Exit) {
				this.onFileSizeExceed_Exit();
			}
		},

		postBPDeclarationData: function (fileMime, fileName, size, base64) {
			var that = this;
			var oView = gUploadAttachments;
			busyDialog.open();
			oPPCCommon.removeAllMsgs();
			var methodType = "POST";
			var BPDocuments = that.getView().getModel("BRDocument").getProperty("/");
			var DocumentID = oPPCCommon.generateUUID().toUpperCase();
			gDocumentID = DocumentID.split("-").join('');
			var data = {
				"ObjectKey": gDocumentID,
				"Source": "S4QCLNT101",
				"ApplicationID": "PD",
				"ObjectTypeID": "/ARTEC/DOC",
				"DocumentTypeID": "SRV_IMG",
				"FileName": fileName,
				// "MimeType": "image/png",
				"MimeType": BPDocuments.FileType,
				"DocumentSize": size,
				"Param1": "",
				"Param2": "",
				"Param3": "",
				"StatusID": "",
				"FileContent": base64
			};

			var data = {
				"ObjectKey": gDocumentID,
				"Source": BPDocuments.Source,
				"ApplicationID": "PD",
				"ObjectTypeID": BPDocuments.ObjectTypeID,
				"DocumentTypeID": BPDocuments.DocumentTypeID,
				"FileName": fileName,
				// "MimeType": "image/png",
				"MimeType": "image/png",
				"DocumentSize": size,
				"Param1": "",
				"Param2": "",
				"Param3": "",
				"StatusID": "",
				"FileContent": base64
			};

			$.ajax({
				url: "/sap/opu/odata/ARTEC/ProcessDocument/ProcessDocument",
				type: methodType,
				data: JSON.stringify(data),
				dataType: "JSON",
				async: true,
				contentType: "application/json; charset=utf-8",
				success: function (data, textStatus, jqXHR) {
					that.dialog.close();
					if (data.ErrorCode === "") {
						that.getDocument();
						// that.getDocumentsUrl();
					} else {
						busyDialog.close();
						var message = data.Message;
						if (data.Message === "Document with the same name is already available in the repository") {
							message = "Same Document name already exits kindly Rename the document or upload new document";
						}
						// that.displaySuccessMessage(message);
						oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
					}
				},
				error: function (xhr, status, e) {
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					busyDialog.close();
				}
			});
		},

		displaySuccessMessage: function (msg) {
			var that = this;
			// var messageType = this.getMessageType();
			var dialog = new sap.m.Dialog({
				title: 'Success',
				type: 'Message',
				state: 'Success',
				content: new sap.m.Text({
					// text: oPPCCommon.getMsgsFromMsgMgr()
					text: msg
				}),
				buttons: [
					new sap.m.Button({
						// icon: "sap-icon://home",
						text: "Ok",
						press: function () {
							// window.location = "#";
							dialog.close();
						}
					}),
					new sap.m.Button({
						text: 'View Image',
						press: function () {
							// that.goToSODetail(SONo);
							dialog.close();
						}
					}),
					new sap.m.Button({
						icon: "sap-icon://copy",
						text: 'Copy Url',
						press: function () {
							that.copyToClipboard("Copied Url Successfully");
							// that.resetQuotecreate();
							//that.getView().getModel("LocalViewSetting").setProperty("/HeaderReviewVisibility", true);
							//window.location.reload();
							// that.onInit();
							that._TempSOItemDetails = [];
							dialog.close();
						}
					}),
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		copyToClipboard: function (message) {
			// window.prompt("Copy to clipboard: Ctrl+C, Enter", message);
			navigator.clipboard.writeText(message);
		},

		getDocumentsUrl: function (DocumentID, openByControl) {
			var that = this;
			var sURL = "/sap/opu/odata/ARTEC/ProcessDocument/ProcessDocument/?";

			// sURL = sURL + "?RepositoryID=15346049-4888-4f9c-804e-4537e3aa3561&Source=S4DCLNT101&DocumentID=" +
			// 	gDocumentID;

			sURL = sURL +
				"RepositoryID=07aab0df-8003-44bd-bd79-62cca06f3fb5&Source=MDTDEV100&DocumentID=JZ__d8pIIuoXG5r86jqMbKzpeKKd615Qb3VCquuvgDE";

			$.ajax({
				type: "GET",
				url: sURL,
				contentType: "application/json; charset=utf-8",
				dataType: "json",
				crossDomain: true,
				headers: {
					'Access-Control-Allow-Origin': '*',
				},
				success: function (data) {
					if (data.Status === "000001") {
						that.getView().getModel("LocalViewSetting").setProperty("/URL", data.FileContent);
						that.getView().setBusy(false);
						// that._oPopover.openBy(openByControl);
					} else {
						that.getView().setBusy(false);
						sap.m.MessageToast.show("Failed to Load Image Attachment", {
							duration: 5000
						});
					}

				},
				failure: function (errMsg) {
					that.getView().setBusy(false);
				}
			});
		},

		getDocument: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGWHANA");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ObjectKey", sap.ui.model.FilterOperator
				.EQ, [
					gDocumentID
				], false, false, false);

			oModelData.read("/DocumentLinks", {
				filters: oStatusFilter,
				success: function (oData) {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel(oData.results);
					that._oComponent.setModel(json, "DocumentLinks");
					if (oData.results.length > 0) {
						// that.getRepConfigDetailTypes("15346049-4888-4f9c-804e-4537e3aa3561", k);
						var DocuemtTypes = that.getView().getModel("DoumentTypes").getProperty("/");
						for (var k = 0; k < oData.results.length; k++) {
							for (var z = 0; z < DocuemtTypes.length; z++) {
								if (oData.results[k].DocumentTypeID === DocuemtTypes[z].DocumentType) {
									that.DetailCount = oData.results.length;
									that.getRepConfigDetailTypes(DocuemtTypes[z].DocumentRepositoryGUID, k);
								}
							}
						}
					} else {
						busyDialog.close();
						if (that._oComponent.getModel("DocumentLinks")) {
							that._oComponent.getModel("DocumentLinks").setProperty("/", []);
						}
					}
				},
				error: function () {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel([]);
					that._oComponent.setModel(json, "DocumentLinks");

				}
			});

			if (this.setSourceDD_Exit) {
				this.setSourceDD_Exit();
			}
		},
		getRepConfigDetailTypes: function (DocumentTypeConfigGUID, k) {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGWHANA");
			var oStatusFilter = new Array();
			// oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "AggregatorID", sap.ui.model.FilterOperator.EQ, [
			// 	"AGGRMDT"
			// ], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ID", sap.ui.model.FilterOperator.EQ, [
				DocumentTypeConfigGUID
			], false, false, false);

			oModelData.read("/DocumentRepConfigs", {
				filters: oStatusFilter,
				success: function (oData) {
					// busyDialog.close();
					that._oComponent.getModel("DocumentLinks").setProperty("/" + k + "/DocumentRepositoryGUID", oData.results[0].ID);
					// that._oComponent.getModel("DocumentLinks").setProperty("/" + k + "/ObjectKey", gWarrantyNo);
					that._oComponent.getModel("DocumentLinks").setProperty("/" + k + "/Source", oData.results[0].SourceID);
					var json = new sap.ui.model.json.JSONModel(oData.results);
					that.getView().setModel(json, "DocumentDetailRepConfigsTypes");
					that.DetailCount--;
					if (that.DetailCount === 0) {
						that.getBPDeclarationData();
					}
				},
				error: function () {
					// busyDialog.close();
					var json = new sap.ui.model.json.JSONModel([]);
					that.getView().setModel(json, "DocumentDetailRepConfigsTypes");

				}
			});

			if (this.setSourceDD_Exit) {
				this.setSourceDD_Exit();
			}
		},

		onCopyUrl: function () {
			var localData = this._oComponent.getModel("LocalViewSetting").getProperty("/")
			navigator.clipboard.writeText(localData.CopiedUrl);
			setTimeout(function () {
				sap.m.MessageToast.show("Image url copied to clipboard");
			}, 100);
		},

		getBPDeclarationData: function () {
			var that = this;
			var oView = gUploadAttachments;
			// oView.setBusy(true);
			oPPCCommon.removeAllMsgs();
			var aGetDocument = {};
			var Documentlinks = that._oComponent.getModel("DocumentLinks").getProperty("/");
			var Count = Documentlinks.length;
			for (var k = 0; k < Documentlinks.length; k++) {
				var methodType = "GET";
				var data = "RepositoryID=" +
					Documentlinks[k].DocumentRepositoryGUID + "&" + "Source=" +
					Documentlinks[k].Source + "&" + "DocumentID=" +
					Documentlinks[k].DocumentID;
				that._oComponent.getModel("LocalViewSetting").setProperty("/CopiedUrl", data);
				that._oComponent.getModel("LocalViewSetting").setProperty("/CopyButtonEnabled", true);
				$.ajax({
					url: "/sap/opu/odata/ARTEC/ProcessDocument/ProcessDocument?" + data,
					type: "GET",
					dataType: "JSON",
					async: false,
					jsonpCallback: "getJSON",
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {
						that.dialog.close();
						// oView.setBusy(false);
						Count--;
						if (Count === 0) {
							busyDialog.close();
							busyDialog.close();
						}
						var base64ConversionRes = data.FileContent;
						if (base64ConversionRes) {
							const byteString = window.atob(base64ConversionRes);
							const arrayBuffer = new ArrayBuffer(byteString.length);
							const int8Array = new Uint8Array(arrayBuffer);
							for (let i = 0; i < byteString.length; i++) {
								int8Array[i] = byteString.charCodeAt(i);
							}
							// const blob = new Blob([int8Array], {
							// 	type: 'image/png'
							// });
							const blob = new Blob([int8Array], {
								type: Documentlinks[k].MimeType
							});
							const url = URL.createObjectURL(blob);
							that._oComponent.getModel("DocumentLinks").setProperty("/" + k + "/DocumentUrl", url);
							// window.open(url, '_blank');
						} else {
							MessageBox.information("File is not uploaded");
						}
						// gChFinancingView.byId("RFConfirmButton").setEnabled(true);
						// // if (gChFinancingView.getModel("LocalViewSetting").getProperty("/RejectionForRej")) {
						// that.sentRejectionMail(BPGUID);
						// // } else {
						// // 	that.displayRFSuccessDialog();
						// // }
					},
					error: function (xhr, status, e) {

						oPPCCommon.removeDuplicateMsgsInMsgMgr();
						// var message = oi18n.getText("Currently.We.are.facing.some.issues.Please.try.after.sometime");
						// oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
						oView.setBusy(false);
						busyDialog.close();
					}
				});
			}

		},

		onTypeMissmatch: function (oEvent) {
			sap.m.MessageToast.show("Please Select Images");
			if (this.onTypeMissmatch_Exit) {
				this.onTypeMissmatch_Exit();
			}
		},

		onChange: function (oEvent) {

			var token = this._oComponent.getModel("SSGW_MM").getSecurityToken();
			var oUploadCollection = this.getView().byId('UploadCollectionView');
			var url = this._oComponent.getModel("SSGW_MM").sServiceUrl + "/MaterialDocDocuments";
			var sLoginID = this.getCurrentUsers("MaterialDocDocuments", "write");
			var oHeaderLoginId = new sap.m.UploadCollectionParameter({
				name: "x-arteria-loginid",
				value: sLoginID
			});
			var oHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});
			var oHeaderMethod = new sap.m.UploadCollectionParameter({
				name: "type",
				value: "POST"
			});
			var sFileName = oEvent.getParameter("mParameters").files[0].name;

			var oHeaderSlug;

			// var DocTypeID = this.getView().getModel("DocTypeDD").getData()[0].Key;
			DocumentStore = "A";
			// SchemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();

			SchemeGUID = this._oComponent.getModel("LocalViewSetting").getProperty("/GRDocGuid").toUpperCase();

			var matGuid = oPPCCommon.generateUUID();

			// if (sFileName.split(".")[1] === "png" || sFileName.split(".")[1] === "doc") {

			oHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: "MaterialDocGUID:" + SchemeGUID + ",DocumentStore:" + DocumentStore + ",FileName:" +
					sFileName +
					",LoginID:" + sLoginID
			});

			oUploadCollection.setUploadUrl(url);
			oUploadCollection.addHeaderParameter(oHeaderLoginId);
			oUploadCollection.addHeaderParameter(oHeaderSlug);
			oUploadCollection.addHeaderParameter(oHeaderToken);
			oUploadCollection.addHeaderParameter(oHeaderMethod);

			// } else {
			// 	setTimeout(function () {
			// 		var message = "Please Select png or doc File";
			// 		sap.m.MessageToast.show(message);
			// 	}, 100);
			// }
		},

		onFileDeleted: function (oEvent) {
			var that = this;
			var oView = gUploadAttachments;
			busyDialog.open();
			oPPCCommon.removeAllMsgs();
			var methodType = "DELETE";
			var Documents = that._oComponent.getModel("DocumentLinks").getProperty("/");
			var DeletedData;
			var BPDocuments = that.getView().getModel("BRDocument").getProperty("/");
			for (var z = 0; z < Documents.length; z++) {
				if (oEvent.mParameters.documentId === Documents[z].DocumentID) {
					DeletedData = Documents[z];
				}
			}
			var data = {
				"Source": BPDocuments.Source,
				"ApplicationID": "PD",
				"ObjectTypeID": DeletedData.ObjectTypeID,
				"DocumentID": oEvent.mParameters.documentId,
				"DocumentTypeID": DeletedData.DocumentTypeID
			};

			$.ajax({
				url: "/sap/opu/odata/ARTEC/ProcessDocument/ProcessDocument",
				type: methodType,
				data: JSON.stringify(data),
				dataType: "JSON",
				async: true,
				contentType: "application/json; charset=utf-8",
				success: function (data, textStatus, jqXHR) {
					that.dialog.close();
					if (data.ErrorCode === "") {
						setTimeout(function () {
							sap.m.MessageToast.show(data.Message);
						}, 10);
						that.getDocument();
					} else {
						var message = data.Message;
						oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
					}

					// gChFinancingView.byId("RFConfirmButton").setEnabled(true);
					// // if (gChFinancingView.getModel("LocalViewSetting").getProperty("/RejectionForRej")) {
					// that.sentRejectionMail(BPGUID);
					// // } else {
					// // 	that.displayRFSuccessDialog();
					// // }
				},
				error: function (xhr, status, e) {

					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					// var message = oi18n.getText("Currently.We.are.facing.some.issues.Please.try.after.sometime");
					// oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");

					busyDialog.close();
				}
			});

		},
		onFilenameLengthExceed: function (UploadCollection) {
			if (UploadCollection.mParameters.mParameters.fileName.length > 55) {
				var msg1 = oi18n.getText("File name Length Exceeded");
				oPPCCommon.displayMsg_MsgBox(this.getView(), msg1, "error");
			}
			if (this.onFilenameLengthExceed_Exit) {
				this.onFilenameLengthExceed_Exit();
			}
		},
		onBeforeUploadStarts: function (oEvent) {
			var sLoginID = this.getCurrentUsers("MaterialDocDocuments", "write");
			var oHeaderLoginId = new sap.m.UploadCollectionParameter({
				name: "x-arteria-loginid",
				value: sLoginID
			});
			var oHeaderSlug;
			var token = this._oComponent.getModel("SSGW_MM").getSecurityToken();

			var oHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});

			var DocTypeID = this._oComponent.getModel("LocalViewSetting").getProperty("/DocType");
			vIndex++;
			// var DocTypeDesc = this.DocType.getSelectedItem().getText().split(" - ")[1].trim();
			var sFileName = oEvent.mParameters.fileName;
			// ContractNo = this.getView().getModel("Contracts").getProperty("/ContractNo");
			// SchemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
			// SchemeGUID = SchemeGUID.split("-").join('');

			SchemeGUID = this._oComponent.getModel("LocalViewSetting").getProperty("/GRDocGuid").toUpperCase();

			SchemeGUID = SchemeGUID.split("-").join('');

			// var DocTypeID = this.getView().getModel("DocTypeDD").getData()[0].Key;
			var DocumentID = oPPCCommon.generateUUID().toUpperCase();
			DocumentID = DocumentID.split("-").join('');
			oHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: "MaterialDocGUID:" + SchemeGUID + ",DocumentStore:" + DocumentStore + ",MatDocDocumentGUID:" + DocumentID +
					",DocumentTypeID:" +
					DocTypeID + ",FileName:" +
					sFileName +
					",LoginID:" + sLoginID
			});
			oEvent.getParameters().addHeaderParameter(oHeaderToken);
			oEvent.getParameters().addHeaderParameter(oHeaderLoginId);
			oEvent.getParameters().addHeaderParameter(oHeaderSlug);

		},
		onUploadComplete: function (oEvent) {
			if (oEvent.getParameter("files")[0].status === 201) {
				this.getContractDocumentss(this._oComponent, oi18n.getText(
					"ContractAttachments.message.uploaded"));
				gUploadAttachments.setBusy(false);
			} else {
				var message = "";
				var response = oEvent.getParameter("files")[0].responseRaw;
				message = oPPCCommon.parseoDataXMLErrorMessage(response);
				this.getContractDocumentss(this._oComponent, oi18n.getText(
					"ContractAttachments.message.notuploaded") + message);
				gUploadAttachments.setBusy(false);
			}
		},
		getContractDocumentss: function (component, message) {
			var that = this;
			var SchemeDetails = gGRCreateView;
			var controllerthis = this;
			var mandatoryDocs = "";
			var DocumentTypeID = [];
			// this.DynamicSideContent = gGRCreateView.byId("ObjectPageLayout");
			var ContractDocumentsModel = component.getModel("SSGW_MM");
			var LoginID = controllerthis.getCurrentUsers("MaterialDocDocuments", "read");
			ContractDocumentsModel.attachRequestSent(
				function () {});
			ContractDocumentsModel.attachRequestCompleted(function () {});
			ContractDocumentsModel.setHeaders({
				"x-arteria-loginid": LoginID
			});

			ContractDocumentsModel.read("/MaterialDocDocuments", {
				filters: controllerthis.prepareContractDocumentsODataFilter(component, LoginID),
				success: function (oData) {
					oPPCCommon.removeAllMsgs();
					oPPCCommon.hideMessagePopover(gObjectPageLayout);
					// SchemeDetails.getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					// 	.getData().length);
					if (oData.results.length > 0) {
						var DocsModel = new sap.ui.model.json.JSONModel();
						for (var i = 0; i < oData.results.length; i++) {
							// var LoginIDz = controllerthis.getCurrentUsers("MaterialDocDocuments", "read");
							var sServiceURL = SchemeDetails.getModel("SSGW_MM").sServiceUrl;
							var SchemeGuid = "guid'" + oData.results[i].MaterialDocGUID + "'";
							var sUrl = sServiceURL + "/MaterialDocDocuments(MaterialDocGUID=" + SchemeGuid + ",MatDocDocumentGUID='" +
								oData.results[i].MatDocDocumentGUID + "',DocumentStore='" + oData.results[i].DocumentStore +
								"')/$value";
							oData.results[i].DocumentUrl = oPPCCommon.getDocumentURL({
								sServiceUrl: sUrl,
								sApplication: "PD"
							});
						}
						DocsModel.setData(oData.results);

						that._oComponent.getModel("LocalViewSetting").setProperty("/AttachmentCount", oData.results.length);
						// SchemeDetails.getModel("LocalViewSetting").setProperty("/AttachmentCount", oData.results.length);
						if (component.getModel("SchemeCPDocuments")) {
							component.getModel("SchemeCPDocuments").setProperty("/", []);
						}
						component.setModel(DocsModel, "SchemeCPDocuments");

					} else {
						that._oComponent.getModel("LocalViewSetting").setProperty("/AttachmentCount", "");
						if (component.getModel("SchemeCPDocuments")) {
							component.getModel("SchemeCPDocuments").setProperty("/", []);
							// SchemeDetails.getModel("LocalViewSetting").setProperty("/AttachmentCount", 0);

						}
					}
					vIndex--;
					if (vIndex === 0) {
						if (message) {
							setTimeout(function () {
								sap.m.MessageToast.show(message);
							}, 10);
						}
						gUploadAttachments.setBusy(false);

						oDialog.close();
					}
					gUploadAttachments.setBusy(false);
				},
				error: function (error) {
					if (component.getModel("MaterialDocDocuments")) {
						component.getModel("MaterialDocDocuments").setProperty("/", {});
					}
					oPPCCommon.removeAllMsgs();
					if (message) {
						setTimeout(function () {
							sap.m.MessageToast.show(message);
						}, 10);
					}
					if (DocumentStore === "A") {
						controllerthis.setMessageStrip(mandatoryDocs, component);

					}
					gUploadAttachments.setBusy(false);
					oDialog.close();
				}
			});
		},
		setMessageStrip: function (mandatoryDocs, component) {
			for (var k = 0; k < mandatoryDocs.length; k++) {
				if (mandatoryDocs[k].Count === 0) {
					if (mandatoryDocs === "") {
						mandatoryDocs = "'" + mandatoryDocs[k].Text + "'";
					} else {
						mandatoryDocs = mandatoryDocs + "," + "'" + gPOMandatoryDocType[k].Text + "'";
					}
				}
			}

			if (mandatoryDocs === "") {
				component.getModel("LocalAttachmentModel").setProperty("/MessageStripVisible", false);
			} else {
				var i18nProperty = "ContractAttachmentsA.ContractDocuments.DocTypeAttachmentMandatoryError";
				var msg = oi18n.getText(i18nProperty, mandatoryDocs);
				component.getModel("LocalAttachmentModel").setProperty("/MessageStripVisible", true);
				component.getModel("LocalAttachmentModel").setProperty("/MessageStripMessage", msg);
			}
		},
		prepareContractDocumentsODataFilter: function (component, LoginID) {
			// var schemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
			var schemeGUID = this._oComponent.getModel("LocalViewSetting").getProperty("/GRDocGuid").toUpperCase();

			// schemeGUID = "guid'" + schemeGUID + "'";
			var that = this;
			var oModelData = component.getModel("SSGW_MM");

			var ContractDocumentsFilters = new Array();
			ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "LoginID", "", [LoginID],
				false, false, false);
			ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "MaterialDocGUID", sap.ui
				.model
				.FilterOperator.EQ, [schemeGUID], true, false, false);

			ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui
				.model
				.FilterOperator.EQ, [DocumentStore], true, false, false);
			// ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui
			// 	.model
			// 	.FilterOperator.EQ, [DocumentStore], true, false, false);
			// ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui
			// 	.model
			// 	.FilterOperator.EQ, [DocumentStore], true, false, false);

			return ContractDocumentsFilters;
		},

		validateContractAttachments: function (UploadCollection) {
			var valid = true;
			var dcType = this._oComponent.getModel("LocalViewSetting").getProperty("/DocType");
			if (dcType === "") {
				var msg2 = "Select Document Type";
				var msgObj = oPPCCommon.addMsg_MsgMgr(msg2, "error", "FGroup_Attachment");
				valid = false;
			}
			if (UploadCollection.getItems().length === 0) {
				var msg2 = oi18n.getText("ContractAttachmentsA.Page.Upload.AttachmentErrorMsg");
				var msgObj = oPPCCommon.addMsg_MsgMgr(msg2, "error", "FGroup_Attachment");
				valid = false;
			}

			// for (var i = 0; i < UploadCollection.getItems().length; i++) {
			// 	var fType = UploadCollection.getItems()[i].mProperties.fileName.split(".")[1];
			// 	if (fType === "jpeg" || fType === "jpg" || fType === "png" || fType === "png" || fType === "doc") {

			// 	} else {
			// 		var msg2 = "Please Select Images";
			// 		var msgObj = oPPCCommon.addMsg_MsgMgr(msg2, "error", "FGroup_Attachment");
			// 		valid = false;
			// 	}
			// }

			// if (UploadCollection.getItems().length > 3) {
			// 	var msg2 = "Please select max 3 images";
			// 	var msgObj = oPPCCommon.addMsg_MsgMgr(msg2, "error", "FGroup_Attachment");
			// 	valid = false;
			// }

			// else {
			// 	setTimeout(function () {
			// 		var message = "Please Select png or doc File";
			// 		sap.m.MessageToast.show(message);
			// 	}, 0);
			// }

			return valid;
		},

		startUpload: function (UploadCollectionControl) {
			gUploadAttachments.setBusy(true);
			var oUploadCollection = UploadCollectionControl;
			var oHeaderMethod = new sap.m.UploadCollectionParameter({
				name: "type",
				value: "POST"
			});
			oUploadCollection.addHeaderParameter(oHeaderMethod);
			var url = this._oComponent.getModel("SSGW_MM").sServiceUrl + "/MaterialDocDocuments";
			var token = this._oComponent.getModel("SSGW_MM").getSecurityToken();

			var oHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});

			oUploadCollection.addHeaderParameter(oHeaderToken);
			oUploadCollection.addHeaderParameter(oHeaderMethod);
			oUploadCollection.setUploadUrl(url);
			oUploadCollection.upload();
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.sf.prsctform.view.PstDocument
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.sf.prsctform.view.PstDocument
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.sf.prsctform.view.PstDocument
		 */
		//	onExit: function() {
		//
		//	}

	});

});