sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ppc/utils/js/Common",
	"sap/m/MessageBox"
], function (Controller, oSSCommon, oPPCCommon, MessageBox) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oBusyDialog = new sap.m.BusyDialog();
	return Controller.extend("com.arteriatech.pc.survey.pcsurveyupd.controller.SurveyUploadList", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.pc.survey.pcsurveyupd.view.List
		 */
		onInit: function () {
			this.onInitHookUp();
		},
		onInitHookUp: function () {
			gObjectPageLayout = this.getView().byId("ObjectPageLayout_ID");
			gListView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gListView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.getDestinationProperties();
		},
		onClear: function () {
			var that = this;
			// gList.byId("Customer").setSelectedKey("");
			gList.byId("fileUploader").setValue("");
			gList.getModel("LocalViewSetting").setProperty("/ErrorCount", 0);
			gList.getModel("LocalViewSetting").setProperty("/TableCount", 0);
			// gList.getModel("LocalViewSetting").setProperty("/ErrorMessageLength", "");
			if (that._oComponent.getModel("ErrorLog")) {
				that._oComponent.getModel("ErrorLog").setProperty("/", []);
			}
			if (that._oComponent.getModel("CPConfigUploads"))
				that._oComponent.getModel("CPConfigUploads").setProperty("/", []);
			that.getView().getModel("LocalViewSetting").setProperty("/erroLogPage", false);
			that.getView().getModel("LocalViewSetting").setProperty("/reviewButton", false);
			that.getView().getModel("LocalViewSetting").setProperty("/ErrorVisible", false);
		},
		getDestinationProperties: function () {
			var that = this;
			var DestinationName = "PCGWHANA";
			if (oPPCCommon.getFLPTileAction().split("&")[0] === "Common") {
				DestinationName = "PCGWXCMNHANA";
			} else {
				DestinationName = "PCGWHANA";
			}
			var sUrl = "/sap/opu/odata/ARTEC/PCGW_UTILS/CPDestination";
			var mRequestData = [{}];
			mRequestData[0].destinationName = DestinationName;
			mRequestData[0].Application = "PD";
			mRequestData[0].Method = "read";
			mRequestData[0].IsTestRun = "";
			mRequestData[0].FmName = "";
			$.ajax({
				url: sUrl,
				type: "POST",
				dataType: "JSON",
				async: true,
				data: {
					destination: JSON.stringify(mRequestData)
				},
				success: function (data, textStatus, jqXHR) {
					if (data.destination[0].PCGWXCMNHANA !== undefined) {
						var gAggregatorID = data.destination[0].PCGWXCMNHANA.AggregatorID;
						that.getView().getModel("LocalViewSetting").setProperty("/AggregatorID", gAggregatorID);
					} else if (data.destination[0].PCGWHANA !== undefined) {
						var gAggregatorID = data.destination[0].PCGWHANA.AggregatorID;
						that.getView().getModel("LocalViewSetting").setProperty("/AggregatorID", gAggregatorID);
					}
				}
			});
		},
		confirmDialog: function () {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				stete: 'Warning',
				icon: 'sap-icon://message-warning',
				content: new sap.m.Text({
					text: oi18n.getText("PickListCreate.Popup.confirmation")
				}),
				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function () {
						oPPCCommon.removeAllMsgs();
						that.onClear();

						dialog.close();

					}
				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},
		validateData: function () {
			var that = this;
			that.validateItems();
		},

		validateItems: function () {
			var items = this.getView().getModel("CPConfigUploads").getData();
			if (items.length < 1) {
				oPPCCommon.addMsg_MsgMgr("Please add atleast one item", "error");
			}
			for (var i = 0; i < items.length; i++) {
				if (gList.byId("SelectGroupID").getSelectedIndex() === 0) {
					if (!items[i].SurveyTitle) {
						oPPCCommon.addMsg_MsgMgr("Please enter SurveyTitle for item " + (i + 1), "error");
					} else if (!items[i].SurveyTitle.length > 50) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid SurveyTitle for item " + (i + 1), "error");
					}
					if (!items[i].SurveyDesc) {
						oPPCCommon.addMsg_MsgMgr("Please enter SurveyDesc for item " + (i + 1), "error");
					} else if (!items[i].SurveyDesc.length > 200) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid SurveyDesc for item " + (i + 1), "error");
					}
					if (!items[i].ValidFrom) {
						oPPCCommon.addMsg_MsgMgr("Please enter ValidFrom for item " + (i + 1), "error");
					}
					if (!items[i].ApplicationCategory) {
						oPPCCommon.addMsg_MsgMgr("Please enter ApplicationCategory for item " + (i + 1), "error");
					} else if (!items[i].ApplicationCategory.length > 6) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid ApplicationCategory for item " + (i + 1), "error");
					}

				} else if (gList.byId("SelectGroupID").getSelectedIndex() === 1) {
					if (!items[i].SurveyGUID) {
						oPPCCommon.addMsg_MsgMgr("Please enter SurveyGUID for item " + (i + 1), "error");
					}
					if (!items[i].Question) {
						oPPCCommon.addMsg_MsgMgr("Please enter Question for item " + (i + 1), "error");
					}
					if (!items[i].IsRoot) {
						// oPPCCommon.addMsg_MsgMgr("Please enter IsRoot for item " + (i + 1), "error");
					} else if (!items[i].IsRoot.length > 1) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid IsRoot for item " + (i + 1), "error");
					}
					if (!items[i].Sequence) {
						// oPPCCommon.addMsg_MsgMgr("Please enter Sequence for item " + (i + 1), "error");
					}
					if (!items[i].QuestionLabel) {
						// oPPCCommon.addMsg_MsgMgr("Please enter QuestionLabel for item " + (i + 1), "error");
					} else if (!items[i].QuestionLabel.length > 10) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid QuestionLabel for item " + (i + 1), "error");
					}
					if (!items[i].QuestionCategory) {
						oPPCCommon.addMsg_MsgMgr("Please enter QuestionCategory for item " + (i + 1), "error");
					} else if (!items[i].QuestionCategory.length > 6) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid QuestionCategory for item " + (i + 1), "error");
					}

					if (items[i].IsMandatory) {
						if (items[i].IsMandatory.length > 1) {
							oPPCCommon.addMsg_MsgMgr("Please enter valid IsMandatory for item " + (i + 1), "error");
						}
					}
					if (items[i].MaxLength) {
						if (items[i].MaxLength.length > 4) {
							oPPCCommon.addMsg_MsgMgr("Please enter valid MaxLength for item " + (i + 1), "error");
						} else if (items[i].MaxLength.split(".").length > 1) {
							if (items[i].MaxLength.split(".")[1].length > 1) {
								oPPCCommon.addMsg_MsgMgr("Please enter valid MaxLength for item " + (i + 1), "error");
							}
						}
					}
					if (items[i].FieldType) {
						if (!items[i].FieldType.length > 6) {
							oPPCCommon.addMsg_MsgMgr("Please enter FieldType for item " + (i + 1), "error");
						}
					}
				} else if (gList.byId("SelectGroupID").getSelectedIndex() === 2) {
					if (!items[i].OptionID) {
						oPPCCommon.addMsg_MsgMgr("Please enter OptionID for item " + (i + 1), "error");
					} else if (!items[i].OptionID.length > 20) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid OptionID for item " + (i + 1), "error");
					}
					if (!items[i].Sequence) {
						oPPCCommon.addMsg_MsgMgr("Please enter Sequence for item " + (i + 1), "error");
					}
					if (!items[i].OptionText) {
						oPPCCommon.addMsg_MsgMgr("Please enter OptionText for item " + (i + 1), "error");
					} else if (!items[i].OptionText.length > 30) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid OptionText for item " + (i + 1), "error");
					}
					if (!items[i].OptionCategory) {
						oPPCCommon.addMsg_MsgMgr("Please enter OptionCategory for item " + (i + 1), "error");
					} else if (!items[i].OptionCategory.length > 6) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid OptionCategory for item " + (i + 1), "error");
					}
					if (!items[i].MaxLength) {
						// oPPCCommon.addMsg_MsgMgr("Please enter MaxLength for item " + (i + 1), "error");
					} else if (items[i].MaxLength.length > 4) {
						oPPCCommon.addMsg_MsgMgr("Please enter valid MaxLength for item " + (i + 1), "error");
					} else if (items[i].MaxLength.split(".").length > 1) {
						if (items[i].MaxLength.split(".")[1].length > 1) {
							oPPCCommon.addMsg_MsgMgr("Please enter valid MaxLength for item " + (i + 1), "error");
						}
					}
					if (items[i].FieldType) {
						if (!items[i].FieldType.length > 6) {
							oPPCCommon.addMsg_MsgMgr("Please enter FieldType for item " + (i + 1), "error");
						}
					}
				}
			}
		},

		onReview: function () {
			var that = this;
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(gObjectPageLayout);
			this.getView().getModel("LocalViewSetting").setProperty("/messageLength", 0);
			this.validateData();
			if (oPPCCommon.doErrMessageExist()) {
				that.getView().getModel("LocalViewSetting").setProperty("/ReviewMode", true);
				that.getView().getModel("LocalViewSetting").setProperty("/DetailMode", false);
				that.getView().getModel("LocalViewSetting").setProperty("/ReviewButton", true);
			} else {
				this.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);
				oPPCCommon.showMessagePopover(gObjectPageLayout);
			}
		},

		padDigits: function (number, digits) {
			return Array(Math.max(digits - String(number).length + 1, 0)).join(0) + number;
		},

		SurveyItemPost: function (HeaderData) {
			var that = this;
			var ItemData = {
				"SurveyGUID": HeaderData.SurveyGUID,
				"SurveyTitle": HeaderData.SurveyTitle,
				"SurveyDesc": HeaderData.SurveyDesc
			};
			var oModel = this._oComponent.getModel("PCGWHANA");
			oModel.create("/SurveyText", ItemData, {
				success: function (oData) {
					that.getView().setBusy(false);
				},
				error: function (error) {
					oBusyDialog.close();
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData().length);
					if (that.getView().getModel("LocalViewSetting").getProperty("/messageLength") > 0) {
						oPPCCommon.showMessagePopover(gObjectPageLayout);
					}
				}
			});
		},

		onSave: function () {
			var that = this;
			oBusyDialog.open();
			var LoginID = sap.ushell.Container.getService("UserInfo");
			var Pusers = LoginID.getId().toUpperCase();
			var TodayDae = new Date();
			var CurrentTime = "PT" + TodayDae.getHours() + "H" + TodayDae.getMinutes() + "M" + TodayDae.getSeconds() + "S";
			//Update model setting 
			var oModel = this._oComponent.getModel("PCGWHANA");
			if (oPPCCommon.getFLPTileAction().split("&")[0] === "Common") {
				oModel = this._oComponent.getModel("PCGWHANA");
			} else {
				oModel = this._oComponent.getModel("PCGWHANA");
			}
			oModel.setUseBatch(false);
			oModel.setDeferredBatchGroups(["createUserLoginTestRun"]);
			var oPartnerItemObj = this.getView().getModel("CPConfigUploads").getProperty("/");
			var oPartnerItem = $.map(oPartnerItemObj, function (value) {
				return [value];
			});
			if (gList.byId("SelectGroupID").getSelectedIndex() === 0) {
				if (oPartnerItem.length > 0) {
					var iSuccessCount = oPartnerItem.length;
					for (var i = 0; i < oPartnerItem.length; i++) {
						oPartnerItem[i].SurveyGUID = oPPCCommon.generateUUID().toUpperCase();
						oPartnerItem[i].CreatedBy = Pusers;
						oPartnerItem[i].CreatedAt = CurrentTime;
						oPartnerItem[i].CreatedOn = TodayDae;

						var HeaderData = {
							"SurveyGUID": oPartnerItem[i].SurveyGUID,
							"SurveyCategory": oPartnerItem[i].SurveyCategory,
							"ApplicationCategory": oPartnerItem[i].ApplicationCategory,
							"ValidFrom": oPartnerItem[i].ValidFrom,
							"ValidTo": oPartnerItem[i].ValidTo,
							"SurveyType": oPartnerItem[i].SurveyType,
							"Status": "",
							"CreatedBy": Pusers,
							"CreatedAt": CurrentTime,
							"CreatedOn": TodayDae,
							"Source": "PORTAL"
						};

						oModel.setHeaders({
							"x-arteria-loginid": this.getCurrentUsers("Survey", "read")
						});

						oModel.create("/Survey", HeaderData, {
							success: function (oData) {
								that.getView().setBusy(false);
								iSuccessCount--;
								that.SurveyItemPost(oPartnerItem[iSuccessCount]);
								if (iSuccessCount === 0) {
									oBusyDialog.close();
									that.displaySuccessMessage("Data Posted Successfully.");
								}
							},
							error: function (error) {
								oBusyDialog.close();
								oPPCCommon.removeDuplicateMsgsInMsgMgr();
								that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData().length);
								if (that.getView().getModel("LocalViewSetting").getProperty("/messageLength") > 0) {
									oPPCCommon.showMessagePopover(gObjectPageLayout);
								}
							}
						});
					}
				}
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 1) {
				if (oPartnerItem.length > 0) {
					var iSuccessCount = oPartnerItem.length;
					for (var i = 0; i < oPartnerItem.length; i++) {
						oPartnerItem[i].QuinSrvGUID = oPPCCommon.generateUUID().toUpperCase();
						oPartnerItem[i].CreatedBy = Pusers;
						oPartnerItem[i].CreatedAt = CurrentTime;
						oPartnerItem[i].CreatedOn = TodayDae;
						oPartnerItem[i].Status = "X";
						delete oPartnerItem[i].ItemNo;
						delete oPartnerItem[i].ErrorDesc;
						delete oPartnerItem[i].DistributorCode;
						delete oPartnerItem[i].DistributorName;
						delete oPartnerItem[i].CustomerCodeConversion;
						delete oPartnerItem[i].MaterialCodeConversion;
						delete oPartnerItem[i].SRCutoffDate;
						oModel.setHeaders({
							"x-arteria-loginid": this.getCurrentUsers("SurveyHdr", "read")
						});
						oModel.create("/SurveyHdr", oPartnerItem[i], {
							success: function (oData) {
								that.getView().setBusy(false);
								iSuccessCount--;
								if (iSuccessCount === 0) {
									oBusyDialog.close();
									that.displaySuccessMessage("Data Posted Successfully.");
								}
							},
							error: function (error) {
								oBusyDialog.close();
								oPPCCommon.removeDuplicateMsgsInMsgMgr();
								that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData().length);
								if (that.getView().getModel("LocalViewSetting").getProperty("/messageLength") > 0) {
									oPPCCommon.showMessagePopover(gObjectPageLayout);
								}
							}
						});
					}
				}
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 2) {
				if (oPartnerItem.length > 0) {
					var iSuccessCount = oPartnerItem.length;
					for (var i = 0; i < oPartnerItem.length; i++) {
						oPartnerItem[i].QuinSrvOptGUID = oPPCCommon.generateUUID().toUpperCase();
						oPartnerItem[i].CreatedBy = Pusers;
						oPartnerItem[i].CreatedAt = CurrentTime;
						oPartnerItem[i].CreatedOn = TodayDae;
						delete oPartnerItem[i].ItemNo;
						delete oPartnerItem[i].ErrorDesc;
						delete oPartnerItem[i].DistributorCode;
						delete oPartnerItem[i].DistributorName;
						delete oPartnerItem[i].CustomerCodeConversion;
						delete oPartnerItem[i].MaterialCodeConversion;
						delete oPartnerItem[i].SRCutoffDate;
						oModel.setHeaders({
							"x-arteria-loginid": this.getCurrentUsers("SurveyItm", "read")
						});
						oModel.create("/SurveyItm", oPartnerItem[i], {
							success: function (oData) {
								that.getView().setBusy(false);
								iSuccessCount--;
								if (iSuccessCount === 0) {
									oBusyDialog.close();
									that.displaySuccessMessage("Data Posted Successfully.");
								}
							},
							error: function (error) {
								oBusyDialog.close();
								oPPCCommon.removeDuplicateMsgsInMsgMgr();
								that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData().length);
								if (that.getView().getModel("LocalViewSetting").getProperty("/messageLength") > 0) {
									oPPCCommon.showMessagePopover(gObjectPageLayout);
								}
							}
						});
					}
				}
			} else if (gList.byId("SelectGroupID").getSelectedIndex() === 4) {
				if (oPartnerItem.length > 0) {
					var iSuccessCount = oPartnerItem.length;
					for (var i = 0; i < oPartnerItem.length; i++) {
						oPartnerItem[i].SurveyGeoGUID = oPPCCommon.generateUUID().toUpperCase();
						var HeaderData = {
							"SurveyGeoGUID": oPartnerItem[i].SurveyGeoGUID,
							"SurveyGUID": oPartnerItem[i].SurveyGUID,
							"GeoType": oPartnerItem[i].GeoType,
							"GeoValue": oPartnerItem[i].GeoValue,
							"GeoDesc": oPartnerItem[i].GeoDesc,
							"CreatedBy": Pusers,
							"CreatedAt": CurrentTime,
							"CreatedOn": TodayDae,
							"Source": "PORTAL"
						};

						oModel.setHeaders({
							"x-arteria-loginid": this.getCurrentUsers("SurveyGeo", "read")
						});

						oModel.create("/SurveyGeo", HeaderData, {
							success: function (oData) {
								that.getView().setBusy(false);
								iSuccessCount--;
								if (iSuccessCount === 0) {
									oBusyDialog.close();
									that.displaySuccessMessage("Data Posted Successfully.");
								}
							},
							error: function (error) {
								oBusyDialog.close();
								oPPCCommon.removeDuplicateMsgsInMsgMgr();
								that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData().length);
								if (that.getView().getModel("LocalViewSetting").getProperty("/messageLength") > 0) {
									oPPCCommon.showMessagePopover(gObjectPageLayout);
								}
							}
						});
					}
				}

			}
		},
		showPopUp: function () {
			var that = this;
			that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			oPPCCommon.showMessagePopover(gObjectPageLayout);
		},
		onBack: function (oEvent) {
			var that = this;
			that.getView().getModel("LocalViewSetting").setProperty("/ReviewMode", false);
			that.getView().getModel("LocalViewSetting").setProperty("/DetailMode", true);
		},
		displaySuccessMessage: function (sMessage) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Success',
				type: 'Message',
				state: 'Success',
				content: new sap.m.Text({
					text: sMessage
				}),
				buttons: [
					new sap.m.Button({
						icon: "sap-icon://home",
						text: "Home",
						press: function () {
							window.location = "#";
							dialog.close();
						}
					}),
					new sap.m.Button({
						text: 'Upload New',
						press: function () {
							that.getView().getModel("LocalViewSetting").setProperty("/ReviewMode", false);
							that.getView().getModel("LocalViewSetting").setProperty("/DetailMode", true);
							oPPCCommon.removeAllMsgs();
							that.onClear();
							//	window.location.reload(true);
							dialog.close();
						}
					})
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
			dialog.attachBrowserEvent("keydown", function (oEvent) {
				oEvent.stopPropagation();
				oEvent.preventDefault();
			});
		},
	});

});