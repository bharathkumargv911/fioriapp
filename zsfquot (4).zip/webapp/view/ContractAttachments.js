sap.ui.define(["sap/uxap/BlockBase"], function(BlockBase) {
	"use strict";
	var myBlock = BlockBase.extend("com.arteriatech.zsf.quot.view.ContractAttachments", {
		metadata: {}
	});
	return myBlock;
}, true);