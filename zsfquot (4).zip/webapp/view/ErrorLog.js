sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";
	var stockBlock = BlockBase.extend("com.arteriatech.zsf.quot.view.ErrorLog", {
		metadata: {}
	});
	return stockBlock;
}, true);

