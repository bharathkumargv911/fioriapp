sap.ui.define(["sap/uxap/BlockBase"], function(BlockBase) {
	"use strict";
	var myBlock = BlockBase.extend("com.arteriatech.zsf.quot.view.DetailPageHeader", {
		metadata: {}
	});
	return myBlock;
}, true);