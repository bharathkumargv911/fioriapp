//sort the table by using table reference
function sortAndFilterTable(table,oEvent) {
	  var p = oEvent.getParameters();
	  var oBinding = table.getBinding("items");

	    // 1) apply sorter to binding
	    // (grouping comes before sorting)
	    var aSorters = [];
	    if (p.groupItem) {
	      var sPath = p.groupItem.getKey();
	      var bDescending = p.groupDescending;
	      var vGroup = this.mGroupFunctions[sPath];
	      aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, vGroup));
	    }
	    if (p.sortItem) {
		    var sPath = p.sortItem.getKey();
		    var bDescending = p.sortDescending;
		    var oSorter = new sap.ui.model.Sorter(sPath, bDescending)
		    // for number comparision
			oSorter.fnCompare = function(value1, value2) {
		    	if(isNumber(value1) && isNumber(value2)){
					value2 = parseFloat(value2);
					value1 = parseFloat(value1);
					if (value1 < value2) return -1;
					if (value1 == value2) return 0;
					if (value1 > value2) return 1;
		    	}
		    	if (typeof value1 == "string" && typeof value2 == "string") {
		    		  return value1.localeCompare(value2);
		    	}
			};
		    aSorters.push(oSorter);
	    }
	    
	    // 2) filtering (standard/custom filters)
	    // apply filters to binding
		var oFilters,
		oCallback,
		customInputControl,
		oItem,
		filterStrArr = "Filtered by: ";
		aTableFilters = [],
		customFilters = [],
		toolBarVal = "",
		key = "",
		customContrlText = "";
		filterVal = "",
		i = 0;
		for (; i < p.filterItems.length; i++) {
			if (p.filterItems[i] instanceof sap.m.ViewSettingsCustomItem) {
				customInputControl = p.filterItems[i].getCustomControl(); 
				key = customInputControl.getTooltip();
				customContrlText = p.filterItems[i].getText();
				if(customInputControl instanceof sap.m.Select){
					filterVal = customInputControl.getSelectedKey();
					customFilters.push(new sap.ui.model.Filter(key, sap.ui.model.FilterOperator.EQ, filterVal, "X"));
					filterVal = customInputControl.getSelectedItem().getText();
				}
				else if(customInputControl instanceof sap.m.DatePicker){
					filterVal = customInputControl.getValue();
					//var jsonDate =convertToJSONDate(filterVal);
					var dt = new Date(filterVal);
					customFilters.push(new sap.ui.model.Filter(key, sap.ui.model.FilterOperator.EQ, dt, "X"));
				}else{
					filterVal = customInputControl.getValue();
					customFilters.push(new sap.ui.model.Filter(key, sap.ui.model.FilterOperator.Contains, filterVal, "X"));
				}
				
				oFilters = customFilters;
				if (oFilters) {
					// the filter could be an array of filters or a single filter so we transform it to an array
					if (!Array.isArray(oFilters)) {
						oFilters = [oFilters];
					}
					aTableFilters = aTableFilters.concat(oFilters);
					//setting filter string to display on toolbar
					filterStrArr = filterStrArr + " "+customContrlText+"("+filterVal+")";
					
				}
			} else if (p.filterItems[i] instanceof sap.m.ViewSettingsItem) { // standard filter
				      oItem = p.filterItems[i];
				      var aSplit = oItem.getKey().split("___");
				      var sPath = aSplit[0];
				      var sOperator = aSplit[1];
				      var sValue1 = aSplit[2];
				      var sValue2 = aSplit[3];
				      var oFilter = new sap.ui.model.Filter(sPath, sOperator, sValue1, sValue2);
				      customContrlText = p.filterItems[i].getText();
				      filterStrArr = filterStrArr + " "+customContrlText+"("+sValue1+","+sValue2+")";
				      aTableFilters.push(oFilter);
			}
		}
		if(filterStrArr != "Filtered by: ")
		p.filterString = filterStrArr;
		// apply sorters & filters to the table binding
		oBinding.sort(aSorters);
		oBinding.filter(aTableFilters);
	    
		// update table info bar text (show only if we have a text & set text to label)
		table.getInfoToolbar().setVisible(!!p.filterString);
		table.getInfoToolbar().getContent()[0].setText(p.filterString);
 
}


function addCustomControlToFilter(oEvent){
	  var source = oEvent.getSource();
	  var inputKey =source.getTooltip();
	  var vsd = sap.ui.getCore().byId(source.getParent().getParent().getId().substr(0,4));	
	  var filters = vsd.getFilterItems();
	  var customFilter;
	
	for(var i = 0; i < filters.length; i++) {
		if(filters[i] instanceof sap.m.ViewSettingsCustomItem && filters[i].getKey() === inputKey) {
			customFilter = filters[i];
			vsd.attachResetFilters(customReset);
			vsd.attachCancel(customCancel);
			break;
		}
	}

	if(customFilter) {
		if(source instanceof sap.m.Select){
			customFilter.setSelected(true);
			customFilter.setFilterCount(1);
		}
		else if(oEvent.getParameter("value") !== null && oEvent.getParameter("value").trim() !== "" ) {
			customFilter.setSelected(true);
			customFilter.setFilterCount(1);
		} 
		else {
			customFilter.setSelected(false);
			customFilter.setFilterCount(0);
		}
	}
}

var customReset = function (oEvent) {
	var source = oEvent.getSource(),
		filters = source.getFilterItems(),
		customControl,
		customFilter,
		i = 0; 
	// this functionality only needed because custom control is cloned for this test page
	// if you don't have cloned controls you can directly access them by id and set/reset the values
	for(; i < filters.length; i++) {
		if(filters[i] instanceof sap.m.ViewSettingsCustomItem) {
			customFilter = filters[i];
			customControl = customFilter.getCustomControl();
			customControl.setValue("");
			customFilter.setSelected(false);
			customFilter.setFilterCount(0);
		}
	}
	/* if(customFilter) {
		customFilter.setSelected(false);
		customFilter.setFilterCount(0);
	}
	if(customControl) {
		customControl.setValue("");
	} */
};
var customCancel = customReset;
//returns true is object is number
function isNumber(obj) { return !isNaN(parseFloat(obj)) }
//03/25/1015 to (/Date(1427846400000)/)
function convertToJSONDate(strDate){
	var dt = new Date(strDate);
    var newDate = new Date(Date.UTC(dt.getFullYear(), dt.getMonth(), dt.getDate(), dt.getHours(), dt.getMinutes(), dt.getSeconds(), dt.getMilliseconds()));
    return '/Date(' + newDate.getTime() + ')/';
}
//(/Date(1427846400000)/) to 25/03/1015
function fromJsonToDate(fValue) {
 	  if(fValue)
 		  {
 		  var sJsonDate = fValue;/\/(.+)\//.exec(sJsonDate);  
 		  var oDate = eval("new " + RegExp.$1); 
 		  var day 	= ('0'+(oDate.getDate())).slice(-2);
		      var month = ('0'+(oDate.getMonth()+1)).slice(-2);
		      var year 	= oDate.getFullYear();
		      var date 	= day+"/"+month+"/"+year;
     	  return date;
 		  }
 	     else {
	       return "";
	     }
	}