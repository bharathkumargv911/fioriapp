//date format from Json format
		function date(fValue) {
	   	  if(fValue)
	   		  {
	   		  var sJsonDate = fValue;/\/(.+)\//.exec(sJsonDate);  
	   		  var oDate = eval("new " + RegExp.$1); 
	   		  var day 	= ('0'+(oDate.getDate())).slice(-2);
			      var month = ('0'+(oDate.getMonth()+1)).slice(-2);
			      var year 	= oDate.getFullYear();
			      var date 	= day+"/"+month+"/"+year;
	       	  return date;
	   		  }
	   	     else {
		       return "";
		     }
		}
		function checkToDateLNFromDate(date1, date2)
		{
			var dateFrom =new Date(date1);
			var dateTo =new Date(date2);
			dateFrom.setHours(0,0,0,0);
			dateTo.setHours(0,0,0,0);
			var diffDays = (dateTo - dateFrom)/(1000*60*60*24); 
			var valid = false;
			/*
			if(diffDays<=-1)
			 {
				valid = false;
			}
			return valid;*/
			if(diffDays<0)
			 {
				valid = true;
			}
			/* else if(diffDays>0)
			{
			  
			   return false;
			}
			 else
				 {
				 return true;
				 }*/
			return valid;
		}
		//Future Date
		function checkFutureDate(value)
		{
			var CurrentDate = new Date();
			var dateFrom =new Date(value);
			CurrentDate.setHours(0,0,0,0);
			dateFrom.setHours(0,0,0,0);
		    var dateDifference = (CurrentDate - dateFrom)/(1000*60*60*24);
		   var valid = false;
		   /*   if(dateDifference >=1)
	    	{
	    	valid = false;
	    	}
		    return valid; */
		    if(dateDifference <0)
	    	{
		    	valid =  true;
	    	}
		    	return valid;
		}
		function checkPastDate(deliveryDate){
		    var currentDate = new Date();
		    var difference = ((currentDate - deliveryDate)/(1000*60*60*24));
		    var valid = true;
		    if(difference >= 1)
		    {
		    	valid=false;
		    }
		    return valid; 
		}
		function getCurrentDate() {
				return new Date();
		}
		function getDate(value) {
			var date = new Date();
			date.setDate(date.getDate() - value);
			return date;
		}
		function after30daysDate() {
			var cur = new Date();
		    cur.setDate(cur.getDate() + 30);
			return cur;
		}
		function validateDate(fValue) 
		{
			re = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
		    if(fValue != '' && !fValue.match(re)) {
		      return false;
		    }
		    else
	    	{
	    	 return true;
	    	}
			
		}
		function dateValueHdr(fValue) {

			if(fValue)
			{
				var sJsonDate = fValue;/\/(.+)\//.exec(sJsonDate);  
				var oDate = eval("new " + RegExp.$1); 
				var day 	= ('0'+(oDate.getDate())).slice(-2);
				var month = ('0'+(oDate.getMonth()+1)).slice(-2);
				var year 	= oDate.getFullYear();
				var date 	= day+"/"+month+"/"+year;
				return date;
			}

		}
		function validByDatesDifference(date1,date2,noOfDays){
        	var dateFrom =new Date(date1);
			var dateTo =new Date(date2);	
			var diffDays = (dateTo - dateFrom)/(1000*60*60*24); 
			var valid = false;
        	if(diffDays <= noOfDays){
        		valid = true;
        	}
			return valid;
		}
		//convering date to 2015-03-27T00:00:00
		function getOdataDateFormat(oInputDate){
			  var oInputDate_var = oInputDate.toString();
			  //Changing the From date format
			  var oInputDateArr = oInputDate_var.split(" ");
			  var odateNum = oInputDateArr[2];
			  var oMonthStr = "JanFebMarAprMayJunJulAugSepOctNovDec".indexOf(oInputDateArr[1]) / 3 + 1 ;
			  var oMonthNum = "00"+oMonthStr;
			  oMonthNum = oMonthNum.slice(-2);
			  var oYearNum = oInputDateArr[3];
			  return oYearNum+"-"+oMonthNum+"-"+odateNum+"T00:00:00";
		}
		function validateEmail(email) {
		    var re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		    return re.test(email);
		}
		function validateMobile(phone) {
		    var re = /^\+?([0-9]{2})\)?[-. ]?([0-9]{4})[-. ]?([0-9]{4})$/;
		    return re.test(phone);
		}
		function validateLandline(landline) {
		    var re = /^(?:(?:\(?(?:00|\+)([1-4]\d\d|[1-9]\d?)\)?)?[\-\.\ \\\/]?)?((?:\(?\d{1,}\)?[\-\.\ \\\/]?){0,})(?:[\-\.\ \\\/]?(?:#|ext\.?|extension|x)[\-\.\ \\\/]?(\d+))?$/i;
		    return re.test(landline);
		}
		function validPostalCode(postalCode){
			var re = (/^-?\d*(\.\d+)?$/);
			return re.test(postalCode);
		}	
		//opens popup here, to display the error message, mainly for validations
		function errorPopUp(messageArea){
			 sap.ca.ui.message.showMessageBox({
	              type: sap.ca.ui.message.Type.ERROR,

	              message: messageArea.getText(),
	      });
		}
		function amountFormat(fValue) {
			   if(fValue)
			   {
			    /*var amnt = parseFloat(fValue).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
			    var x = amnt;
			    var res = x;
			    if(x.length>6){
			     x=x.toString();
			     var lastThree = x.substring(x.length-6);
			     var otherNumbers = x.substring(0,x.length-6);
			     if(otherNumbers != '')
			      res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;*/
				   
				   var sCurrentLocale = sap.ui.getCore().getConfiguration().getLanguage();
				   fValue.toLocaleString(sCurrentLocale);
			    return fValue;
			   }
		}
		function checkNull(value)
		{
		    if(value == undefined || value == "")
		      {
		     return true;
		      }
		    else
		     {
		     return false;
		     }
		 }
		//ajax error message
		function displayErrorMsg(err){
			/* var msgSize= err.responseJSON.error.innererror.errordetails.length;
		     var oMessage = ""; var dupMsg = ""; var backendMsg = "";
		     for(var i=0;i<msgSize;i++)
		      {
		    	 backendMsg = "";
		    	 if(dupMsg != backendMsg){
		    	 oMessage=oMessage+"\n"+err.responseJSON.error.innererror.errordetails[i].message;
		    	 }
		    	 dupMsg = err.responseJSON.error.innererror.errordetails[i].message;
		      }
		     jQuery.sap.require("sap.ca.ui.message.message");  
		     sap.ca.ui.message.showMessageBox({type: sap.ca.ui.message.Type.ERROR, message:oMessage});  */
			if(err != null && err != undefined && err != ""){
			var displayMsg = "";
			var msg = "<html>";
			
			if(err.responseText.startsWith(msg)){
				parser=new DOMParser();
				htmlDoc=parser.parseFromString(err.responseText, "text/html");
				var h2Arr = htmlDoc.getElementsByTagName('H2');
				displayMsg = h2Arr[0].innerHTML;
			}
			else{
					   var msgSize= err.responseJSON.error.innererror.errordetails.length;
				       var oMessage = ""; 
				       var msgArr = err.responseJSON.error.innererror.errordetails;
				       
				       
				       var arr = {};
				       for ( var i=0; i < msgArr.length; i++ )
				           arr[msgArr[i]['message']] = msgArr[i];
		
				       msgArr = new Array();
				       for ( var key in arr )
				        msgArr.push(arr[key]);
				      
				       for(var i=0;i<msgArr.length;i++)
				        {
				        oMessage = msgArr[i].message;
				        displayMsg = displayMsg+"\n"+oMessage;
				         }  
			}
		       jQuery.sap.require("sap.ca.ui.message.message");  
		       sap.ca.ui.message.showMessageBox({type: sap.ca.ui.message.Type.ERROR, message:displayMsg});  
			}
		}
		//ajax success message
		function displaySuccMsg(message){
			  var xml= message["sap-message"];
			  var $doc = $.parseXML(xml);
			  var attr = $($doc).find('message');
			  var msg = attr[0].innerHTML;
			  new  sap.ca.ui.message.showMessageBox({
			   type: sap.ca.ui.message.Type.SUCCESS,
			   message: msg,
			  });
		}
		//oData error message
		function displayErrMsg(error){
			  var message=error.response;
		      var xml=message["body"];
		      var $doc = $.parseXML(xml);
		      var attr = $($doc).find('message');
		      var oMessage ="";  var displayMsg = "";
		        
		      var arr = {};
		       for ( var i=0; i < attr.length; i++ )
		           arr[attr[i]['innerHTML']] = attr[i];

		       attr = new Array();
		       for ( var key in arr )
		        attr.push(arr[key]);
		      
		       for(var i=0;i<attr.length;i++)
		        {
		        oMessage = attr[i].innerHTML;
		        displayMsg = displayMsg+"\n"+oMessage;
		    } 
		      
		      new  sap.ca.ui.message.showMessageBox({
		         type: sap.ca.ui.message.Type.ERROR,
		         message: displayMsg,
		      });
		}
		//open new window to see the pdf, which is coming from backend
		function printPdf(loginUrl)
		 {
		     window.open(loginUrl,'winname','directories=no,titlebar=no,navigationtoolbar=no,addressbar=no,toolbar=no,location=no,status=no,menubar=no,scrollbars=no,resizable=no');
		 }
		//json date format
		function formatJDate(aData,dateArr){
			var dateStr = "";
			for(var j=0; j<dateArr.length; j++){
				dateStr = "";
				dateStr = dateArr[j];
			     for(var i=0; i<aData.length; i++ )
			     {
			      var fValue=aData[i][dateStr];
			      if(fValue != null && fValue != "" && fValue != undefined){
			    	  var sJsonDate = fValue;/\/(.+)\//.exec(sJsonDate);  
			    	  var oDate = eval("new " + RegExp.$1); 
			    	  oDate.setHours("00");
			    	  oDate.setMinutes("00");
			    	  oDate.setSeconds("00");
			    	  aData[i][dateStr]=oDate;
			      }
			     }
			}
		    return aData;
		}
		
		function formatAmount (fAmount, fCurr) {
			   
			   return sap.ca.ui.model.format.AmountFormat.getInstance("","").format(fAmount);
			  }
		
		function formatQty(fQty, fUOM) {
			   
			   return sap.ca.ui.model.format.QuantityFormat.getInstance("","").format(fQty);
			  }
		function endsWith(str, suffix) {
		    return str.indexOf(suffix, str.length - suffix.length) !== -1;
		}
		function toInteger(stringVal){
			if(stringVal != null)
			return parseInt(stringVal);
		}
		function toDecimal(stringVal){
			if(stringVal != null)
			return parseDecimal(stringVal);
		}
		/*function getTokenForSingleInput(view,fieldId)
		{
			var oMultiInputObj = view.byId(fieldId);
			//this one supports only one token in the field
			oMultiInputObj.addValidator(function(args){
				oMultiInputObj.removeAllTokens();
			    var oToken = new sap.m.Token({key: args.text, text: args.text});
			    args.asyncCallback(oToken);
			    return sap.m.MultiInput.WaitForAsyncValidation;
			  });
		 }
		function getTokenForMultipleInput(view,fieldId)
		{
			var oMultiInputObj = view.byId(fieldId);
			//this one supports only one token in the field
			oMultiInputObj.addValidator(function(args){
			    var oToken = new sap.m.Token({key: args.text, text: args.text});
			    args.asyncCallback(oToken);
			    return sap.m.MultiInput.WaitForAsyncValidation;
			  });
	     }*/
		 function getTokenForSingleInput(args, oMultiInputObj,url,desc)
			{
	        	var oDialog = new sap.m.BusyDialog();
	        	oDialog.open();
					$.ajax({       
				           url :url,
				           jsonpCallback : 'getJSON',    
				           contentType : "application/json",    
				           dataType : 'json', 
				           //async : false,
				           success : function(data, textStatus, jqXHR) 
				           {    
				        	   oMultiInputObj.removeAllTokens();
					            var oModel1 = new sap.ui.model.json.JSONModel();    
					            oModel1.setData(data); 
					            var aData = oModel1.getProperty("/d/results"); 
					            var oToken = "";
					            if(desc == "" || desc == null || desc == undefined){
					            	oToken = new sap.m.Token({key: args.text, text: args.text});
					            }else{
					            	if(aData[0][desc] == undefined && aData[0][desc] == "" ){
					            		oToken = new sap.m.Token({key: args.text, text: args.text});
					            	}else{
					            		oToken = new sap.m.Token({key: args.text, text: aData[0][desc]+" ("+args.text+")"});
					            	}
					            }
							   args.asyncCallback(oToken);
							   oDialog.close();
							    return sap.m.MultiInput.WaitForAsyncValidation;
				           },
				           error : function (err){ 
				        	   oDialog.close();
				               displayErrorMsg(err);
				           }
				   });
			 }
		 function getTokenForMultipleInput(args, oMultiInputObj,url,desc)
			{
	        	var oDialog = new sap.m.BusyDialog();
	        	oDialog.open();
					$.ajax({       
				           url :url,
				           jsonpCallback : 'getJSON',    
				           contentType : "application/json",    
				           dataType : 'json', 
				          // async : false,
				           success : function(data, textStatus, jqXHR) 
				           {  
				        	   
				        	   
				        	   
					            var oModel1 = new sap.ui.model.json.JSONModel();    
					            oModel1.setData(data); 
					            var aData = oModel1.getProperty("/d/results"); 
					            if(aData.length == 0)
				        		   {
					            	oDialog.close();
					            	return;
				        		   }
					            
					            var oToken = "";
					            if(desc == "" || desc == null || desc == undefined){
					            	oToken = new sap.m.Token({key: args.text, text: args.text});
					            }else{
					            	if(aData[0][desc] == undefined && aData[0][desc] == "" ){
					            		oToken = new sap.m.Token({key: args.text, text: args.text});
					            	}else{
					            		oToken = new sap.m.Token({key: args.text, text: aData[0][desc]+" ("+args.text+")"});
					            	}
					            }
							   args.asyncCallback(oToken);
							   oDialog.close();
							    return sap.m.MultiInput.WaitForAsyncValidation;
				           },
				           error : function (err){ 
				        	   oDialog.close();
				               displayErrorMsg(err);
				           }
				   });
			 }