/*
 * Copyright (C) 2015-2016 Arteria Technologies Pvt. Ltd. All rights reserved
 */
jQuery.sap.declare("com.arteriatech.ss.cp.create1.util.CPStatusFormatter");
com.arteriatech.ss.cp.create1.util.CPStatusFormatter = {};

com.arteriatech.ss.cp.create1.util.CPStatusFormatter.formatCPStatusImage=function (fValue){      
	var img ;  
	if(fValue === '01')
	{
		img = "sap-icon://status-positive";
		return img;
	}
	else if(fValue === '02')
	{
		img = "sap-icon://status-inactive";
	return img;
	}
	
	
};
function toInteger(stringVal){
	if(stringVal != null)
		return parseInt(stringVal);
};

com.arteriatech.ss.cp.create1.util.CPStatusFormatter.formatCPStatusState=function(val)
{
	var returnVal = "None";
	if(val === '02')
	{
		returnVal = "Error";
	}
	else if(val === '01')
	{
		returnVal = "Success";
	}

	return returnVal;
};
com.arteriatech.ss.cp.create1.util.CPStatusFormatter.formatAppStatusIcon=function (fValue){      
	var img ;  
	if(fValue === '02')
	{
		img = "sap-icon://pending";
		return img;
	}
	else if(fValue === '03')
	{
		img = "sap-icon://employee-approvals";
		return img;
	} else if(fValue === '01')
	{
		img = "sap-icon://status-inactive";
		return img;
	}else if(fValue === '04') {
		img = "sap-icon://employee-rejections";
		return img;
	}
};


com.arteriatech.ss.cp.create1.util.CPStatusFormatter.formatAppStatusState=function(val)
{
	var returnVal = "None";
	if(val == '01' || val == '03')
	{
		returnVal = "Success";
	}
	else if(val == '02' || val == '04')
	{
		returnVal = "Error";
	}

	return returnVal;
};
com.arteriatech.ss.cp.create1.util.CPStatusFormatter.formatText=function (desc,id)
{
 var text="";
 if((id!=="" && desc!=="")|| (id!==undefined && desc!==undefined))
 {
  if(id==="" || id===undefined)
  {
   text=desc;
  }
  else
  {
   text=desc+" "+":"+id+"";
  }
 }
 else
 {
  text="";
 }
 return text;
};