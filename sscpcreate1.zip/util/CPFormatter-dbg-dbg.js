jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require('sap.m.MessageBox');
jQuery.sap.require("sap.ca.ui.message.message");  
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.declare("com.arteriatech.ss.cp.util.CPFormatter");
//date format from Json format
com.arteriatech.ss.cp.util.CPFormatter = {};
com.arteriatech.ss.cp.util.CPFormatter.formatImage = function(fValue){      
	var img ;  
	if(fValue == '01')
	{
		img = 'sap-icon://task';
		return img;
	}
	if(fValue == '02')
	{
		img = 'sap-icon://status-in-process';
		return img;
	}
	if(fValue == '03')
	{
		img = 'sap-icon://home';
		return img;
	}
	if(fValue == '04')
	{
		img = 'sap-icon://status-error';
		return img;
	}
}

com.arteriatech.ss.cp.util.CPFormatter.formatImageColor = function(fValue){      
	var img ;  
	if(fValue == '01')
	{
		img = "Error";
		return img;
	}
	if(fValue == '02')
	{
		img = "Warning";
		return img;
	}
	if(fValue == '03')
	{
		img = "Success";
		return img;
	}
	if(fValue == '04')
	{
		img = "Error";
		return img;
	}
}
com.arteriatech.ss.cp.util.CPFormatter.formatIsEscalatedImageColor = function(fValue) {
	var img;
	if (fValue === true) {
		img = "Error";
		return img;
	} else if (fValue === false) {
		img = "Success";
		return img;
	}
}
com.arteriatech.ss.cp.util.CPFormatter.isEscalated = function(fValue) {
	var img;
	if (fValue === true) {
		img = "sap-icon://status-negative";
		return img;
	} else if (fValue === false) {
		img = "";
		return img;
	}
}
com.arteriatech.ss.cp.util.CPFormatter.StatusPriority = function(fValue) {
	var img;
	if (fValue === "1" || fValue === "2") {
		img = "sap-icon://status-negative";
		return img;
	} else if (fValue === "3" || fValue === "4") {
		img = "sap-icon://status-critical";
		return img;
	} else if (fValue === "5") {
		img = "sap-icon://status-inactive";
		return img;
	} else if (fValue === "6" || fValue === "7" || fValue === "8" || fValue === "9") {
		img = "sap-icon://status-positive";
		return img;
	}
}
com.arteriatech.ss.cp.util.CPFormatter.StatusPriorityColor = function(fValue) {
	var img;
	if (fValue === "1" || fValue === "2") {
		img = "Error";
		return img;
	} else if (fValue === "3" || fValue === "4") {
		img = "Warning";
		return img;
	} else if (fValue === "5") {
		img = "Warning";
		return img;
	} else if (fValue === "6" || fValue === "7" || fValue === "8" || fValue === "9") {
		img = "Success";
		return img;
	}
}
com.arteriatech.ss.cp.util.CPFormatter.formatText=function (desc,id)
{
 var text="";
 if((id!=="" && desc!=="")|| (id!==undefined && desc!==undefined))
 {
  if(desc==="" || desc===undefined)
  {
   text=id;
  }
  else
  {
   text=desc+" "+":"+id+"";
  }
 }
 else
 {
  text="";
 }
 return text;
};