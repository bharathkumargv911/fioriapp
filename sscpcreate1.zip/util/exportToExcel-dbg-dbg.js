jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");
function exportToExcel(table, oModel, tableId)
 {
	//calling sapui5 control
	//doExport(table, oModel);
	exportToExcelUsingUI(table, oModel);
	 
	 //calling jquery
	/* $(tableId).table2excel({
		    exclude: ".noExl",
		    name: "Excel Document Name"
		  });*/
 }

function doExport(oTable, oModel) {
    var aColumns = getColumns(oTable);
    var oExport  = new sap.ui.core.util.Export({
        exportType : new sap.ui.core.util.ExportTypeCSV({
            separatorChar : ",",
            charset : "utf-8",
        }),
        models : oModel,
        rows : {
            path : oTable.getBinding("items").getPath(),
        },
        columns : aColumns
    });

    oExport.saveFile().always(function() {
        this.destroy();
    });
}

 function getColumns(oTable) {
    var aColumns  = oTable.getColumns();
    var aItems    = oTable.getItems();
    var aTemplate = [];
    var oControl; var sType;

    for (var i = 0; i< aColumns.length; i++) {
        var oColumn = { 
            name : aColumns[i].getHeader().getText(),
            template : {
                content : {
                    path : null
                }
            }
        };
        if (aItems.length > 0) {
        	oControl = sap.ui.getCore().byId(aItems[0].getCells()[i].getId());
        	sType = oControl.getMetadata().getName();
        	if(sType == "sap.m.Text"){
        		oColumn.template.content.path = aItems[0].getCells()[i].getBinding("text").getPath();
        	}
        }
        aTemplate.push(oColumn);
    }
    return aTemplate;
}

 function exportToExcelUsingUI(table, oModel)
 {
		var cols = table.getColumns();
		var items;
		if(table instanceof sap.m.Table)
		{
			items = table.getItems();
		}
		else
		{
			items = table.getRows();
		}
		var cellId = null; 
         var cellObj = null;
		 var cellVal = null;
		 var headerColId = null;
		 var headerColObj = null;
		 var headerColVal = null;
		 var column = null;
		 var json = {}; var colArray = []; var itemsArray = [];
		 //push header column names to array
		 for(var j=0; j<cols.length;j++){
            	column = "";
            	column = cols[j];
            	if(column.getAggregation("header") != undefined && column.getAggregation("header") != null)
            	{
            		headerColId = column.getAggregation("header").getId();
            	}
            	else
            	{
            		headerColId = column.getAggregation("label").getId();
            	}
				headerColObj = sap.ui.getCore().byId(headerColId);
				if(headerColObj instanceof sap.m.Text ||headerColObj instanceof sap.m.Label ||headerColObj instanceof sap.m.Link) {
					headerColVal = headerColObj.getText();
		 		}else if(headerColObj instanceof sap.ui.core.Icon){
		 			headerColVal = headerColObj.getTooltip();
		 		}else{
		 			headerColVal = "";
		 		}
				
				if(column.getVisible() && headerColVal != ""){
					json={name: headerColVal};
					colArray.push(json);
				}
				
				var item = items[0];
				cellId = "";   cellObj = "";  cellVal = "";
            	cellId = item.getAggregation("cells")[j].getId(); 
            	cellObj = sap.ui.getCore().byId(cellId);
            	if(cellObj.getVisible()){
            		if(cellObj instanceof sap.m.ObjectNumber){
            			headerColVal = "Unit";
            			json={name: headerColVal};
    					colArray.push(json);
            		}else if(cellObj instanceof sap.m.ObjectIdentifier){
            			headerColVal = "Code";
            			json={name: headerColVal};
    					colArray.push(json);
            		}
            	}
				
            }
            itemsArray.push(colArray);
          //push table cell values to array 
          for (i = 0; i < items.length; i++) {
        	  colArray = [];
	          var item = items[i];
	            for(var j=0; j<cols.length;j++){
	            	cellId = "";   cellObj = "";  cellVal = "";
	            	cellId = item.getAggregation("cells")[j].getId(); 
	            	cellObj = sap.ui.getCore().byId(cellId);
	            	if(cellObj.getVisible()){
		            	if(cellObj instanceof sap.m.Text ||cellObj instanceof sap.m.Label ||cellObj instanceof sap.m.Link) 
		            		cellVal = cellObj.getText();
		            	else if(cellObj instanceof sap.m.ObjectNumber){
		            		var k = cellObj.getUnit();
//		            		cellVal = cellObj.getNumber()+" "+k;
		            		cellVal = cellObj.getNumber();
		            	}
		            	else if(cellObj instanceof sap.m.ObjectIdentifier){
		            		var objectIdentifierVal = "";
		            		if(cellObj.getTitle() != undefined && cellObj.getTitle() != "" && cellObj.getTitle() != null )
		            			objectIdentifierVal = cellObj.getTitle();
		            		if(cellObj.getText() != undefined && cellObj.getText() != "" && cellObj.getText() != null )
//		            			objectIdentifierVal = objectIdentifierVal+" "+cellObj.getText();
		            		objectIdentifierVal = objectIdentifierVal;
		            		
		            		cellVal = objectIdentifierVal;
		            	}
		            	else if(cellObj instanceof sap.ui.core.Icon){
		            		if(cellObj.getTooltip() != undefined && cellObj.getTooltip() != "" && cellObj.getTooltip() != null )
		            		cellVal = cellObj.getTooltip();
		            	}
		            	else if(cellObj instanceof sap.m.Button){
		            		cellVal = "";
		            	}
		            	
		            	var newColumn = "empty";
		            	if(cellObj instanceof sap.m.ObjectNumber){
		            		newColumn = cellObj.getUnit();
		            	}
		            	else if(cellObj instanceof sap.m.ObjectIdentifier){
		            		var objectIdentifierVal = "";
		            		if(cellObj.getTitle() != undefined && cellObj.getTitle() != "" && cellObj.getTitle() != null )
		            		newColumn = "";
		            		if(cellObj.getText() != undefined && cellObj.getText() != "" && cellObj.getText() != null )
		            			newColumn = cellObj.getText();
		            	}
		            	var newColumnJson = {};
		            	if(j==0){
		            		if(newColumn != "empty"){
		            			newColumnJson={ name:  "\r"+newColumn};
		            		}else{
		            			json={ name:  "\r"+cellVal};
		            		}
						}
						else
						{
							json={ name:  cellVal};
							newColumnJson ={ name:  newColumn};
						}
		            	colArray.push(json);
		            	if(newColumn != "empty"){
		            		colArray.push(newColumnJson);
		            	}
	            	}
	            }
	            itemsArray.push(colArray);
	            
	            
            }
         //export json array to csv file
          var oExport = new sap.ui.core.util.Export({
        	    // Type that will be used to generate the content. Own ExportType's can be created to support other formats
        	    exportType: new sap.ui.core.util.ExportTypeCSV({
        	        separatorChar: ","
        	    }),
        	    // Pass in the model created above
        	    models: oModel,
        	    // binding information for the rows aggregation 
        	    rows: {
        	        path: "/" 
        	    },
        	    // column definitions with column name and binding info for the content
        	    columns: [itemsArray]
        	});
          oExport.saveFile(table.getId().split("--")[1]+" ("+new Date().toLocaleString()+")").always(function() {
        	    this.destroy();
        	});
 }
 

 /*
//table2excel.js
 ;(function ( $, window, document, undefined ) {
 		var pluginName = "table2excel",
 				defaults = {
 				exclude: ".noExl",
                 name: "Table2Excel"
 		};

 		// The actual plugin constructor
 		function Plugin ( element, options ) {
 				this.element = element;
 				// jQuery has an extend method which merges the contents of two or
 				// more objects, storing the result in the first object. The first object
 				// is generally empty as we don't want to alter the default options for
 				// future instances of the plugin
 				this.settings = $.extend( {}, defaults, options );
 				this._defaults = defaults;
 				this._name = pluginName;
 				this.init();
 		}

 		Plugin.prototype = {
 			init: function () {
 				var e = this;
 				e.template = "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:x=\"urn:schemas-microsoft-com:office:excel\" xmlns=\"http://www.w3.org/TR/REC-html40\"><head><!--[if gte mso 9]><xml>";
 				e.template += "<x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions>";
 				e.template += "<x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>";
 				e.tableRows = "";

 				// get contents of table except for exclude
 				$(e.element).find("tr").not(this.settings.exclude).each(function (i,o) {
 					e.tableRows += "<tr>" + $(o).html() + "</tr>";
 				});
 				this.tableToExcel(this.tableRows, this.settings.name);
 			},
 			tableToExcel: function (table, name) {
 				var e = this;
 				e.uri = "data:application/vnd.ms-excel;base64,";
 				e.base64 = function (s) {
 					return window.btoa(unescape(encodeURIComponent(s)));
 				};
 				e.format = function (s, c) {
 					return s.replace(/{(\w+)}/g, function (m, p) {
 						return c[p];
 					});
 				};
 				e.ctx = {
 					worksheet: name || "Worksheet",
 					table: table
 				};
 				window.location.href = e.uri + e.base64(e.format(e.template, e.ctx));
 			}
 		};

 		$.fn[ pluginName ] = function ( options ) {
 				this.each(function() {
 						if ( !$.data( this, "plugin_" + pluginName ) ) {
 								$.data( this, "plugin_" + pluginName, new Plugin( this, options ) );
 						}
 				});

 				// chain jQuery functions
 				return this;
 		};

 })( jQuery, window, document );*/