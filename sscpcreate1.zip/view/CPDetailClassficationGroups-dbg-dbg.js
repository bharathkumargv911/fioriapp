sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";
	var myBlock = BlockBase.extend("com.arteriatech.ss.cp.create1.view.CPDetailClassficationGroups", {
		metadata: {}
	});
	return myBlock;
}, true);