sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/UserMapping",
	"com/arteriatech/ss/cp/create1/controller/BaseController",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"sap/m/MessageToast"

], function (Controller, oSSUserMapping, BaseController, oSSCommonValueHelp, oPPCCommon, oSSCommon, MessageToast) {
	"use strict";
	var oi18n, oUtilsI18n;
	var busyDialog = new sap.m.BusyDialog();

	return Controller.extend("com.arteriatech.ss.cp.create1.controller.CPDetailClassficationGroups", {

		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gCPDetailClassGroups = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.setDefaultSettings();
			this.setCPScheduleDetails();
			this.getDropDowns();
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},
		setDefaultSettings: function () {
			var distanceFromParentUOM = "";
			if (this.getView().getModel("DstnceFromPUOMDD")) {
				distanceFromParentUOM = this.getView().getModel("DstnceFromPUOMDD").getData()[0].Key;
			}

			var oData = {
				Group1: "",
				Group1Desc: "",
				Group2: "",
				Group2Desc: "",
				Group3: "",
				Group3Desc: "",
				Group4: "",
				Group4Desc: "",
				Group5: "",
				Group5Desc: "",
				Group6: "",
				Group6Desc: "",
				Group7: "",
				Group7Desc: "",
				Group8: "",
				Group8Desc: "",
				Group9: "",
				Group9Desc: "",
				Group10: "",
				Group10Desc: "",
				DistanceFromParent: "0",
				DstnceFromPUOM: distanceFromParentUOM,
				BillSeries: "",
				BillSeriesDesc: ""

			};
			var oJSON = new sap.ui.model.json.JSONModel(oData);
			gCPDetailClassGroups.setModel(oJSON, "CPGroupTemp");
		},
		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		getDropDowns: function () {
			this.Group1DD();
			this.Group4DD();
			this.Group5DD();
			this.Group6DD();
			this.Group7DD();
			this.Group8DD();
			this.Group9DD();
			this.Group10DD();
			this.setFreqDispatch();
			this.distanceUOMDD();
			this.BillSeriesDD();
		},
		Group1DD: function () {
			busyDialog.open();
			var that = this;
			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP1"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ParentID", sap.ui
				.model.FilterOperator.EQ, ["COMMON"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"Group1DD", "Select",
				function () {
					busyDialog.close();
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.Group1DD_Exit) {
				this.Group1DD_Exit();
			}
		},
		Group2DD: function (oEvent) {
			busyDialog.open();
			var Group1 = oEvent.getSource().getSelectedKey();
			var Group1Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group1Desc) {
				Group1Desc = Group1Desc.split("-")[1].trim();
			}

			this.getView().byId("idSelectGroup1").setValueState(null);
			this.getView().byId("idSelectGroup1").setValueStateText("");

			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group1", Group1);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group1Desc", Group1Desc);

			var id = this.getView().byId("idSelectGroup1").getSelectedKey();
			var that = this;

			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP2"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ParentID", sap.ui
				.model.FilterOperator.EQ, ["COMMON"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);

			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"Group2DD", "Select",
				function () {
					busyDialog.close();
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.Group2DD_Exit) {
				this.Group2DD_Exit();
			}
		},

		Group3DD: function (oEvent) {
			// this.setDDDesciption(oEvent);

			this.getView().byId("idSelectGroup2").setValueState(null);
			this.getView().byId("idSelectGroup2").setValueStateText("");

			var Group2 = oEvent.getSource().getSelectedKey();
			var Group2Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group2Desc) {
				Group2Desc = Group2Desc.split("-")[1].trim();
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group2", Group2);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group2Desc", Group2Desc);

			var id = this.getView().byId("idSelectGroup2").getSelectedKey();
			var that = this;

			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP3"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ParentID", sap.ui
				.model.FilterOperator.EQ, ["COMMON"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);

			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, this.getView(),
				"Group3DD", "Select",
				function (aData) {
					if (that.getView().getModel("Group3DD") && aData.length === 0) {
						that.getView().getModel("Group3DD").setProperty("/", aData);
					}
					// that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.Group3DD_Exit) {
				this.Group3DD_Exit();
			}
		},
		Group4DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP4"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group4DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group5DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP5"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group5DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group5DD_Exit) {
				this.Group5DD_Exit();
			}
		},
		Group6DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP6"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group6DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group7DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP7"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group7DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group8DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP8"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group8DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group9DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP9"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group9DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group10DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGR10"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group10DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		BillSeriesDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPBILS"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"BillSeriesDD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.BillSeriesDD_Exit) {
				this.BillSeriesDD_Exit();
			}
		},
		setFreqDispatch: function () {
			busyDialog.open();
			var that = this;
			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["FreqOfDispatch"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"FreqOfDispatchDD", "Select",
				function () {
					busyDialog.close();
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.setFreqDispatch_Exit) {
				this.setFreqDispatch_Exit();
			}
		},
		onChangeGroup3DD: function (oEvent) {
			var Group3 = oEvent.getSource().getSelectedKey();
			var Group3Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group3Desc) {
				Group3Desc = Group3Desc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group3", Group3);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group3Desc", Group3Desc);
		},
		onChangeGroup4DD: function (oEvent) {
			var Group4 = oEvent.getSource().getSelectedKey();
			var Group4Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group4Desc) {
				Group4Desc = Group4Desc.split("-")[1].trim();
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group4", Group4);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group4Desc", Group4Desc);
		},
		onChangeGroup5DD: function (oEvent) {
			var Group5 = oEvent.getSource().getSelectedKey();
			var Group5Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group5Desc) {
				Group5Desc = Group5Desc.split("-")[1].trim();
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group5", Group5);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group5Desc", Group5Desc);
		},
		distanceUOMDD: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPDFUM"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"DstnceFromPUOMDD", "",
				function () {}, true, "PD", true);

			if (this.distanceUOMDD_Exit) {
				this.distanceUOMDD_Exit();
			}
		},
		onChangeBillSeries: function (oEvent) {
			var BillSeries = oEvent.getSource().getSelectedKey();
			var BillSeriesDesc = oEvent.getSource().getSelectedItem().getText();
			if (BillSeriesDesc) {
				BillSeriesDesc = BillSeriesDesc.split("-")[1].trim();
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/BillSeries", BillSeries);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/BillSeriesDesc", BillSeriesDesc);
		},
		validateNumeric: function (oEvent) {
			var value = oEvent.getSource().getValue();
			var currentValueEntered = value.substring(value.length - 1);
			var lastValueEnterd = value.substring(0, value.length - 1);
			var reg = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,<>\/a-z A-Z?]/;
			if (reg.test(currentValueEntered)) {
				oEvent.getSource().setValue(lastValueEnterd);
			}
		},
		onChangeFrequency: function (oEvent) {
			oEvent.getSource().setValueState(null);
			oEvent.getSource().setValueStateText("");

			var freqke = oEvent.getSource().getSelectedKey();
			var freqDsc = oEvent.getSource().getSelectedItem().getText();
			if (freqke) {
				freqDsc = freqDsc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/FreqOfDispatch", freqke);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/FreqOfDispatchDesc", freqDsc);

			this.setCPScheduleDetails();
		},
		setCPScheduleDetails: function () {
			var CPSchedule = [{
				MonSelected: false,
				TueSelected: false,
				WedSelected: false,
				ThurSelected: false,
				FriSelected: false,
				SatSelected: false,
				SunSelected: false
			}];
			var oJSONData = new sap.ui.model.json.JSONModel();
			oJSONData.setData(CPSchedule);
			gCPDetailClassGroups.setModel(oJSONData, "CPScheduleDetails");
		},
		onChangeMonday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = true;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].MonSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].MonSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeTuesday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = true;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].TueSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].TueSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeWednesday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = true;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].WedSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].WedSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeThursday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = true;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].ThurSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].ThurSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeFriday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = true;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].FriSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].FriSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeSaturday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = true;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].SatSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].SatSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeSunday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this.getView().getModel("CPGroupTemp").getProperty("/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = true;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].SunSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].SunSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		numberOfDaysSelected: function (CPSchedules) {
			var count = 0;
			if (CPSchedules[0].MonSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].TueSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].WedSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].ThurSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].FriSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].SatSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].SunSelected) {
				count = count + 1;

			}
			return count;
		},
		showMessageToast: function (days) {
			var message = oi18n.getText("CPDetail.Schedule.CPDetail.Column.CantSelect", days);
			MessageToast.show(message);
		},
		onGroup6: function (oEvent) {
			var Group = oEvent.getSource().getSelectedKey();
			var GroupDesc = oEvent.getSource().getSelectedItem().getText();
			if (GroupDesc) {
				GroupDesc = GroupDesc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group6", Group);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group6Desc", GroupDesc);
		},
		onGroup7: function (oEvent) {
			var Group = oEvent.getSource().getSelectedKey();
			var GroupDesc = oEvent.getSource().getSelectedItem().getText();
			if (GroupDesc) {
				GroupDesc = GroupDesc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group7", Group);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group7Desc", GroupDesc);
		},
		onGroup8: function (oEvent) {
			var Group = oEvent.getSource().getSelectedKey();
			var GroupDesc = oEvent.getSource().getSelectedItem().getText();
			if (GroupDesc) {
				GroupDesc = GroupDesc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group8", Group);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group8Desc", GroupDesc);
		},
		onGroup9: function (oEvent) {
			var Group = oEvent.getSource().getSelectedKey();
			var GroupDesc = oEvent.getSource().getSelectedItem().getText();
			if (GroupDesc) {
				GroupDesc = GroupDesc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group9", Group);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group9Desc", GroupDesc);
		},
		onGroup10: function (oEvent) {
			var Group = oEvent.getSource().getSelectedKey();
			var GroupDesc = oEvent.getSource().getSelectedItem().getText();
			if (GroupDesc) {
				GroupDesc = GroupDesc.split("-")[1];
			}
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group10", Group);
			gCPDetailClassGroups.getModel("CPGroupTemp").setProperty("/Group10Desc", GroupDesc);
		},
	});

});