jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/CommonValueHelp"
], function (Controller, oSSCommonValueHelp) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var contextPath = "";
	var busyDialog = new sap.m.BusyDialog();

	return Controller.extend("com.arteriatech.ss.cp.create1.controller.CPDetailTaxClassification", {
		onInit: function () {
			gCPDetailTaxClassification = this.getView();
			gObjectPageLayout1 = this.getView().byId("ObjectPageLayout1");
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.router.attachRouteMatched(this.onRouteMatched, this);
			// this.setFreqDispatch();
			if (this.onInit_Exit) {
				this.onInit_Exit();
			}
		},
		onRouteMatched: function (oEvent) {
			// gCPDetailView.setBusy(true);
			if (oEvent.getParameter("name") !== "TaxCreate" && oEvent.getParameter("name") !== "TaxEdit") {
				return;
			}

			// this.getView().setBusy(true);

			//if (oHistory.getDirection() !== "Backwards") {

			if (oEvent.getParameter("name") === "TaxCreate") {
				contextPath = oEvent.getParameter("arguments").contextPath;
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/CreateType", oEvent.getParameter("name"));

				this.AddClissificationChannels();

				if (gTaxClassificationView) {
					if (gTaxClassificationView.getModel("Group2DD")) {
						gTaxClassificationView.getModel("Group2DD").setData([]);
					}
					if (gTaxClassificationView.getModel("Group3DD")) {
						gTaxClassificationView.getModel("Group3DD").setData([]);
					}

				}

			} else if (oEvent.getParameter("name") === "TaxEdit") {
				var aData = this._oComponent.getModel("CPDMSDivisionsTemp").getData();
				// var aScheduledata = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
				var oCPDMSDivisionsModel = new sap.ui.model.json.JSONModel();
				oCPDMSDivisionsModel.setData(aData);
				this._oComponent.setModel(oCPDMSDivisionsModel, "CPDMSDivisionsTemp");
				var TaxItems = aData[0].CPDMSDivisionTaxes;

				var oCPDMSDivisionTaxesModel = new sap.ui.model.json.JSONModel();

				oCPDMSDivisionTaxesModel.setData(TaxItems);
				this._oComponent.setModel(oCPDMSDivisionTaxesModel, "CPDMSDivisionTaxes");

				// var oCPScheduleModel = new sap.ui.model.json.JSONModel();
				// oCPScheduleModel.setData(aScheduledata);
				// gDeliverySchedulesView.setModel(oCPScheduleModel, "CPScheduleDetails");

				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/TaxCatItemsCount", TaxItems.length);
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/CreateType", oEvent.getParameter("name"));
				// gDeliverySchedulesView.getModel("LocalViewSettingDtlSchedule").setProperty("/RSTableRowCount", aData.length);
			}

			// this.getView().setBusy(false);
		},
		setFreqDispatch: function () {
			busyDialog.open();
			var that = this;
			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["FreqOfDispatch"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"FreqOfDispatchDD", "Select",
				function () {
					busyDialog.close();
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.setFreqDispatch_Exit) {
				this.setFreqDispatch_Exit();
			}
		},
		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},

		AddClissificationChannels: function () {
			var that = this;
			var newItem = [];
			newItem.push({
				"CPGUID": gCPDetailView.getModel("ChannelPartners").getProperty("/CPGUID"),
				"CP1GUID": oPPCCommon.generateUUID(),
				"ParentID": that._oComponent.getModel("ChannelPartners").getProperty("/CustomerNo"),
				"ParentTypeID": that.getView().getModel("LocalViewSettingDtl").getProperty("/CPTypeID"),
				"LoginID": "",
				"CPNo": "",
				"Name": "",
				"DMSDivision": "",
				"DMSDivisionDesc": "",
				"Currency": gCPDetailView.getModel("ChannelPartners").getProperty("/Currency"),
				"RouteID": "",
				"RouteDesc": "",
				"CPUID": "",
				"OwnerName": "",
				"MobileNo": "",
				"Group1": "",
				"Group1Desc": "",
				"Group2": "",
				"Group2Desc": "",
				"Group3": "",
				"Group3Desc": "",
				"Group4": "",
				"Group4Desc": "",
				"Group5": "",
				"Group5Desc": "",
				"PartnerMgrGUID": null,
				"PartnerMgrNo": "",
				"PartnerMgrName": "",
				"DiscountPer": null,
				"StatusID": "01",
				"ApprvlStatusID": "",
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT00H00M00S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				// "Geo1": this._oComponent.getModel("OwnData").getProperty("/Geo1"),
				// "Geo1Desc": this._oComponent.getModel("OwnData").getProperty("/Geo1Desc"),
				// "Geo2": this._oComponent.getModel("OwnData").getProperty("/Geo2"),
				// "Geo2Desc": this._oComponent.getModel("OwnData").getProperty("/Geo2Desc"),
				// "Geo3": this._oComponent.getModel("OwnData").getProperty("/Geo3"),
				// "Geo3Desc": this._oComponent.getModel("OwnData").getProperty("/Geo3Desc"),
				// "Geo4": this._oComponent.getModel("OwnData").getProperty("/Geo4"),
				// "Geo4Desc": this._oComponent.getModel("OwnData").getProperty("/Geo4Desc"),
				// "Geo5": this._oComponent.getModel("OwnData").getProperty("/Geo5"),
				// "Geo5Desc": this._oComponent.getModel("OwnData").getProperty("/Geo5Desc"),
				// "Geo6": this._oComponent.getModel("OwnData").getProperty("/Geo6"),
				// "Geo6Desc": this._oComponent.getModel("OwnData").getProperty("/Geo6Desc"),
				// "Geo7": this._oComponent.getModel("OwnData").getProperty("/Geo7"),
				// "Geo7Desc": this._oComponent.getModel("OwnData").getProperty("/Geo7Desc"),
				// "Geo8": this._oComponent.getModel("OwnData").getProperty("/Geo8"),
				// "Geo8Desc": this._oComponent.getModel("OwnData").getProperty("/Geo8Desc"),
				// "Geo9": this._oComponent.getModel("OwnData").getProperty("/Geo9"),
				// "Geo9Desc": this._oComponent.getModel("OwnData").getProperty("/Geo9Desc"),
				// "Geo10": this._oComponent.getModel("OwnData").getProperty("/Geo10"),
				// "Geo10Desc": this._oComponent.getModel("OwnData").getProperty("/Geo10Desc"),
				"CPDMSDivisionTaxes": [],
				"ItemNo": this.setItemNo()

			});
			var oCPDMSDivisionTaxesModel = new sap.ui.model.json.JSONModel();

			oCPDMSDivisionTaxesModel.setData(newItem);
			this._oComponent.setModel(oCPDMSDivisionTaxesModel, "CPDMSDivisionsTemp");

			this.setCPDMSDIVISIONTaxes(newItem);

			if (this.AddClissificationChannels_Exit) {
				this.AddClissificationChannels_Exit();
			}
		},
		setItemNo: function () {

			if (this.getView().getModel("CPDMSDivisions")) {
				var ItemData = this.getView().getModel("CPDMSDivisions").getProperty("/");
				if (ItemData.length > 0) {
					for (var i = 0; i < ItemData.length; i++) {
						var ItemNo = ItemData[i].ItemNo + 10;

					}
					return ItemNo;
				} else {
					return 10;
				}
			} else {
				return 10;
			}

		},

		setCPDMSDIVISIONTaxes: function (oData) {
			var aData = [];
			var taxItems = [];
			for (var i = 0; i < oData.length; i++) {

				if (oData[i].CPDMSDivisionTaxes.length === 0) {
					aData.push({

						"CPTaxGUID": oPPCCommon.generateUUID(),
						"CP1GUID": oData[i].CP1GUID,
						"DMSDivision": "",
						"DMSDIvisionDesc": "",
						"StatusID": "01",
						"TaxCategoryID": "",
						"TaxCategoryDesc": "",
						"TaxClassificationID": "",
						"TaxClassificationDesc": ""
					});
					oData[i].CPDMSDivisionTaxes = aData;
					taxItems.push(oData[i].CPDMSDivisionTaxes[0]);
				} else {
					taxItems.push(oData[i].CPDMSDivisionTaxes[0]);
				}

			}
			var oCPDMSDivisionTaxesModel = new sap.ui.model.json.JSONModel();

			oCPDMSDivisionTaxesModel.setData(taxItems);
			this._oComponent.setModel(oCPDMSDivisionTaxesModel, "CPDMSDivisionTaxes");

			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/TaxCatItemsCount", taxItems.length);

		},
		onCancel: function () {
			window.history.go(-1);

		},
		onBack: function () {
			window.history.go(-1);
		},
		onAdd: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var MainData = this.getView().getModel("CPDMSDivisions").getProperty("/");
			var HeaderData = this.getView().getModel("CPDMSDivisionsTemp").getProperty("/");

			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			oPPCCommon.hideMessagePopover(gObjectPageLayout1);
			var oCPDMSDivisionsModel = new sap.ui.model.json.JSONModel();
			this.validateGroups();
			// this.validateDuplicateDivision(MainData, HeaderData);
			if (oPPCCommon.doErrMessageExist()) {

				/*that._oComponent.getModel("ChannelPartners").setProperty("/ParentID", that.getView().getModel("Customers").getProperty(
				"/0/CPGUID"));
			that._oComponent.getModel("ChannelPartners").setProperty("/ParentName", that.getView().getModel("Customers").getProperty("/0/Name"));
			that._oComponent.getModel("ChannelPartners").setProperty("/ParentTypeID", that.getView().getModel("Customers").getProperty(
				"/0/CPTypeID"));
			that._oComponent.getModel("ChannelPartners").setProperty("/ParentTypDesc", that.getView().getModel("Customers").getProperty(
				"/0/CPTypeDesc"));*/

				HeaderData[0].ParentID = that.getView().getModel("ChannelPartners").getProperty("/ParentID");
				HeaderData[0].ParentName = that.getView().getModel("LocalViewSettingDtl").getProperty("/Name");
				HeaderData[0].ParentTypeID = that.getView().getModel("LocalViewSettingDtl").getProperty("/CPTypeID");
				HeaderData[0].ParentTypDesc = that.getView().getModel("ChannelPartners").getProperty("/CPTypeDesc");
				HeaderData[0].RouteDesc = gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/oRouteDesc");
				HeaderData[0].RouteID = gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/oRouteId");
				HeaderData[0].RouteGUID = gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/oRouteguid");
				// if (!HeaderData[0].DstnceFromPUOM) {
				// 	if (gTaxClassificationView.getModel("DstnceFromPUOMDD")) {
				// 		HeaderData[0].DstnceFromPUOM = gTaxClassificationView.getModel("DstnceFromPUOMDD").getData()[0].Key;
				// 	} else {
				// 		HeaderData[0].DstnceFromPUOM = "KM";
				// 	}
				// }
				// HeaderData = this.addDaySchedule(HeaderData); // adding day1 to day7 selected

				if (gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/CreateType") === "TaxCreate") {

					if (this.getView().getModel("CPDMSDivisions")) {

						MainData.push(HeaderData[0]);
						oCPDMSDivisionsModel.setData(MainData);
						this._oComponent.setModel(oCPDMSDivisionsModel, "CPDMSDivisions");

						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/TableRowCountClassification", MainData.length);
					} else {
						oCPDMSDivisionsModel.setData(HeaderData);
						this._oComponent.setModel(oCPDMSDivisionsModel, "CPDMSDivisions");

					}
				}

				if (gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/CreateType") === "TaxEdit") {

					for (var i = 0; i < MainData.length; i++) {
						if (MainData[i].DMSDivision === HeaderData[0].DMSDivision) {
							MainData[i] = HeaderData[0];
						}
					}
					MainData = this.getView().getModel("CPDMSDivisions").getProperty("/");

					oCPDMSDivisionsModel.setData(MainData);
					this._oComponent.setModel(oCPDMSDivisionsModel, "CPDMSDivisions");

				}
				if (!HeaderData[0].DMSDivision) {
					this.extendToAllDivisions(HeaderData);
				}
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/TableRowCountClassification", this.getView().getModel("CPDMSDivisions")
					.getData().length);
				// this.resetScheduleTable();
				window.history.go(-1);
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(gObjectPageLayout1);
			}

		},
		resetScheduleTable: function () {
			gDeliverySchedulesView.oController.setCPScheduleDetails();
		},
		extendToAllDivisions: function () {
			var oExModel = this.getView().getModel("CPDMSDivisionsTemp").getData();
			var oModel = jQuery.extend(true, [], oExModel);
			var oTemp = [];
			var DMSDivision = gTaxClassificationView.getModel("DMSDivisionDD").getData();
			for (var i = 1; i < DMSDivision.length; i++) {
				var aoJSON = this.getJSONModelfor(oModel, DMSDivision[i]);
				oTemp.push(aoJSON);
			}
			this._oComponent.getModel("CPDMSDivisions").setData(oTemp);
		},
		addDaySchedule: function (HeaderData) {
			var daySchedData = gDeliverySchedulesView.getModel("CPScheduleDetails").getData()[0];
			if (daySchedData.MonSelected) {
				HeaderData[0].Day1 = "X";
			} else {
				HeaderData[0].Day1 = "";
			}
			if (daySchedData.TueSelected) {
				HeaderData[0].Day2 = "X";
			} else {
				HeaderData[0].Day2 = "";
			}
			if (daySchedData.WedSelected) {
				HeaderData[0].Day3 = "X";
			} else {
				HeaderData[0].Day3 = "";
			}
			if (daySchedData.ThurSelected) {
				HeaderData[0].Day4 = "X";
			} else {
				HeaderData[0].Day4 = "";
			}
			if (daySchedData.FriSelected) {
				HeaderData[0].Day5 = "X";
			} else {
				HeaderData[0].Day5 = "";
			}
			if (daySchedData.SatSelected) {
				HeaderData[0].Day6 = "X";
			} else {
				HeaderData[0].Day6 = "";
			}
			if (daySchedData.SunSelected) {
				HeaderData[0].Day7 = "X";
			} else {
				HeaderData[0].Day7 = "";
			}
			return HeaderData;
		},
		getJSONModelfor: function (oModel, DMSDivision) {
			var ojson = {
				ApprvlStatusID: oModel[0].ApprvlStatusID,
				CP1GUID: oPPCCommon.generateUUID().toUpperCase(),
				CPDMSDivisionTaxes: this.setCPDMSDivisionTaxesForAllDMS(oModel),
				CPGUID: oModel[0].CPGUID.toUpperCase(),
				CPNo: oModel[0].CPNo,
				CPUID: oModel[0].CPUID,
				ChangedAt: oModel[0].ChangedAt,
				ChangedBy: oModel[0].ChangedBy,
				ChangedOn: oModel[0].ChangedOn,
				CreatedAt: oModel[0].CreatedAt,
				CreatedBy: oModel[0].CreatedBy,
				CreatedOn: oModel[0].CreatedOn,
				CreditBills: oModel[0].CreditBills,
				CreditDays: oModel[0].CreditDays,
				CreditLimit: oModel[0].CreditLimit,
				Currency: oModel[0].Currency,
				// Day1: oModel[0].Day1,
				// Day2: oModel[0].Day2,
				// Day3: oModel[0].Day3,
				// Day4: oModel[0].Day4,
				// Day5: oModel[0].Day5,
				// Day6: oModel[0].Day6,
				// Day7: oModel[0].Day7,
				// DistanceFromParent: oModel[0].DistanceFromParent,
				// DstnceFromPUOM: oModel[0].DstnceFromPUOM,
				// BillSeries: oModel[0].BillSeries,
				DMSDivision: DMSDivision.Key,
				DMSDivisionDesc: DMSDivision.Text,
				DiscountPer: oModel[0].DiscountPer,
				FreqOfDispatch: oModel[0].FreqOfDispatch,
				Geo1: oModel[0].Geo1,
				Geo1Desc: oModel[0].Geo1Desc,
				Geo2: oModel[0].Geo2,
				Geo2Desc: oModel[0].Geo2Desc,
				Geo3: oModel[0].Geo3,
				Geo3Desc: oModel[0].Geo3Desc,
				Geo4: oModel[0].Geo4,
				Geo4Desc: oModel[0].Geo4Desc,
				Geo5: oModel[0].Geo5,
				Geo5Desc: oModel[0].Geo5Desc,
				Geo6: oModel[0].Geo6,
				Geo6Desc: oModel[0].Geo6Desc,
				Geo7: oModel[0].Geo7,
				Geo7Desc: oModel[0].Geo7Desc,
				Geo8: oModel[0].Geo8,
				Geo8Desc: oModel[0].Geo8Desc,
				Geo9: oModel[0].Geo9,
				Geo9Desc: oModel[0].Geo9Desc,
				Geo10: oModel[0].Geo10,
				Geo10Desc: oModel[0].Geo10Desc,
				// Group1: oModel[0].Group1,
				// Group1Desc: oModel[0].Group1Desc,
				// Group2: oModel[0].Group2,
				// Group2Desc: oModel[0].Group2Desc,
				// Group3: oModel[0].Group3,
				// Group3Desc: oModel[0].Group3Desc,
				// Group4: oModel[0].Group4,
				// Group4Desc: oModel[0].Group4Desc,
				// Group5: oModel[0].Group5,
				// Group5Desc: oModel[0].Group5Desc,
				// Group6: oModel[0].Group6,
				// Group6Desc: oModel[0].Group6Desc,
				// Group7: oModel[0].Group7,
				// Group7Desc: oModel[0].Group7Desc,
				// Group8: oModel[0].Group8,
				// Group8Desc: oModel[0].Group8Desc,
				// Group9: oModel[0].Group9,
				// Group9Desc: oModel[0].Group9Desc,
				// Group10: oModel[0].Group10,
				// Group10Desc: oModel[0].Group10Desc,
				ItemNo: oModel[0].ItemNo,
				LoginID: oModel[0].LoginID,
				MobileNo: oModel[0].MobileNo,
				Name: oModel[0].Name,
				OwnerName: oModel[0].OwnerName,
				ParentID: oModel[0].ParentID,
				ParentName: oModel[0].ParentName,
				ParentTypDesc: oModel[0].ParentTypDesc,
				ParentTypeID: oModel[0].ParentTypeID,
				PartnerMgrGUID: oModel[0].PartnerMgrGUID,
				PartnerMgrName: oModel[0].PartnerMgrName,
				PartnerMgrNo: oModel[0].PartnerMgrNo,
				RouteDesc: oModel[0].RouteDesc,
				RouteGUID: oModel[0].RouteGUID,
				RouteID: oModel[0].RouteID,
				StatusID: oModel[0].StatusID
			}
			return ojson;
		},
		setCPDMSDivisionTaxesForAllDMS: function (oData) {
			var mTaxArray = [];
			var oTaxes = {
				"CPTaxGUID": oPPCCommon.generateUUID().toUpperCase(),
				"CP1GUID": oData[0].CP1GUID.toUpperCase(),
				"DMSDivision": "",
				"DMSDIvisionDesc": "",
				"StatusID": "01",
				"TaxCategoryID": "",
				"TaxCategoryDesc": "",
				"TaxClassificationID": "",
				"TaxClassificationDesc": ""
			};
			mTaxArray.push(oTaxes);
			return mTaxArray;
		},
		validateGroups: function () {
			var oModelCPDMSDivisions = this.getView().getModel("CPDMSDivisionsTemp");
			var oDataCPDMSDivisions = oModelCPDMSDivisions.getProperty("/");
			// if (oDataCPDMSDivisions[0].FreqOfDispatch) {
			// 	this.validateDelSchecdules(oDataCPDMSDivisions[0].FreqOfDispatch);
			// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueState(null);
			// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueStateText("");
			// } else {
			// 	var msg = oi18n.getText("cpcreate.please.select", gDeliverySchedulesView.byId("lidFreqOfDispatch").getText());
			// 	oPPCCommon.addMsg_MsgMgr(msg, "error");
			// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueState("Error");
			// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueStateText(msg);
			// }

			for (var i = 0; i < oDataCPDMSDivisions.length; i++) {
				// if (!oDataCPDMSDivisions[i].Group1) {
				// 	var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", gTaxClassificationView.byId("lGroup1").getText());
				// 	sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
				// 		"/" + i + "/Group1ValueState", "/" + i + "/Group1ValueStateText",
				// 		msg,
				// 		oModelCPDMSDivisions);
				// 	gTaxClassificationView.byId("fGroup1Edit").setValueState("Error");
				// 	gTaxClassificationView.byId("fGroup1Edit").setValueStateText(msg);
				// } else {
				// 	gTaxClassificationView.byId("fGroup1Edit").setValueState(null);
				// 	gTaxClassificationView.byId("fGroup1Edit").setValueStateText("");
				// }
				// if (!oDataCPDMSDivisions[i].FreqOfDispatch) {
				// 	var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", gDeliverySchedulesView.byId("lidFreqOfDispatch").getText());
				// 	oPPCCommon.addMsg_MsgMgr(msg, "error");
				// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueState("Error");
				// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueStateText(msg);
				// } else {
				// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueState(null);
				// 	gDeliverySchedulesView.byId("idFreqOfDispatchDD").setValueStateText("");
				// }

				// if (!oDataCPDMSDivisions[i].DMSDivision) {
				// 	sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
				// 		"/" + i + "/DMSDivisionValueState", "/" + i + "/DMSDivisionValueStateText",
				// 		oi18n.getText("common.message.pleaseEnterValid",
				// 			gTaxClassificationView.byId("lDMSDivision").getText()),
				// 		oModelCPDMSDivisions);
				// }
				/*
				if (!oDataCPDMSDivisions[i].Group1) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/Group1ValueState", "/" + i + "/Group1ValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lGroup1").getText()),
						oModelCPDMSDivisions);
				}

				if (!oDataCPDMSDivisions[i].Group2) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/Group2ValueState", "/" + i + "/Group2ValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lGroup2").getText()),
						oModelCPDMSDivisions);
				}

				if (!oDataCPDMSDivisions[i].Group3) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/Group3ValueState", "/" + i + "/Group3ValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lGroup3").getText()),
						oModelCPDMSDivisions);
				}

				if (!oDataCPDMSDivisions[i].Group4) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/Group4ValueState", "/" + i + "/Group4ValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lGroup4").getText()),
						oModelCPDMSDivisions);
				}

				if (!oDataCPDMSDivisions[i].Group5) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/Group5ValueState", "/" + i + "/Group5ValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lGroup5").getText()),
						oModelCPDMSDivisions);

				}*/
				var CreditBills = oDataCPDMSDivisions[i].CreditBills;
				if (!CreditBills || CreditBills === undefined || CreditBills === null) {
					oModelCPDMSDivisions.setProperty("/" + i + "/CreditBills", 0);
				} else if (CreditBills && CreditBills < 0) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/CreditBillsValueState", "/" + i + "/CreditBillsValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lCreditLimit").getText()),
						oModelCPDMSDivisions);
				}
				var CreditDays = oDataCPDMSDivisions[i].CreditDays;
				if (!CreditDays || CreditDays === undefined || CreditDays === null) {
					oModelCPDMSDivisions.setProperty("/" + i + "/CreditDays", 0);
				} else if (CreditDays && CreditDays < 0) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/CreditDaysValueState", "/" + i + "/CreditDaysValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lCreditDays").getText()),
						oModelCPDMSDivisions);
				}
				var creditlimit = oDataCPDMSDivisions[i].CreditLimit;
				if (!creditlimit || creditlimit === undefined || creditlimit === null) {
					oModelCPDMSDivisions.setProperty("/" + i + "/CreditLimit", "0.00");
				} else if (creditlimit && parseFloat(creditlimit) < 0) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/CreditLimitValueState", "/" + i + "/CreditLimitValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lCreditLimit").getText()),
						oModelCPDMSDivisions);
				}

				var DiscountPer = oDataCPDMSDivisions[i].DiscountPer;
				var MaxDiscountPerce = this.getView().getModel("LocalViewSettingDtl").getProperty("/MaxDiscountPerce");
				if (DiscountPer && DiscountPer < 0) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/DiscountPerValueState", "/" + i + "/DiscountPerValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gTaxClassificationView.byId("lDiscountPer").getText()),
						oModelCPDMSDivisions);
				} else if (DiscountPer && DiscountPer > MaxDiscountPerce) {
					sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addItemErrorMessages(gTaxClassificationView,
						"/" + i + "/DiscountPerValueState", "/" + i + "/DiscountPerValueStateText",
						gTaxClassificationView.byId("lDiscountPer").getText() +
						" Should not be greater than " + MaxDiscountPerce,
						oModelCPDMSDivisions);
				}
				if (!DiscountPer) {
					oModelCPDMSDivisions.setProperty("/" + i + "/DiscountPer", "0");
				}
			}
		},
		validateDuplicateDivision: function (MainData, HeaderData) {
			var valid = true;
			MainData.forEach(function (eachElement) {
				if (eachElement.DMSDivision === HeaderData[0].DMSDivision) {
					valid = false;
					var msg = oi18n.getText("common.message.Duplication.Division", gTaxClassificationView.byId("lDMSDivision").getText());
					oPPCCommon.addMsg_MsgMgr(msg, "error");
					gTaxClassificationView.byId("fDMSDivisionEdit").setValueState("Error");
					gTaxClassificationView.byId("fDMSDivisionEdit").setValueStateText(msg);
				}
			});
			if (valid) {
				gTaxClassificationView.byId("fDMSDivisionEdit").setValueState(null);
				gTaxClassificationView.byId("fDMSDivisionEdit").setValueStateText("");
			}
		},
		validateDelSchecdules: function (FreqOfDispatch) {
			var valid = false;
			var sCount = 0;
			var CPScheduleDetails = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			if (CPScheduleDetails[0].MonSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].TueSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].WedSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].ThurSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].FriSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].SatSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].SunSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (!valid) {
				var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", "Days");
				oPPCCommon.addMsg_MsgMgr(msg, "error");
				return;
			}
			if (parseInt(FreqOfDispatch) === 4) {
				if (sCount !== 1) {
					var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", "Days");
					oPPCCommon.addMsg_MsgMgr(msg, "error");
					return;
				}
			} else {
				if (parseInt(FreqOfDispatch) !== sCount) {
					var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", "Days");
					oPPCCommon.addMsg_MsgMgr(msg, "error");
					return;
				}
			}

			// if (parseInt(FreqOfDispatch) !== sCount) {
			// 	if (FreqOfDispatch !== "000004") {
			// 		var msg = oi18n.getText("daySchedule.valid.days", parseInt(FreqOfDispatch));
			// 		oPPCCommon.addMsg_MsgMgr(msg, "error");
			// 	}
			// }
		},
		showPopUp: function () {
			oPPCCommon.showMessagePopover(gObjectPageLayout1);
		},

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailTaxClassification
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailTaxClassification
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailTaxClassification
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailTaxClassification
		 */
		//	onExit: function() {
		//
		//	}

	});

});