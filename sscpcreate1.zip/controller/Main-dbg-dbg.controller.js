/*
* Copyright 
(C)
 2015-2016 Arteria Technologies Pvt. Ltd. All rights reserved
*/
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common"
], function(Controller,oPPCCommon,oSSCommon) {
	"use strict";
	return Controller.extend("com.arteriatech.ss.cp.create1.controller.Main", {
		
		onInit: function() {
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			goi18n = this._oComponent.getModel("i18n").getResourceBundle();
			goUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			
			var oDataModel = this._oComponent.getModel("PCGW");
			var oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			/*
			 *PSPO name should be from generic table which a is typeset name for app-wise generic checks, this name changes for each app, it will be maintained uniquely.
			 *call util function to get constant value and this value should me maintained in the ppsutil constants also
			 */
			//var pspoTypsetName = oSSCommon.getPPSUIConstants("PSPO");
			//call ppsutil function to load product and app features, and this function saves features globally
			oSSCommon.loadProductFeatures({
				oDataModel: oDataModel,
				oUtilsI18n: oUtilsI18n,
				Component: this._oComponent
			});
			
			oPPCCommon.initMsgMangerObjects();
			
			if (sap.ui.Device.support.touch === false) {
				this.getView().addStyleClass("sapUiSizeCompact");
			}
			if (this.onInitHookUp_Exit) {
				this.onInitHookUp();
			}
		}
	});
});