jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.cp.create1.block.NewPartenerCP");
jQuery.sap.require("com.arteriatech.ss.cp.create1.block.LinkPartenerCP");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/CommonValueHelp"
], function (Controller, CommonValueHelp) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	return Controller.extend("com.arteriatech.ss.cp.create1.controller.CPDetailALTERNATEBILLINGS", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailALTERNATEBILLINGS
		 */
		onInit: function () {
			this.onInitialHookUps();
		},

		onInitialHookUps: function () {
			gPartnerFunction = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			this.setValueHelpProperty();
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},

		setValueHelpProperty: function () {

			if (this.setValueHelpProperty_Exit) {
				this.setValueHelpProperty_Exit();
			}
		},

		gotoParterCP: function (oEvent) {
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			var path = "";
			var oModelContext = oEvent.getSource().getBindingContext("CPAlternateBillings");
			/**
			 * Check for the Multi-Origin of the service
			 * If true pass Multi-Origin Property in the routing  
			 */
			if (oPPCCommon.isMultiOrigin(oModelContext)) {
				var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
				path = "ChannelPartners(CPGUID=guid'" + oModelContext.getProperty("CPGUID") + "'," +
					SAPMultiOriginPropertyName + "='" + oModelContext.getProperty(SAPMultiOriginPropertyName) + "')";
			} else {
				path = "ChannelPartners(CPGUID=guid'" + oModelContext.getProperty("CPGUID") + "')";
			}
			this._oRouter.navTo("cpdetail", {
				contextPath: path
			}, false);

			if (this.gotoParterCP_Exit) {
				this.gotoParterCP_Exit();
			}
		},

		AddAlternateBillings: function () {

			var that = this;
			this.Content = new com.arteriatech.ss.cp.create1.block.NewPartenerCP({
				columnLayout: '4',
				formAdjustment: 'BlockColumns'
			});
			var dialog = new sap.m.Dialog({
				title: 'Create Partner CP',
				type: 'Message',
				content: this.Content,
				contentWidth: '70%',
				beginButton: new sap.m.Button({
					text: 'Save',
					press: function () {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
						that.saveCP(dialog);
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function () {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			var oModel = this.getView().getModel("SSGW_MST");
			dialog.setModel(oModel, "SSGW_MST");

			var oLocalModelModelData = this.getView().getModel("LocalViewSettingDtl").getProperty("/");

			var oViewSettingModel = new sap.ui.model.json.JSONModel(oLocalModelModelData);
			dialog.setModel(oViewSettingModel, "LocalViewSettingDtl");

			var CPGUID = null,
				Name = "",
				CPTypeID = "",
				CPTypeDesc = "";
			if (that.getView().getModel("Customers")) {
				CPGUID = that.getView().getModel("Customers").getProperty("/1/CPGUID");
				Name = that.getView().getModel("Customers").getProperty("/1/Name");
				CPTypeID = that.getView().getModel("Customers").getProperty("/1/CPTypeID");
				CPTypeDesc = that.getView().getModel("Customers").getProperty("/1/CPTypeDesc");
			}
			var channelPartnerModel = that.getView().getModel("ChannelPartners");
			var oModel = jQuery.extend(true, [], channelPartnerModel.getData());

			var aNewCP = {
				"CPGUID": oPPCCommon.generateUUID(),
				"LoginID": "",
				"CPNo": "",
				"PartnerMgrGUID": null,
				"PartnerMgrName": "",
				"PartnerMgrNo": "",
				"Name": oModel.Name,
				"CPUID": "",
				"AccountGrp": "",
				"ParentID": CPGUID,
				"ParentName": Name,
				"SearchTerm": "",
				"ParentTypeID": CPTypeID,
				"ParentTypDesc": CPTypeDesc,
				"CPTypeID": "20",
				"CPTypeDesc": "",
				"Group1": "",
				"Group2": "",
				"Group3": "",
				"Group4": "",
				"CPStock": null,
				"UOM": "",
				"DOB": null,
				"Anniversary": null,
				"RouteID": "",
				"RouteDesc": "",
				"Latitude": oModel.Latitude,
				"Longitude": oModel.Longitude,
				"Address1": oModel.Address1,
				"Address2": oModel.Address2,
				"Address3": oModel.Address3,
				"Address4": oModel.Address4,
				"Landmark": oModel.Landmark,
				"ZoneID": "",
				"ZoneDesc": "",
				"TownID": "",
				"TownDesc": "",
				"CityID": "",
				"CityDesc": "",
				"StateID": "",
				"StateDesc": "",
				"DistrictID": "",
				"DistrictDesc": "",
				"Country": "",
				"CountryName": "",
				"PostalCode": oModel.PostalCode,
				"Mobile1": oModel.Mobile1,
				"Mobile2": oModel.Mobile2,
				"Landline": oModel.Landline,
				"EmailID": oModel.EmailID,
				"Currency": "",
				"CreditLimit": null,
				"CreditDays": 0,
				"VATNo": "",
				"TIN": "",
				"PAN": "",
				"StatusID": "01",
				"StatusDesc": "",
				"ApprvlStatusID": "",
				"ApprvlStatusDesc": "",
				"OwnerName": oModel.OwnerName,
				"SalesOfficeID": "",
				"SalesGrpDesc": "",
				"SalesGroupID": "",
				"SalesOffDesc": "",
				"IsKeyCP": "",
				"WeeklyOff": "",
				"WeeklyOffDesc": "",
				"ID1": oModel.ID1,
				"ID2": oModel.ID2,
				"FaxNo": "",
				"BusinessID1": oModel.BusinessID1,
				"BusinessID2": oModel.BusinessID2,
				"Tax1": "",
				"Tax2": "",
				"Tax3": "",
				"Tax4": "",
				"DeactivatedOn": null,
				"TaxClassification": "",
				"ApprovedOn": null,
				"ApprovedBy": "",
				"ApprovedAt": "PT15H43M52S",
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT14H17M09S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				"TestRun": "",
				"Group1Desc": "",
				"Group2Desc": "",
				"Group3Desc": "",
				"Group4Desc": ""
			};
			var oNewCPModel = new sap.ui.model.json.JSONModel();
			oNewCPModel.setData(aNewCP);
			dialog.setModel(oNewCPModel, "ChannelPartners");

			if (sap.ui.Device.support.touch === false) {
				dialog.addStyleClass("sapUiSizeCompact");
			}

			dialog.open();

			this.setValueHelps();

			if (this.AddAlternateBillings_Exit) {
				this.AddAlternateBillings_Exit();
			}

		},

		saveCP: function (dialog) {
			var that = this;
			this.validateHeader(dialog);
			if (oPPCCommon.doErrMessageExist()) {
				this.postCP(dialog);
				//	that.addNewCP(dialog);
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				this.DynamicSideContent = gCPDetailView.byId("ObjectPageLayout");
				oPPCCommon.showMessagePopover(this.DynamicSideContent);
			}

			if (this.saveCP_Exit) {
				this.saveCP_Exit();
			}
		},

		validateHeader: function (view) {

			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			var ChannelPartnersModel = view.getModel("ChannelPartners");
			var control = "",
				isCorrect = false;
			if (ChannelPartnersModel.getProperty("/Name") === "" || ChannelPartnersModel.getProperty("/Name") === undefined ||
				ChannelPartnersModel.getProperty("/Name").trim() === "") {
				this.addErrorMessages(gNewPartenerCP, "fNameEdit", oi18n.getText("common.message.pleaseEnter", gNewPartenerCP.byId("lNameEdit").getText()));
			}
			if (ChannelPartnersModel.getProperty("/OwnerName") === "" || ChannelPartnersModel.getProperty("/OwnerName") === undefined ||
				ChannelPartnersModel.getProperty("/OwnerName").trim() === "") {
				this.addErrorMessages(gNewPartenerCP, "fOwnerNameEdit", oi18n.getText("common.message.pleaseEnter", gNewPartenerCP.byId(
					"lOwnerNameEdit").getText()));
			}
			if (ChannelPartnersModel.getProperty("/Address1") === "" || ChannelPartnersModel.getProperty("/Address1") === undefined ||
				ChannelPartnersModel.getProperty("/Address1").trim() === "") {
				this.addErrorMessages(gNewPartenerCP, "fAddress1Edit", oi18n.getText("common.message.pleaseEnter", gNewPartenerCP.byId(
					"lAddress1Edit").getText()));
			}
			// if (ChannelPartnersModel.getProperty("/Landmark") === "" || ChannelPartnersModel.getProperty("/Landmark") === undefined ||
			// 	ChannelPartnersModel.getProperty("/Landmark").trim() === "") {
			// 	this.addErrorMessages(gNewPartenerCP, "fLandmarkEdit", oi18n.getText("common.message.pleaseEnter", gNewPartenerCP.byId(
			// 		"lLandmarkEdit").getText()));
			// }

			// if (gNewPartenerCP.byId("fDistrictIDEdit").getTokens().length === 0) {
			// 	this.addErrorMessages(gNewPartenerCP, "fDistrictIDEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
			// 		"lDistrictIDEdit").getText()));
			// }

			// if (gNewPartenerCP.byId("fCityIDEdit").getTokens().length === 0) {
			// 	this.addErrorMessages(gNewPartenerCP, "fCityIDEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
			// 		"lCityIDEdit").getText()));
			// }
			// if (gNewPartenerCP.byId("fTownIDEdit").getTokens().length === 0) {
			// 	this.addErrorMessages(gNewPartenerCP, "fTownIDEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
			// 		"lTownIDEdit").getText()));
			// }
			if (ChannelPartnersModel.getProperty("/PostalCode") === "" || ChannelPartnersModel.getProperty("/PostalCode") === undefined ||
				ChannelPartnersModel.getProperty("/PostalCode").trim() === "") {
				this.addErrorMessages(gNewPartenerCP, "fPostalCodeEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
					"lPostalCodeEdit").getText()));
			}
			if (gNewPartenerCP.byId("fStateIDEdit").getTokens().length === 0) {

				this.addErrorMessages(gNewPartenerCP, "fStateIDEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
					"lStateIDEdit").getText()));
			}
			if (gNewPartenerCP.byId("fCountryEdit").getTokens().length === 0) {

				this.addErrorMessages(gNewPartenerCP, "fCountryEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
					"lCountryEdit").getText()));
			}

			if (ChannelPartnersModel.getProperty("/PostalCode") !== "" && ChannelPartnersModel.getProperty("/PostalCode") !== undefined &&
				ChannelPartnersModel.getProperty("/PostalCode").trim() !== "") {
				control = gNewPartenerCP.byId("fPostalCodeEdit");
				isCorrect = oPPCCommon.isValidPostalCode(control.getValue());
				if (!isCorrect) {
					this.addErrorMessages(gNewPartenerCP, "fPostalCodeEdit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
						"lPostalCodeEdit").getText()));
				}

			}

			control = gNewPartenerCP.byId("fMobile1Edit");
			var isValidMobile = oPPCCommon.isValidPhone(control.getValue());
			if (!isValidMobile || control.getValue() === "") {
				this.addErrorMessages(gNewPartenerCP, "fMobile1Edit", oi18n.getText("commmon.valid.input", gNewPartenerCP.byId(
					"lMobile1Edit").getText()));
			}

			if (ChannelPartnersModel.getProperty("/DOB") !== "" && ChannelPartnersModel.getProperty("/DOB") !== null) {
				if (oPPCCommon.isFutureDate(ChannelPartnersModel.getProperty("/DOB"))) {
					this.addErrorMessages(view, "fDOBEdit", oi18n.getText("common.message.canNotBeFutureDate", "Date of Birth"));
				}
			}

			if (ChannelPartnersModel.getProperty("/Anniversary") !== "" && ChannelPartnersModel.getProperty("/Anniversary") !== null) {
				if (oPPCCommon.isFutureDate(ChannelPartnersModel.getProperty("/Anniversary"))) {
					this.addErrorMessages(view, "fAnniversaryEdit", oi18n.getText("common.message.canNotBeFutureDate", "Anniversary Date"));
				}
			}

			if (ChannelPartnersModel.getProperty("/EmailID") !== "" && ChannelPartnersModel.getProperty("/EmailID") !== undefined &&
				ChannelPartnersModel.getProperty("/EmailID").trim() !== "") {
				if (!oPPCCommon.isValidEmail(ChannelPartnersModel.getProperty("/EmailID"))) {
					this.addErrorMessages(view, "fEmailIDEdit", oi18n.getText("commmon.valid.input", "Email ID"));
				}
			}

			/*if (gNewPartenerCP.byId("fPartnerMgrNoEdit").getTokens().length === 0) {
				this.addErrorMessages(gNewPartenerCP, "fPartnerMgrNoEdit", oi18n.getText("commmon.valid.input", gSalesDataBlock.byId(
					"lPartnerMgrNo").getText()));
			}

			var creditlimit = gNewPartenerCP.byId("fCreditLimitEdit").getValue();
			if (creditlimit < 0) {
				this.addErrorMessages(gNewPartenerCP, "fCreditLimitEdit", oi18n.getText("common.message.pleaseEnterPositive", gSalesDataBlock.byId(
					"lCreditLimit").getText()));
			}*/

			if (this.validateHeader_Exit) {
				this.validateHeader_Exit();
			}

		},

		addErrorMessages: function (a, b, c, d) {
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(a, b, c, d);

			if (this.addErrorMessages_Exit) {
				this.addErrorMessages_Exit();
			}
		},

		addNewCP: function (dialog) {
			var sGUID = dialog.getModel("ChannelPartners").getProperty("/CPGUID");
			sGUID = sGUID.replace("-", "");
			sGUID = sGUID.replace("-", "");
			sGUID = sGUID.replace("-", "");
			sGUID = sGUID.replace("-", "");

			var newItem = {
				"CPGUID": this.getView().getModel("ChannelPartners").getProperty("/CPGUID"),
				"PFGUID": oPPCCommon.generateUUID(),
				"LoginID": "",
				"PartnerFunction": "",
				"CPNo": this.getView().getModel("ChannelPartners").getProperty("/CPNo"),
				"CPName": this.getView().getModel("ChannelPartners").getProperty("/Name"),
				"CPMobileNo": this.getView().getModel("ChannelPartners").getProperty("/Mobile1"),
				"PartnerCPNo": dialog.getModel("ChannelPartners").getProperty("/CPNo"),
				"PartnarName": dialog.getModel("ChannelPartners").getProperty("/Name"),
				"PartnerMobileNo": dialog.getModel("ChannelPartners").getProperty("/Mobile1"),
				"PartnarCPGUID": sGUID,
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT13H07M02S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				"StatusID": "01"
			};

			//Pus new row to model
			var oItemModel = this.getView().getModel("CPAlternateBillings");
			var oItemModelData = oItemModel.getData();
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Update Table count
			var iTotalLength = this.getView().getModel("CPAlternateBillings").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", iTotalLength);
			}

			dialog.close();

			if (this.addNewCP_Exit) {
				this.addNewCP_Exit();
			}
		},
		postCP: function (dialog) {
			var that = this;
			var oHeader = dialog.getModel("ChannelPartners");

			var view = this.getView();
			oHeader.setProperty("/DOB", oPPCCommon.addHoursAndMinutesToDate({
				dDate: oHeader.getProperty("/DOB")
			}));
			oHeader.setProperty("/Anniversary", oPPCCommon.addHoursAndMinutesToDate({
				dDate: oHeader.getProperty("/Anniversary")
			}));

			// oHeader.setProperty("/SalesOffDesc", this.getDDDescrption("fSalesOfficeIDEdit", view));
			// oHeader.setProperty("/CPTypeDesc", this.getDDDescrption("fCPTypeEdit", view));
			// oHeader.setProperty("/SalesGrpDesc", this.getDDDescrption("fSalesGroupIDEdit", view));
			// oHeader.setProperty("/WeeklyOffDesc", this.getDDDescrption("fWeeklyOffEdit", view));
			oHeader.setProperty("/TownID", this.getTokenKey("fTownIDEdit", view));
			oHeader.setProperty("/TownDesc", this.getTokenDesc("fTownIDEdit", view));
			oHeader.setProperty("/DistrictID", this.getTokenKey("fDistrictIDEdit", view));
			oHeader.setProperty("/DistrictDesc", this.getTokenDesc("fDistrictIDEdit", view));
			// oHeader.setProperty("/CityID", this.getTokenKey("fCityIDEdit", view));
			// oHeader.setProperty("/CityDesc", this.getTokenDesc("fCityIDEdit", view));
			oHeader.setProperty("/StateID", this.getTokenKey("fStateIDEdit", view));
			oHeader.setProperty("/StateDesc", this.getTokenDesc("fStateIDEdit", view));
			oHeader.setProperty("/Country", this.getTokenKey("fCountryEdit", view));
			oHeader.setProperty("/CountryName", this.getTokenDesc("fCountryEdit", view));

			// oHeader.setProperty("/ZoneID", this.getTokenKey("fZoneIDEdit", view));
			// oHeader.setProperty("/ZoneDesc", this.getTokenDesc("fZoneIDEdit", view));
			if (!that.getView().getModel("Customers")) {

				oHeader.setProperty("ParentID", that.getView().getModel("Customers").getProperty("/0/CPGUID"));
				oHeader.setProperty("ParentName", that.getView().getModel("Customers").getProperty("/0/Name"));
				oHeader.setProperty("ParentTypeID", that.getView().getModel("Customers").getProperty("/0/CPTypeID"));
				oHeader.setProperty("ParentTypDesc", that.getView().getModel("Customers").getProperty("/0/CPTypeDesc"));
			}
			if (this._oComponent.getModel("Customers")) {
				oHeader.setProperty("ParentID", that.getView().getModel("Customers").getProperty("/0/CPGUID"));
				oHeader.setProperty("ParentName", that.getView().getModel("Customers").getProperty("/0/Name"));
				oHeader.setProperty("ParentTypeID", that.getView().getModel("Customers").getProperty("/0/CPTypeID"));
				oHeader.setProperty("ParentTypDesc", that.getView().getModel("Customers").getProperty("/0/CPTypeDesc"));
			}

			var oHeaderData = dialog.getModel("ChannelPartners").getProperty("/");
			var loginID = sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").getCurrentUsers("ChannelPartners", "create");
			//Data Post
			var oModelCreate = this.getView().getModel("SSGW_MST");
			oModelCreate.setUseBatch(true);
			// oModelCreate.setDeferredBatchGroups(["create"]);
			oModelCreate.setHeaders({
				"x-arteria-loginid": loginID
			});
			oModelCreate.create("/ChannelPartners", oHeaderData, {
				success: function (oData) {
					if (oPPCCommon.doErrMessageExist()) {
						dialog.getModel("ChannelPartners").setProperty("/", oData);
						that.addNewCP(dialog);
					} else {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						that.DynamicSideContent = gCPDetailView.byId("ObjectPageLayout");
						oPPCCommon.showMessagePopover(that.DynamicSideContent);
					}
				},
				error: function (response) {
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);
					that.DynamicSideContent = gCPDetailView.byId("ObjectPageLayout");
					oPPCCommon.showMessagePopover(that.DynamicSideContent);
				}
			});
			if (this.postCP_Exit) {
				this.postCP_Exit();
			}
		},

		getTokenKey: function (controlID, view) {
			if (view && view.byId(controlID)) {
				view = view;
			} else if (gBasicDataBlock && gBasicDataBlock.byId(controlID)) {
				view = gBasicDataBlock;
			} else if (gSalesDataBlock && gSalesDataBlock.byId(controlID)) {
				view = gSalesDataBlock;
			} else if (gHeaderBlock && gHeaderBlock.byId(controlID)) {
				view = gHeaderBlock;
			}
			var key = "";
			if (view.byId(controlID)) {
				if (view.byId(controlID).getTokens() !== undefined) {
					if (view.byId(controlID).getTokens().length !== 0) {
						key = view.byId(controlID).getTokens()[0].getProperty("key");
					}
				}

			}

			if (this.getTokenKey_Exit) {
				key = this.getTokenKey_Exit(controlID, view);
			}

			return key;
		},

		getTokenDesc: function (controlID, view) {
			if (view && view.byId(controlID)) {
				view = view;
			} else if (gBasicDataBlock && gBasicDataBlock.byId(controlID)) {
				view = gBasicDataBlock;
			} else if (gSalesDataBlock && gSalesDataBlock.byId(controlID)) {
				view = gSalesDataBlock;
			} else if (gHeaderBlock && gHeaderBlock && gHeaderBlock.byId(controlID)) {
				view = gHeaderBlock;
			}
			var desc = "";
			if (view.byId(controlID)) {
				if (view.byId(controlID).getTokens().length !== 0) {

					desc = view.byId(controlID).getTokens()[0].getProperty("text").split("(")[0];

				}
			}

			if (this.getTokenDesc_Exit) {
				desc = this.getTokenDesc_Exit(controlID, view);
			}

			return desc;
		},

		LinkAlternateBillings: function () {
			var that = this;
			this.Content = new com.arteriatech.ss.cp.create1.block.LinkPartenerCP({
				columnLayout: '4',
				formAdjustment: 'BlockColumns'
			});
			var dialog = new sap.m.Dialog({
				title: 'Link Partner CP',
				type: 'Message',
				content: this.Content,
				contentWidth: '70%',
				beginButton: new sap.m.Button({
					text: 'Save',
					press: function () {
						that.linkCP(dialog);
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});

			var oModel = this.getView().getModel("SSGW_MST");
			dialog.setModel(oModel, "SSGW_MST");

			this.getCPs(dialog);

			if (sap.ui.Device.support.touch === false) {
				dialog.addStyleClass("sapUiSizeCompact");
			}

			// dialog.open();
			if (this.LinkAlternateBillings_Exit) {
				this.LinkAlternateBillings_Exit();
			}
		},

		linkCP: function (dialog) {
			var oItemModel = this.getView().getModel("CPAlternateBillings");
			var oItemModelData = oItemModel.getData();

			var aSelectedIndices = gLinkPartenerCP.byId("UICPTable").getSelectedIndices();
			for (var i = 0; i < aSelectedIndices.length; i++) {
				var sGUID = dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPGUID");
				sGUID = sGUID.replace("-", "");
				sGUID = sGUID.replace("-", "");
				sGUID = sGUID.replace("-", "");
				sGUID = sGUID.replace("-", "");

				var newItem = {
					"CPGUID": this.getView().getModel("ChannelPartners").getProperty("/CPGUID"),
					"PFGUID": oPPCCommon.generateUUID(),
					"LoginID": "",
					"PartnerFunction": "",
					"CPNo": this.getView().getModel("ChannelPartners").getProperty("/CPNo"),
					"CPName": this.getView().getModel("ChannelPartners").getProperty("/Name"),
					"CPMobileNo": this.getView().getModel("ChannelPartners").getProperty("/Mobile1"),
					"PartnerCPNo": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo"),
					"PartnarName": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name"),
					"PartnerMobileNo": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Mobile1"),
					"PartnarCPGUID": sGUID,
					"StatusID": "01",
					"CreatedBy": "",
					"CreatedOn": null,
					"CreatedAt": "PT13H07M02S",
					"ChangedBy": "",
					"ChangedOn": null,
					"ChangedAt": "PT00H00M00S"
				};

				//Pus new row to model
				oItemModelData.push(newItem);

			}

			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Update Table count
			var iTotalLength = this.getView().getModel("CPAlternateBillings").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", iTotalLength);
			}

			dialog.close();
			if (this.linkCP_Exit) {
				this.linkCP_Exit();
			}
		},

		getCPs: function (dialog) {
			var aCPNoF4Filter = [];
			aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "ParentID",
				sap.ui.model.FilterOperator.EQ, [this.getView().getModel("ChannelPartners").getProperty("/ParentID")],
				false, false, false);
			aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
				sServiceName: "ChannelPartners",
				sRequestType: "read"
			})], false, false, false);
			var SFGW_MSTModel = this._oComponent.getModel("SSGW_MST");
			SFGW_MSTModel.attachRequestSent(function () {
				gCPDetailView.setBusy(true);
			});
			SFGW_MSTModel.attachRequestCompleted(function () {
				gCPDetailView.setBusy(false);
			});
			SFGW_MSTModel.read(
				"/ChannelPartners", {
					filters: aCPNoF4Filter,
					success: function (oData) {
						var oNewCPModel = new sap.ui.model.json.JSONModel();
						oNewCPModel.setData(oData.results);
						dialog.setModel(oNewCPModel, "CPs");
						dialog.open();
					},
					error: function (error) {
						var oNewCPModel = new sap.ui.model.json.JSONModel();
						oNewCPModel.setData([]);
						dialog.setModel(oNewCPModel, "CPs");
						dialog.open();
					}
				});
			if (this.getCPs_Exit) {
				this.getCPs_Exit();
			}
		},

		DeleteAlternateBillings: function (oEvent) {
			oPPCCommon.removeAllMsgs();
			this.DynamicSideContent = gCPDetailView.byId("ObjectPageLayout");

			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("CPAlternateBillings").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));

			//Remove Row from model
			var oItemModel = this.getView().getModel("CPAlternateBillings");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}

			//Update MessagManager message count 
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);

			//If no errors in message manager, hide popover
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.DynamicSideContent);
			}

			//Update Table count
			var iTotalLength = this.getView().getModel("CPAlternateBillings").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", iTotalLength);
			}

			if (this.DeleteAlternateBillings_Exit) {
				this.DeleteAlternateBillings_Exit();
			}

		},
		PartnerCPF4: function (oEvent) {
			/*
						this.CPTokenInput = oEvent.getSource();
						var that = this;
						var sControlID = "fPartnerCPNoEdit";
						if (sap.ui.Device.system.tablet || sap.ui.Device.system.phone) {
							sControlID = "fPartnerCPNoEditM";
						}

						CommonValueHelp.ChannelPartenerF4({
							oController: this,
							oi18n: oi18n,
							oUtilsI18n: oUtilsI18n,
							sCustomerCode: that.getView().getModel("ChannelPartners").getProperty("/ParentID"),
							sCustomerName: that.getView().getModel("ChannelPartners").getProperty("/ParentName"),
							controlID: sControlID,
							bCPType: false,
							bCPGUIDKey: true,
							bApprovedNTRequired: false,
							bMultiSelect: false
						});
					*/

			if (this.PartnerCPF4_Exit) {
				this.PartnerCPF4_Exit();
			}
		},
		setValueHelps: function () {
			var lNewPartenerCP = gNewPartenerCP;
			var lBasicDataBlock = gBasicDataBlock;
			var tokens;
			if (lBasicDataBlock.byId("fCountryEdit").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("fCountryEdit").getTokens();
				lNewPartenerCP.byId("fCountryEdit").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
			if (lBasicDataBlock.byId("fStateIDEdit").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("fStateIDEdit").getTokens();
				lNewPartenerCP.byId("fStateIDEdit").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
			if (lBasicDataBlock.byId("fDistrictIDEdit").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("fDistrictIDEdit").getTokens();
				lNewPartenerCP.byId("fDistrictIDEdit").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
			if (lBasicDataBlock.byId("fCityIDEdit").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("fCityIDEdit").getTokens();
				lNewPartenerCP.byId("fCityIDEdit").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
			if (lBasicDataBlock.byId("fTownIDEdit").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("fTownIDEdit").getTokens();
				lNewPartenerCP.byId("fTownIDEdit").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
			if (lBasicDataBlock.byId("idSubDistrict").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("idSubDistrict").getTokens();
				lNewPartenerCP.byId("idSubDistrict").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
			if (lBasicDataBlock.byId("idWard").getTokens().length > 0) {
				tokens = lBasicDataBlock.byId("idWard").getTokens();
				lNewPartenerCP.byId("idWard").addToken(new sap.m.Token({
					key: tokens[0].getKey(),
					text: tokens[0].getText()
				}));
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailALTERNATEBILLINGS
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailALTERNATEBILLINGS
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailALTERNATEBILLINGS
		 */
		//	onExit: function() {
		//
		//	}

	});

});