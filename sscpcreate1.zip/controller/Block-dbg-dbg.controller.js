/*
 * Copyright (C) 2015-2016 Arteria Technologies Pvt. Ltd. All rights reserved
 */

jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.require("com.arteriatech.ss.cp.create1.util.CPStatusFormatter");
jQuery.sap.require("com.arteriatech.ss.cp.create1.util.CPFormatter");
jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.CommonValueHelp");

sap.ui.define([
	"com/arteriatech/ss/cp/create1/controller/BaseController",
	"com/arteriatech/ss/utils/js/CommonValueHelp"

], function (BaseController, oSSCommonValueHelp) {
	"use strict";
	var contextPath = "";
	var oDialog = new sap.m.BusyDialog();
	var busyDialog = new sap.m.BusyDialog();
	var oi18n = "",
		oUtilsI18n;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;

	return BaseController.extend("com.arteriatech.ss.cp.create1.controller.Block", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf webapp.view.CPCreate
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gCPBlockView = this.getView();

			if (gCPDetailView === "") {
				this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			} else {
				this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gCPDetailView));
				this.ObjectPageLayout = gCPDetailView.byId("ObjectPageLayout");
			}
			if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.SalesDataBlock") {
				gSalesDataBlock = this.getView();
				this.setSalesDataValueHelpProperty();
			} else if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.BasicDataBlock") {
				this._oView = this.getView();
				//	this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
				gBasicDataBlock = this.getView();
				this.setBasicDataValueHelpProperty();
				// this.CountryModel();

			} else if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.HeaderBlock") {
				gHeaderBlock = this.getView();
			} else if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.LinkPartenerCP") {
				gLinkPartenerCP = this.getView();
			} else if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.NewPartenerCP") {
				gNewPartenerCP = this.getView();
				this.setNewCPDataValueHelpProperty();
			} else if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.DMSGeo") {
				gDMSGeo = this.getView();
			} else if (this.getView().sViewName === "com.arteriatech.ss.cp.create1.block.CPAdditionalDetails") {
				gAdditionalDetails = this.getView();
			}
			if (gCPDetailView === "") {
				this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			} else {
				this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gCPDetailView));
				this.ObjectPageLayout = gCPDetailView.byId("ObjectPageLayout");
			}
			oi18n = goi18n;
			oUtilsI18n = goUtilsI18n;

			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.setSalesPersonModel();
			this.setValueHelpProperty();

			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},
		setValueHelpProperty: function () {
			this.stateTokenInput = this.getView().byId("fStateIDEdit");
			this.aStateKeys = ["ID", "Description"];
			this.countryTokenInput = this.getView().byId("fCountryEdit");
			this.aCountryKeys = ["ID", "Description"];
			this.subDisTokenInput = this.getView().byId("idSubDistrict");
			this.aSubDiscKeys = ["SubDistrictID", "SubDistrictDesc"];
			this.wardTokenInput = this.getView().byId("idWard");
			this.aWardKeys = ["CNSWardID", "CNSWardName"];
		},
		ontokenCountryF4: function () {
			var that = this;
			gBasicDataBlock.byId("fCountryEdit").removeAllTokens();
			gBasicDataBlock.byId("fStateIDEdit").removeAllTokens();
			gBasicDataBlock.byId("fDistrictIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idSubDistrict").removeAllTokens();
			gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idWard").removeAllTokens();
			gBasicDataBlock.byId("fCityIDEdit").removeAllTokens();
			that.CountryModel();
		},
		onNewCPtokenCountryF4: function () {
			// var that = this;
			gNewPartenerCP.byId("fCountryEdit").removeAllTokens();
			gNewPartenerCP.byId("fStateIDEdit").removeAllTokens();
			gNewPartenerCP.byId("fDistrictIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idSubDistrict").removeAllTokens();
			gNewPartenerCP.byId("fTownIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idWard").removeAllTokens();
			gNewPartenerCP.byId("fCityIDEdit").removeAllTokens();
			// that.CountryModel();
		},

		CustomerF4: function () {
			var that = this;
			that.CustomerNoF4({
				oController: that,
				oi18n: oi18n,
				oUtilsI18n: oUtilsI18n,
				controlID: "inputCustomerF4",
				title: oi18n.getText("List.ValueHelp.Parent.header"),
				customerIDLabel: oi18n.getText("List.ValueHelp.Parent.parentNo"),
				customerNameLabel: oi18n.getText("List.ValueHelp.Parent.name"),
				bMultiSelect: false
			}, function (Customers) {
				var cust = [];
				cust.push(Customers[0].mAggregations.customData[0].mProperties.value);
				var oCustomersModel = new sap.ui.model.json.JSONModel();
				oCustomersModel.setData("");

				that._oComponent.getModel("ChannelPartners").setProperty("/CustomerNo", Customers[0].mAggregations.customData[0].mProperties.value
					.CPNo);

				that._oComponent.getModel("ChannelPartners").setProperty("/CPNo", Customers[0].mAggregations.customData[0].mProperties.value.CPNo);

				//that._oComponent.getModel("ChannelPartners").setProperty("/Name", Customers[0].mAggregations.customData[0].mProperties.value.Name);

				that._oComponent.getModel("ChannelPartners").setProperty("/ParentID", Customers[0].mAggregations.customData[0].mProperties.value
					.CPNo);

				that._oComponent.getModel("ChannelPartners").setProperty("/CPTypeID", Customers[0].mAggregations.customData[0].mProperties.value
					.CPTypeID);

				that._oComponent.getModel("LocalViewSettingDtl").setProperty("/CPTypeID", Customers[0].mAggregations.customData[0].mProperties.value
					.CPTypeID);

				that._oComponent.getModel("LocalViewSettingDtl").setProperty("/Name", Customers[0].mAggregations.customData[0].mProperties.value
					.Name);

				that._oComponent.getModel("LocalViewSettingDtl").setProperty("/gCPGUID", Customers[0].mAggregations.customData[0].mProperties.value
					.CPGUID);

				that._oComponent.getModel("LocalViewSettingDtl").setProperty("/gCPTypeId", Customers[0].mAggregations.customData[0].mProperties.value
					.CPTypeID);
				//
				that._oComponent.getModel("LocalViewSettingDtl").setProperty("/CustomerNo", Customers[0].mAggregations.customData[0].mProperties
					.value.CPNo);

				that.CustomerDetails(Customers[0].mAggregations.customData[0].mProperties.value.CPGUID);

			});
		},
		CustomerNoF4: function (mParameters, requestCompleted) {
			if (mParameters.controlID === undefined ||
				mParameters.controlID === null) {
				mParameters.controlID = "inputCustomerNo"
			}
			if (mParameters.bMultiSelect === undefined ||
				mParameters.bMultiSelect === null) {
				mParameters.bMultiSelect = true;
			}
			var sF4Heading = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SFGW_MST"),
				sEntityType: "Customer",
				sPropertyName: "CustomerNo",
				oUtilsI18n: mParameters.oUtilsI18n
			});

			var oCustomerTokenInput;
			if (mParameters.oController.CustomerTokenInput) {
				oCustomerTokenInput = mParameters.oController.CustomerTokenInput.getValue();
			}
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: oCustomerTokenInput,
				title: sF4Heading,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.oController.aCustomerKeys[0],
				descriptionKey: mParameters.oController.aCustomerKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					if (mParameters.oController.CustomerTokenInput) {
						mParameters.oController.CustomerTokenInput.setTokens(oControlEvent.getParameter("tokens"));
						if (mParameters.controlID) {
							if (mParameters.oController.getView().byId(mParameters.controlID)) {
								mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
								mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
							} else {
								mParameters.oController.CustomerTokenInput.setValueState(sap.ui.core.ValueState.None);
								mParameters.oController.CustomerTokenInput.setValueStateText("");
							}
						} else {
							mParameters.oController.CustomerTokenInput.setValueState(sap.ui.core.ValueState.None);
							mParameters.oController.CustomerTokenInput.setValueStateText("");
						}
						if (requestCompleted) {
							requestCompleted(mParameters.oController.CustomerTokenInput.getTokens());
						}
					}

					oValueHelpDialog.close();
				},
				cancel: function (oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			this.setCustomerF4Columns(oValueHelpDialog, mParameters);
			this.setCustomerF4FilterBar(oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
			if (mParameters.oController.CustomerTokenInput) {
				oValueHelpDialog.setTokens(mParameters.oController.CustomerTokenInput.getTokens());
			}
		},
		setCustomerF4Columns: function (oValueHelpDialog, mParameters) {
			var sCustomerNoLbl = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SFGW_MST"),
				sEntityType: "Customer",
				sPropertyName: "CustomerNo",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			var sNameLbl = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SFGW_MST"),
				sEntityType: "Customer",
				sPropertyName: "Name",
				oUtilsI18n: mParameters.oUtilsI18n
			});

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: sCustomerNoLbl,
						template: "CustomerNo"
					}, {
						label: sNameLbl,
						template: "Name"
					}]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

			} else {
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: sCustomerNoLbl
					}),
					template: new sap.m.Text({
						text: "{CPNo}"
					}),
					sortProperty: "CustomerNo",
					filterProperty: "CustomerNo"
				}));
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: sNameLbl
					}),
					template: new sap.m.Text({
						text: "{Name}"
					}),
					sortProperty: "Name",
					filterProperty: "Name"
				}));
				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}
		},
		setCustomerF4FilterBar: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var oTokenInputValue = "";
			if (mParameters.oController.CustomerTokenInput) {
				oTokenInputValue = mParameters.oController.CustomerTokenInput.getValue();
			}
			var code = new sap.m.Input({
				value: oTokenInputValue,
				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SFGW_MST"),
					sEntityType: "Customer",
					sPropertyName: "CustomerNo",
					oUtilsI18n: mParameters.oUtilsI18n
				})
			});
			var desc = new sap.m.Input({

			});
			var sCustomerNoLbl = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SFGW_MST"),
				sEntityType: "Customer",
				sPropertyName: "CustomerNo",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			var sNameLbl = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SFGW_MST"),
				sEntityType: "Customer",
				sPropertyName: "Name",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "Customer",
						groupName: "gn1",
						name: "n1",
						label: sCustomerNoLbl,
						control: code
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "Customer",
						groupName: "gn1",
						name: "n2",
						label: sNameLbl,
						control: desc
					})
				],
				search: function (oEvent) {
					var codeValue = code.getValue();
					var descValue = desc.getValue();
					var aCustomerF4Filter = new Array();
					aCustomerF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCustomerF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
						sServiceName: "Customers",
						sRequestType: "read"
					})], false, false, false);
					aCustomerF4Filter = com.arteriatech.ss.utils.js.CommonValueHelp.setODataModelReadFilter(mParameters.oController.getView(), "",
						aCustomerF4Filter, "CustomerNo", "", [codeValue], false, false, false);
					aCustomerF4Filter = com.arteriatech.ss.utils.js.CommonValueHelp.setODataModelReadFilter(mParameters.oController.getView(), "",
						aCustomerF4Filter, "Name", "", [descValue], false, false, false);
					var SSGW_MST = mParameters.oController._oComponent.getModel("SSGW_MST");
					SSGW_MST.attachRequestSent(function () {
						busyDialog.open();
					});
					SSGW_MST.attachRequestCompleted(function () {
						busyDialog.close();
					});
					// SFGW_MSTModel.setHeaders({
					// "x-arteria-loginid":
					// oSSCommon.getCurrentUsers("Customers",
					// "read")
					// });
					SSGW_MST
						.read(
							"/UserChannelPartners", {
								filters: aCustomerF4Filter,
								/*	urlParameters: {
										"$select": "CustomerNo,Name"
									},*/
								success: function (oData) {
									var CustomersModel = new sap.ui.model.json.JSONModel();
									if (oValueHelpDialog.getTable().bindRows) {
										oValueHelpDialog.getTable().clearSelection();
										CustomersModel.setData(oData.results);
										oValueHelpDialog.getTable().setModel(CustomersModel);
										oValueHelpDialog.getTable().bindRows("/");

										if (oData.results.length === 0) {
											oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
										}
									} else {
										//Setting Rows for sap.m.Table....................................
										var oRowsModel = new sap.ui.model.json.JSONModel();
										oRowsModel.setData(oData.results);
										oValueHelpDialog.getTable().setModel(oRowsModel);
										if (oValueHelpDialog.getTable().bindItems) {
											var oTable = oValueHelpDialog.getTable();
											oTable.bindAggregation("items", "/", function () {
												var aCols = oTable.getModel("columns").getData().cols;
												return new sap.m.ColumnListItem({
													cells: aCols.map(function (column) {
														var colname = column.template;
														return new sap.m.Text({
															text: "{" + colname + "}",
															wrapping: true
														});
													})
												});
											});
										}

										if (oData.results.length === 0) {
											oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
										}
									}
									if (oData.results.length > 0) {
										oValueHelpDialog.update();
									}
								},
								error: function (error) {
									oValueHelpDialog.getTable().clearSelection();
									if (oValueHelpDialog.getTable().getModel() != undefined)
										oValueHelpDialog.getTable().getModel().setProperty("/", {});
									oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									com.arteriatech.ss.utils.js.CommonValueHelp.dialogErrorMessage(error, "No Data Found");

								}
							});
				},
				reset: function () {

				}
			}));
		},

		onChangeOutletSize: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			selectedText = selectedText.split("- ")[1];
			that._oComponent.getModel("ChannelPartners").setProperty("/OutletSizeDesc", selectedText);
		},
		onChangeOutletShape: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			selectedText = selectedText.split("- ")[1];
			that._oComponent.getModel("ChannelPartners").setProperty("/OutletShapeDesc", selectedText);
		},
		onChangeOutletLocation: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			selectedText = selectedText.split("- ")[1];
			that._oComponent.getModel("ChannelPartners").setProperty("/OutletLocDesc", selectedText);
		},
		onChangeHomeDelivery: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/HomeDelivery", selectedText);
		},
		onChangePhoneOrderAvl: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/PhoneOrder", selectedText);
		},
		onChangeComputerBilling: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/ComputerBilling", selectedText);
		},
		onChangeHospitalNearBy: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/HospitalNear", selectedText);
		},
		onChangeEduInsAvl: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/EdcNear", selectedText);
		},
		onChangeSmtPhneAvl: function (oEvent) {
			var that = this;
			var selectedText = oEvent.getSource().getSelectedItem().getText();
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/SmartPhone", selectedText);
		},
		onOpeningTimeChange: function (oEvent) {
			var that = this;
			var time = oEvent.getParameter("value");
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm"
			});
			var TZOffms = new Date(0).getTimezoneOffset() * 60 * 1000;
			var parsedTime = timeFormat.parse(time).getTime() - TZOffms;
			var depTime = {
				ms: parsedTime,
				__edmType: "Edm.Time"
			};
			that._oComponent.getModel("ChannelPartners").setProperty("/OpeningTime", depTime);
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/OpeningTime", time);
		},
		onClosingTimeChange: function (oEvent) {
			var that = this;
			var time = oEvent.getParameter("value");
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm"
			});
			var TZOffms = new Date(0).getTimezoneOffset() * 60 * 1000;
			var parsedTime = timeFormat.parse(time).getTime() - TZOffms;
			var depTime = {
				ms: parsedTime,
				__edmType: "Edm.Time"
			};
			that._oComponent.getModel("ChannelPartners").setProperty("/ClosingTime", depTime);
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/ClosingTime", time);
		},
		onLunchTimeChange: function (oEvent) {
			var that = this;
			var time = oEvent.getParameter("value");
			var timeFormat = sap.ui.core.format.DateFormat.getTimeInstance({
				pattern: "HH:mm"
			});
			var TZOffms = new Date(0).getTimezoneOffset() * 60 * 1000;
			var parsedTime = timeFormat.parse(time).getTime() - TZOffms;
			var depTime = {
				ms: parsedTime,
				__edmType: "Edm.Time"
			};
			that._oComponent.getModel("ChannelPartners").setProperty("/LunchTime", depTime);
			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/LunchTime", time);
		},
		getSelectedCPParent: function (oEvent) {
			var that = this;

			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();

			var custcontrl = oEvent.getSource().getSelectedItem().getBindingContext("Customers");

			var customerselected = custcontrl.getObject();

			that._oComponent.getModel("ChannelPartners").setProperty("/CustomerNo", customerselected.CustomerNo);

			that._oComponent.getModel("ChannelPartners").setProperty("/CPNo", customerselected.CustomerNo);

			// that._oComponent.getModel("ChannelPartners").setProperty("/Name", customerselected.Name);

			that._oComponent.getModel("ChannelPartners").setProperty("/ParentID", customerselected.CustomerNo);

			that._oComponent.getModel("ChannelPartners").setProperty("/ParentName", customerselected.Name);

			//	that._oComponent.getModel("ChannelPartners").setProperty("/CPTypeID", customerselected.CPTypeID);

			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/CPTypeID", customerselected.CPTypeID);

			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/CPTypeIDMandat", customerselected.CPTypeID);

			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/Name", customerselected.Name);

			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/gCPGUID", customerselected.CPGUID);

			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/gCPTypeId", customerselected.CPTypeID);

			that._oComponent.getModel("LocalViewSettingDtl").setProperty("/CustomerNo", customerselected.CustomerNo);

			that._oComponent.getModel("ChannelPartners").setProperty("/CPTypeDesc", customerselected.CPTypeDesc);

			// if (customerselected.CustomerNo === "") {
			gBasicDataBlock.byId("fStateIDEdit").removeAllTokens();
			gBasicDataBlock.byId("fDistrictIDEdit").removeAllTokens();
			gBasicDataBlock.byId("fCityIDEdit").removeAllTokens();
			gBasicDataBlock.byId("fCountryEdit").removeAllTokens();
			// }

			if (customerselected.CPTypeID === "02") {
				that.DistributorDetails(customerselected.CPGUID);
			} else {
				that.CustomerDetails(customerselected.CPGUID);
			}
		},

		CustomerDetails: function (CustomerNo) {

			oDialog.open();
			var view = this.getView();
			var oSSGW_MSTModel = view.getModel("SFGW_MST");

			oSSGW_MSTModel.setUseBatch(true);
			var thisController = this;
			var LoginID = this.getCurrentUsers("ChannelPartners", "read");
			oSSGW_MSTModel.setHeaders({
				"x-arteria-loginid": LoginID
			});
			oSSGW_MSTModel.read("/Customers", {
				filters: this.prepareDebitItemsODataFilter(LoginID, CustomerNo),
				success: function (oData) {
					setTimeout(function () {
						thisController.setDataFromParent(oData.results[0]);
					}, 1000);

					oDialog.close();
					return;
				},
				error: function (error) {
					oDialog.close();
					return;
				}
			});

		},
		prepareDebitItemsODataFilter: function (LoginID, CustomerNo) {
			var DebitItemsFilters = new Array();
			var that = this;
			var oView = this.getView();
			var DNin = new Array();
			// Getting values from context path

			DebitItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", DebitItemsFilters, "CustomerNo", sap.ui.model.FilterOperator
				.EQ, [CustomerNo], false, false, false);

			DebitItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", DebitItemsFilters, "LoginID", "", [LoginID],
				false, false, false);

			return DebitItemsFilters;
		},
		DistributorDetails: function (GUID) {
			GUID = GUID.substring(0, 8) + "-" + GUID.substring(8, 12) + "-" + GUID.substring(12, 16) + "-" + GUID.substring(16, 20) + "-" +
				GUID.substring(20, GUID.length);
			var that = this;
			var view = this.getView();
			var oSSGW_MSTModel = view.getModel("SSGW_MST");
			oSSGW_MSTModel.setUseBatch(true);
			var thisController = this;
			var LoginID = that.getCurrentUsers("ChannelPartners", "read");
			oSSGW_MSTModel.setHeaders({
				"x-arteria-loginid": LoginID
			});
			oSSGW_MSTModel.read("/ChannelPartners(CPGUID=guid'" + GUID + "')", {
				urlParameters: {
					"$expand": "CPDMSDivisions,CPPartnerFunctions"
				},
				success: function (oData) {
					thisController.setDataFromParent(oData);
				},
				error: function (error) {}
			});

			if (this.DistributorDetails_Exit) {
				this.DistributorDetails_Exit();
			}
		},

		setDataFromParent: function (oData) {
			if (oData) {
				if (oData.Currency) {
					this.getView().getModel("ChannelPartners").setProperty("/Currency", oData.Currency);
				}
				//	gBasicDataBlock.byId("fCountryEdit").removeAllTokens();

				//	gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();

				if (oData.CountryID) {
					gBasicDataBlock.byId("fCountryEdit").addToken(new sap.m.Token({
						key: oData.CountryID,
						text: oData.CountryDesc + " (" + oData.CountryID + ")"
					}));
					this.getPostalMaxLength(oData.CountryID);
				} else if (oData.Country) {
					gBasicDataBlock.byId("fCountryEdit").addToken(new sap.m.Token({
						key: oData.Country,
						text: oData.CountryName + " (" + oData.Country + ")"
					}));
					this.getPostalMaxLength(oData.CountryID);
				}
				if (oData.Region) {
					gBasicDataBlock.byId("fStateIDEdit").addToken(new sap.m.Token({
						key: oData.Region,
						text: oData.RegionDesc + " (" + oData.Region + ")"
					}));
				}
				// if (oData.District) {
				// 	gBasicDataBlock.byId("fDistrictIDEdit").addToken(new sap.m.Token({
				// 		key: "9999",
				// 		text: oData.District + " (9999)"
				// 	}));
				// }
				// if (oData.DistrictID) {
				// 	gBasicDataBlock.byId("fDistrictIDEdit").addToken(new sap.m.Token({
				// 		key: oData.DistrictID,
				// 		text: oData.DistrictDesc + " (" + oData.DistrictID + ")"
				// 	}));
				// }
				// if (oData.City) {
				// 	gBasicDataBlock.byId("fCityIDEdit").addToken(new sap.m.Token({
				// 		key: "9999999999",
				// 		text: oData.City + " (9999999999)"
				// 	}));
				// }
				// if (oData.CityID) {
				// 	gBasicDataBlock.byId("fCityIDEdit").addToken(new sap.m.Token({
				// 		key: oData.CityID,
				// 		text: oData.CityDesc + " (" + oData.CityID + ")"
				// 	}));
				// }
				// if (oData.SubDistrictID) {
				// 	gBasicDataBlock.byId("idSubDistrict").addToken(new sap.m.Token({
				// 		key: oData.SubDistrictID,
				// 		text: oData.SubDistrictDesc + " (" + oData.SubDistrictID + ")"
				// 	}));
				// }
				// if (oData.SubDistrictID) {
				// 	gBasicDataBlock.byId("idWard").addToken(new sap.m.Token({
				// 		key: oData.WardID,
				// 		text: oData.WardDesc + " (" + oData.WardID + ")"
				// 	}));
				// }
				// if (oData.Region) {
				// 	gBasicDataBlock.byId("fStateIDEdit").addToken(new sap.m.Token({
				// 		key: oData.Region,
				// 		text: oData.RegionDesc + " (" + oData.Region + ")"
				// 	}));
				// }
				// 	if(oData.City){
				// 		gBasicDataBlock.byId("fCityIDEdit").addToken(new sap.m.Token({
				// 		key: oData.City,
				// 		text: oData.City + " (" + oData.City + ")"
				// 	}));
				// }
				// 	if(oData.District){
				// 		gBasicDataBlock.byId("fDistrictIDEdit").addToken(new sap.m.Token({
				// 		key: oData.District,
				// 		text: oData.District + " (" + oData.District + ")"
				// 	}));
				// }
			}
			//	this.setstateModel();
			var oOwnDataModel = new sap.ui.model.json.JSONModel();
			oOwnDataModel.setData(oData);
			this._oComponent.setModel(oOwnDataModel, "OwnData");
		},

		getPostalMaxLength: function (CountryID) {
			var that = this;
			var view = this.getView();
			var oPCGWModel = view.getModel("PCGW");
			oPCGWModel.setUseBatch(false);
			oPCGWModel.read("/CountryByCountryID", {
				urlParameters: "CountryID='" + CountryID + "'",
				success: function (oData) {
					oPCGWModel.setUseBatch(true);
					if (oData && oData.CountryByCountryID && oData.CountryByCountryID.PostalCodeLength) {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/MaxLengthPostalCode", parseInt(oData.CountryByCountryID.PostalCodeLength));
					}
				},
				error: function (error) {
					oPCGWModel.setUseBatch(true);
				}
			});
			if (this.getPostalMaxLength_Exit) {
				this.getPostalMaxLength_Exit();
			}
		},

		CountryModel: function () {
			var that = this;

			var aCityFilterArray = new Array();
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "LoginID", "", [
				that.getCurrentUsers("ChannelPartners", "read")
			], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "EntityType", sap.ui
				.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "PropName", sap.ui
				.model.FilterOperator.EQ, ["Country"], false, false, false);

			var sPCGWModel = that._oComponent.getModel("PCGW");

			sPCGWModel.read("/ValueHelps", {
				filters: aCityFilterArray,
				urlParameters: {
					"$select": "ID,Description"
				},
				success: function (oData) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData(oData.results);
					that._oComponent.setModel(SONosModel, "CountryModel");
					//that.getCustomerDetail();
				},
				error: function (error) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData([]);
					that._oComponent.setModel(SONosModel, "CountryModel");
				}
			});
		},
		handleCountrySuggest: function (oEvent) {

			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["ID", "Description"],
				sBinding: "suggestionItems"
			});
		},

		suggestionItemCountry: function (oEvent) {
			var that = this;
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "CountryModel",
					//sKey: "ID",
					sKey: "ID",
					sDescription: "Description"
				},
				function (key, desc) {

					that.getView().getModel("ChannelPartners").setProperty("/Country", key);
					that.getView().getModel("ChannelPartners").setProperty("/CountryName", desc);
					that.setstateModel();
					//oEvent.getSource().setValue("");
				}
			);
			// this.getView().byId("inputMaterial").setValueState("None");
			// this.getView().byId("inputMaterial").setValueStateText("");
		},
		onChangeCountry: function (oEvent) {
			if (oEvent.getSource().getValue() === "") {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}
			var that = this;
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "CountryModel",
					sKey: "ID",
					sDescription: "Description"
				},
				function (enteredVal, bFound, key, desc) {
					that.getView().getModel("ChannelPartners").setProperty("/Country", key);
					that.getView().getModel("ChannelPartners").setProperty("/CountryName", desc);
					that.setstateModel();
				}
			);
			if (this.onChangeSTKF4_Exit) {
				this.onChangeSTKF4_Exit(oEvent);
			}
		},
		// setCountryDetails: function(tokens) {
		// 	var that = this;
		// 	this.getView().byId("fCountryEdit").setValueState(sap.ui.core.ValueState.None);
		// 	this.getView().byId("fCountryEdit").setValueStateText("");
		// 	oPPCCommon.removeMsgsInMsgMgrByMsgCode("fCountryEdit");
		// 	var countryID = tokens.ID;
		// 	var Desc = tokens.Description;
		// 	//this._oComponent.getModel("LocalViewSetting").setProperty("/Country", countryID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/Country", countryID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/CountryName", Desc);
		// 	that.setstateModel();
		// },

		setstateModel: function () {
			var that = this;

			var aCityFilterArray = new Array();
			var parentID = "000003" + oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit");
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "LoginID", "", [
				that.getCurrentUsers("ChannelPartners", "read")
			], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "ParentID", sap.ui
				.model.FilterOperator.EQ, [parentID], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "EntityType", sap.ui
				.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "PropName", sap.ui
				.model.FilterOperator.EQ, ["StateID"], false, false, false);

			var sPCGWModel = this._oComponent.getModel("PCGW");

			sPCGWModel.read("/ValueHelps", {
				filters: aCityFilterArray,
				urlParameters: {
					"$select": "ID,Description"
				},
				success: function (oData) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData(oData.results);
					that._oComponent.setModel(SONosModel, "StateModel");
					//that.getCustomerDetail();
				},
				error: function (error) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData([]);
					that._oComponent.setModel(SONosModel, "StateModel");
				}
			});
		},
		handleStateSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["ID", "Description"],
				sBinding: "suggestionItems"
			});
		},
		suggestionItemState: function (oEvent) {
			var that = this;
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "StateModel",
					sKey: "ID",
					sDescription: "Description"
				},
				function (key, desc, jdata) {

					that.getView().getModel("ChannelPartners").setProperty("/StateID", key);
					that.getView().getModel("ChannelPartners").setProperty("/StateDesc", desc);
					that.setDistrictModel();

				}
			);
			// this.getView().byId("inputMaterial").setValueState("None");
			// this.getView().byId("inputMaterial").setValueStateText("");
		},

		onChangeStateF4: function (oEvent) {
			if (oEvent.getSource().getValue() === "") {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}
			var that = this;
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "StateModel",
					sKey: "ID",
					sDescription: "Description"
				},
				function (enteredVal, bFound, key, desc) {
					if (enteredVal !== "") {
						if (!bFound) {
							var msg = oi18n.getText("common.message.pleaseEnterPositive", [gBasicDataBlock.byId("lStateIDEdit").getLabel()]);
							oPPCCommon.displayMsg_MsgBox(that.getView(), msg, "error");
						}
					}

					that.getView().getModel("ChannelPartners").setProperty("/StateID", key);
					that.getView().getModel("ChannelPartners").setProperty("/StateDesc", desc);
					that.setDistrictModel();
				}
			);
			if (this.onChangeSTKF4_Exit) {
				this.onChangeSTKF4_Exit(oEvent);
			}
		},
		tokenChangeStateF4: function () {
			gBasicDataBlock.byId("fStateIDEdit").removeAllTokens();
			gBasicDataBlock.byId("fDistrictIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idSubDistrict").removeAllTokens();
			gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idWard").removeAllTokens();
			gBasicDataBlock.byId("fCityIDEdit").removeAllTokens();
		},
		tokenNewCPChangeStateF4: function () {
			gNewPartenerCP.byId("fStateIDEdit").removeAllTokens();
			gNewPartenerCP.byId("fDistrictIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idSubDistrict").removeAllTokens();
			gNewPartenerCP.byId("fTownIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idWard").removeAllTokens();
			gNewPartenerCP.byId("fCityIDEdit").removeAllTokens();
		},
		setDistrictModel: function () {
			var that = this;
			var parentID = oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
				"fStateIDEdit");
			var aStateArray = new Array();
			aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "LoginID", "", [
				that.getCurrentUsers("ChannelPartners", "read")
			], false, false, false);
			aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "ParentID", sap.ui
				.model.FilterOperator.EQ, [parentID], false, false, false);
			aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "EntityType", sap.ui
				.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "PropName", sap.ui
				.model.FilterOperator.EQ, ["DistrictID"], false, false, false);

			var sPCGWModel = this._oComponent.getModel("PCGW");

			sPCGWModel.read("/ValueHelps", {
				filters: aStateArray,
				urlParameters: {
					"$select": "ID,Description"
				},
				success: function (oData) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData(oData.results);
					that._oComponent.setModel(SONosModel, "DistrictModel");
					//that.getCustomerDetail();
				},
				error: function (error) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData([]);
					that._oComponent.setModel(SONosModel, "DistrictModel");
				}
			});
		},
		handleDistrictSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["ID", "Description"],
				sBinding: "suggestionItems"
			});
		},
		suggestionItemDistrict: function (oEvent) {
			var that = this;
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "DistrictModel",
					//sKey: "ID",
					sKey: "ID",
					sDescription: "Description"
				},
				function (key, desc, jdata) {
					that.setDistrictDetails(jdata);
					oEvent.getSource().setValue("");

				}
			);
			// this.getView().byId("inputMaterial").setValueState("None");
			// this.getView().byId("inputMaterial").setValueStateText("");
		},
		onChangeDistrictF4: function (oEvent) {
			if (oEvent.getSource().getValue() === "") {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}
			var that = this;
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "DistrictModel",
					sKey: "ID",
					sDescription: "Description"
				},
				function (enteredVal, bFound, key, desc) {
					if (enteredVal !== "") {
						if (!bFound) {
							var msg = oi18n.getText("common.message.pleaseEnterPositive", [gBasicDataBlock.byId("lDistrictIDEdit").getLabel()]);
							oPPCCommon.displayMsg_MsgBox(that.getView(), msg, "error");
						}
					}
					that.getView().getModel("ChannelPartners").setProperty("/DistrictID", key);
					that.getView().getModel("ChannelPartners").setProperty("/DistrictDesc", desc);
					that.setCityModel();

				}
			);
			if (this.onChangeSTKF4_Exit) {
				this.onChangeSTKF4_Exit(oEvent);
			}
		},
		tokenChangeDistrictF4: function () {
			gBasicDataBlock.byId("fDistrictIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idSubDistrict").removeAllTokens();
			gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idWard").removeAllTokens();
			gBasicDataBlock.byId("fCityIDEdit").removeAllTokens();
		},
		tokenNewCPChangeDistrictF4: function () {
			gNewPartenerCP.byId("fDistrictIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idSubDistrict").removeAllTokens();
			gNewPartenerCP.byId("fTownIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idWard").removeAllTokens();
			gNewPartenerCP.byId("fCityIDEdit").removeAllTokens();
		},

		tokenChangeSubDistrictF4: function () {
			gBasicDataBlock.byId("idSubDistrict").removeAllTokens();
			gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idWard").removeAllTokens();
		},
		tokenNewCPChangeSubDistrictF4: function () {
			gNewPartenerCP.byId("idSubDistrict").removeAllTokens();
			gNewPartenerCP.byId("fTownIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idWard").removeAllTokens();
		},
		tokenChangeTownF4: function () {
			gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();
			gBasicDataBlock.byId("idWard").removeAllTokens();
		},
		tokenNewCPChangeTownF4: function () {
			gNewPartenerCP.byId("fTownIDEdit").removeAllTokens();
			gNewPartenerCP.byId("idWard").removeAllTokens();
		},
		setDistrictDetails: function (tokens) {
			var that = this;
			this.getView().byId("fDistrictIDEdit").setValueState(sap.ui.core.ValueState.None);
			this.getView().byId("fDistrictIDEdit").setValueStateText("");
			oPPCCommon.removeMsgsInMsgMgrByMsgCode("fDistrictIDEdit");
			var stateID = tokens.ID;
			var Desc = tokens.Description;
			//this._oComponent.getModel("LocalViewSetting").setProperty("/Country", countryID);
			this.getView().getModel("ChannelPartners").setProperty("/DistrictID", stateID);
			this.getView().getModel("ChannelPartners").setProperty("/DistrictDesc", Desc);
			that.setCityModel();
		},
		setCityModel: function () {
			var that = this;
			var parentID = oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
				"fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(), "fDistrictIDEdit");
			var aCityArray = new Array();
			aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "LoginID", "", [
				that.getCurrentUsers("ChannelPartners", "read")
			], false, false, false);
			aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "ParentID", sap.ui
				.model.FilterOperator.EQ, [parentID], false, false, false);
			aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "EntityType", sap.ui
				.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CityID"], false, false, false);

			var sPCGWModel = this._oComponent.getModel("PCGW");

			sPCGWModel.read("/ValueHelps", {
				filters: aCityArray,
				urlParameters: {
					"$select": "ID,Description"
				},
				success: function (oData) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData(oData.results);
					that._oComponent.setModel(SONosModel, "CityModel");
					//that.getCustomerDetail();
				},
				error: function (error) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData([]);
					that._oComponent.setModel(SONosModel, "CityModel");
				}
			});
		},
		handleCitySuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["ID", "Description"],
				sBinding: "suggestionItems"
			});
		},
		suggestionItemCity: function (oEvent) {
			var that = this;
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "CityModel",
					//sKey: "ID",
					sKey: "ID",
					sDescription: "Description"
				},
				function (key, desc, jdata) {
					that.setCityDetails(jdata);

					// that.getView().getModel("ChannelPartners").setProperty("/CityID", key);
					//that.getView().getModel("ChannelPartners").setProperty("/CityDesc", desc);
					oEvent.getSource().setValue("");
				}
			);
			// this.getView().byId("inputMaterial").setValueState("None");
			// this.getView().byId("inputMaterial").setValueStateText("");
		},
		onChangeCityF4: function (oEvent) {
			if (oEvent.getSource().getValue() === "") {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}
			var that = this;
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "CityModel",
					sKey: "ID",
					sDescription: "Description"
				},
				function (enteredVal, bFound, key, desc) {
					if (enteredVal !== "") {
						if (!bFound) {
							var msg = oi18n.getText("common.message.pleaseEnterPositive", [gBasicDataBlock.byId("lCityIDEdit").getLabel()]);
							oPPCCommon.displayMsg_MsgBox(that.getView(), msg, "error");
						}
					}
				}
			);
			if (this.onChangeSTKF4_Exit) {
				this.onChangeSTKF4_Exit(oEvent);
			}
		},
		// tokenChangeCityF4: function() {
		// // this.getView().byId("fCityIDEdit").removeAllTokens();
		// },
		setCityDetails: function (tokens) {
			var that = this;
			this.getView().byId("fCityIDEdit").setValueState(sap.ui.core.ValueState.None);
			this.getView().byId("fCityIDEdit").setValueStateText("");
			oPPCCommon.removeMsgsInMsgMgrByMsgCode("fCityIDEdit");
			var stateID = tokens.ID;
			var Desc = tokens.Description;
			//this._oComponent.getModel("LocalViewSetting").setProperty("/Country", countryID);
			this.getView().getModel("ChannelPartners").setProperty("/CityID", stateID);
			this.getView().getModel("ChannelPartners").setProperty("/CityDesc", Desc);
			that.setCityModel();
		},
		setBasicDataValueHelpProperty: function () {

			var that = this;

			this.CustomerTokenInput = this.getView().byId("inputCustomerF4");
			this.aCustomerKeys = ["CustomerNo", "Name"];
			this.countryTokenInput = this.getView().byId("fCountryEdit");
			this.aCountryKeys = ["ID", "Description"];
			var sCountryPreviourEnteredValue;
			// this.countryTokenInput.addValidator(function (args) {
			// 	if (sCountryPreviourEnteredValue !== args.text) {
			// 		oPPCCommon.removeAllMsgs();
			// 		sCountryPreviourEnteredValue = args.text;
			// 		var oDataModel = that._oComponent.getModel("PCGW");
			// 		args.text = args.text.toUpperCase();
			// 		var F4Filters = [];
			// 		var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
			// 		F4Filters.push(fVendorNo);
			// 		F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
			// 		F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
			// 		F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "Country"));
			// 		oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.countryTokenInput, "Country",
			// 			function (oToken, IsSuccess) {
			// 				if (IsSuccess) {
			// 					sCountryPreviourEnteredValue = "";
			// 				}
			// 			});
			// 	}
			// });

			this.stateTokenInput = this.getView().byId("fStateIDEdit");
			this.aStateKeys = ["ID", "Description"];
			var sStatePreviourEnteredValue;
			// this.stateTokenInput.addValidator(function(args) {
			// 	if (sStatePreviourEnteredValue !== args.text) {
			// 		oPPCCommon.removeAllMsgs();
			// 		if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {
			// 			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fCountryEdit", oi18n.getText(
			// 				"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
			// 			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
			// 				.getData()
			// 				.length);
			// 			oPPCCommon.showMessagePopover(that.ObjectPageLayout);
			// 		} else {
			// 			// sStatePreviourEnteredValue = args.text;
			// 			// var oDataModel = that._oComponent.getModel("PCGW");
			// 			// args.text = args.text.toUpperCase();
			// 			// var F4Filters = [];
			// 			// var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
			// 			// F4Filters.push(fVendorNo);
			// 			// F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
			// 			// F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
			// 			// F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "StateID"));
			// 			// F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, oPPCCommon.getKeysFromTokens(
			// 			// 	gBasicDataBlock, "fCountryEdit")));
			// 			// oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.stateTokenInput, "State",
			// 			// 	function(oToken, IsSuccess) {
			// 			// 		if (IsSuccess) {
			// 			// 			sStatePreviourEnteredValue = "";
			// 			// 		}
			// 			// 	});
			// 		}
			// 	}
			// });

			this.districtTokenInput = this.getView().byId("fDistrictIDEdit");
			this.aDistricteKeys = ["ID", "Description"];
			var sDistrictPreviourEnteredValue;
			this.districtTokenInput.addValidator(function (args) {
				if (sDistrictPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fCountryEdit",
							oi18n.getText("cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					}
					if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fStateIDEdit", oi18n.getText(
							"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {

						// sDistrictPreviourEnteredValue = args.text;
						// var oDataModel = that._oComponent.getModel("PCGW");
						// args.text = args.text.toUpperCase();
						// var F4Filters = [];
						// var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						// F4Filters.push(fVendorNo);
						// F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						// F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						// F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "DistrictID"));

						// var parentID = oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fCountryEdit") + "/" +
						// 	oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fStateIDEdit");
						// F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						// oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.districtTokenInput,
						// 	"District",
						// 	function(oToken, IsSuccess) {
						// 		if (IsSuccess) {
						// 			sDistrictPreviourEnteredValue = "";
						// 		}
						// 	});
					}
				}
			});

			this.cityTokenInput = this.getView().byId("fCityIDEdit");
			this.aCityKeys = ["ID", "Description"];
			var sCityPreviourEnteredValue;
			this.cityTokenInput.addValidator(function (args) {
				if (sCityPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					var errorCount = 0;
					if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fCountryEdit", oi18n
							.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fStateIDEdit", oi18n
							.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fDistrictIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fDistrictIDEdit",
							oi18n.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
						errorCount++;
					}
					if (errorCount !== 0) {
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {

						// sCityPreviourEnteredValue = args.text;
						// var oDataModel = that._oComponent.getModel("PCGW");
						// args.text = args.text.toUpperCase();
						// var F4Filters = [];
						// var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						// F4Filters.push(fVendorNo);
						// F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						// F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						// F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "CityID"));

						// var parentID = oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(
						// 	gBasicDataBlock,
						// 	"fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fDistrictIDEdit");
						// F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						// oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.cityTokenInput, "City",
						// 	function(oToken, IsSuccess) {
						// 		if (IsSuccess) {
						// 			sCityPreviourEnteredValue = "";
						// 		}
						// 	});
					}
				}
			});

			this.townTokenInput = this.getView().byId("fTownIDEdit");
			this.aTownKeys = ["ID", "Description"];
			var sTownPreviourEnteredValue;
			this.townTokenInput.addValidator(function (args) {
				if (sTownPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					var errorCount = 0;
					if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fCountryEdit", oi18n
							.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fStateIDEdit", oi18n
							.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fDistrictIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fDistrictIDEdit",
							oi18n.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fCityIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fCityIDEdit", oi18n.getText(
							"cpcreate.please.select", gBasicDataBlock.byId("lCityIDEdit").getText()));
						errorCount++;
					}
					if (errorCount !== 0) {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {

						// sTownPreviourEnteredValue = args.text;
						// var oDataModel = that._oComponent.getModel("PCGW");
						// args.text = args.text.toUpperCase();
						// var F4Filters = [];
						// var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						// F4Filters.push(fVendorNo);
						// F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						// F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						// F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "TownID"));
						// var parentID = oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fDistrictIDEdit");
						// F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						// oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.townTokenInput, "Town",
						// 	function(oToken, IsSuccess) {
						// 		if (IsSuccess) {
						// 			sTownPreviourEnteredValue = "";
						// 		}
						// 	});
					}
				}
			});

			if (this.setBasicDataValueHelpProperty_Exit) {
				this.setBasicDataValueHelpProperty_Exit();
			}

		},

		setNewCPDataValueHelpProperty: function () {

			var that = this;
			this.countryTokenInput = this.getView().byId("fCountryEdit");
			this.aCountryKeys = ["ID", "Description"];
			var sCountryPreviourEnteredValue;
			this.countryTokenInput.addValidator(function (args) {
				if (sCountryPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					sCountryPreviourEnteredValue = args.text;
					var oDataModel = that._oComponent.getModel("PCGW");
					args.text = args.text.toUpperCase();
					var F4Filters = [];
					var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
					F4Filters.push(fVendorNo);
					F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
					F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
					F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "Country"));
					oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.countryTokenInput, "Country",
						function (oToken, IsSuccess) {
							if (IsSuccess) {
								sCountryPreviourEnteredValue = "";
							}
						});
				}
			});

			this.stateTokenInput = this.getView().byId("fStateIDEdit");
			this.aStateKeys = ["ID", "Description"];
			var sStatePreviourEnteredValue;
			this.stateTokenInput.addValidator(function (args) {
				if (sStatePreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					if (gNewPartenerCP.byId("fCountryEdit").getTokens().length === 0) {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fCountryEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lCountryEdit").getText()));
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {
						sStatePreviourEnteredValue = args.text;
						var oDataModel = that._oComponent.getModel("PCGW");
						args.text = args.text.toUpperCase();
						var F4Filters = [];
						var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						F4Filters.push(fVendorNo);
						F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "StateID"));
						F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, oPPCCommon.getKeysFromTokens(
							gNewPartenerCP, "fCountryEdit")));
						oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.stateTokenInput, "State",
							function (oToken, IsSuccess) {
								if (IsSuccess) {
									sStatePreviourEnteredValue = "";
								}
							});
					}
				}
			});

			this.districtTokenInput = this.getView().byId("fDistrictIDEdit");
			this.aDistricteKeys = ["ID", "Description"];
			var sDistrictPreviourEnteredValue;
			this.districtTokenInput.addValidator(function (args) {
				if (sDistrictPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					if (gNewPartenerCP.byId("fCountryEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fCountryEdit",
							oi18n.getText("cpcreate.please.select", gNewPartenerCP.byId("lCountryEdit").getText()));
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					}
					if (gNewPartenerCP.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fStateIDEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lStateIDEdit").getText()));
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {

						sDistrictPreviourEnteredValue = args.text;
						var oDataModel = that._oComponent.getModel("PCGW");
						args.text = args.text.toUpperCase();
						var F4Filters = [];
						var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						F4Filters.push(fVendorNo);
						F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "DistrictID"));

						var parentID = oPPCCommon.getKeysFromTokens(gNewPartenerCP, "fCountryEdit") + "/" +
							oPPCCommon.getKeysFromTokens(gNewPartenerCP, "fStateIDEdit");
						F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.districtTokenInput,
							"District",
							function (oToken, IsSuccess) {
								if (IsSuccess) {
									sDistrictPreviourEnteredValue = "";
								}
							});
					}
				}
			});

			this.cityTokenInput = this.getView().byId("fCityIDEdit");
			this.aCityKeys = ["ID", "Description"];
			var sCityPreviourEnteredValue;
			this.cityTokenInput.addValidator(function (args) {
				if (sCityPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					var errorCount = 0;
					if (gNewPartenerCP.byId("fCountryEdit").getTokens().length === 0) {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fCountryEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lCountryEdit").getText()));
						errorCount++;
					}
					if (gNewPartenerCP.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fStateIDEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lStateIDEdit").getText()));
						errorCount++;
					}
					if (gNewPartenerCP.byId("fDistrictIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fDistrictIDEdit",
							oi18n.getText(
								"cpcreate.please.select", gNewPartenerCP.byId("lDistrictIDEdit").getText()));
						errorCount++;
					}
					if (errorCount !== 0) {
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {

						sCityPreviourEnteredValue = args.text;
						var oDataModel = that._oComponent.getModel("PCGW");
						args.text = args.text.toUpperCase();
						var F4Filters = [];
						var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						F4Filters.push(fVendorNo);
						F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "CityID"));

						var parentID = oPPCCommon.getKeysFromTokens(gNewPartenerCP, "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(
							gNewPartenerCP,
							"fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gNewPartenerCP, "fDistrictIDEdit");
						F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.cityTokenInput, "City",
							function (oToken, IsSuccess) {
								if (IsSuccess) {
									sCityPreviourEnteredValue = "";
								}
							});
					}
				}
			});

			this.townTokenInput = this.getView().byId("fTownIDEdit");
			this.aTownKeys = ["ID", "Description"];
			var sTownPreviourEnteredValue;
			this.townTokenInput.addValidator(function (args) {
				if (sTownPreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					var errorCount = 0;
					if (gNewPartenerCP.byId("fCountryEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fCountryEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lCountryEdit").getText()));
						errorCount++;
					}
					if (gNewPartenerCP.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fStateIDEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lStateIDEdit").getText()));
						errorCount++;
					}
					if (gNewPartenerCP.byId("fDistrictIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fDistrictIDEdit",
							oi18n.getText(
								"cpcreate.please.select", gNewPartenerCP.byId("lDistrictIDEdit").getText()));
						errorCount++;
					}
					if (gNewPartenerCP.byId("fCityIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gNewPartenerCP, "fCityIDEdit", oi18n.getText(
							"cpcreate.please.select", gNewPartenerCP.byId("lCityIDEdit").getText()));
						errorCount++;
					}
					if (errorCount !== 0) {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {

						sTownPreviourEnteredValue = args.text;
						var oDataModel = that._oComponent.getModel("PCGW");
						args.text = args.text.toUpperCase();
						var F4Filters = [];
						var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						F4Filters.push(fVendorNo);
						F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "TownID"));
						var parentID = oPPCCommon.getKeysFromTokens(gNewPartenerCP, "fDistrictIDEdit");
						F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.townTokenInput, "Town",
							function (oToken, IsSuccess) {
								if (IsSuccess) {
									sTownPreviourEnteredValue = "";
								}
							});
					}
				}
			});

			this.subDisTokenInput = this.getView().byId("idSubDistrict");
			this.aSubDiscKeys = ["SubDistrictID", "SubDistrictDesc"];

			this.wardTokenInput = this.getView().byId("idWard");
			this.aWardKeys = ["CNSWardID", "CNSWardName"];

			if (this.setNewCPDataValueHelpProperty_Exit) {
				this.setNewCPDataValueHelpProperty_Exit();
			}

		},

		setSalesDataValueHelpProperty: function () {

			var that = this;
			this.zoneTokenInput = this.getView().byId("fZoneIDEdit");
			this.aZoneKeys = ["ID", "Description"];
			var sZonePreviourEnteredValue;
			this.zoneTokenInput.addValidator(function (args) {
				if (sZonePreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(that.getView(), "fCountryEdit", oi18n.getText(
							"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.ObjectPageLayout);
					} else {
						sZonePreviourEnteredValue = args.text;
						var oDataModel = that._oComponent.getModel("PCGW");
						args.text = args.text.toUpperCase();
						var F4Filters = [];
						var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						F4Filters.push(fVendorNo);
						F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "ZoneID"));
						F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, oPPCCommon.getKeysFromTokens(
							gBasicDataBlock, "fCountryEdit")));
						oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.zoneTokenInput, "Zone",
							function (oToken, IsSuccess) {
								if (IsSuccess) {
									sZonePreviourEnteredValue = "";
								}
							});
					}
				}
			});

			/*this.routeTokenInput = this.getView().byId("fRouteIDEdit");
			this.aRouteKeys = ["ID", "Description"];
			var sRoutePreviourEnteredValue;
			this.routeTokenInput.addValidator(function(args) {
				if (sRoutePreviourEnteredValue !== args.text) {
					oPPCCommon.removeAllMsgs();
					var errorCount = 0;
					if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fStateIDEdit", oi18n
							.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fDistrictIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fDistrictIDEdit",
							oi18n.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
						errorCount++;
					}
					if (gBasicDataBlock.byId("fTownIDEdit").getTokens().length === 0) {

						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(gBasicDataBlock, "fTownIDEdit", oi18n.getText(
							"cpcreate.please.select", gBasicDataBlock.byId("lTownIDEdit").getText()));
						errorCount++;
					}
					if (errorCount !== 0) {
						gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(this.ObjectPageLayout);
					} else {
						sRoutePreviourEnteredValue = args.text;
						var oDataModel = that._oComponent.getModel("PCGW");
						args.text = args.text.toUpperCase();
						var F4Filters = [];
						var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
						F4Filters.push(fVendorNo);
						F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
						F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
						F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "RouteID"));

						var parentID = oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(
							gBasicDataBlock,
							"fDistrictIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fTownIDEdit");
						F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

						oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.routeTokenInput, "Route",
							function(oToken, IsSuccess) {
								if (IsSuccess) {
									sRoutePreviourEnteredValue = "";
								}
							});
					}
				}
			});*/

			/*this.SPTokenInput = this.getView().byId("fPartnerMgrNoEdit");
			this.aSPKeys = ["SPNo", "FirstName"];
			var sSPPreviourEnteredValue;
			this.SPTokenInput.addValidator(function(args) {
				if (sSPPreviourEnteredValue !== args.text) {
					sSPPreviourEnteredValue = args.text;
					var oDataModel = that._oComponent.getModel("SSGW_MST");
					args.text = args.text.toUpperCase();
					var F4Filters = [];
					var fVendorNo = new sap.ui.model.Filter("SPNo", sap.ui.model.FilterOperator.EQ, args.text);
					F4Filters.push(fVendorNo);
					F4Filters.push(new sap.ui.model.Filter("CPGUID", sap.ui.model.FilterOperator.EQ, that.getView().getModel("ChannelPartners").getProperty(
						"/ParentID")));
					oSSCommon.getTokenForInput(args, oDataModel, "SalesPersons", F4Filters, "SPNo", "FirstName", that.SPTokenInput,
						"Partnr Mgr No",
						function(oToken, IsSuccess) {
							if (IsSuccess) {
								sSPPreviourEnteredValue = "";
							}
						});
				}
			});*/

			/*this.weeklyOffTokenInput = this.getView().byId("fWeeklyOffEdit");
			this.aWeeklyOffKeys = ["ID", "Description"];
			var sWeeklyOffPreviourEnteredValue;
			this.weeklyOffTokenInput.addValidator(function(args) {
				if (sWeeklyOffPreviourEnteredValue !== args.text) {
					sWeeklyOffPreviourEnteredValue = args.text;
					var oDataModel = that._oComponent.getModel("PCGW");
					args.text = args.text.toUpperCase();
					var F4Filters = [];
					var fVendorNo = new sap.ui.model.Filter("ID", sap.ui.model.FilterOperator.EQ, args.text);
					F4Filters.push(fVendorNo);
					F4Filters.push(new sap.ui.model.Filter("ModelID", sap.ui.model.FilterOperator.EQ, "SSGW_MST"));
					F4Filters.push(new sap.ui.model.Filter("EntityType", sap.ui.model.FilterOperator.EQ, "ChannelPartner"));
					F4Filters.push(new sap.ui.model.Filter("PropName", sap.ui.model.FilterOperator.EQ, "WeeklyOff"));

					var parentID = "";
					F4Filters.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentID));

					oSSCommon.getTokenForInput(args, oDataModel, "ValueHelps", F4Filters, "ID", "Description", that.aWeeklyOffKeys, "Weekly Off",
						function(oToken, IsSuccess) {
							if (IsSuccess) {
								sWeeklyOffPreviourEnteredValue = "";
							}
						});
				}
			});*/

			if (this.setSalesDataValueHelpProperty_Exit) {
				this.setSalesDataValueHelpProperty_Exit();
			}

		},

		CountryF4: function () {
			var view = this.getView();
			oSSCommonValueHelp.setValueHelp({
				title: "Country",
				oController: this,
				controlID: "fCountryEdit",
				idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.country"),
				descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.countryName"),
				oUtilsI18n: oUtilsI18n,
				modelID: "SSGW_MST",
				entityType: "ChannelPartner",
				partnerNo: view.getModel("ChannelPartners").getProperty("/ParentID"),
				propName: "Country",
				tokenInput: this.countryTokenInput,
				aKeys: this.aCountryKeys,
				defaultVisible: false
			}, function (oControlEvent) {
				var currency = oControlEvent.getParameter("tokens")[0].getCustomData()[0].getValue().DepPropDefID;
				view.getModel("ChannelPartners").setProperty("/Currency", currency);
			});

			if (this.CountryF4_Exit) {
				this.CountryF4_Exit();
			}
		},

		StateF4: function () {
			var view = this.getView();
			oPPCCommon.removeAllMsgs();
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
			if (view.byId("fCountryEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCountryEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			} else {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oSSCommonValueHelp.setValueHelp({
					title: "State",
					parentID: "000003" + oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit"),
					oController: this,
					controlID: "fStateIDEdit",
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.stateID"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.stateDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "ChannelPartner",
					propName: "StateID",
					tokenInput: this.stateTokenInput,
					aKeys: this.aStateKeys,
					defaultVisible: true,
					defaultLabel: "Country",
					defaultText: oPPCCommon.getTextFromTokens(this.getView(), "fCountryEdit"),
					idVisible: false,
					groupTitle: "State"

				});

			}

			if (this.StateF4_Exit) {
				this.StateF4_Exit();
			}

		},
		DitrictF4: function () {
			var view = this.getView();
			oPPCCommon.removeAllMsgs();
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
			if (view.byId("fCountryEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCountryEdit",
					oi18n.getText("cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			}
			if (view.byId("fStateIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fStateIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			} else {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oSSCommonValueHelp.setValueHelp({
					title: "District",
					parentID: oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
						"fStateIDEdit"),
					oController: this,
					controlID: "fDistrictIDEdit",
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.districtID"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.districtDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "ChannelPartner",
					propName: "DistrictID",
					tokenInput: this.districtTokenInput,
					aKeys: this.aDistricteKeys,
					defaultVisible: true,
					defaultLabel: "State",
					defaultText: oPPCCommon.getTextFromTokens(this.getView(), "fStateIDEdit"),
					idVisible: false,
					groupTitle: "District"

				});
			}

			if (this.DitrictF4_Exit) {
				this.DitrictF4_Exit();
			}

		},
		TownF4: function () {

			var view = this.getView();
			oPPCCommon.removeAllMsgs();
			var errorCount = 0;
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
			if (view.byId("fCountryEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCountryEdit", oi18n.getText(
					"List.Filterbar.MultiInput.CpNoError", gBasicDataBlock.byId("lCountryEdit").getText()));
				errorCount++;
			}
			if (view.byId("fStateIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fStateIDEdit", oi18n.getText(
					"List.Filterbar.MultiInput.CpNoError", gBasicDataBlock.byId("lStateIDEdit").getText()));
				errorCount++;
			}
			if (view.byId("fDistrictIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fDistrictIDEdit", oi18n.getText(
					"List.Filterbar.MultiInput.CpNoError", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
				errorCount++;
			}
			// if (view.byId("fCityIDEdit").getTokens().length === 0) {

			// 	sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCityIDEdit", oi18n.getText(
			// 		"cpcreate.please.select", gBasicDataBlock.byId("lCityIDEdit").getText()));
			// 	errorCount++;
			// }
			if (errorCount !== 0) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			} else {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oSSCommonValueHelp.setValueHelp({
					title: "Town",
					oController: this,
					controlID: "fTownIDEdit",
					parentID: oPPCCommon.getKeysFromTokens(this.getView(), "fDistrictIDEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
						"idSubDistrict"),
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.townID"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.townDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "ChannelPartner",
					propName: "TownID",
					tokenInput: this.townTokenInput,
					aKeys: this.aTownKeys,
					defaultVisible: true,
					defaultLabel: "Sub District",
					defaultText: oPPCCommon.getTextFromTokens(this.getView(), "idSubDistrict"),
					idVisible: false,
					groupTitle: "Town"

				});
			}

			if (this.TownF4_Exit) {
				this.TownF4_Exit();
			}
		},

		CityF4: function () {
			var view = this.getView();
			oPPCCommon.removeAllMsgs();
			var errorCount = 0;
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
			if (view.byId("fCountryEdit").getTokens().length === 0) {
				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCountryEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
				errorCount++;
			}
			if (view.byId("fStateIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fStateIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
				errorCount++;
			}
			if (view.byId("fDistrictIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fDistrictIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
				errorCount++;
			}
			if (errorCount !== 0) {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			} else {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oSSCommonValueHelp.setValueHelp({
					title: "City",
					oController: this,
					controlID: "fCityIDEdit",
					parentID: oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
						"fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(), "fDistrictIDEdit"),
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.cityID"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.cityDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "ChannelPartner",
					propName: "CityID",
					tokenInput: this.cityTokenInput,
					aKeys: this.aCityKeys,
					defaultVisible: true,
					defaultLabel: "District",
					defaultText: oPPCCommon.getTextFromTokens(this.getView(), "fDistrictIDEdit"),
					idVisible: false,
					groupTitle: "City"

				});
			}

			if (this.CityF4_Exit) {
				this.CityF4_Exit();
			}
		},

		SalesPersonF4: function (mParameters, requestCompleted) {
			var that = this;
			if (mParameters.controlID === undefined || mParameters.controlID === null) {
				mParameters.controlID = "fSalesPersonIDEdit";
			}
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.oi18n.getText("List.ValueHelp.SalesPerson.Header"),
				supportMultiselect: false,
				supportRanges: false,

				supportRangesOnly: false,
				key: mParameters.oController.aSPKeys[0],
				descriptionKey: mParameters.oController.aSPKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					mParameters.tokenInput.setTokens(oControlEvent.getParameter("tokens"));
					gPartnerMgrGUID = oControlEvent.getParameter("tokens")[0].getCustomData()[0].getValue().SPGUID;
					//	gCPDetailView.getModel("ChannelPartners").setProperty("/PartnerMgrGUID",spguid);
					mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
					mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
					if (requestCompleted) {
						requestCompleted(mParameters.tokenInput.getTokens());
					}

					oValueHelpDialog.close();
				},
				cancel: function (oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			this.SalesPersonF4Columns(oValueHelpDialog, mParameters);
			this.SalesPersonF4FilterBar(oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
		},
		/*Sales Person F4 Column*/
		SalesPersonF4Columns: function (oValueHelpDialog, mParameters) {

			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: mParameters.oi18n.getText("List.ValueHelp.SalesPerson.SPNo"),
				template: new sap.m.Text({
					text: "{SPNo}"
				}),
				sortProperty: "SPNo",
				filterProperty: "SPNo"
			}));
			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: mParameters.firstNameLabel,
				template: new sap.m.Text({
					text: "{FirstName}"
				}),
				sortProperty: "FirstName",
				filterProperty: "FirstName"
			}));
			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: mParameters.lastNameLabel,
				template: new sap.m.Text({
					text: "{LastName}"
				}),
				sortProperty: "LastName",
				filterProperty: "LastName"
			}));
			/*	oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: mParameters.oi18n.getText("List.ValueHelp.SalesPerson.SPGUID"),
					
					template: new sap.m.Text({
						text: "{SPGUID}"
					}),
					sortProperty: "SPGUID",
					filterProperty: "SPGUID"
				}));*/

			oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoItemSelected"));
		},
		/*Sales Person Filter Column*/
		SalesPersonF4FilterBar: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var firstName = new sap.m.Input({
				value: mParameters.oController.SPTokenInput.getValue(),
				change: function () {
					oValueHelpDialog.getFilterBar().search();
				}
			});
			var lastName = new sap.m.Input({
				value: mParameters.oController.SPTokenInput.getValue(),
				change: function () {
					oValueHelpDialog.getFilterBar().search();
				}
			});

			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "SP",
						groupName: "gn1",
						name: "n1",
						label: mParameters.firstNameLabel,
						control: firstName
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "SP",
						groupName: "gn1",
						name: "n2",
						label: mParameters.lastNameLabel,
						control: lastName
					})

				],
				search: function (oEvent) {

					var salesPersonFilterArray = new Array();
					salesPersonFilterArray = oPPCCommon.setODataModelReadFilter("", "", salesPersonFilterArray, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
						sServiceName: "SalesPersons",
						sRequestType: "read"
					})], false, false, false);

					salesPersonFilterArray = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(),
						"", salesPersonFilterArray, "FirstName", "", [firstName.getValue()], false, false, false);
					salesPersonFilterArray = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(),
						"", salesPersonFilterArray, "LastName", "", [lastName.getValue()], false, false, false);

					var SSGW_MSTModel = mParameters.oController._oComponent.getModel("SSGW_MST");
					SSGW_MSTModel.attachRequestSent(function () {
						busyDialog.open();
					});
					SSGW_MSTModel.attachRequestCompleted(function () {
						busyDialog.close();
					});
					SSGW_MSTModel.read("/SalesPersons", {
						filters: salesPersonFilterArray,
						urlParameters: {
							"$select": "SPNo,FirstName,LastName,SPGUID"
						},
						success: function (oData) {

							/*for(var i=0;i<oData.results.length;i++)
							{
								oData.results[i].Text=oData.results[i].FirstName+"("+oData.results[i].SPGUID+")";
							}*/
							var VInvModel = new sap.ui.model.json.JSONModel();
							VInvModel.setData(oData.results);
							oValueHelpDialog.getTable().setModel(VInvModel);
							oValueHelpDialog.getTable().bindRows("/");
							if (oData.results.length == 0) {
								oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
								oPPCCommon.dialogErrorMessage("No Data", "No Records Found");
							}
						},
						error: function (error) {
							if (oValueHelpDialog.getTable().getModel() !== undefined) {
								oValueHelpDialog.getTable().getModel().setProperty("/", {});
							}

							oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
							oPPCCommon.dialogErrorMessage(error, "No Records Found");
						}
					});
				},
				reset: function () {

				}
			}));
		},
		SPF4: function () {
			/*
						var that = this;
						oSSCommonValueHelp.SalesPersonF4({
							oController: that,
							oi18n: oi18n,
							oUtilsI18n: oUtilsI18n,
							controlID: "fPartnerMgrNoEdit",
							tokenInput: this.SPTokenInput,
							SPNoLabel: oi18n.getText("List.ValueHelp.SalesPerson.SPNo"),
							firstNameLabel: oi18n.getText("List.ValueHelp.SalesPerson.firstName"),
							lastNameLabel: oi18n.getText("List.ValueHelp.SalesPerson.lastName"),
							title: oi18n.getText("List.ValueHelp.SalesPerson.Header"),
							bMultiSelect: false,
							sCustomerCode: that.getView().getModel("ChannelPartners").getProperty("/ParentID"),
							sCustomerName: that.getView().getModel("ChannelPartners").getProperty("/ParentName")
						}, function(oToken) {

						});
						
						if (this.SPF4_Exit) {
							this.SPF4_Exit();
						}
					*/
		},
		setSalesPersonModel: function () {
			/*
						var that = this;
						var SSGW_MST_MSTModel = this._oComponent.getModel("SSGW_MST");
						SSGW_MST_MSTModel.attachRequestSent(function() {});
						SSGW_MST_MSTModel.attachRequestCompleted(function() {});
						var aSPF4Filter = new Array();
						aSPF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSPF4Filter, "LoginID", "", [
							that.getCurrentUsers("SalesPersons", "read")
						], false, false, false);
						SSGW_MST_MSTModel.read("/SalesPersons", {
							filters: aSPF4Filter,
							urlParameters: {
								"$select": "SPNo,FirstName,SPGUID"
							},
							success: function(oData) {
								var SalesPersonModel = new sap.ui.model.json.JSONModel();
								SalesPersonModel.setData(oData.results);
								that._oComponent.setModel(SalesPersonModel, "SalesPersonSuggestorModel");
							},
							error: function(error) {
								//alert(error);
							}
						});
					*/
		},
		onChangeSPF4: function (oEvent) {
			var that = this;
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "SalesPersonSuggestorModel",
					// sKey: "SPGUID",
					// sDescription: "Name"
					sKey: "SPNo",
					sDescription: "FirstName",
					sGUID: "SPGUID"
				},
				function (enteredVal, bFound, key, desc) {
					if (enteredVal !== "") {
						if (!bFound) {
							var msg = oi18n.getText("List.Filterbar.MultiInput.SpNoError", [that.getView().byId("LSPNo").getLabel()]);
							oPPCCommon.displayMsg_MsgBox(that.getView(), msg, "error");
						}
					}
				}
			);

			if (this.onChangeSPF4_Exit) {
				this.onChangeSPF4_Exit();
			}
		},
		handleSalesPersonSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["SPNo", "FirstName"],
				sBinding: "suggestionItems"
			});

			if (this.handleSalesPersonSuggest_Exit) {
				this.handleSalesPersonSuggest_Exit();
			}
		},
		suggestionItemSelected: function (oEvent) {
			/*
						var that = this;
						oPPCCommon.suggestionItemSelected({
								oEvent: oEvent,
								thisController: this,
								sModelName: "SalesPersonSuggestorModel",
								sKey: "SPNo",
								sDescription: "FirstName",
								sGUID: that.getView().getModel("ChannelPartners").getProperty("/ParentID")
							},
							function(key, desc) {

							}
						);
						this.getView().byId("fPartnerMgrNoEdit").setValueState("None");
						this.getView().byId("fPartnerMgrNoEdit").setValueStateText("");
						
						if (this.suggestionItemSelected_Exit) {
							this.suggestionItemSelected_Exit();
						}
					*/
		},

		//Route
		RouteF4: function () {
			/*
						var view = this.getView();
						oPPCCommon.removeAllMsgs();
						var errorCount = 0;
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();

						if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

							sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(view, "fStateIDEdit", oi18n.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
							errorCount++;
						}
						if (gBasicDataBlock.byId("fDistrictIDEdit").getTokens().length === 0) {

							sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(view, "fDistrictIDEdit", oi18n.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
							errorCount++;
						}
						if (gBasicDataBlock.byId("fTownIDEdit").getTokens().length === 0) {

							sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(view, "fTownIDEdit", oi18n.getText(
								"cpcreate.please.select", gBasicDataBlock.byId("lTownIDEdit").getText()));
							errorCount++;
						}
						if (errorCount !== 0) {
							gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
								.getData()
								.length);
							oPPCCommon.showMessagePopover(this.ObjectPageLayout);
						} else {
							oSSCommonValueHelp.setValueHelp({
								title: "Route",
								oController: this,
								controlID: "fRouteIDEdit",
								parentID: oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock,
									"fDistrictIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fTownIDEdit"),
								idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.routeID"),
								descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.routeDesc"),
								oUtilsI18n: oUtilsI18n,
								modelID: "SSGW_MST",
								entityType: "ChannelPartner",
								propName: "RouteID",
								tokenInput: this.routeTokenInput,
								aKeys: this.aRouteKeys,
								defaultVisible: true,
								defaultLabel: "Town",
								defaultText: oPPCCommon.getTextFromTokens(gBasicDataBlock, "fTownIDEdit"),
								idVisible: false,
								groupTitle: "Town",
								fireOnLoad: true
							});
						}
						if (this.RouteF4_Exit) {
							this.RouteF4_Exit();
						}
					*/
		},

		WeeklyOffF4: function () {
			/*
						oPPCCommon.removeAllMsgs();
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
						oSSCommonValueHelp.setValueHelp({
							title: "Weekly Off",
							oController: this,
							controlID: "fWeeklyOffEdit",
							parentID: "",
							idLabel: "Weekly Off",
							descriptionLabel: "Weekly Off",
							oUtilsI18n: oUtilsI18n,
							modelID: "SSGW_MST",
							entityType: "ChannelPartner",
							propName: "WeeklyOff",
							tokenInput: this.weeklyOffTokenInput,
							aKeys: this.aWeeklyOffKeys,
							defaultVisible: false,
							defaultLabel: "",
							defaultText: "",
							idVisible: false,
							groupTitle: "Weekly Off",
							fireOnLoad: true
						});
						if (this.WeeklyOffF4_Exit) {
							this.WeeklyOffF4_Exit();
						}
					*/
		},

		//Zone
		ZoneF4: function () {
			oPPCCommon.removeAllMsgs();
			if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCountryEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			} else {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oSSCommonValueHelp.setValueHelp({
					title: "Zone",
					oController: this,
					controlID: "fZoneIDEdit",
					parentID: oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fCountryEdit"),
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.zoneID"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.zoneDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "ChannelPartner",
					propName: "ZoneID",
					tokenInput: this.zoneTokenInput,
					aKeys: this.aZoneKeys,
					defaultVisible: true,
					defaultLabel: "Country",
					defaultText: oPPCCommon.getTextFromTokens(gBasicDataBlock, "fCountryEdit"),
					idVisible: false,
					groupTitle: "Zone",
					fireOnLoad: true
				});
			}

			if (this.ZoneF4_Exit) {
				this.ZoneF4_Exit();
			}
		},

		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},

		getCPTypeDescription: function (oEvent) {
			/*var desc = sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").getDDDescrption(
				"fCPTypeEdit", this.getView());*/
			var that = this;
			oEvent.getSource().setValueState(null);
			oEvent.getSource().setValueStateText("");
			var desc = "";
			var key = oEvent.getSource().getSelectedKey();
			if (oEvent.getSource().getSelectedKey() !== "") {
				if (oEvent.getSource().getSelectedItem().getText().split("-").length > 1) {
					desc = oEvent.getSource().getSelectedItem().getText().split("-")[1].trim();
				} else {
					desc = oEvent.getSource().getSelectedItem().getText().split("-")[0].trim();
				}
			}

			that.getView().getModel("LocalViewSettingDtl").setProperty("/cptype", key);

			this.DMSDivisionDD();
			/*if(gCPDetailView.byId("ObjectPageHeader")) {
				gCPDetailView.byId("ObjectPageHeader").setObjectTitle("New " + desc);
			}*/
			// gCPDetailView.byId("ObjectPageHeader").mProperties.objectTitle = "New "+desc;
			if (gCPDetailView.getModel("ChannelPartners")) {
				gCPDetailView.getModel("ChannelPartners").setProperty("/CPTypeDesc", desc);
			}
			/*if(ChannelPartnersModel.setProperty("/CPTypeID") === "10" || ChannelPartnersModel.setProperty("/CPTypeID") === "20") {
				gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/")
			}else {
				
			}*/
			//call a typeset to make icon tab bar visibility
			if (oEvent.getSource().getSelectedKey()) {

				this.setIconTabBarVisibility(oEvent.getSource().getSelectedKey());
				this.getCPTypeEnable(oEvent.getSource().getSelectedKey());

			}

			var ChannelPartnersModel = this.getView().getModel("ChannelPartners");
			if (ChannelPartnersModel.getProperty("/CPTypeID") !== "10" &&
				ChannelPartnersModel.getProperty("/CPTypeID") !== "20") {

				var oTable = gDMSDivisions.byId("CLASSIFICATIONCHANNELSTABLEEdit")
				if (oTable) {
					var aRows = oTable.getRows();
					for (var row = 0; row < aRows.length; row++) {
						var aCells = aRows[row].getCells();
						for (var cell = 0; cell < aCells.length; cell++) {
							var cellId = aCells[cell].getId();
							if (cellId.indexOf("fGroup3Edit") > -1) {
								if (gDMSDivisions.byId(cellId).getModel("Group3DD")) {
									gDMSDivisions.byId(cellId).getModel("Group3DD").setData([]);
								}
							}
						}
					}
				}

				if (this.getView().getModel("CPAlternateBillings")) {
					this.getView().getModel("CPAlternateBillings").setProperty("/", []);
				}
				if (this.getView().getModel("LocalViewSettingDtl")) {
					this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCountClassification", 0);
				}
				if (this.getView().getModel("CPDMSDivisions")) {
					this.getView().getModel("CPDMSDivisions").setProperty("/", []);
				}
				if (this.getView().getModel("LocalViewSettingDtl")) {
					this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", 0);
				}
			}

			if (this.getCPTypeDescription_Exit) {
				this.getCPTypeDescription_Exit();
			}
		},
		setAllTabsVisible: function (visibility) {
			this.getView().getModel("LocalViewSettingDtl").setProperty("/BasciDataTabVisible", visibility);
			this.getView().getModel("LocalViewSettingDtl").setProperty("/SalesDataVisible", visibility);
			this.getView().getModel("LocalViewSettingDtl").setProperty("/ChannelClassVisible", visibility);
			this.getView().getModel("LocalViewSettingDtl").setProperty("/InfraVisible", visibility);
			this.getView().getModel("LocalViewSettingDtl").setProperty("/AlternateBillVisible", visibility);
			this.getView().getModel("LocalViewSettingDtl").setProperty("/AdditionalDetailVisible", visibility);
			this.getView().getModel("LocalViewSettingDtl").setProperty("/GroupTabVisible", visibility);
		},
		setIconTabBarVisibility: function (CPType) {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPCDSP"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginId", "", [this.getCurrentUsers(
				"ConfigTypsetTypeValues", "read")], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Types", "", [CPType], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypsetTypeValues", oStatusFilter, "Types", "TypeValue", busyDialog, this.getView(),
				"TabBarModel", "",
				function (aDDValue) {
					that.setAllTabsVisible(false);
					var VisibleCodes = aDDValue[0].Text.split(",");
					VisibleCodes.forEach(function (eachElement) {
						if (eachElement === "01") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/BasciDataTabVisible", true);
						}
						if (eachElement === "02") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/SalesDataVisible", true);
						}
						if (eachElement === "03") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/ChannelClassVisible", true);
						}
						if (eachElement === "04") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/InfraVisible", true);
						}
						if (eachElement === "05") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/AlternateBillVisible", true);
						}
						if (eachElement === "06") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/AdditionalDetailVisible", true);
						}
						if (eachElement === "07") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/GroupTabVisible", true);
						}

					});
					if (VisibleCodes.length === 0) {
						that.setAllTabsVisible(true);
					}

					// busyDialog.close();
				}, true, "PD", true);

		},
		getCPTypeEnable: function (CPType) {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPUID"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginId", "", [this.getCurrentUsers(
				"ConfigTypsetTypeValues", "read")], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Types", "", [CPType], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypsetTypeValues", oStatusFilter, "Types", "TypeValue", busyDialog, this.getView(),
				"CPUIDMODEL", "",
				function (aDDValue) {

				}, true, "PD", true);

		},

		DMSDivisionDD: function (oEvent) {
			var view = gDMSDivisions;
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
				"SSGW_MST"
			], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
				"ChannelPartner"
			], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
				"DMSDiv"
			], false, false, false);
			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", oDialog, view, "DMSDivisionDD",
				"Select",
				function () {
					// that.busyCount();
				}, false, "PD", true);
			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}
		},
		validateNumeric: function (oEvent) {
			var value = oEvent.getSource().getValue();
			var currentValueEntered = value.substring(value.length - 1);
			var lastValueEnterd = value.substring(0, value.length - 1);
			var reg = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/a-z A-Z?]/;
			if (reg.test(currentValueEntered)) {
				oEvent.getSource().setValue(lastValueEnterd);
			}
		},
		validateDistrict: function () {
			var view = this.getView();
			var valid = true;
			if (view.byId("fDistrictIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fDistrictIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
				valid = false;
			}
			return valid;
		},

		validateward: function () {
			var errorCount = 0;
			var view = this.getView();
			var valid = true;
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
			if (view.byId("fCountryEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fCountryEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lCountryEdit").getText()));
				errorCount++;
			}
			if (view.byId("fStateIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fStateIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lStateIDEdit").getText()));
				errorCount++;
			}
			if (view.byId("fDistrictIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fDistrictIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
				errorCount++;
			}
			if (view.byId("idSubDistrict").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "idSubDistrict", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lSubDistrictIDEdit").getText()));
				errorCount++;
			}
			if (view.byId("fTownIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(this.getView(), "fTownIDEdit", oi18n.getText(
					"cpcreate.please.select", gBasicDataBlock.byId("lTownIDEdit").getText()));
				errorCount++;
			}
			if (errorCount !== 0) {
				valid = false;
			}
			return valid;
		},
		subDistrictF4: function () {
			var that = this;
			var view = this.getView();
			var validate = this.validateDistrict();
			if (validate) {
				this.setValueHelpForSubDt({
					title: "Sub District",
					oController: this,
					controlID: "idSubDistrict",
					DistrctID: this.getView().byId("fDistrictIDEdit").getTokens()[0].getKey(),
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.Subdistrict"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.SubdistrictDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "SubDistrict",
					// propName: "Country",
					tokenInput: this.subDisTokenInput,
					aKeys: this.aSubDiscKeys,
					defaultVisible: false
				}, function (oControlEvent) {
					that._oComponent.getModel("ChannelPartners").setProperty("/SubDistrictGUID", oControlEvent.getParameter("tokens")[0].getCustomData()[
						0].getValue().SubDistGUID);
					that._oComponent.getModel("ChannelPartners").setProperty("/SubDistrictDesc", oControlEvent.getParameter("tokens")[0].getCustomData()[
						0].getValue().SubDistrictDesc);
					// this.getView().byId("fDistrictIDEdit").setValueState(null);
					// this.getView().byId("fDistrictIDEdit").setValueStateText("");
					// var currency = oControlEvent.getParameter("tokens")[0].getCustomData()[0].getValue().DepPropDefID;
					// view.getModel("ChannelPartners").setProperty("/Currency", currency);
				});
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			}

			if (this.CountryF4_Exit) {
				this.CountryF4_Exit();
			}
		},
		setValueHelpForSubDt: function (mParameters, requestCompleted) {

			if (mParameters.bMultiSelect === undefined ||
				mParameters.bMultiSelect === null) {
				mParameters.bMultiSelect = false;
			}
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.title,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.aKeys[0],
				descriptionKey: mParameters.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					mParameters.tokenInput.setTokens(oControlEvent
						.getParameter("tokens"));
					mParameters.oController.getView().byId(
						mParameters.controlID).setValueState(
						sap.ui.core.ValueState.None);
					mParameters.oController.getView().byId(
						mParameters.controlID).setValueStateText("");
					if (requestCompleted) {
						requestCompleted(oControlEvent);
					}

					oValueHelpDialog.close();
				},
				cancel: function () {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			this.setValueHelpColumnsForSubDis(
				oValueHelpDialog, mParameters);
			this.setValueHelpFilterBarForSubDis(
				oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
			if (mParameters.oController.tokenInput) {
				oValueHelpDialog.setTokens(mParameters.oController.tokenInput.getTokens());
			}
			if (mParameters.fireOnLoad && sap.ui.getCore().byId(mParameters.controlID)) {
				sap.ui.getCore().byId(mParameters.controlID).fireSearch();
			}
		},
		setValueHelpColumnsForSubDis: function (oValueHelpDialog, mParameters) {

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: mParameters.idLabel,
						template: "SubDistrictID"
					}, {
						label: mParameters.descriptionLabel,
						template: "SubDistrictDesc"
					}]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

			} else {

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: mParameters.idLabel
					}),
					template: new sap.m.Text({
						text: "{SubDistrictID}"
					}),
					sortProperty: "SubDistrictID",
					filterProperty: "SubDistrictID"
				}));

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: mParameters.descriptionLabel
					}),
					template: new sap.m.Text({
						text: "{SubDistrictDesc}"
					}),
					sortProperty: "SubDistrictDesc",
					filterProperty: "SubDistrictDesc"
				}));

				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}

		},
		setValueHelpFilterBarForSubDis: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var oTokenInputValue = "";
			if (mParameters.oController.tokenInput) {
				oTokenInputValue = mParameters.oController.tokenInput.getValue();
			}
			var code = new sap.m.Input({

			});
			var desc = new sap.m.Input({

			});
			oValueHelpDialog
				.setFilterBar(new sap.ui.comp.filterbar.FilterBar({

					advancedMode: true,
					filterGroupItems: [
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: mParameters.groupTitle,
							groupName: "gn1",
							name: "n1",
							label: mParameters.idLabel,
							control: code,
							visible: mParameters.idVisible
						}),
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: "",
							groupName: "gn1",
							name: "n2",
							label: mParameters.descriptionLabel,
							control: desc,
							visible: mParameters.descriptionVisible
						}),
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: ".",
							groupName: "gn2",
							name: "n3",
							label: mParameters.defaultLabel,
							control: new sap.m.Text({
								text: mParameters.defaultText
							}),
							visible: mParameters.defaultVisible
						})
					],
					search: function () {
						var codeValue = code.getValue();
						var descValue = desc.getValue();
						var filterArray = new Array();
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								"",
								"",
								filterArray,
								"LoginID",
								"", [oSSCommon
									.getCurrentLoggedUser({
										sServiceName: "SubDistricts",
										sRequestType: "read"
									})
								], false, false,
								false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "SubDistrictID", "", [codeValue], false, false,
								false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "DistrctID", "", [mParameters.DistrctID], false, false,
								false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "SubDistrictDesc", "", [descValue], true, false,
								false);
						var SSGWMSTModel = mParameters.oController._oComponent
							.getModel("SSGW_MST");
						SSGWMSTModel.attachRequestSent(function () {
							busyDialog.open();
						});
						SSGWMSTModel.attachRequestCompleted(function () {
							busyDialog.close();
						});
						SSGWMSTModel
							.read(
								"/SubDistricts", {
									filters: filterArray,
									success: function (oData) {
										var ValueHelpsModel = new sap.ui.model.json.JSONModel();
										if (oValueHelpDialog.getTable().bindRows) {
											oValueHelpDialog.getTable().clearSelection();
											ValueHelpsModel
												.setData(oData.results);
											oValueHelpDialog
												.getTable()
												.setModel(
													ValueHelpsModel);
											oValueHelpDialog
												.getTable()
												.bindRows("/");

											if (oData.results.length == 0) {
												oValueHelpDialog
													.getTable()
													.setNoData(
														mParameters.oUtilsI18n
														.getText("common.NoResultsFound"));

											}
										} else {

											//Setting Rows for sap.m.Table....................................
											var oRowsModel = new sap.ui.model.json.JSONModel();
											oRowsModel.setData(oData.results);
											oValueHelpDialog.getTable().setModel(oRowsModel);
											if (oValueHelpDialog.getTable().bindItems) {
												var oTable = oValueHelpDialog.getTable();
												oTable.bindAggregation("items", "/", function () {
													var aCols = oTable.getModel("columns").getData().cols;
													return new sap.m.ColumnListItem({
														cells: aCols.map(function (column) {
															var colname = column.template;
															return new sap.m.Text({
																text: "{" + colname + "}",
																wrapping: true
															});
														})
													});
												});
											}

											if (oData.results.length === 0) {
												oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
											}

										}
										if (oData.results.length > 0) {
											oValueHelpDialog.update();
										}
									},
									error: function (error) {
										oValueHelpDialog.getTable().clearSelection();
										if (oValueHelpDialog
											.getTable()
											.getModel() != undefined)
											oValueHelpDialog
											.getTable()
											.getModel()
											.setProperty(
												"/", {});
										oValueHelpDialog
											.getTable()
											.setNoData(
												mParameters.oUtilsI18n
												.getText("common.NoResultsFound"));
										com.arteriatech.ss.utils.js.CommonValueHelp
											.dialogErrorMessage(
												error,
												"No Data Found");
									}
								});
					}

				}));
		},
		wardF4: function () {
			var that = this;
			var view = this.getView();
			var validate = this.validateward();
			if (validate) {
				this.setValueHelpForWard({
					title: "Ward",
					oController: this,
					controlID: "idWard",
					Country: this.getView().byId("fCountryEdit").getTokens()[0].getKey(),
					State: this.getView().byId("fStateIDEdit").getTokens()[0].getKey(),
					DistrictCode: this.getView().byId("fDistrictIDEdit").getTokens()[0].getKey(),
					SubdistrictID: this.getView().byId("idSubDistrict").getTokens()[0].getKey(),
					TownCode: this.getView().byId("fTownIDEdit").getTokens()[0].getKey(),
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.Ward"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.WardDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "Wards",
					SubDistGuid: that._oComponent.getModel("ChannelPartners").getProperty("/SubDistrictGUID"),
					// propName: "Country",
					tokenInput: this.wardTokenInput,
					aKeys: this.aWardKeys,
					defaultVisible: false
				}, function (oControlEvent) {
					that._oComponent.getModel("ChannelPartners").setProperty("/WardGUID", oControlEvent.getParameter("tokens")[0].getCustomData()[
						0].getValue().WardGUID);
					that._oComponent.getModel("ChannelPartners").setProperty("/WardName", oControlEvent.getParameter("tokens")[0].getCustomData()[
						0].getValue().CNSWardName);
					// this.getView().byId("fDistrictIDEdit").setValueState(null);
					// this.getView().byId("fDistrictIDEdit").setValueStateText("");
					// var currency = oControlEvent.getParameter("tokens")[0].getCustomData()[0].getValue().DepPropDefID;
					// view.getModel("ChannelPartners").setProperty("/Currency", currency);
				});
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			}

			if (this.CountryF4_Exit) {
				this.CountryF4_Exit();
			}
		},
		setValueHelpForWard: function (mParameters, requestCompleted) {

			if (mParameters.bMultiSelect === undefined ||
				mParameters.bMultiSelect === null) {
				mParameters.bMultiSelect = false;
			}
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.title,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.aKeys[0],
				descriptionKey: mParameters.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					mParameters.tokenInput.setTokens(oControlEvent
						.getParameter("tokens"));
					mParameters.oController.getView().byId(
						mParameters.controlID).setValueState(
						sap.ui.core.ValueState.None);
					mParameters.oController.getView().byId(
						mParameters.controlID).setValueStateText("");
					if (requestCompleted) {
						requestCompleted(oControlEvent);
					}

					oValueHelpDialog.close();
				},
				cancel: function () {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			this.setValueHelpColumnsForWard(
				oValueHelpDialog, mParameters);
			this.setValueHelpFilterBarForWard(
				oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
			if (mParameters.oController.tokenInput) {
				oValueHelpDialog.setTokens(mParameters.oController.tokenInput.getTokens());
			}
			if (mParameters.fireOnLoad && sap.ui.getCore().byId(mParameters.controlID)) {
				sap.ui.getCore().byId(mParameters.controlID).fireSearch();
			}
		},
		setValueHelpColumnsForWard: function (oValueHelpDialog, mParameters) {

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: mParameters.idLabel,
						template: "CNSWardID"
					}, {
						label: mParameters.descriptionLabel,
						template: "CNSWardName"
					}]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

			} else {

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: mParameters.idLabel
					}),
					template: new sap.m.Text({
						text: "{CNSWardID}"
					}),
					sortProperty: "CNSWardID",
					filterProperty: "CNSWardID"
				}));

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: mParameters.descriptionLabel
					}),
					template: new sap.m.Text({
						text: "{CNSWardName}"
					}),
					sortProperty: "CNSWardName",
					filterProperty: "CNSWardName"
				}));

				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}

		},
		setValueHelpFilterBarForWard: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var oTokenInputValue = "";
			if (mParameters.oController.tokenInput) {
				oTokenInputValue = mParameters.oController.tokenInput.getValue();
			}
			var code = new sap.m.Input({

			});
			var desc = new sap.m.Input({

			});
			oValueHelpDialog
				.setFilterBar(new sap.ui.comp.filterbar.FilterBar({

					advancedMode: true,
					filterGroupItems: [
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: mParameters.groupTitle,
							groupName: "gn1",
							name: "n1",
							label: mParameters.idLabel,
							control: code,
							visible: mParameters.idVisible
						}),
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: "",
							groupName: "gn1",
							name: "n2",
							label: mParameters.descriptionLabel,
							control: desc,
							visible: mParameters.descriptionVisible
						}),
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: ".",
							groupName: "gn2",
							name: "n3",
							label: mParameters.defaultLabel,
							control: new sap.m.Text({
								text: mParameters.defaultText
							}),
							visible: mParameters.defaultVisible
						})
					],
					search: function () {
						var codeValue = code.getValue();
						var descValue = desc.getValue();
						var filterArray = new Array();
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								"",
								"",
								filterArray,
								"LoginID",
								"", [oSSCommon
									.getCurrentLoggedUser({
										sServiceName: "SubDistricts",
										sRequestType: "read"
									})
								], false, false,
								false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "CNSWardID", "", [codeValue], false, false,
								false);

						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "CNSWardName", "", [descValue], true, false,
								false);
						// filterArray = oPPCCommon
						// 	.setODataModelReadFilter(
						// 		mParameters.oController
						// 		.getView(), "",
						// 		filterArray, "Country", "", [mParameters.Country], false, false,
						// 		false);
						// filterArray = oPPCCommon
						// 	.setODataModelReadFilter(
						// 		mParameters.oController
						// 		.getView(), "",
						// 		filterArray, "State", "", [mParameters.State], false, false,
						// 		false);
						// filterArray = oPPCCommon
						// 	.setODataModelReadFilter(
						// 		mParameters.oController
						// 		.getView(), "",
						// 		filterArray, "DistrictCode", "", [mParameters.DistrictCode], false, false,
						// 		false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "TownCode", "", [mParameters.TownCode], false, false,
								false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "SubDistGuid", "", [mParameters.SubDistGuid], false, false,
								false);
						var SSGWMSTModel = mParameters.oController._oComponent
							.getModel("SSGW_MST");
						SSGWMSTModel.attachRequestSent(function () {
							busyDialog.open();
						});
						SSGWMSTModel.attachRequestCompleted(function () {
							busyDialog.close();
						});
						SSGWMSTModel
							.read(
								"/Wards", {
									filters: filterArray,
									success: function (oData) {
										var ValueHelpsModel = new sap.ui.model.json.JSONModel();
										if (oValueHelpDialog.getTable().bindRows) {
											oValueHelpDialog.getTable().clearSelection();
											ValueHelpsModel
												.setData(oData.results);
											oValueHelpDialog
												.getTable()
												.setModel(
													ValueHelpsModel);
											oValueHelpDialog
												.getTable()
												.bindRows("/");

											if (oData.results.length == 0) {
												oValueHelpDialog
													.getTable()
													.setNoData(
														mParameters.oUtilsI18n
														.getText("common.NoResultsFound"));

											}
										} else {

											//Setting Rows for sap.m.Table....................................
											var oRowsModel = new sap.ui.model.json.JSONModel();
											oRowsModel.setData(oData.results);
											oValueHelpDialog.getTable().setModel(oRowsModel);
											if (oValueHelpDialog.getTable().bindItems) {
												var oTable = oValueHelpDialog.getTable();
												oTable.bindAggregation("items", "/", function () {
													var aCols = oTable.getModel("columns").getData().cols;
													return new sap.m.ColumnListItem({
														cells: aCols.map(function (column) {
															var colname = column.template;
															return new sap.m.Text({
																text: "{" + colname + "}",
																wrapping: true
															});
														})
													});
												});
											}

											if (oData.results.length === 0) {
												oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
											}

										}
										if (oData.results.length > 0) {
											oValueHelpDialog.update();
										}
									},
									error: function (error) {
										oValueHelpDialog.getTable().clearSelection();
										if (oValueHelpDialog
											.getTable()
											.getModel() != undefined)
											oValueHelpDialog
											.getTable()
											.getModel()
											.setProperty(
												"/", {});
										oValueHelpDialog
											.getTable()
											.setNoData(
												mParameters.oUtilsI18n
												.getText("common.NoResultsFound"));
										com.arteriatech.ss.utils.js.CommonValueHelp
											.dialogErrorMessage(
												error,
												"No Data Found");
									}
								});
					}

				}));
		},
		onChangeMobVer: function (oEvent) {
			var state = oEvent.getParameters("state");
			if (state) {
				this._oComponent.getModel("ChannelPartners").setProperty("/MobileVerifed", "Y");
			} else {
				this._oComponent.getModel("ChannelPartners").setProperty("/MobileVerifed", "N");
			}
		},
		onChangePAN: function (oEvent) {
			var msg;
			var PANNumber = oEvent.getSource().getValue();
			if (!PANNumber) {
				msg = oi18n.getText("commmon.valid.input", gSalesDataBlock.byId("lPAN").getLabel());
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/PANNo");
				gSalesDataBlock.byId("fInPAN").setValueState("Error");
				gSalesDataBlock.byId("fInPAN").setValueStateText(msg);
			} else {
				var regpan = /^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}?$/;
				var PanVal = PANNumber;
				if (!regpan.test(PanVal)) {
					msg = oi18n.getText("commmon.valid.input", gSalesDataBlock.byId("lPAN").getLabel());
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/PANNo");
					gSalesDataBlock.byId("fInPAN").setValueState("Error");
					gSalesDataBlock.byId("fInPAN").setValueStateText(msg);
				} else if (PanVal.charAt(3) !== "C" && PanVal.charAt(3) !== "P" && PanVal.charAt(3) !== "H" && PanVal.charAt(3) !== "F" && PanVal.charAt(
						3) !== "A" && PanVal.charAt(3) !== "T" && PanVal.charAt(3) !== "B" && PanVal.charAt(3) !== "L" && PanVal.charAt(3) !== "G" &&
					PanVal.charAt(3) !== "J") {
					msg = oi18n.getText("commmon.valid.input", gSalesDataBlock.byId("lPAN").getLabel());
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/PANNo");
					gSalesDataBlock.byId("fInPAN").setValueState("Error");
					gSalesDataBlock.byId("fInPAN").setValueStateText(msg);
				} else {
					gSalesDataBlock.byId("fInPAN").setValueState(null);
					gSalesDataBlock.byId("fInPAN").setValueStateText("");
				}
			}
		},

	});
});