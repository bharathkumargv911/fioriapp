/*
 * Copyright (C) 2015-2016 Arteria Technologies Pvt. Ltd. All rights reserved
 */

jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.require("com.arteriatech.ss.cp.create1.util.CPStatusFormatter");
jQuery.sap.require("com.arteriatech.ss.cp.create1.util.CPFormatter");
jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.CommonValueHelp");

sap.ui.define([
	"com/arteriatech/ss/utils/js/UserMapping",
	"com/arteriatech/ss/cp/create1/controller/BaseController",
	"com/arteriatech/ss/utils/js/CommonValueHelp"

], function (oSSUserMapping, BaseController, oSSCommonValueHelp) {
	"use strict";
	var contextPath = "";
	var oDialog = new sap.m.BusyDialog();
	var oi18n = "",
		oUtilsI18n;
	var ChannelPartnerData = {};
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var aTaskDecisions = [];
	var busyDialog = new sap.m.BusyDialog();
	// var gHeaderBlock = gHeaderBlock, gBasicDataBlock = gBasicDataBlock, gSalesDataBlock = gSalesDataBlock;
	// var gPartnerMgrGUID = gPartnerMgrGUID;

	var sCurrentBreakpoint, oDynamicSideView, oOPSideContentBtn;

	return BaseController.extend("com.arteriatech.ss.cp.create1.controller.CPCreate", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf webapp.view.CPCreate
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			var that = this;
			// this.getView().setBusy(true);
			gCPDetailView = this.getView();
			oDialog.open();
			var selectedCustomer = "";
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.setDefaultSettings();
			this.DynamicSideContent = this.getView().byId("ObjectPageLayout");
			gDynamicSideContent = this.getView().byId("ObjectPageLayout");
			// this._oRouter = this.getRouter();
			this.router = sap.ui.core.UIComponent.getRouterFor(this);
			this.router.attachRouteMatched(this.onRouteMatched, this);
			oPPCCommon.initMsgMangerObjects();
			this.setValueHelpProperty();
			var oDataModel = this._oComponent.getModel("PUGW");
			oSSCommon.setODataModel(oDataModel);
			oSSCommon.getCustomerInputType(function (customerInputType) {
				that.sCustomerInputType = customerInputType;
				// that.sCustomerInputType = "VH";
				that.getCustomers();
			});

			oDialog.close();
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}

			/*oDynamicSideView = this.getView().byId("DynamicSideContent");
			oOPSideContentBtn = this.getView().byId("ObjectPageHeader").getSideContentButton();*/
		},
		setValueHelpProperty: function () {

			this.CustomerTokenInput = this.getView().byId("inputCustomerF4");
			this.aCustomerKeys = ["CustomerNo", "Name"];
		},
		onRouteMatched: function (oEvent) {
			// gCPDetailView.setBusy(true);
			if (oEvent.getParameter("name") !== "cpdetail" && oEvent.getParameter("name") !== "cpchange" && oEvent.getParameter("name") !==
				"cpApprovedetail" && oEvent.getParameter("name") !== "cpapprovechange") {
				return;
			}
			var contextPath = "";

			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(this.DynamicSideContent);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData()
				.length);
			this.getView().setBusy(true);
			this.ddCount = 7;
			var oHistory = sap.ui.core.routing.History.getInstance();
			//if (oHistory.getDirection() !== "Backwards") {
			var that = this;
			if (oHistory.getDirection() !== "Backwards") {
				if (oEvent.getParameter("name") === "cpdetail") {
					contextPath = oEvent.getParameter("arguments").contextPath;
					//	oDialog.open();
					that.getRetailerDetails(function () {});
					that.gotoEdit();
					this.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", true);
					///	oDialog.close();
				} else if ((oHistory.getDirection() === undefined || oHistory.getDirection() === "Unknown" || oHistory.getDirection() ===
						"NewEntry") && oEvent.getParameter("name") === "cpchange") {
					contextPath = oEvent.getParameter("arguments").contextPath;

					this.router.navTo("cpdetail", {
						contextPath: contextPath
					}, true);

				}
				this.getView().setBusy(false);
			} else {
				if (this._oComponent.getModel("CPDMSDivisionTaxes")) {
					gCPDetailView.setBusy(false);
				} else {
					if (oEvent.getParameter("name") === "cpdetail" || oEvent.getParameter("name") === "cpchange") {
						contextPath = oEvent.getParameter("arguments").contextPath;

						if (oHistory.getDirection() === "Backwards") {
							if (contextPath === undefined) {
								that.getRetailerDetails(function () {});
								that.gotoEdit();
								this.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", true);
								gCPDetailView.setBusy(false);
							} else {
								this.router.navTo("cpdetail", {
									contextPath: contextPath
								}, true);
							}
						} else {

							that.getRetailerDetails(function () {});
							that.gotoEdit();
							this.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", true);
							gCPDetailView.setBusy(false);
						}
					}
				}
			}

		},
		gotoEdit: function () {
			var that = this;
			this.getMaxDiscount();
			oPPCCommon.removeAllMsgs();
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData()
				.length);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/editMode", true);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
			//	gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/pageHeader", oi18n.getText("sodetail.Page.editHeader"));

			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/approveButton", false);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/rejectButton", false);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/editApproveButton", false);

			//Clone the data
			this._oCPDetails = jQuery.extend(true, [], that.getView().getModel("ChannelPartners").getData());
			this._oCPs = jQuery.extend({}, this._oComponent.getModel("ChannelPartners").getData());

			if (gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/approveVisible")) {
				this._oTaskHistorys = jQuery.extend(true, [], this.getView().getModel("TaskHistorys").getData());
				this._oTaskDecisions = jQuery.extend(true, [], this.getView().getModel("TaskDecisions").getData());
			}
			//Clone the data
			this._oChannelPartners = jQuery.extend({}, this.getView().getModel("ChannelPartners").getData());

			this.setChannelPartnerTypeDD();
			this.setSalesGroup();
			this.setSalesOffice();
			this.setPartnerFunctionDD();
			this.DMSDivisionDD();

			this.WeeklyOffDD();
			// this.Group1DD();

			// this.Group4DD();
			// this.Group5DD();
			// this.TaxCategoryDD();
			this.TaxRegStatusDD();
			this.OutletsizeDD();
			this.OutletshapeDD();
			this.Outletlocation();
			this.setYesNoDD();
			if (this.gotoEdit_Exit) {
				this.gotoEdit_Exit();
			}
		},

		setCustomerInputVisibility: function () {
			if (this.sCustomerInputType === "DD") {
				this._oComponent.getModel("LocalViewSettingDtl").setProperty("/CustomerDD", true);
				this._oComponent.getModel("LocalViewSettingDtl").setProperty("/CustomerVH", false);
			} else if (this.sCustomerInputType === "VH") {
				this._oComponent.getModel("LocalViewSettingDtl").setProperty("/CustomerDD", false);
				this._oComponent.getModel("LocalViewSettingDtl").setProperty("/CustomerVH", true);
			}

		},
		setChannelPartnerTypeDD: function (fCPTypeID) {
			var view = gCPDetailView;
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPTypeID"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [fCPTypeID], false, false, false);

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"ChannelPartnerType", "Select",
				function () {

					that.busyCount();
				}, false, "PD", true);

			if (this.setChannelPartnerTypeDD_Exit) {
				this.setChannelPartnerTypeDD_Exit();
			}

		},
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},
		getRetailerDetails: function () {
			var that = this;
			var oData = {
				"CPGUID": oPPCCommon.generateUUID(),
				"LoginID": "",
				"CPNo": "",

				// "PartnerMgrGUID": oPPCCommon.generateUUID(),
				"PartnerMgrName": "",
				"PartnerMgrNo": "",
				"Name": "",
				"CPUID": "",
				"AccountGrp": "",
				"ParentID": "",
				"ParentName": "",
				"SearchTerm": "",
				"ParentTypeID": "",
				"ParentTypDesc": "",
				"CPTypeID": "",
				"CPTypeDesc": "",
				"Group1": "",
				"Group2": "",
				"Group3": "",
				"Group4": "",
				"CPStock": null,
				"UOM": "",
				"DOB": null,
				"Anniversary": null,
				"RouteID": "",
				"RouteDesc": "",
				"Latitude": null,
				"Longitude": null,
				"Address1": "",
				"Address2": "",
				"Address3": "",
				"Address4": "",
				"Landmark": "",
				"ZoneID": "",
				"ZoneDesc": "",
				"TownID": "",
				"TownDesc": "",
				"CityID": "",
				"CityDesc": "",
				"StateID": "",
				"StateDesc": "",
				"DistrictID": "",
				"DistrictDesc": "",
				"Country": "",
				"CountryName": "",
				"PostalCode": "",
				"Mobile1": "",
				"Mobile2": "",
				"Landline": "",
				"EmailID": "",
				"Currency": "",
				"CreditLimit": null,
				"CreditDays": 0,
				"VATNo": "",
				"TIN": "",
				"PAN": "",
				"StatusID": "",
				"StatusDesc": "",
				"ApprvlStatusID": "",
				"ApprvlStatusDesc": "",
				"OwnerName": "",
				"SalesOfficeID": "",
				"SalesGrpDesc": "",
				"SalesGroupID": "",
				"SalesOffDesc": "",
				"IsKeyCP": "",
				"WeeklyOff": "",
				"WeeklyOffDesc": "",
				"ID1": "",
				"ID2": "",
				"FaxNo": "",
				"BusinessID1": "",
				"BusinessID2": "",
				"Tax1": "",
				"Tax2": "",
				"Tax3": "",
				"Tax4": "",
				"DeactivatedOn": null,
				"TaxClassification": "",
				"ApprovedOn": null,
				"ApprovedBy": "",
				"ApprovedAt": "PT15H43M52S",
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT14H17M09S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				"TestRun": "",
				"Group1Desc": "",
				"Group2Desc": "",
				"Group3Desc": "",
				"Group4Desc": "",
				"TaxRegStatus": "",
				"TaxRegStatusDesc": "",
				"IsHomedlvryAvl": " ",
				"IsPhOrderAvl": " ",
				"IsCompBillAvl": " ",
				"IsHsptlNearBy": " ",
				"IsEduInstNrby": " ",
				"IsSmartPhAvl": " ",
				"OutletShapeId": "",
				"OutletSizeId": "",
				"OutletSizeDesc": "",
				"OutletLocId": "",
				"OutletShapeDesc": "",
				"OutletLocDesc": "",
				"CPDMSDivisions": [],
				"CPPartnerFunctions": []
			};
			this.setChannelPartnerDetails(oData);
			this.setAdditionalDetailLocalModel(["/HomeDelivery", "/PhoneOrder", "/ComputerBilling", "/HospitalNear", "/EdcNear", "/SmartPhone"]);
			this.setAdditionalDetailLocalModelForTime(["/OpeningTime", "/ClosingTime", "/LunchTime"]);

			// if (gBasicDataBlock) {
			// 	gBasicDataBlock.byId("Customer").setSelectedKey("");
			// }
			// this.getView().getModel("LocalViewSettingDtl").setProperty("/Name", "");
			// this.getView().getModel("LocalViewSettingDtl").setProperty("/CustomerNo", "");

			// gCPDetailClassGroups.oController.setCPScheduleDetails();
			// if (gCPDetailClassGroups.getModel("CPGroupTemp")) {
			// 	gCPDetailClassGroups.oController.setDefaultSettings();
			// }
			// this.getView().setBusy(false);

			if (this.getRetailerDetails_Exit) {
				this.getRetailerDetails_Exit();
			}
		},
		setAdditionalDetailLocalModel: function (properties) {
			var that = this;
			properties.forEach(function (eachElement) {
				that.getView().getModel("LocalViewSettingDtl").setProperty(eachElement, "No");
			});
		},
		setAdditionalDetailLocalModelForTime: function (properties) {
			var that = this;
			properties.forEach(function (eachElement) {
				that.getView().getModel("LocalViewSettingDtl").setProperty(eachElement, "00:00");
			});
		},

		setChannelPartnerDetails: function (oData) {
			ChannelPartnerData = oData;
			if (oData.ApprvlStatusID && (oData.ApprvlStatusID === "01" || oData.ApprvlStatusID === "03")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/HeaderObjectApprovalVisibility", true);
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/HeaderObjectApprovalVisibility", false);
			}
			gPartnerMgrGUID = oData.PartnerMgrGUID;

			var oChannelPartnersModel = new sap.ui.model.json.JSONModel();
			oChannelPartnersModel.setData(oData);
			this._oComponent.setModel(oChannelPartnersModel, "ChannelPartners");

			var aData = [];
			var oChannelPartnerssModel = new sap.ui.model.json.JSONModel();
			oChannelPartnerssModel.setData(aData);
			this._oComponent.setModel(oChannelPartnerssModel, "ChannelPartnerss");

			var oCPModel = this._oComponent.getModel("ChannelPartners");
			//	this.getCustomers();

			var oCPAlterntateData = [{
				AlternateName: oCPModel.getProperty("/AlternateName"),
				Address1: oCPModel.getProperty("/Address1"),
				ID1: oCPModel.getProperty("/ID1"),
				PAN: oCPModel.getProperty("/PAN"),
				TIN: oCPModel.getProperty("/TIN")
			}];

			var oCPAlternateBillsJson = new sap.ui.model.json.JSONModel();
			/*for (var i = 0; i < oData.CPPartnerFunctions.length; i++) {
				oData.CPPartnerFunctions[i].bIsNew = false;
			}*/
			oCPAlternateBillsJson.setData(oData.CPPartnerFunctions);
			this._oComponent.setModel(oCPAlternateBillsJson, "CPAlternateBillings");
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", oData.CPPartnerFunctions.length);
			}

			this.setRetailerDMSChannels(oData.CPDMSDivisions);

			if (this.setChannelPartnerDetails_Exit) {
				this.setChannelPartnerDetails_Exit();
			}

		},
		getRetailerDMSChannels: function () {},
		setNodataFound: function () {
			var oView = this.getView();
			/** Clear Model of the view */
			if (oView.getModel("CPDMSDivisions") !== undefined) {
				oView.getModel("CPDMSDivisions").setProperty("/", {});
			}

			if (this.setNodataFound_Exit) {
				this.setNodataFound_Exit();
			}
		},
		setRetailerDMSChannels: function (oData) {
			var oCPDMSDivisionsModel = new sap.ui.model.json.JSONModel();
			/*for (var i = 0; i < oData.length; i++) {
				oData[i].bIsNew = false;
			}*/
			oCPDMSDivisionsModel.setData(oData);
			this._oComponent.setModel(oCPDMSDivisionsModel, "CPDMSDivisions");
			this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCountClassification", oData.length);

			if (this.setRetailerDMSChannels_Exit) {
				this.setRetailerDMSChannels_Exit();
			}
		},

		handleoDataError: function (error) {
			var message = oPPCCommon.parseoDataErrorMessage(error);
			if (message.trim() === "Not Found") {
				this.clearModel();
				this.router.navTo("NoMatching");
			} else {
				var that = this;
				oPPCCommon.dialogErrorMessage(error, "Service error" /*oUtilsI18n.getText("common.Dialog.Error.ServiceError.Header")*/ , function () {
					that.backToList();
				});
			}

			if (this.handleoDataError_Exit) {
				this.handleoDataError_Exit();
			}
		},
		onBack: function () {
			var oView = this.getView();
			if (oView.getModel('LocalViewSettingDtl').getProperty('/reviewMode')) {
				oView.getModel('LocalViewSettingDtl').setProperty('/detailMode', false);
				oView.getModel('LocalViewSettingDtl').setProperty('/editButton', false);
				oView.getModel('LocalViewSettingDtl').setProperty('/editMode', true);
				oView.getModel('LocalViewSettingDtl').setProperty('/reviewMode', false);
				this.resetDivisionClassiModel();
			}

			if (this.onBack_Exit) {
				this.onBack_Exit();
			}
		},
		resetDivisionClassiModel: function () {
			var CPDMSDivisionsData = this.getView().getModel("CPDMSDivisions").getData();
			for (var i = CPDMSDivisionsData.length - 1; i >= 0; i--) {
				if (CPDMSDivisionsData[i].DMSDivision === "COMMON") {
					CPDMSDivisionsData.splice(i, 1);
				}
			}
		},
		backToList: function () {
			//window.history.go(-1);

			if (this.backToList_Exit) {
				this.backToList_Exit();
			}
		},
		clearModel: function () {
			if (this.getView().getModel("ChannelPartners")) {
				this.getView().getModel("ChannelPartners").setProperty("/", {});
			}
			if (this.getView().getModel("TaskHistorys")) {
				this.getView().getModel("TaskHistorys").setProperty("/", {});
			}
			if (this.getView().getModel("TaskDecisions")) {
				this.getView().getModel("TaskDecisions").setProperty("/", {});
			}

			if (this.clearModel_Exit) {
				this.clearModel_Exit();
			}
		},
		onEdit: function () {
			var oView = this.getView();
			oView.getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
			oView.getModel("LocalViewSettingDtl").setProperty("/editButton", false);
			oView.getModel("LocalViewSettingDtl").setProperty("/editMode", true);
			oView.getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
			oView.getModel("LocalViewSettingDtl").setProperty("/pageHeader", oi18n.getText("CPChange.Page.header"));

			this.addTokensForCommonValueHelp(gCPDetailView);
			//Clone the data
			this._oChannelPartners = jQuery.extend({}, this.getView().getModel("ChannelPartners").getData());
			this.setSalesGroup();
			this.setSalesOffice();
			this.setPartnerFunctionDD();
			this.DMSDivisionDD();
			// this.SalesPersonDD();
			this.Group1DD();
			// this.Group2DD();
			//this.Group3DD();
			this.Group4DD();
			this.Group5DD();
			this.setCPTypeDD();
			this.TaxCategoryDD();
			// /this.TaxClassificationDD();

			//this.setWeeklyOffDD();

			var oCPAlterntateData = this._oComponent.getModel("CPAlternateBillings").getData();
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", oCPAlterntateData.length);
			}

			var oSOItemDetailModel = this.getView().getModel("ChannelPartners");
			if (oSOItemDetailModel) {
				this._oCPDetails = oSOItemDetailModel.getData();
			}
			var oSOModel = this.getView().getModel("ChannelPartners");
			if (oSOModel) {
				this._oCPs = oSOModel.getData();
			}
			var oTaskDecisionsModel = this.getView().getModel("TaskDecisions");
			if (oTaskDecisionsModel) {
				this._oTaskDecisions = oTaskDecisionsModel.getData();
			}

			var oTaskHistorysModel = this.getView().getModel("TaskHistorys");
			if (oTaskHistorysModel) {
				this._oTaskHistorys = oTaskHistorysModel.getData();
			}

			var CPAlternateBillings = this.getView().getModel("CPAlternateBillings");
			if (CPAlternateBillings) {
				this._oCPAlternateBillings = CPAlternateBillings.getData();
			}

			var CPDMSDivisions = this.getView().getModel("CPDMSDivisions");
			if (CPDMSDivisions) {
				this._oCCPDMSDivisions = CPDMSDivisions.getData();
			}

			if (this.onEdit_Exit) {
				this.onEdit_Exit();
			}

		},
		busyCount: function () {
			this.ddCount--;
			if (this.ddCount === 0) {
				this.getView().setBusy(false);

			}
		},

		addDefaultAlternatBilling: function (sPartnerFunction, sPartnerSesc) {

			var sGUID = this.getView().getModel("ChannelPartners").getProperty("/CPGUID");
			sGUID = sGUID.replace("-", "");
			sGUID = sGUID.replace("-", "");
			sGUID = sGUID.replace("-", "");
			sGUID = sGUID.replace("-", "");

			var newItem = {
				"CPGUID": this.getView().getModel("ChannelPartners").getProperty("/CPGUID"),
				"PFGUID": oPPCCommon.generateUUID(),
				"LoginID": "",
				"PartnerFunction": sPartnerFunction,
				"PartnerFunctionDesc": sPartnerSesc,
				"CPNo": this.getView().getModel("ChannelPartners").getProperty("/CPNo"),
				"CPName": this.getView().getModel("ChannelPartners").getProperty("/Name"),
				"CPMobileNo": this.getView().getModel("ChannelPartners").getProperty("/Mobile1"),
				"PartnerCPNo": this.getView().getModel("ChannelPartners").getProperty("/CPNo"),
				"PartnarName": this.getView().getModel("ChannelPartners").getProperty("/Name"),
				"PartnerMobileNo": this.getView().getModel("ChannelPartners").getProperty("/Mobile1"),
				"PartnarCPGUID": sGUID,
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT13H07M02S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				"StatusID": "01"
			};

			//Pus new row to model
			var oItemModel = this.getView().getModel("CPAlternateBillings");
			var oItemModelData = oItemModel.getData();
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Update Table count
			var iTotalLength = this.getView().getModel("CPAlternateBillings").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", iTotalLength);
			}

			if (this.addDefaultAlternatBilling_Exit) {
				this.addDefaultAlternatBilling_Exit();
			}
		},
		setCPTypeDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPTYPE"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"CPTypeDD", "Select",
				function () {
					that.busyCount();
				});

			if (this.setCPTypeDD_Exit) {
				this.setCPTypeDD_Exit();
			}

		},
		TaxCategoryDD: function () {
			// busyDialog.open();
			var that = this;
			var view = gCPDetailView;
			var oModelData = this._oComponent.getModel("PCGW");
			var oTaxCategoryFilter = new Array();
			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["TaxCategory"], false, false, false);

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oTaxCategoryFilter, "ID", "Description", busyDialog, view,
				"TaxCategoryDD", "Select",
				function () {
					that.busyCount();
				}, false, "PD", true);

			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}

		},

		TaxRegStatusDD: function () {
			// busyDialog.open();
			var view = gCPDetailView;
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");

			oModelData.setUseBatch(false);
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["TaxRegStatus"], false, false, false);

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"TaxRegStatusDD", "Select",
				function () {
					that.busyCount();
				}, false, "PD", true);

			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}

		},
		OutletsizeDD: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");

			oModelData.setUseBatch(false);
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPOLSZ"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"OutletsizeDD", "Select",
				function (response) {
					that.getView().getModel("ChannelPartners").setProperty("/OutletSizeId", "");
				}, true, "PD", true);

			if (this.OutletsizeDD_Exit) {
				this.OutletsizeDD_Exit();
			}
		},
		OutletshapeDD: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			oModelData.setUseBatch(false);
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPOLSP"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"OutletshapeDD", "Select",
				function (response) {
					that.getView().getModel("ChannelPartners").setProperty("/OutletShapeId", "");
				}, true, "PD", true);

			if (this.OutletshapeDD_Exit) {
				this.OutletshapeDD_Exit();
			}
		},
		Outletlocation: function () {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			oModelData.setUseBatch(false);
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPOLLC"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"OutletlocationDD", "Select",
				function (response) {
					that.getView().getModel("ChannelPartners").setProperty("/OutletLocId", "");
				}, true, "PD", true);

			if (this.Outletlocation_Exit) {
				this.Outletlocation_Exit();
			}
		},
		setYesNoDD: function () {
			var that = this;
			var arr = [];
			arr.push({
				Key: "X",
				Text: "Yes"
			}, {
				Key: " ",
				Text: "No"
			});
			var oViewSettingModel = new sap.ui.model.json.JSONModel();
			oViewSettingModel.setData(arr);
			that.getView().setModel(oViewSettingModel, "YesNoDD");
			that.getView().getModel("ChannelPartners").setProperty("/IsHomedlvryAvl", " ");
			that.getView().getModel("ChannelPartners").setProperty("/IsPhOrderAvl", " ");
			that.getView().getModel("ChannelPartners").setProperty("/IsCompBillAvl", " ");
			that.getView().getModel("ChannelPartners").setProperty("/IsHsptlNearBy", " ");
			that.getView().getModel("ChannelPartners").setProperty("/IsEduInstNrby", " ");
			that.getView().getModel("ChannelPartners").setProperty("/IsSmartPhAvl", " ");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/HomeDelivery", "No");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/PhoneOrder", "No");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/ComputerBilling", "No");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/HospitalNear", "No");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/EdcNear", "No");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/SmartPhone", "No");
			that.getView().getModel("LocalViewSettingDtl").setProperty("/SmartPhone", "No");
		},
		DMSDivisionDD: function (oEvent) {
			// busyDialog.open();
			var view = gCPDetailView;
			var that = this;

			var oModelData = this._oComponent.getModel("PCGW");

			oModelData.setUseBatch(false);
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["DMSDiv"], false, false, false);

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"DMSDivisionDD", "Select",
				function () {
					that.busyCount();

				}, false, "PD", true);

			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}

		},
		WeeklyOffDD: function () {
			// busyDialog.open();
			var view = gCPDetailView;
			var that = this;

			var oModelData = this._oComponent.getModel("PCGW");
			oModelData.setUseBatch(false);

			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["WeeklyOff"], false, false, false);

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"WeeklyOffDD", "Select",
				function () {
					that.busyCount();
				}, false, "PD", true);

			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}

		},
		SalesPersonDD: function (CPGUID) {
			// busyDialog.open();
			var view = gCPDetailView;
			var that = this;

			var oModelData = this._oComponent.getModel("SSGW_MST");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "CPGUID", sap.ui
				.model.FilterOperator.EQ, [
					CPGUID
				], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "StatusID", sap.ui
				.model.FilterOperator.EQ, [
					"01"
				], false, false, false);
			this.getDropDown(oModelData, "SalesPersons", oSalesGroupFilter, "SPGUID", "FirstName", busyDialog, view,
				"SalesPersonDD", "Select",
				function () {
					that.busyCount();

				}, true, "PD", true, "SPNo");

			if (this.SalesPersonDD_Exit) {
				this.SalesPersonDD_Exit();
			}

		},
		Group1DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP1"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group1DD", "Select",
				function () {
					that.busyCount();
				}, true, "PD", true);

			if (this.Group1DD_Exit) {
				this.Group1DD_Exit();
			}
		},
		Group2DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP2"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group2DD", "Select",
				function () {
					that.busyCount();
				}, true, "PD", true);

			if (this.Group2DD_Exit) {
				this.Group2DD_Exit();
			}
		},
		Group3DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP3"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group3DD", "Select",
				function () {
					that.busyCount();
				}, true, "PD", true);

			if (this.Group3DD_Exit) {
				this.Group3DD_Exit();
			}
		},
		Group4DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP4"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group4DD", "Select",
				function () {
					that.busyCount();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group5DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP5"
			], false, false, false);
			/*oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group5DD", "Select",
				function () {
					that.busyCount();
				}, true, "PD", true);

			if (this.Group5DD_Exit) {
				this.Group5DD_Exit();
			}
		},
		setPartnerFunctionDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");

			oModelData.setUseBatch(false);
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"SSPF"
			], false, false, false);
			oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"SSPF", "Select",
				function () {
					that.busyCount();
				}, true, "PD", true);

			if (this.setPartnerFunctionDD_Exit) {
				this.setPartnerFunctionDD_Exit();
			}
		},
		setSalesGroup: function () {
			// busyDialog.open();
			var view = gCPDetailView;
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");

			oModelData.setUseBatch(false);
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["SalesGroupID"], false, false, false);
			/*oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSalesGroupFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"SalesGroupDD", "Select",
				function () {
					that.busyCount();
				}, false, "PD", true);

			if (this.setSalesGroup_Exit) {
				this.setSalesGroup_Exit();
			}

		},
		setSalesOffice: function () {
			// busyDialog.open();
			var view = gCPDetailView;
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");

			oModelData.setUseBatch(false);
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["SalesOfficeID"], false, false, false);
			/*oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSalesGroupFilter, "LoginID", "", [this.getCurrentUsers(
				"ChannelPartners", "read")], false, false, false);*/

			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"SalesOfficeDD", "Select",
				function () {
					that.busyCount();
				}, false, "PD", true);

			if (this.setSalesOffice_Exit) {
				this.setSalesOffice_Exit();
			}
		},
		addTokensForCommonValueHelp: function (view) {
			this.addTokens(view, ChannelPartnerData.StateID, ChannelPartnerData.StateDesc, "fStateIDEdit");
			this.addTokens(view, ChannelPartnerData.CityID, ChannelPartnerData.CityDesc, "fCityIDEdit");
			this.addTokens(view, ChannelPartnerData.Country, ChannelPartnerData.CountryName, "fCountryEdit");
			this.addTokens(view, ChannelPartnerData.Country, ChannelPartnerData.CountryName, "idWard");
			this.addTokens(view, ChannelPartnerData.Country, ChannelPartnerData.CountryName, "idSubDistrict");
			// this.addTokens(view, ChannelPartnerData.WeeklyOff, ChannelPartnerData.WeeklyOffDesc, "fWeeklyOffEdit");
			// this.addTokens(view, ChannelPartnerData.RouteID, ChannelPartnerData.RouteDesc, "fRouteIDEdit");
			this.addTokens(view, ChannelPartnerData.ZoneID, ChannelPartnerData.ZoneDesc, "fZoneIDEdit");
			this.addTokens(view, ChannelPartnerData.TownID, ChannelPartnerData.TownDesc, "fTownIDEdit");
			this.addTokens(view, ChannelPartnerData.DistrictID, ChannelPartnerData.DistrictDesc, "fDistrictIDEdit");
			// this.addTokens(view,ChannelPartnerData.SalesOfficeID,ChannelPartnerData.SalesOffDesc,"SalesOfficeID");
			// this.addTokens(view,ChannelPartnerData.SalesGroupID,ChannelPartnerData.SalesGrpDesc,"SalesGroupID");
			// this.addTokens(view,ChannelPartnerData.SalesGroupID,ChannelPartnerData.SalesGrpDesc,"SalesGroupID");
			// this.addTokens(view, ChannelPartnerData.PartnerMgrNo, ChannelPartnerData.PartnerMgrName, "fPartnerMgrNoEdit");
			/*this.addTokens(view, ChannelPartnerData.PartnerMgrNo, ChannelPartnerData.PartnerMgrName, "fWeeklyOffEdit");
			this.addTokens(view, ChannelPartnerData.PartnerMgrNo, ChannelPartnerData.PartnerMgrName, "fZoneIDEdit");
			this.addTokens(view, ChannelPartnerData.PartnerMgrNo, ChannelPartnerData.PartnerMgrName, "fRouteIDEdit");*/
			this.addDMSDivisionTokens();
			this.addParnerFunctionTokens();

			if (this.addTokensForCommonValueHelp_Exit) {
				this.addTokensForCommonValueHelp_Exit();
			}
		},

		addDMSDivisionTokens: function () {
			/*
						var oModel = this.getModel("CPDMSDivisions");
						if (sap.ui.Device.system.tablet || sap.ui.Device.system.phone) {
							var oTable = gDMSDivisions.byId("CLASSIFICATIONCHANNELSTABLEEditM")
							if (oTable) {
								var aRows = oTable.getItems();
								for (var row = 0; row < aRows.length; row++) {
									var aCells = aRows[row].getCells();
									for (var cell = 0; cell < aCells.length; cell++) {
										var cellId = aCells[cell].getId();
										if (cellId.indexOf("fDMSDivisionLayoutM") > -1) {
											cellId = cellId.replace("fDMSDivisionLayoutM", "fDMSDivisionEditM");
											gDMSDivisions.byId(cellId).removeAllTokens();
											if (oModel.getProperty("/" + row + "/DMSDivision")) {
												gDMSDivisions.byId(cellId).addToken(new sap.m.Token({
													key: oModel.getProperty("/" + row + "/DMSDivision"),
													desc: oModel.getProperty("/" + row + "/DMSDivisionDesc") + "(" + oModel.getProperty("/" + row + "/DMSDivision") + ")"
												}));
											}
										} else if (cellId.indexOf("fRouteIDEditM") > -1) {
											gDMSDivisions.byId(cellId).removeAllTokens();
											if (oModel.getProperty("/" + row + "/RouteID")) {
												gDMSDivisions.byId(cellId).addToken(new sap.m.Token({
													key: oModel.getProperty("/" + row + "/RouteID"),
													desc: oModel.getProperty("/" + row + "/RouteDesc") + "(" + oModel.getProperty("/" + row + "/RouteID") + ")"
												}));
											}
										}
									}
								}
							}
						} else {
							var oTable = gDMSDivisions.byId("CLASSIFICATIONCHANNELSTABLEEdit")
							if (oTable) {
								var aRows = oTable.getRows();
								for (var row = 0; row < aRows.length; row++) {
									var aCells = aRows[row].getCells();
									for (var cell = 0; cell < aCells.length; cell++) {
										var cellId = aCells[cell].getId();
										if (cellId.indexOf("fDMSDivisionEdit") > -1) {
											gDMSDivisions.byId(cellId).removeAllTokens();
											if (oModel.getProperty("/" + row + "/DMSDivision")) {
												gDMSDivisions.byId(cellId).addToken(new sap.m.Token({
													key: oModel.getProperty("/" + row + "/DMSDivision"),
													desc: oModel.getProperty("/" + row + "/DMSDivisionDesc") + "(" + oModel.getProperty("/" + row + "/DMSDivision") + ")"
												}));
											}
										} else if (cellId.indexOf("fRouteIDEdit") > -1) {
											gDMSDivisions.byId(cellId).removeAllTokens();
											if (oModel.getProperty("/" + row + "/RouteID")) {
												gDMSDivisions.byId(cellId).addToken(new sap.m.Token({
													key: oModel.getProperty("/" + row + "/RouteID"),
													desc: oModel.getProperty("/" + row + "/RouteDesc") + "(" + oModel.getProperty("/" + row + "/RouteID") + ")"
												}));
											}
										}
									}
								}
							}
						}

						if (this.addDMSDivisionTokens_Exit) {
							this.addDMSDivisionTokens_Exit();
						}
					*/
		},

		addParnerFunctionTokens: function () {

			if (this.addParnerFunctionTokens_Exit) {
				this.addParnerFunctionTokens_Exit();
			}
		},
		//to add tokens for multiInput
		addTokens: function (view, key, desc, controlID) {
			//Token for State
			var oToken;
			if (view.byId(controlID)) {
				view.byId(controlID).removeAllTokens();
				if (key !== "") {
					oToken = new sap.m.Token({
						key: key,
						text: desc + " (" + key + ")"
					});
					view.byId(controlID).addToken(oToken);
				}
			} else if (gBasicDataBlock.byId(controlID)) {
				gBasicDataBlock.byId(controlID).removeAllTokens();
				if (key !== "") {
					oToken = new sap.m.Token({
						key: key,
						text: desc + " (" + key + ")"
					});
					gBasicDataBlock.byId(controlID).addToken(oToken);
				}
			} else if (gSalesDataBlock.byId(controlID)) {
				gSalesDataBlock.byId(controlID).removeAllTokens();
				if (key !== "") {
					oToken = new sap.m.Token({
						key: key,
						text: desc + " (" + key + ")"
					});
					gSalesDataBlock.byId(controlID).addToken(oToken);
				}
			}

			if (this.addTokens_Exit) {
				this.addTokens_Exit();
			}
		},

		onReview: function (oEvent) {

			var that = this;
			that.getView().byId("saveBtn").setEnabled(true);
			var view = gCPDetailView;
			var that = this;
			oPPCCommon.removeAllMsgs();
			that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);

			this.validateForm(view);
			this.validateDuplicatePFs();
			var ChannelPartnersModel = this.getView().getModel("ChannelPartners");
			var aData = ChannelPartnersModel.getData();
			if (gCPInfraView.getModel("InfraDetailsModel")) {
				var InfraDetails = gCPInfraView.getModel("InfraDetailsModel").getData();
				this.validateInfra(InfraDetails);
				InfraDetails = this.formatInfraDetails(InfraDetails, aData);
				gCPInfraView.getModel("InfraDetailsModel").setProperty("/", InfraDetails);
			}

			if (ChannelPartnersModel.getProperty("/CPTypeID") === "" || ChannelPartnersModel.getProperty("/CPTypeID") === "10" ||
				ChannelPartnersModel.getProperty("/CPTypeID") === "20") {
				this.validateItem(view);
			}
			// this._oComponent.getModel("CPDMSDivisions").setProperty("/ParentID", aData.ParentID);

			var tData = this.getView().getModel("CPDMSDivisions").getData();
			if (tData.length > 0) {
				tData[0].ParentID = aData.ParentID;

			}
			if (oPPCCommon.doErrMessageExist()) {

				if (ChannelPartnersModel.getProperty("/CPTypeID") === "01" || ChannelPartnersModel.getProperty("/CPTypeID") === "90") {
					var CPDMSDivisions = [];
					// var tData = this.getView().getModel("CPDMSDivisions").getData();
					var testData = gDMSDivisions.getModel("DMSDivisionDD").getProperty("/");
					var tempData = [];
					for (var index = 0; index < testData.length; index++) {
						if (testData[index].Key === "") {} else {
							tempData.push(testData[index]);
						}
					}
					// 
					for (var indexj = 0; indexj < tempData.length; indexj++) {
						var newItem = {
							"CPGUID": that._oComponent.getModel("ChannelPartners").getProperty("/CPGUID"),
							"CP1GUID": oPPCCommon.generateUUID(),
							"LoginID": "",
							"CPNo": "",
							"Name": "",
							"DMSDivision": "",
							"DMSDivisionDesc": "",
							"Currency": that._oComponent.getModel("ChannelPartners").getProperty("/Currency"),
							"RouteID": "",
							"RouteDesc": "",
							"CPUID": "",
							"OwnerName": "",
							"MobileNo": "",
							"Group1": "",
							"Group1Desc": "",
							"Group2": "",
							"ParentTypeID": that._oComponent.getModel("LocalViewSettingDtl").getProperty("/CPTypeIDMandat"),
							"ParentID": that._oComponent.getModel("ChannelPartners").getProperty("/ParentID"),
							"ParentName": that._oComponent.getModel("LocalViewSettingDtl").getProperty("/Name"),
							"Group2Desc": "",
							"Group3": "",
							"Group3Desc": "",
							"Group4": "",
							"Group4Desc": "",
							"Group5": "",
							"Group5Desc": "",
							"PartnerMgrGUID": null,
							"PartnerMgrNo": "",
							"PartnerMgrName": "",
							"DiscountPer": null,
							"StatusID": "01",
							"ApprvlStatusID": "",
							"CreatedBy": "",
							"CreatedOn": null,
							"CreatedAt": "PT00H00M00S",
							"ChangedBy": "",
							"ChangedOn": null,
							"ChangedAt": "PT00H00M00S",
							// "Geo1": this._oComponent.getModel("OwnData").getProperty("/Geo1"),
							// "Geo1Desc": this._oComponent.getModel("OwnData").getProperty("/Geo1Desc"),
							// "Geo2": this._oComponent.getModel("OwnData").getProperty("/Geo2"),
							// "Geo2Desc": this._oComponent.getModel("OwnData").getProperty("/Geo2Desc"),
							// "Geo3": this._oComponent.getModel("OwnData").getProperty("/Geo3"),
							// "Geo3Desc": this._oComponent.getModel("OwnData").getProperty("/Geo3Desc"),
							// "Geo4": this._oComponent.getModel("OwnData").getProperty("/Geo4"),
							// "Geo4Desc": this._oComponent.getModel("OwnData").getProperty("/Geo4Desc"),
							// "Geo5": this._oComponent.getModel("OwnData").getProperty("/Geo5"),
							// "Geo5Desc": this._oComponent.getModel("OwnData").getProperty("/Geo5Desc"),
							// "Geo6": this._oComponent.getModel("OwnData").getProperty("/Geo6"),
							// "Geo6Desc": this._oComponent.getModel("OwnData").getProperty("/Geo6Desc"),
							// "Geo7": this._oComponent.getModel("OwnData").getProperty("/Geo7"),
							// "Geo7Desc": this._oComponent.getModel("OwnData").getProperty("/Geo7Desc"),
							// "Geo8": this._oComponent.getModel("OwnData").getProperty("/Geo8"),
							// "Geo8Desc": this._oComponent.getModel("OwnData").getProperty("/Geo8Desc"),
							// "Geo9": this._oComponent.getModel("OwnData").getProperty("/Geo9"),
							// "Geo9Desc": this._oComponent.getModel("OwnData").getProperty("/Geo9Desc"),
							// "Geo10": this._oComponent.getModel("OwnData").getProperty("/Geo10"),
							// "Geo10Desc": this._oComponent.getModel("OwnData").getProperty("/Geo10Desc"),
							"CPDMSDivisionTaxes": [],
							"ItemNo": this.setItemNo()

						};

						if (!this.getView().getModel("CPDMSDivisions")) {
							var oCPDMSDivisionTaxesModel = new sap.ui.model.json.JSONModel();
							oCPDMSDivisionTaxesModel.setData(newItem);
							this._oComponent.setModel(oCPDMSDivisionTaxesModel, "CPDMSDivisions");
						} else {
							CPDMSDivisions.push(newItem);
						}
						this._oComponent.getModel("CPDMSDivisions").setProperty("/", CPDMSDivisions);

					}
					tData = this._oComponent.getModel("CPDMSDivisions").getData();
					for (var index1 = 0; index1 < tempData.length; index1++) {
						tData[index1].DMSDivision = tempData[index1].Key;
						tData[index1].DMSDivisionDesc = tempData[index1].Text;

						delete tData[index1].ItemNo;
					}

					var ChannelPartnersModel = this.getView().getModel("ChannelPartners");
					ChannelPartnersModel.setProperty("/CPDMSDivisions", tData);

					// ChannelPartnersModel.CPDMSDivisions = tempData;

					// for (var i = 0; i < tData.length; i++) {
					// 	delete tData[i].ItemNo;
					// }
				} else {
					for (var i = 0; i < tData.length; i++) {
						delete tData[i].ItemNo;
					}

				}

				var ChannelPartnersModel = this.getView().getModel("ChannelPartners");
				// tData = this.formatDivisionModel(tData, ChannelPartnersModel.getData());
				// if (ChannelPartnersModel.getProperty("/CPTypeID") === "" || ChannelPartnersModel.getProperty("/CPTypeID") === "10" ||
				// 	ChannelPartnersModel.getProperty("/CPTypeID") === "20") {
				tData = this.setCommonDivision(tData);
				// }

				ChannelPartnersModel.setProperty("/CPDMSDivisions", tData);
				if (InfraDetails) {
					ChannelPartnersModel.setProperty("/CPInfras", InfraDetails);
				}

				// var tData = this.getView().getModel("CPDMSDivisions").getData();
				// for (var i = 0; i < tData.length; i++) {
				// 	delete tData[i].ItemNo;
				// }
				// var ChannelPartnersModel = this.getView().getModel("ChannelPartners");

				ChannelPartnersModel.setProperty("/DOB", oPPCCommon.addHoursAndMinutesToDate({
					dDate: ChannelPartnersModel.getProperty("/DOB")
				}));

				ChannelPartnersModel.setProperty("/ActivationDate", oPPCCommon.addHoursAndMinutesToDate({
					dDate: ChannelPartnersModel.getProperty("/ActivationDate")
				}));
				ChannelPartnersModel.setProperty("/Anniversary", oPPCCommon.addHoursAndMinutesToDate({
					dDate: ChannelPartnersModel.getProperty("/Anniversary")
				}));

				// ChannelPartnersModel.setProperty("/SalesOfficeID", this.getDDKey("fSalesOfficeIDEdit", view));
				/*ChannelPartnersModel.setProperty("/Group1Desc", that.getDDKey("Group1", view));
				ChannelPartnersModel.setProperty("/Group2Desc", that.getDDKey("Group2", view));
				ChannelPartnersModel.setProperty("/Group3Desc", that.getDDKey("Group3", view));
				ChannelPartnersModel.setProperty("/Group4Desc", that.getDDKey("Group4", view));*/

				/*if(gBasicDataBlock.byId("fIsKeyCP").getState()) {
					ChannelPartnersModel.setProperty("/IsKeyCP", "X");
				}else {
					ChannelPartnersModel.setProperty("/IsKeyCP", "");
				}*/
				// ChannelPartnersModel.setProperty("/TaxClassificationDesc", this.getDDDescrption("fTaxClassificationDDEdit", view));
				if (ChannelPartnersModel.getProperty("/Longitude") === "" || ChannelPartnersModel.getProperty("/Longitude") === undefined) {
					ChannelPartnersModel.setProperty("/Longitude", null);
				}
				if (ChannelPartnersModel.getProperty("/Latitude") === "" || ChannelPartnersModel.getProperty("/Latitude") === undefined) {
					ChannelPartnersModel.setProperty("/Latitude", null);
				}
				ChannelPartnersModel.setProperty("/TaxRegStatusDesc", this.getDDDescrption("fTaxRegStatusEdit", view));
				// ChannelPartnersModel.setProperty("/TaxCategoryDesc", this.getDDDescrption("fTaxCategoryEdit", view));
				ChannelPartnersModel.setProperty("/SalesOffDesc", this.getDDDescrption("fSalesOfficeIDEdit", view));
				ChannelPartnersModel.setProperty("/CPTypeDesc", this.getDDDescrption("fCPTypeEdit", view));
				ChannelPartnersModel.setProperty("/SalesGrpDesc", this.getDDDescrption("fSalesGroupIDEdit", view));
				ChannelPartnersModel.setProperty("/WeeklyOffDesc", this.getDDDescrption("fWeeklyOffEdit", view));
				ChannelPartnersModel.setProperty("/TownID", this.getTokenKey("fTownIDEdit", view));
				ChannelPartnersModel.setProperty("/TownDesc", this.getTokenDesc("fTownIDEdit", view));
				ChannelPartnersModel.setProperty("/DistrictID", this.getTokenKey("fDistrictIDEdit", view));
				ChannelPartnersModel.setProperty("/DistrictDesc", this.getTokenDesc("fDistrictIDEdit", view));
				ChannelPartnersModel.setProperty("/CityID", this.getTokenKey("fCityIDEdit", view));
				ChannelPartnersModel.setProperty("/CityDesc", this.getTokenDesc("fCityIDEdit", view));
				ChannelPartnersModel.setProperty("/StateID", this.getTokenKey("fStateIDEdit", view));
				ChannelPartnersModel.setProperty("/StateDesc", this.getTokenDesc("fStateIDEdit", view));
				ChannelPartnersModel.setProperty("/Country", this.getTokenKey("fCountryEdit", view));
				ChannelPartnersModel.setProperty("/CountryName", this.getTokenDesc("fCountryEdit", view));
				ChannelPartnersModel.setProperty("/RouteID", gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/oRouteId"));
				ChannelPartnersModel.setProperty("/RouteDesc", gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/oRouteDesc"));
				// ChannelPartnersModel.setProperty("/RouteID", this.getTokenKey("fRouteIDEdit", view));
				// ChannelPartnersModel.setProperty("/RouteDesc", this.getTokenDesc("fRouteIDEdit", view));
				/*ChannelPartnersModel.setProperty("/WeeklyOff", this.getTokenKey("fWeeklyOffEdit", view));
				ChannelPartnersModel.setProperty("/WeeklyOffDesc", this.getTokenDesc("fWeeklyOffEdit", view));*/

				ChannelPartnersModel.setProperty("/ZoneID", this.getTokenKey("fZoneIDEdit", view));
				ChannelPartnersModel.setProperty("/ZoneDesc", this.getTokenDesc("fZoneIDEdit", view));
				// ChannelPartnersModel.setProperty("/PartnerMgrNo", this.getTokenKey("fPartnerMgrNoEdit", view));
				// ChannelPartnersModel.setProperty("/PartnerMgrName", that.getTokenDesc("fPartnerMgrNoEdit", view));

				//var ManagerGUID =ChannelPartnersModel.getProperty("/PartnerMgrGUID");

				// ChannelPartnersModel.setProperty("/PartnerMgrGUID", gPartnerMgrGUID);
				// if (gBasicDataBlock && gBasicDataBlock.byId("fIsKeyCP").getState()) {
				// 	this.getView().getModel("ChannelPartners").setProperty("/IsKeyCP", "X");
				// } else {
				// 	this.getView().getModel("ChannelPartners").setProperty("/IsKeyCP", "");
				// }
				ChannelPartnersModel.setProperty("/TestRun", "X");
				this.create(function (msgFrom) {

					/*var oItemDetailModel = that.getView().getModel("ChannelPartners");
					var oItemDetailData = oItemDetailModel.getData();
					oItemDetailData = that._oChannelPartnersData;
					oItemDetailModel.setData(oItemDetailData);*/

					/*for (var j = 0; j < that.CPDMSDivisions.length; j++) {
						if (that.aTempArray[j]) {
							that.CPDMSDivisions[j].bIsNew = that.aTempArray[j].bIsNew;
						}
					}*/

					if (msgFrom === "success") {

						// ChannelPartnersModel.setProperty("/Group1Desc", that.getDDDescrption("Group1", view));
						// ChannelPartnersModel.setProperty("/Group2Desc", that.getDDDescrption("Group2", view));
						// ChannelPartnersModel.setProperty("/Group3Desc", that.getDDDescrption("Group3", view));
						// ChannelPartnersModel.setProperty("/Group4Desc", that.getDDDescrption("Group4", view));
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/editMode", false);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", false);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/reviewMode", true);
					} else if (msgFrom === "error") {
						oPPCCommon.removeDuplicateMsgsInMsgMgr();
						// oPPCCommon.removeServerMsgsInMsgMgrByTarget(target);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						if (that.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") > 0) {
							oPPCCommon.showMessagePopover(that.DynamicSideContent);
						}

					}
				});
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.DynamicSideContent);
			}

			if (this.onReview_Exit) {
				this.onReview_Exit();
			}
		},
		setCommonDivision: function (tData) {
			if (gCPDetailClassGroups.getModel("CPGroupTemp")) {
				var commonDiv = gCPDetailClassGroups.getModel("CPGroupTemp").getData();
				var oJson = this.getObjectForCommonDiv(commonDiv);
				tData.push(oJson);
			}
			return tData;

		},
		getObjectForCommonDiv: function (commonDiv) {
			var that = this;
			var daySchedule = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			var newItem = {
				"CPGUID": that._oComponent.getModel("ChannelPartners").getProperty("/CPGUID").toUpperCase(),
				"CP1GUID": oPPCCommon.generateUUID().toUpperCase(),
				"LoginID": "",
				"CPNo": "",
				"Name": "",
				"DMSDivision": "COMMON",
				"DMSDivisionDesc": "COMMON",
				"DistanceFromParent": commonDiv.DistanceFromParent,
				"DstnceFromPUOM": commonDiv.DstnceFromPUOM,
				"BillSeries": commonDiv.BillSeries,
				"Currency": that._oComponent.getModel("ChannelPartners").getProperty("/Currency"),
				"RouteID": "",
				"RouteDesc": "",
				"CPUID": "",
				"OwnerName": "",
				"MobileNo": "",
				"Day1": this.setDay(daySchedule[0].MonSelected),
				"Day2": this.setDay(daySchedule[0].TueSelected),
				"Day3": this.setDay(daySchedule[0].WedSelected),
				"Day4": this.setDay(daySchedule[0].ThurSelected),
				"Day5": this.setDay(daySchedule[0].FriSelected),
				"Day6": this.setDay(daySchedule[0].SatSelected),
				"Day7": this.setDay(daySchedule[0].SunSelected),
				"Group1": commonDiv.Group1,
				"Group1Desc": commonDiv.Group1Desc,
				"Group2": commonDiv.Group2,
				"ParentTypeID": that._oComponent.getModel("LocalViewSettingDtl").getProperty("/CPTypeIDMandat"),
				"ParentID": that._oComponent.getModel("ChannelPartners").getProperty("/ParentID"),
				"ParentName": that._oComponent.getModel("LocalViewSettingDtl").getProperty("/Name"),
				"Group2Desc": commonDiv.Group2Desc,
				"Group3": commonDiv.Group3,
				"Group3Desc": commonDiv.Group3Desc,
				"Group4": commonDiv.Group4,
				"Group4Desc": commonDiv.Group4Desc,
				"Group5": commonDiv.Group5,
				"Group5Desc": commonDiv.Group5Desc,
				"Group6": commonDiv.Group6,
				"Group6Desc": commonDiv.Group6Desc,
				"Group7": commonDiv.Group7,
				"Group7Desc": commonDiv.Group7Desc,
				"Group8": commonDiv.Group8,
				"Group8Desc": commonDiv.Group8Desc,
				"Group9": commonDiv.Group9,
				"Group9Desc": commonDiv.Group9Desc,
				"Group10": commonDiv.Group10,
				"Group10Desc": commonDiv.Group10Desc,
				"PartnerMgrGUID": null,
				"PartnerMgrNo": "",
				"PartnerMgrName": "",
				"DiscountPer": null,
				"StatusID": "01",
				"ApprvlStatusID": "",
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT00H00M00S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				// "Geo1": this._oComponent.getModel("OwnData").getProperty("/Geo1"),
				// "Geo1Desc": this._oComponent.getModel("OwnData").getProperty("/Geo1Desc"),
				// "Geo2": this._oComponent.getModel("OwnData").getProperty("/Geo2"),
				// "Geo2Desc": this._oComponent.getModel("OwnData").getProperty("/Geo2Desc"),
				// "Geo3": this._oComponent.getModel("OwnData").getProperty("/Geo3"),
				// "Geo3Desc": this._oComponent.getModel("OwnData").getProperty("/Geo3Desc"),
				// "Geo4": this._oComponent.getModel("OwnData").getProperty("/Geo4"),
				// "Geo4Desc": this._oComponent.getModel("OwnData").getProperty("/Geo4Desc"),
				// "Geo5": this._oComponent.getModel("OwnData").getProperty("/Geo5"),
				// "Geo5Desc": this._oComponent.getModel("OwnData").getProperty("/Geo5Desc"),
				// "Geo6": this._oComponent.getModel("OwnData").getProperty("/Geo6"),
				// "Geo6Desc": this._oComponent.getModel("OwnData").getProperty("/Geo6Desc"),
				// "Geo7": this._oComponent.getModel("OwnData").getProperty("/Geo7"),
				// "Geo7Desc": this._oComponent.getModel("OwnData").getProperty("/Geo7Desc"),
				// "Geo8": this._oComponent.getModel("OwnData").getProperty("/Geo8"),
				// "Geo8Desc": this._oComponent.getModel("OwnData").getProperty("/Geo8Desc"),
				// "Geo9": this._oComponent.getModel("OwnData").getProperty("/Geo9"),
				// "Geo9Desc": this._oComponent.getModel("OwnData").getProperty("/Geo9Desc"),
				// "Geo10": this._oComponent.getModel("OwnData").getProperty("/Geo10"),
				// "Geo10Desc": this._oComponent.getModel("OwnData").getProperty("/Geo10Desc"),
				"FreqOfDispatch": commonDiv.FreqOfDispatch,
				"CPDMSDivisionTaxes": []

			};
			return newItem;
		},
		setDay: function (day) {
			if (day) {
				return "X";
			} else {
				return "";
			}

		},
		validateDuplicatePFs: function () {
			var CPAlternateBillings = this.getView().getModel("CPAlternateBillings").getData();
			var duplcatedDMSDivisions = [];
			var formattedArray = this.getUniqueArray(CPAlternateBillings);
			var seen = 0;
			var index;
			for (var i = 0; i < formattedArray.length; i++) {
				seen = 0;
				for (var j = 0; j < CPAlternateBillings.length; j++) {
					if ((CPAlternateBillings[i].PartnerCPNo === CPAlternateBillings[j].PartnerCPNo) &&
						(CPAlternateBillings[i].PartnerFunction === CPAlternateBillings[j].PartnerFunction)) {
						seen++;
						index = i;
					}
				}
				if (seen > 1) {
					var msg = "Retailer with partner function Duplicated Please Remove";
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/PFssDuplicated" + i + "/", msg);
				}

			}
		},
		getUniqueArray: function (CPAlternateBillings) {
			var aTemArray = [];
			var seen;
			for (var i = 0; i < CPAlternateBillings.length; i++) {
				seen = false;
				if (aTemArray.length === 0) {
					aTemArray.push(CPAlternateBillings[i]);
				} else {

					for (var j = 0; j < aTemArray.length; j++) {
						if ((CPAlternateBillings[i].PartnerCPNo === aTemArray[j].PartnerCPNo) &&
							(CPAlternateBillings[i].PartnerFunction === aTemArray[j].PartnerFunction)) {
							seen = true;
							break;
						}
					}
					if (!seen) {
						aTemArray.push(CPAlternateBillings[i]);
					}

				}

			}

			return aTemArray;
		},
		validateInfra: function (InfraDetails) {
			for (var i = 0; i < InfraDetails.length; i++) {
				if (InfraDetails[i].InfraQty === "") {
					oPPCCommon.addMsg_MsgMgr(oi18n.getText("infra.validation.quantity", InfraDetails[i].InfraCode), "error");
				}
			}
		},
		formatInfraDetails: function (infraDetails, ChannelPartnersModel) {
			var that = this;
			infraDetails.forEach(function (eachElement) {
				if (eachElement.InfraUOM === "") {
					eachElement.InfraUOM = gCPInfraView.getModel("InfraUOMDD").getData()[0].Key;
				}
				eachElement.CPGUID = ChannelPartnersModel.CPGUID.toUpperCase();
				eachElement.CP2GUID = eachElement.CP2GUID.toUpperCase();
			});
			return infraDetails;
		},
		formatDivisionModel: function (tData, ChannelPartnersModel) {
			tData.forEach(function (eachElement) {
				eachElement.BillSeries = ChannelPartnersModel.BillSeries;
				eachElement.FreqOfDispatch = ChannelPartnersModel.FreqOfDispatch;
				eachElement.Dow = ChannelPartnersModel.Dow;
			});
			return tData;
		},
		setItemNo: function () {

			if (this.getView().getModel("CPDMSDivisions")) {
				var ItemData = this.getView().getModel("CPDMSDivisions").getProperty("/");
				if (ItemData.length > 0) {
					for (var i = 0; i < ItemData.length; i++) {
						var ItemNo = ItemData[i].ItemNo + 10;

					}
					return ItemNo;
				} else {
					return 10;
				}
			} else {
				return 10;
			}

		},
		validateForm: function (view) {
			this.clearAllErrors();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			var ChannelPartnersModel = this.getView().getModel("ChannelPartners");
			var oCommonDivision = gCPDetailClassGroups.getModel("CPGroupTemp");
			var control = "",
				isCorrect = false;

			if (ChannelPartnersModel.getProperty("/CPTypeID") === "" || ChannelPartnersModel.getProperty("/CPTypeID") === undefined ||
				ChannelPartnersModel.getProperty("/CPTypeID").trim() === "") {
				this.addErrorMessages(view, "fCPTypeEdit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
					"_views")[0].byId("lCPTypeEdit").getText()));
			}
			if (ChannelPartnersModel.getProperty("/Name") === "" || ChannelPartnersModel.getProperty("/Name") === undefined ||
				ChannelPartnersModel.getProperty("/Name").trim() === "") {
				this.addErrorMessages(view, "fNameEdit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
					"_views")[0].byId("lNameEdit").getText()));
			}
			if (ChannelPartnersModel.getProperty("/OwnerName") === "" || ChannelPartnersModel.getProperty("/OwnerName") === undefined ||
				ChannelPartnersModel.getProperty("/OwnerName").trim() === "") {
				this.addErrorMessages(view, "fOwnerNameEdit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
					"_views")[0].byId("lOwnerNameEdit").getText()));
			}
			if (ChannelPartnersModel.getProperty("/Address1") === "" || ChannelPartnersModel.getProperty("/Address1") === undefined ||
				ChannelPartnersModel.getProperty("/Address1").trim() === "") {
				this.addErrorMessages(view, "fAddress1Edit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
					"_views")[0].byId("lAddress1Edit").getText()));
			}
			if (ChannelPartnersModel.getProperty("/CPTypeID") === "01") {
				if (ChannelPartnersModel.getProperty("/CPUID") === "" || ChannelPartnersModel.getProperty("/CPUID") === undefined ||
					ChannelPartnersModel.getProperty("/CPUID").trim() === "") {
					this.addErrorMessages(view, "fCPUID", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("CPUID").getText()));
				}
			}
			// if (ChannelPartnersModel.getProperty("/Landmark") === "" || ChannelPartnersModel.getProperty("/Landmark") === undefined ||
			// 	ChannelPartnersModel.getProperty("/Landmark").trim() === "") {

			// 	this.addErrorMessages(view, "fLandmarkEdit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
			// 		"_views")[0].byId("lLandmarkEdit").getText()));
			// }
			/*if (gBasicDataBlock.byId("fDistrictIDEdit")) {
				if (gBasicDataBlock.byId("fDistrictIDEdit").getTokens().length === 0) {
					this.addErrorMessages(view, "fDistrictIDEdit", oi18n.getText("common.message.pleaseEnterValid", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lDistrictIDEdit").getText()));
				}
			}
			if (gBasicDataBlock.byId("fCityIDEdit")) {
				if (gBasicDataBlock.byId("fCityIDEdit").getTokens().length === 0) {
					this.addErrorMessages(view, "fCityIDEdit", oi18n.getText("common.message.pleaseEnterValid", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lCityIDEdit").getText()));
				}
			}
			if (gBasicDataBlock.byId("fTownIDEdit")) {
				if (gBasicDataBlock.byId("fTownIDEdit").getTokens().length === 0) {
					this.addErrorMessages(view, "fTownIDEdit", oi18n.getText("common.message.pleaseEnterValid", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lTownIDEdit").getText()));
				}
			}*/

			var ActivativationDate = ChannelPartnersModel.getProperty("/ActivationDate");

			// if (ActivativationDate === "" || ActivativationDate === undefined ||
			// 	ActivativationDate === "") {
			// 	// this.addErrorMessages(view, "fAddress1Edit", oi18n.getText("common.message.pleaseEnter", gSalesDataBlock.byId("lActivationDateEdit").getText()));
			// 	var msg = oi18n.getText("common.message.pleaseEnter", gSalesDataBlock.byId("lActivationDateEdit").getText());
			// 	oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/InstrumentDateId");
			// }

			// if (!oPPCCommon.isPastDate(ActivativationDate)) {
			// 	// var msg = oi18n.getText("common.message.pastDate", view.byId("ActivationDate").getText());
			// 	var msg = oi18n.getText("Activation Date can not be past date");
			// 	oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/InstrumentDateId");
			// }

			if (ChannelPartnersModel.getProperty("/PostalCode") === "" || ChannelPartnersModel.getProperty("/PostalCode") === undefined ||
				ChannelPartnersModel.getProperty("/PostalCode").trim() === "") {
				this.addErrorMessages(view, "fPostalCodeEdit", oi18n.getText("commmon.valid.input", view.byId("BasicDataBlock").getAggregation(
					"_views")[0].byId("lPostalCodeEdit").getText()));
			}
			if (gBasicDataBlock.byId("fStateIDEdit")) {
				if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

					this.addErrorMessages(view, "fStateIDEdit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lStateIDEdit").getText()));
				}
			}
			if (gBasicDataBlock.byId("fCountryEdit")) {
				if (gBasicDataBlock.byId("fCountryEdit").getTokens().length === 0) {

					this.addErrorMessages(view, "fCountryEdit", oi18n.getText("common.message.pleaseEnter", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lCountryEdit").getText()));
				}
			}

			if (ChannelPartnersModel.getProperty("/PostalCode") !== "" && ChannelPartnersModel.getProperty("/PostalCode") !== undefined &&
				ChannelPartnersModel.getProperty("/PostalCode").trim() !== "") {
				control = gBasicDataBlock.byId("fPostalCodeEdit");
				isCorrect = oPPCCommon.isValidPostalCode(control.getValue());
				if (!isCorrect) {
					this.addErrorMessages(view, "fPostalCodeEdit", oi18n.getText("commmon.valid.input", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lPostalCodeEdit").getText()));
				}

			}
			if (gBasicDataBlock.byId("fMobile1Edit")) {
				control = gBasicDataBlock.byId("fMobile1Edit");
				var isValidMobile = oPPCCommon.isValidPhone(control.getValue());
				if (!isValidMobile || control.getValue() === "") {
					this.addErrorMessages(view, "fMobile1Edit", oi18n.getText("commmon.valid.input", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lMobile1Edit").getText()));
				}
			}

			if (ChannelPartnersModel.getProperty("/DOB") !== "" && ChannelPartnersModel.getProperty("/DOB") !== null) {
				if (oPPCCommon.isFutureDate(ChannelPartnersModel.getProperty("/DOB"))) {
					this.addErrorMessages(view, "fDOBEdit", oi18n.getText("common.message.canNotBeFutureDate", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lDOBEdit").getText()));
				}
			}
			if (ChannelPartnersModel.getProperty("/GSTActiveDate") !== "" && ChannelPartnersModel.getProperty("/GSTActiveDate") !== null) {
				if (oPPCCommon.isFutureDate(ChannelPartnersModel.getProperty("/GSTActiveDate"))) {
					this.addErrorMessages(view, "fActivationDateEdit", oi18n.getText("common.message.canNotBeFutureDate", gSalesDataBlock.byId(
						"ActivationDate").getLabel().getText()));
				}
			}
			if (ChannelPartnersModel.getProperty("/ActivationDate") !== "" && ChannelPartnersModel.getProperty("/ActivationDate") !== null) {
				if (oPPCCommon.isFutureDate(ChannelPartnersModel.getProperty("/ActivationDate"))) {
					this.addErrorMessages(view, "fActiveDateEdit", oi18n.getText("common.message.canNotBeFutureDate", gBasicDataBlock.byId(
						"lActiveDateIDEdit").getText()));
				}
			}

			if (!ChannelPartnersModel.getProperty("/Anniversary")) {

				if (oPPCCommon.isFutureDate(ChannelPartnersModel.getProperty("/Anniversary"))) {
					this.addErrorMessages(view, "fAnniversaryEdit", oi18n.getText("common.message.canNotBeFutureDate", view.byId("BasicDataBlock").getAggregation(
						"_views")[0].byId("lAnniversaryEdit").getText()));
				}
			}
			if (ChannelPartnersModel.getProperty("/DOB") && ChannelPartnersModel.getProperty("/Anniversary")) {

				var bdayDate = ChannelPartnersModel.getProperty("/DOB");

				var annualDate = ChannelPartnersModel.getProperty("/Anniversary");

				if (oPPCCommon.isToDateLessthanFromDate(bdayDate, annualDate)) {

					this.addErrorMessages(view, "fAnniversaryEdit", oi18n.getText("common.message.anniversairydateless", view.byId("BasicDataBlock")
						.getAggregation(
							"_views")[0].byId("lAnniversaryEdit").getText()));
				}

			}

			if (ChannelPartnersModel.getProperty("/EmailID") !== "" && ChannelPartnersModel.getProperty("/EmailID") !== undefined &&
				ChannelPartnersModel.getProperty("/EmailID").trim() !== "") {
				if (!oPPCCommon.isValidEmail(ChannelPartnersModel.getProperty("/EmailID"))) {
					this.addErrorMessages(view, "fEmailIDEdit", oi18n.getText("commmon.valid.input", "Email ID"));
				}
			}

			// if (ChannelPartnersModel.getProperty("/SalesOfficeID") === "" || ChannelPartnersModel.getProperty("/SalesOfficeID") === undefined ||
			// 	ChannelPartnersModel.getProperty("/SalesOfficeID").trim() === "") {
			// 	this.addErrorMessages(view, "fSalesOfficeIDEdit", oi18n.getText("common.message.pleaseEnter", gSalesDataBlock.byId(
			// 		"lSalesOfficeID").getText()));
			// }

			// if (ChannelPartnersModel.getProperty("/SalesGroupID") === "" || ChannelPartnersModel.getProperty("/SalesGroupID") === undefined ||
			// 	ChannelPartnersModel.getProperty("/SalesGroupID").trim() === "") {
			// 	this.addErrorMessages(view, "fSalesGroupIDEdit", oi18n.getText("common.message.pleaseEnter", gSalesDataBlock.byId("lSalesGroupID")
			// 		.getText()));
			// }

			/*if (gSalesDataBlock.byId("fPartnerMgrNoEdit").getTokens().length === 0) {
				this.addErrorMessages(gSalesDataBlock, "fPartnerMgrNoEdit", oi18n.getText("common.message.pleaseEnterValid", gSalesDataBlock.byId(
					"lPartnerMgrNo").getText()));
			}*/

			/*var creditlimit = gSalesDataBlock.byId("fCreditLimitEdit").getValue();
				if(creditlimit === undefined || creditlimit === null || creditlimit === "" || creditlimit.trim() === "") {
					ChannelPartnersModel.setProperty("/CreditLimit", "0.00");
				} else if (parseFloat(creditlimit) < 0) {
					this.addErrorMessages(gSalesDataBlock, "fCreditLimitEdit", oi18n.getText("common.message.pleaseEnterPositive", gSalesDataBlock.byId(
						"lCreditLimit").getText()));
				}
				
				var CreditDays = gSalesDataBlock.byId("fCreditDaysEdit").getValue();
				if(CreditDays === undefined || CreditDays === null) {
					ChannelPartnersModel.setProperty("/CreditDays", 0);
				} else if (CreditDays < 0) {
					this.addErrorMessages(gSalesDataBlock, "fCreditDaysEdit", oi18n.getText("common.message.pleaseEnterPositive", gSalesDataBlock.byId(
						"lCreditDays").getText()));
				}
				
				var CreditBills = ChannelPartnersModel.getProperty("/CreditBills");
				if(CreditBills === undefined || CreditBills === null) {
					ChannelPartnersModel.setProperty("/CreditBills", 0);
				} else if (CreditBills < 0) {
					this.addErrorMessages(gSalesDataBlock, "fCreditBillsEdit", oi18n.getText("common.message.pleaseEnterPositive", gSalesDataBlock.byId(
						"lCreditBills").getText()));
				}
			}*/

			if (this.validateForm_Exit) {
				this.validateForm_Exit();
			}

		},

		validateItem: function (view) {
			if (view.getModel("CPDMSDivisions").getData().length <= 0) {
				oPPCCommon.addMsg_MsgMgr("Please add Atleast one DMS Division", "error", "/UI/CPDMSDivisionsCount",
					"Please add Atleast one DMS Division");
			} else {
				//this.getValueFromCPDMSDivisionsTokens();
				this.validateCPDMSDivisions(view);
				this.validateDuplicateDMSDivisions();
				// this.validateCPDMSDivisionTaxes();
			}
			// if (view.getModel("CPAlternateBillings").getData().length <= 0) {
			// 	oPPCCommon.addMsg_MsgMgr("Please add Atleast one Partner Functions", "error", "/UI/CPAlternateBillingsCount",
			// 		"Please add Atleast one Partner Functions");
			// } else {
			// 	this.getValueFromCPAlternateBillingsTokens();
			// 	this.validateCPAlternateBillings(view);
			// }
			this.getValueFromCPAlternateBillingsTokens();
			this.validateCPAlternateBillings(view);
			this.validateChannelClassification();
			if (this.validateItem_Exit) {
				this.validateItem_Exit();
			}
		},
		validateChannelClassification: function () {

			if (gCPDetailClassGroups.getModel("CPGroupTemp")) {
				var channelClass = gCPDetailClassGroups.getModel("CPGroupTemp").getData();
				if (!channelClass.Group1) {

					this.addErrorMessages(gCPDetailClassGroups, "idSelectGroup1", oi18n.getText("cpcreate.please.select", gCPDetailClassGroups.byId(
						"idLabelGroup1").getText()));
				}
				if (!channelClass.Group2) {

					this.addErrorMessages(gCPDetailClassGroups, "idSelectGroup2", oi18n.getText("cpcreate.please.select", gCPDetailClassGroups.byId(
						"idLabelGroup2").getText()));
				}
				if (channelClass.FreqOfDispatch) {
					this.validateDelSchecdules(channelClass.FreqOfDispatch);
					gCPDetailClassGroups.byId("idFreqOfDispatchDD").setValueState(null);
					gCPDetailClassGroups.byId("idFreqOfDispatchDD").setValueStateText("");
				} else {

					var msg = oi18n.getText("cpcreate.please.select", gCPDetailClassGroups.byId("lidFreqOfDispatch").getText());
					oPPCCommon.addMsg_MsgMgr(msg, "error");
					gCPDetailClassGroups.byId("idFreqOfDispatchDD").setValueState("Error");
					gCPDetailClassGroups.byId("idFreqOfDispatchDD").setValueStateText(msg);
				}

			}

		},
		validateDelSchecdules: function (FreqOfDispatch) {
			var valid = false;
			var sCount = 0;
			var CPScheduleDetails = gCPDetailClassGroups.getModel("CPScheduleDetails").getData();
			if (CPScheduleDetails[0].MonSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].TueSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].WedSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].ThurSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].FriSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].SatSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (CPScheduleDetails[0].SunSelected) {
				valid = true;
				sCount = sCount + 1;
			}
			if (!valid) {
				var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", "Days");
				oPPCCommon.addMsg_MsgMgr(msg, "error");
				return valid;
			}
			if (parseInt(FreqOfDispatch) === 4) {
				if (sCount !== 1) {
					var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", "Days");
					oPPCCommon.addMsg_MsgMgr(msg, "error");
					return valid;
				}
			} else {
				if (parseInt(FreqOfDispatch) !== sCount) {
					var msg = oi18n.getText("List.Filterbar.MultiInput.CpNoError", "Days");
					oPPCCommon.addMsg_MsgMgr(msg, "error");
					return valid;
				}
			}

			// if (parseInt(FreqOfDispatch) !== sCount) {
			// 	if (FreqOfDispatch !== "000004") {
			// 		var msg = oi18n.getText("daySchedule.valid.days", parseInt(FreqOfDispatch));
			// 		oPPCCommon.addMsg_MsgMgr(msg, "error");
			// 	}
			// }
		},

		getValueFromCPDMSDivisionsTokens: function () {
			var oModel = this.getModel("CPDMSDivisions");
			if (sap.ui.Device.system.tablet || sap.ui.Device.system.phone) {
				var oTable = gDMSDivisions.byId("CLASSIFICATIONCHANNELSTABLEEditM")
				if (oTable) {
					var aRows = oTable.getItems();
					for (var row = 0; row < aRows.length; row++) {
						var aCells = aRows[row].getCells();
						for (var cell = 0; cell < aCells.length; cell++) {
							var cellId = aCells[cell].getId();
							if (cellId.indexOf("fDMSDivisionLayoutM") > -1) {
								//if (oModel.getProperty("/" + row + "/bIsNew")) {
								cellId = cellId.replace("fDMSDivisionLayoutM", "fDMSDivisionEditM");
								/*oModel.setProperty("/" + row + "/DMSDivision", this.getTokenKey(cellId, gDMSDivisions));
								oModel.setProperty("/" + row + "/DMSDivisionDesc", this.getTokenDesc(cellId, gDMSDivisions));*/
								//}
								oModel.setProperty("/" + row + "/DMSDivisionDesc", this.getDDDescrption(cellId, gDMSDivisions));
							}
							/*else if (cellId.indexOf("fRouteIDEditM") > -1) {
								oModel.setProperty("/" + row + "/RouteID", this.getTokenKey(cellId, gDMSDivisions));
								oModel.setProperty("/" + row + "/RouteDesc", this.getTokenDesc(cellId, gDMSDivisions));
							}*/
							else if (cellId.indexOf("fPartnerMgrNoEditM") > -1) {
								var desc = this.getDDDescrption(cellId, gDMSDivisions);
								if (desc && desc.trim() !== "" && desc.split("-")) {
									if (desc.split("-").length > 0) {
										oModel.setProperty("/" + row + "/PartnerMgrName", desc);
									} else {
										oModel.setProperty("/" + row + "/PartnerMgrName", this.getDDDescrption(cellId, gDMSDivisions));
									}
								} else {
									oModel.setProperty("/" + row + "/PartnerMgrName", desc);
								}
								var id = "";
								if (gDMSDivisions.byId(cellId).getSelectedKey() !== "") {
									if (gDMSDivisions.byId(cellId).getSelectedItem().getText().split("-").length >= 0) {
										id = gDMSDivisions.byId(cellId).getSelectedItem().getText().split("-")[0].trim();
									}
								}
								oModel.setProperty("/" + row + "/PartnerMgrNo", id);
							} else if (cellId.indexOf("fGroup1EditM") > -1) {
								oModel.setProperty("/" + row + "/Group1Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup2EditM") > -1) {
								oModel.setProperty("/" + row + "/Group2Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup3EditM") > -1) {
								oModel.setProperty("/" + row + "/Group3Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup4EditM") > -1) {
								oModel.setProperty("/" + row + "/Group4Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup5EditM") > -1) {
								oModel.setProperty("/" + row + "/Group5Desc", this.getDDDescrption(cellId, gDMSDivisions));
							}

						}
					}
				}
			} else {
				var oTable = gDMSDivisions.byId("CLASSIFICATIONCHANNELSTABLEEdit")
				if (oTable) {
					var aRows = oTable.getRows();
					for (var row = 0; row < aRows.length; row++) {
						var aCells = aRows[row].getCells();
						for (var cell = 0; cell < aCells.length; cell++) {
							var cellId = aCells[cell].getId();
							if (cellId.indexOf("fDMSDivisionLayout") > -1) {
								//if (oModel.getProperty("/" + row + "/bIsNew")) {
								cellId = cellId.replace("fDMSDivisionLayout", "fDMSDivisionEdit");
								/*oModel.setProperty("/" + row + "/DMSDivision", this.getTokenKey(cellId, gDMSDivisions));
								oModel.setProperty("/" + row + "/DMSDivisionDesc", this.getTokenDesc(cellId, gDMSDivisions));*/
								//}
								oModel.setProperty("/" + row + "/DMSDivisionDesc", this.getDDDescrption(cellId, gDMSDivisions));
							}
							/*else if (cellId.indexOf("fRouteIDEdit") > -1) {
								oModel.setProperty("/" + row + "/RouteID", this.getTokenKey(cellId, gDMSDivisions));
								oModel.setProperty("/" + row + "/RouteDesc", this.getTokenDesc(cellId, gDMSDivisions));
							}*/
							else if (cellId.indexOf("fPartnerMgrNoEdit") > -1) {
								var desc = this.getDDDescrption(cellId, gDMSDivisions);
								if (desc && desc.trim() !== "" && desc.split("-")) {
									if (desc.split("-").length > 0) {
										oModel.setProperty("/" + row + "/PartnerMgrName", desc);
									} else {
										oModel.setProperty("/" + row + "/PartnerMgrName", this.getDDDescrption(cellId, gDMSDivisions));
									}
								} else {
									oModel.setProperty("/" + row + "/PartnerMgrName", desc);
								}
								var id = "";
								if (gDMSDivisions.byId(cellId).getSelectedKey() !== "") {
									if (gDMSDivisions.byId(cellId).getSelectedItem().getText().split("-").length >= 0) {
										id = gDMSDivisions.byId(cellId).getSelectedItem().getText().split("-")[0].trim();
									}
								}
								oModel.setProperty("/" + row + "/PartnerMgrNo", id);
							} else if (cellId.indexOf("fGroup1Edit") > -1) {
								oModel.setProperty("/" + row + "/Group1Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup2Edit") > -1) {
								oModel.setProperty("/" + row + "/Group2Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup3Edit") > -1) {
								oModel.setProperty("/" + row + "/Group3Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup4Edit") > -1) {
								oModel.setProperty("/" + row + "/Group4Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fGroup5Edit") > -1) {
								oModel.setProperty("/" + row + "/Group5Desc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fTaxCategoryEdit") > -1) {
								oModel.setProperty("/" + row + "/TaxCategoryDesc", this.getDDDescrption(cellId, gDMSDivisions));
							} else if (cellId.indexOf("fTaxClassificationDDEdit") > -1) {
								oModel.setProperty("/" + row + "/TaxClassificationDesc", this.getDDDescrption(cellId, gDMSDivisions));
							}
						}
					}
				}
			}

			if (this.getValueFromCPDMSDivisionsTokens_Exit) {
				this.getValueFromCPDMSDivisionsTokens_Exit();
			}
		},
		getValueFromCPAlternateBillingsTokens: function () {
			var oModel = this.getModel("CPAlternateBillings");
			if (sap.ui.Device.system.tablet || sap.ui.Device.system.phone) {
				var oTable = gPartnerFunction.byId("UIALTERNATEBILLINGS_TABLEEditM")
				if (oTable) {
					var aRows = oTable.getRows();
					for (var row = 0; row < aRows.length; row++) {
						var aCells = aRows[row].getCells();
						for (var cell = 0; cell < aCells.length; cell++) {
							var cellId = aCells[cell].getId();
							if (cellId.indexOf("fPartnerFunctionEditM") > -1) {
								oModel.setProperty("/" + row + "/PartnerFunctionDesc", this.getDDDescrption(cellId, gPartnerFunction));
							}
						}
					}
				}
			} else {
				var oTable = gPartnerFunction.byId("UIALTERNATEBILLINGS_TABLEEdit")
				if (oTable) {
					var aRows = oTable.getRows();
					for (var row = 0; row < aRows.length; row++) {
						var aCells = aRows[row].getCells();
						for (var cell = 0; cell < aCells.length; cell++) {
							var cellId = aCells[cell].getId();
							if (cellId.indexOf("fPartnerFunctionEdit") > -1) {
								oModel.setProperty("/" + row + "/PartnerFunctionDesc", this.getDDDescrption(cellId, gPartnerFunction));
							}
						}
					}
				}
			}
			if (this.getValueFromCPAlternateBillingsTokens_Exit) {
				this.getValueFromCPAlternateBillingsTokens_Exit();
			}
		},

		validateCPDMSDivisions: function (view) {
			var oModelCPDMSDivisions = view.getModel("CPDMSDivisions");
			var oDataCPDMSDivisions = oModelCPDMSDivisions.getProperty("/");
			for (var i = 0; i < oDataCPDMSDivisions.length; i++) {
				if (!oDataCPDMSDivisions[i].DMSDivision) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/DMSDivisionValueState", "/" + i + "/DMSDivisionValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gDMSDivisions.byId("lDMSDivisionEdit").getText()),
						oModelCPDMSDivisions);
				}
				/*if (!oDataCPDMSDivisions[i].RouteID) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/RouteIDValueState", "/" + i + "/RouteIDValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gDMSDivisions.byId("lRouteIDEdit").getText()),
						oModelCPDMSDivisions);
				}*/
				/*	if (!oDataCPDMSDivisions[i].Group1) {
						this.addItemErrorMessages(gDMSDivisions,
							"/" + i + "/Group1ValueState", "/" + i + "/Group1ValueStateText",
							oi18n.getText("common.message.pleaseEnterValid",
								gDMSDivisions.byId("lGroup1Edit").getText()),
							oModelCPDMSDivisions);
					}
					if (!oDataCPDMSDivisions[i].Group2) {
						this.addItemErrorMessages(gDMSDivisions,
							"/" + i + "/Group2ValueState", "/" + i + "/Group2ValueStateText",
							oi18n.getText("common.message.pleaseEnterValid",
								gDMSDivisions.byId("lGroup2Edit").getText()),
							oModelCPDMSDivisions);
					}
					if (!oDataCPDMSDivisions[i].Group3) {
						this.addItemErrorMessages(gDMSDivisions,
							"/" + i + "/Group3ValueState", "/" + i + "/Group3ValueStateText",
							oi18n.getText("common.message.pleaseEnterValid",
								gDMSDivisions.byId("lGroup3Edit").getText()),
							oModelCPDMSDivisions);
					}
					if (!oDataCPDMSDivisions[i].Group4) {
						this.addItemErrorMessages(gDMSDivisions,
							"/" + i + "/Group4ValueState", "/" + i + "/Group4ValueStateText",
							oi18n.getText("common.message.pleaseEnterValid",
								gDMSDivisions.byId("lGroup4Edit").getText()),
							oModelCPDMSDivisions);
					}
					if (!oDataCPDMSDivisions[i].Group5) {
						this.addItemErrorMessages(gDMSDivisions,
							"/" + i + "/Group5ValueState", "/" + i + "/Group5ValueStateText",
							oi18n.getText("common.message.pleaseEnterValid",
								gDMSDivisions.byId("lGroup5Edit").getText()),
							oModelCPDMSDivisions);
					}*/

				var DiscountPer = oDataCPDMSDivisions[i].DiscountPer;
				var MaxDiscountPerce = this.getView().getModel("LocalViewSettingDtl").getProperty("/MaxDiscountPerce");
				if (DiscountPer && DiscountPer < 0) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/DiscountPerValueState", "/" + i + "/DiscountPerValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gDMSDivisions.byId("lDiscountPerEdit").getText()),
						oModelCPDMSDivisions);
				} else if (DiscountPer && DiscountPer > MaxDiscountPerce) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/DiscountPerValueState", "/" + i + "/DiscountPerValueStateText",
						gDMSDivisions.byId("lDiscountPerEdit").getText() +
						" Should not be greater than " + MaxDiscountPerce,
						oModelCPDMSDivisions);
				}
				if (!DiscountPer) {
					oModelCPDMSDivisions.setProperty("/" + i + "/DiscountPer", "0");
				}

				var creditlimit = oDataCPDMSDivisions[i].CreditLimit;
				if (!creditlimit || creditlimit === undefined || creditlimit === null) {
					oModelCPDMSDivisions.setProperty("/" + i + "/CreditLimit", "0.00");
				} else if (creditlimit && parseFloat(creditlimit) < 0) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/CreditLimitValueState", "/" + i + "/CreditLimitValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gDMSDivisions.byId("lCreditLimitEdit").getText()),
						oModelCPDMSDivisions);
				}

				var CreditDays = oDataCPDMSDivisions[i].CreditDays;
				if (!CreditDays || CreditDays === undefined || CreditDays === null) {
					oModelCPDMSDivisions.setProperty("/" + i + "/CreditDays", 0);
				} else if (CreditDays && CreditDays < 0) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/CreditDaysValueState", "/" + i + "/CreditDaysValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gDMSDivisions.byId("lCreditDaysEdit").getText()),
						oModelCPDMSDivisions);
				}

				var CreditBills = oDataCPDMSDivisions[i].CreditBills;
				if (!CreditBills || CreditBills === undefined || CreditBills === null) {
					oModelCPDMSDivisions.setProperty("/" + i + "/CreditBills", 0);
				} else if (CreditBills && CreditBills < 0) {
					this.addItemErrorMessages(gDMSDivisions,
						"/" + i + "/CreditBillsValueState", "/" + i + "/CreditBillsValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gDMSDivisions.byId("lCreditBillsEdit").getText()),
						oModelCPDMSDivisions);
				}

			}

			if (this.validateCPDMSDivisions_Exit) {
				this.validateCPDMSDivisions_Exit();
			}
		},
		validateCPDMSDivisionTaxes: function (oEvent) {
			var CPDMSDivisions = this.getView().getModel("CPDMSDivisions").getData();
			var duplcatedTaxCats = [];
			for (var i = 0; i < CPDMSDivisions.length; i++) {
				var compareDMSTax = CPDMSDivisions[i].CPDMSDivisionTaxes;
				var compDMS = CPDMSDivisions[i].DMSDivision;
				for (var j = i + 1; j < CPDMSDivisions.length; j++) {
					if (compDMS === CPDMSDivisions[j].DMSDivision) {
						if (compareDMSTax === CPDMSDivisions[j].TaxCategoryID) {
							var added = false;
							for (var g = 0; g < duplcatedTaxCats.length; g++) {
								if (CPDMSDivisions[j].TaxCategoryDesc === duplcatedTaxCats[g].TaxCategoryDesc) {
									added = true;
								}
							}
							if (!added) {
								duplcatedTaxCats.push(CPDMSDivisions[j]);
								var msg = oi18n.getText("common.message.DMSDivisionDuplicated", CPDMSDivisions[j].TaxCategoryDesc);
								oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/DMSDivisionsDuplicated" + i + "/", msg);
								this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData()
									.length);
							}
						}
					}

				}
			}
		},
		validateDuplicateDMSDivisions: function (oEvent) {
			var DMSDivisions = this.getView().getModel("CPDMSDivisions").getData();
			var duplcatedDMSDivisions = [];
			for (var i = 0; i < DMSDivisions.length; i++) {
				var compareDMS = DMSDivisions[i].DMSDivision;
				for (var j = i + 1; j < DMSDivisions.length; j++) {
					if (compareDMS === DMSDivisions[j].DMSDivision) {
						var added = false;
						for (var g = 0; g < duplcatedDMSDivisions.length; g++) {
							if (DMSDivisions[j].DMSDivisionDesc === duplcatedDMSDivisions[g].DMSDivisionDesc) {
								added = true;
							}
						}
						if (!added) {
							duplcatedDMSDivisions.push(DMSDivisions[j]);
							var msg = oi18n.getText("common.message.DMSDivisionDuplicated", DMSDivisions[j].DMSDivisionDesc);
							oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/DMSDivisionsDuplicated" + i + "/", msg);
							this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
								.getData()
								.length);
						}
					}
				}
			}
		},

		validateCPAlternateBillings: function (view) {
			var oModelCPAlternateBillings = view.getModel("CPAlternateBillings");
			var oDataCPAlternateBillings = oModelCPAlternateBillings.getProperty("/");
			for (var i = 0; i < oDataCPAlternateBillings.length; i++) {
				if (!oDataCPAlternateBillings[i].PartnerFunction) {
					this.addItemErrorMessages(gPartnerFunction,
						"/" + i + "/PartnerFunctionValueState", "/" + i + "/PartnerFunctionValueStateText",
						oi18n.getText("cpcreate.please.select",
							gPartnerFunction.byId("lPartnerFunctionEdit").getText()),
						oModelCPAlternateBillings);
				}
				/*if (!oDataCPAlternateBillings[i].PartnerCPNo) {
					this.addItemErrorMessages(gPartnerFunction,
						"/" + i + "/PartnerCPNoValueState", "/" + i + "/PartnerCPNoValueStateText",
						oi18n.getText("common.message.pleaseEnterValid",
							gPartnerFunction.byId("lPartnerCPNoEdit").getText()),
						oModelCPAlternateBillings);
				}*/
			}

			if (this.validateCPAlternateBillings_Exit) {
				this.validateCPAlternateBillings_Exit();
			}
		},
		//add error message to message manager and valuestate
		addErrorMessages: function (view, controlID, msg) {
			if (gBasicDataBlock.byId(controlID)) {
				view = gBasicDataBlock;
			} else if (gSalesDataBlock.byId(controlID)) {
				view = gSalesDataBlock;
			} else if (gHeaderBlock && gHeaderBlock.byId(controlID)) {
				view = gHeaderBlock;
			}
			if (view.byId(controlID)) {
				// if (!(view.byId(controlID) instanceof sap.m.Select)) {
				view.byId(controlID).setValueState("Error");
				view.byId(controlID).setValueStateText(msg);
				// }
			}

			oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/" + controlID, msg);

			if (this.addErrorMessages_Exit) {
				this.addErrorMessages_Exit();
			}
		},

		addItemErrorMessages: function (view, valueStateProperty, valueStateTextProperty, msg, oModel) {
			oModel.setProperty(valueStateProperty, "Error");
			oModel.setProperty(valueStateTextProperty, msg);
			oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/" + valueStateProperty, msg);

			if (this.addItemErrorMessages_Exit) {
				this.addItemErrorMessages_Exit();
			}
		},

		clearAllErrors: function () {
			this.clearValueState(["fNameEdit", "fOwnerNameEdit", "fAddress1Edit", "fLandmarkEdit", "fCityIDEdit", "fPostalCodeEdit",
				"fStateIDEdit",
				"fTownIDEdit", "fCountryEdit", "fDistrictIDEdit", "fCPTypeEdit",
				"fMobile1Edit", "fMobile2Edit",
				"fCityIDEdit", "fPartnerMgrNoEdit",
				"fTownIDEdit", "fLatitudeEdit", "fLongitudeEdit", "fLandlineEdit", "fEmailIDEdit",
				"fCreditLimitEdit", "fCreditDaysEdit", "fDOBEdit", "fAnniversaryEdit", "fInPAN", "idFreqOfDispatchDD", "idSelectGroup2",
				"idSelectGroup1",
			]);
			// "fPANEdit", "fTINEdit", "fVATNoEdit"

			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("/UI/") > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}

			var oDataCPDMSDivisions = gCPDetailView.getModel("CPDMSDivisions").getProperty("/");
			for (i = 0; i < oDataCPDMSDivisions.length; i++) {
				delete oDataCPDMSDivisions[i].DMSDivisionValueState;
				delete oDataCPDMSDivisions[i].DMSDivisionValueStateText;
				delete oDataCPDMSDivisions[i].RouteIDValueState;
				delete oDataCPDMSDivisions[i].RouteIDValueStateText;
				delete oDataCPDMSDivisions[i].Group1ValueState;
				delete oDataCPDMSDivisions[i].Group1ValueStateText;
				delete oDataCPDMSDivisions[i].Group2ValueState;
				delete oDataCPDMSDivisions[i].Group2ValueStateText;
				delete oDataCPDMSDivisions[i].Group3ValueState;
				delete oDataCPDMSDivisions[i].Group3ValueStateText;
				delete oDataCPDMSDivisions[i].Group4ValueState;
				delete oDataCPDMSDivisions[i].Group4ValueStateText;
				delete oDataCPDMSDivisions[i].Group5ValueState;
				delete oDataCPDMSDivisions[i].Group5ValueStateText;
				delete oDataCPDMSDivisions[i].DiscountPerValueState;
				delete oDataCPDMSDivisions[i].DiscountPerValueStateText;
				delete oDataCPDMSDivisions[i].CreditLimitValueState;
				delete oDataCPDMSDivisions[i].CreditLimitValueStateText;
				delete oDataCPDMSDivisions[i].CreditDaysValueState;
				delete oDataCPDMSDivisions[i].CreditDaysValueStateText;
				delete oDataCPDMSDivisions[i].CreditBillsValueState;
				delete oDataCPDMSDivisions[i].CreditBillsValueStateText;
			}

			var oDataCPAlternateBillings = gCPDetailView.getModel("CPAlternateBillings").getProperty("/");
			for (i = 0; i < oDataCPAlternateBillings.length; i++) {
				delete oDataCPAlternateBillings[i].PartnerFunctionValueState;
				delete oDataCPAlternateBillings[i].PartnerFunctionValueStateText;
				delete oDataCPAlternateBillings[i].PartnerCPNoValueState;
				delete oDataCPAlternateBillings[i].PartnerCPNoValueStateText;
			}
			oPPCCommon.removeAllMsgs();
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (!this.DynamicSideContent) {
				this.DynamicSideContent = gCPDetailView.byId("ObjectPageLayout");
			}
			oPPCCommon.hideMessagePopover(this.DynamicSideContent);

			if (this.clearAllErrors_Exit) {
				this.clearAllErrors_Exit();
			}
		},
		clearValueState: function (aFieldId) {
			for (var i = 0; i < aFieldId.length; i++) {
				if (gCPDetailView.byId(aFieldId[i])) {
					gCPDetailView.byId(aFieldId[i]).setValueState("None");
					gCPDetailView.byId(aFieldId[i]).setValueStateText("");
				} else if (gBasicDataBlock.byId(aFieldId[i])) {
					gBasicDataBlock.byId(aFieldId[i]).setValueState("None");
					gBasicDataBlock.byId(aFieldId[i]).setValueStateText("");
				} else if (gSalesDataBlock.byId(aFieldId[i])) {
					gSalesDataBlock.byId(aFieldId[i]).setValueState("None");
					gSalesDataBlock.byId(aFieldId[i]).setValueStateText("");
				} else if (gHeaderBlock && gHeaderBlock.byId(aFieldId[i])) {
					gHeaderBlock.byId(aFieldId[i]).setValueState("None");
					gHeaderBlock.byId(aFieldId[i]).setValueStateText("");
				} else if (gCPDetailClassGroups && gCPDetailClassGroups.byId(aFieldId[i])) {
					gCPDetailClassGroups.byId(aFieldId[i]).setValueState("None");
					gCPDetailClassGroups.byId(aFieldId[i]).setValueStateText("");
				}
			}

			if (this.clearValueState_Exit) {
				this.clearValueState_Exit();
			}
		},
		getDDKey: function (controlID, view) {
			var key = "";

			if (view.byId(controlID)) {
				var key = view.byId(controlID).getSelectedKey();
			} else if (gBasicDataBlock.byId(controlID)) {
				var key = gBasicDataBlock.byId(controlID).getSelectedKey();
			} else if (gSalesDataBlock.byId(controlID)) {
				var key = gSalesDataBlock.byId(controlID).getSelectedKey();
			} else if (gHeaderBlock && gHeaderBlock.byId(controlID)) {
				var key = gHeaderBlock.byId(controlID).getSelectedKey();
			}

			if (this.getDDKey_Exit) {
				key = this.getDDKey_Exit(controlID, view);
			}

			return key;
		},
		getDDDescrption: function (controlID, view) {
			var desc = "";
			if (view) {
				if (view.byId(controlID)) {
					view = view;
				} else if (gBasicDataBlock.byId(controlID)) {
					view = gBasicDataBlock;
				} else if (gSalesDataBlock.byId(controlID)) {
					view = gSalesDataBlock;
				} else if (gHeaderBlock && gHeaderBlock.byId(controlID)) {
					view = gHeaderBlock;
				}

				if (view.byId(controlID).getSelectedKey() !== "") {
					if (view.byId(controlID).getSelectedItem()) {
						if (view.byId(controlID).getSelectedItem().getText().split("-").length > 1) {
							desc = view.byId(controlID).getSelectedItem().getText().split("-")[1].trim();
						} else {
							desc = view.byId(controlID).getSelectedItem().getText().split("-")[0].trim();
						}
					}
				}

				if (this.getDDDescrption_Exit) {
					desc = this.getDDDescrption_Exit(controlID, view);
				}
			}
			return desc;
		},
		getTokenKey: function (controlID, view) {
			if (view.byId(controlID)) {
				view = view;
			} else if (gBasicDataBlock.byId(controlID)) {
				view = gBasicDataBlock;
			} else if (gSalesDataBlock.byId(controlID)) {
				view = gSalesDataBlock;
			} else if (gHeaderBlock && gHeaderBlock.byId(controlID)) {
				view = gHeaderBlock;
			}
			var key = "";
			if (view.byId(controlID).getTokens() !== undefined) {
				if (view.byId(controlID).getTokens().length !== 0) {
					key = view.byId(controlID).getTokens()[0].getProperty("key");
				}
			}

			if (this.getTokenKey_Exit) {
				key = this.getTokenKey_Exit(controlID, view);
			}

			return key;
		},
		getTokenDesc: function (controlID, view) {
			if (view.byId(controlID)) {
				view = view;
			} else if (gBasicDataBlock.byId(controlID)) {
				view = gBasicDataBlock;
			} else if (gSalesDataBlock.byId(controlID)) {
				view = gSalesDataBlock;
			} else if (gHeaderBlock && gHeaderBlock.byId(controlID)) {
				view = gHeaderBlock;
			}
			var desc = "";
			if (view.byId(controlID).getTokens().length !== 0) {

				desc = view.byId(controlID).getTokens()[0].getProperty("text").split("(")[0];

			}

			if (this.getTokenDesc_Exit) {
				desc = this.getTokenDesc_Exit(controlID, view);
			}

			return desc;
		},
		addMsgIfInvalid: function (isCorrect, fieldObj, i18nName) {
			if (!isCorrect) {
				var msg = oi18n.getText(i18nName);
				fieldObj.setValueState(sap.ui.core.ValueState.Error);
				fieldObj.setValueStateText(msg);
				oPPCCommon.addMsg_MsgMgr(msg);
			} else {
				fieldObj.setValueState(sap.ui.core.ValueState.None);
			}

			if (this.addMsgIfInvalid_Exit) {
				this.addMsgIfInvalid_Exit(isCorrect, fieldObj, i18nName);
			}
		},
		create: function (callBack) {

			/*Method to call create function*/
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(this.DynamicSideContent);
			var that = this;
			busyDialog.open();
			// gCPDetailView.setBusy(true);

			// var oModelcreate=new sap.ui.model.odata.v2.ODataModel(this.getView().getModel("PSGW_SHP").sServiceUrl,{json:false,defaultcreateMethod:"PUT"});
			var oModelCreate = this._oComponent.getModel("SSGW_MST");
			oModelCreate.setUseBatch(true);
			this.getView().getModel("ChannelPartners").setProperty("/LoginID", this.getCurrentUsers("ChannelPartners", "create"));
			// var CPModel = this.getView().getModel("ChannelPartners");
			// ChannelPartnerData = jQuery.extend(true, [], CPModel.getData());
			ChannelPartnerData = this.getView().getModel("ChannelPartners").getProperty("/");
			// if(ChannelPartnerData.CPTypeID === "01" || ChannelPartnerData.CPTypeID === "10" || ChannelPartnerData.CPTypeID === "20"){
			ChannelPartnerData.StatusID = "02";
			// }
			for (var i = 0; i < ChannelPartnerData.CPDMSDivisions.length; i++) {
				ChannelPartnerData.CPDMSDivisions[i].StatusID = "01";
			}
			ChannelPartnerData.Source = "PORTAL";

			delete ChannelPartnerData.CustomerNo;

			delete ChannelPartnerData.__metadata;

			// that._oComponent.getModel("ChannelPartners").setProperty("/ParentName", that.getView().getModel("LocalViewSettingDtl").getProperty(
			// 	"/Name"));
			that._oComponent.getModel("ChannelPartners").setProperty("/ParentTypeID", that.getView().getModel("LocalViewSettingDtl").getProperty(
				"/CPTypeID"));
			that._oComponent.getModel("ChannelPartners").setProperty("/ParentTypDesc", that.getView().getModel("ChannelPartners").getProperty(
				"/CPTypeDesc"));
			if (ChannelPartnerData.CPPartnerFunctions !== undefined) {
				if (ChannelPartnerData.CPPartnerFunctions.length === 0) {
					ChannelPartnerData.CPPartnerFunctions = this.getView().getModel("CPAlternateBillings").getProperty("/");
				}
			}
			if (ChannelPartnerData.CPPartnerFunctions !== undefined) {
				ChannelPartnerData.CPPartnerFunctions = ChannelPartnerData.CPPartnerFunctions;
				this.CPPartnerFunctions = ChannelPartnerData.CPPartnerFunctions;
			}

			if (ChannelPartnerData.CPDMSDivisions !== undefined) {

				ChannelPartnerData.CPDMSDivisions = ChannelPartnerData.CPDMSDivisions;
				this.CPDMSDivisions = ChannelPartnerData.CPDMSDivisions;
			}

			var oItemModel = this.getView().getModel("CPAlternateBillings");
			var oItemModelData = oItemModel.getData();
			delete ChannelPartnerData.PartnerMgrGUID;

			oModelCreate.create("/ChannelPartners",
				ChannelPartnerData, {
					success: function (oData) {
						oPPCCommon.removeDuplicateMsgsInMsgMgr();
						if (oPPCCommon.doErrMessageExist()) {
							callBack("success", oData.CPGUID);
							// gCPDetailView.setBusy(false);
							busyDialog.close();

						} else {
							oItemModelData.pop();
							oItemModelData.pop();
							oItemModel.setData(oItemModelData);
							oItemModel.refresh();
							var iTotalLength = that.getView().getModel("CPAlternateBillings").getProperty("/").length;
							if (that.getView().getModel("LocalViewSettingDtl")) {
								that.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", iTotalLength);
							}
							callBack("error");
							// gCPDetailView.setBusy(false);
							busyDialog.close();
							that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
								.getData()
								.length);
							oPPCCommon.showMessagePopover(that.DynamicSideContent);
						}
					},
					error: function () {
						oItemModelData.pop();
						oItemModelData.pop();
						oItemModel.setData(oItemModelData);
						oItemModel.refresh();
						//Update Table count
						var iTotalLength = that.getView().getModel("CPAlternateBillings").getProperty("/").length;
						if (that.getView().getModel("LocalViewSettingDtl")) {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCount", iTotalLength);
						}
						callBack("error");
						// gCPDetailView.setBusy(false);
						busyDialog.close();
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover(that.DynamicSideContent);
					}
				});
			this.aTempArray = [];

			if (this.create_Exit) {
				this.create_Exit();
			}
		},
		toEdmGuid: function (GUID) {
			return "guid'" + GUID.substring(0, 8) + "-" + GUID.substring(8, 12) + "-" + GUID.substring(12, 16) + "-" + GUID.substring(16, 20) +
				"-" + GUID.substring(20, GUID.length) + "'";
		},
		onSave: function (oEvent) {

			oEvent.getSource().setEnabled(false);
			this._Save("", "");
		},
		_Save: function (testRun, sEditApproveText) {

			busyDialog.open();
			var that = this;
			var view = gCPDetailView;
			this.getView().getModel("ChannelPartners").setProperty("/TestRun", "");
			this.getView().getModel("ChannelPartners").setProperty("/Group1", that.getDDKey("Group1", view));
			this.getView().getModel("ChannelPartners").setProperty("/Group2", that.getDDKey("Group2", view));
			this.getView().getModel("ChannelPartners").setProperty("/Group3", that.getDDKey("Group3", view));
			this.getView().getModel("ChannelPartners").setProperty("/Group4", that.getDDKey("Group4", view));
			//this.getView().getModel("ChannelPartners").setProperty("/Group5", that.getDDKey("Group5", view));

			this.getView().getModel("ChannelPartners").setProperty("/TestRun", "");
			this.getView().getModel("ChannelPartners").setProperty("/ApprvlStatusID", "01");

			// if (this.getView().getModel("CPAlternateBillings").getData().length === 0) {
			if (this.getView().getModel("ChannelPartners").getProperty("/CPTypeID") === "10" || this.getView().getModel("ChannelPartners").getProperty(
					"/CPTypeID") === "20") {
				this.addDefaultAlternatBilling("01", "Ship To");
				this.addDefaultAlternatBilling("02", "Bill To");
			}
			// }

			this.create(function (msgFrom, CPGUID) {
				if (msgFrom === "success") {
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData()
					// 		.length);
					//oPPCCommon.showMessagePopover(gCPDetailView);

					that.getRetailerDetails();

					that.onCreateSuccess(CPGUID);
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/editMode", true);
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", false);
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);

					// that.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCountClassification", 0);
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/TaxCatItemsCount", 0);
					// that.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowReview", 0);

					//that.onInitialHookUps();

				} else if (msgFrom === "error") {
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					// oPPCCommon.removeServerMsgsInMsgMgrByTarget(target);
					that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);
					if (that.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") > 0) {
						oPPCCommon.showMessagePopover(that.DynamicSideContent);
					}
				}
			});

			if (this._Save_Exit) {
				this._Save_Exit();
			}
		},

		onCreateSuccess: function (CPGUID) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Success',
				type: 'Standard',
				state: 'Success',
				draggable: true,
				content: [
					new sap.m.Text({
						text: oPPCCommon.getMsgsFromMsgMgr()
					})
				],
				buttons: [
					new sap.m.Button({
						icon: "sap-icon://home",
						text: "Home",
						press: function () {
							that.onBack();
							window.location = "#";
							dialog.close();
						}
					}),

					new sap.m.Button({
						text: oi18n.getText("view"),
						press: function () {
							that.gotoCPDetail(CPGUID);
							dialog.close();
						}
					}),
					new sap.m.Button({
						text: oi18n.getText("CreateNew"),
						press: function () {
							that.onInit();
							that.getView().getModel("LocalViewSettingDtl").setProperty("/editMode", true);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", false);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCountInfradetails", 0);
							that.getView().getModel("ChannelPartners").setProperty("/IsHomedlvryAvl", " ");
							that.getView().getModel("ChannelPartners").setProperty("/IsHomedlvryAvl", " ");
							that.getView().getModel("ChannelPartners").setProperty("/IsPhOrderAvl", " ");
							that.getView().getModel("ChannelPartners").setProperty("/IsCompBillAvl", " ");
							that.getView().getModel("ChannelPartners").setProperty("/IsHsptlNearBy", " ");
							that.getView().getModel("ChannelPartners").setProperty("/IsEduInstNrby", " ");
							that.getView().getModel("ChannelPartners").setProperty("/IsSmartPhAvl", " ");
							that.getView().getModel("ChannelPartners").setProperty("/OutletShapeId", "");
							that.getView().getModel("ChannelPartners").setProperty("/OutletSizeId", "");
							that.getView().getModel("ChannelPartners").setProperty("/OutletLocId", "");

							gCPDetailClassGroups.oController.setCPScheduleDetails();

							if (gCPInfraView.getModel("InfraDetailsModel")) {
								gCPInfraView.getModel("InfraDetailsModel").setProperty("/", []);
							}
							if (gCPDetailClassGroups.getModel("CPGroupTemp")) {
								gCPDetailClassGroups.oController.setDefaultSettings();
							}
							gBasicDataBlock.byId("inputCustomerF4").removeAllTokens();
							gBasicDataBlock.byId("idSubDistrict").removeAllTokens();
							gBasicDataBlock.byId("idWard").removeAllTokens();
							gBasicDataBlock.byId("Customer").setSelectedKey("");
							gAdditionalDetails.byId("fOpeningTime").setValue("00:00");
							gAdditionalDetails.byId("fClosingTime").setValue("00:00");
							gAdditionalDetails.byId("fLunchTime").setValue("00:00");
							dialog.close();
						}
					})
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			// window.history.back();
			this.addTokensForCommonValueHelp(gCPDetailView);
			dialog.open();
			dialog.attachBrowserEvent("keydown", function (oEvent) {
				oEvent.stopPropagation();
				oEvent.preventDefault();
			});

			if (this.onCreateSuccess_Exit) {
				this.onCreateSuccess_Exit();
			}
		},
		gotoCPDetail: function (CPGUID) {
			var path = "ChannelPartners(CPGUID=guid'" + CPGUID + "')";
			/*var sTargetName = oSSCommon.getProductFeatureValue({
				Types: "WAASN"
			});
			var sCreateSourceName = oSSCommon.getProductFeatureValue({
				Types: "WAASNCRT"
			});*/
			oPPCCommon.crossAppNavigation("sscpcreate1", "sscp1", "Display", "", "", "/View/" + path);

			if (this.gotoCPDetail_Exit) {
				this.gotoCPDetail_Exit();
			}
		},
		onCancel: function () {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				stete: 'Warning',
				icon: 'sap-icon://message-warning',
				content: new sap.m.Text({
					text: oi18n.getText("CPDetailHeaderEdit.Popup.confirmation")
				}),
				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function () {
						oPPCCommon.removeAllMsgs();
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.hideMessagePopover(this.DynamicSideContent);
						that.clearAllErrors();
						that.getRetailerDetails();
						that.resetChannelClass();
						that.addTokensForCommonValueHelp(gCPDetailView);
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
			dialog.attachBrowserEvent("keydown", function (oEvent) {
				oEvent.stopPropagation();
				oEvent.preventDefault();
			});
			if (this.onCancel_Exit) {
				this.onCancel_Exit();
			}

		},
		resetChannelClass: function () {
			if (gBasicDataBlock) {
				gBasicDataBlock.byId("Customer").setSelectedKey("");
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/Name", "");
			this.getView().getModel("LocalViewSettingDtl").setProperty("/CustomerNo", "");

			gCPDetailClassGroups.oController.setCPScheduleDetails();
			if (gCPDetailClassGroups.getModel("CPGroupTemp")) {
				gCPDetailClassGroups.oController.setDefaultSettings();
			}
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf webapp.view.CPCreate
		 */
		//	onBeforeRendering: function() {

		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf webapp.view.CPCreate
		 */
		onAfterRendering: function () {
			//	sCurrentBreakpoint=oDynamicSideView.getCurrentBreakpoint();
		},

		setDefaultSettings: function () {

			/**
			 * All view related local settings should be mapped in a Model and is called LocalViewSettingDtl
			 */
			var oRejectButton,
				oEditApproveButton, oEditButton, oApproveButton, oApproveHistory,
				oApproveButtonType,
				oRejectButtonType,
				oEditApproveButtonType;
			var oLocalData;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				oLocalData = this.getView().getModel("LocalViewSettingDtl").getData();
				if (oLocalData.editApproveButton === true && oLocalData.editButton === true && oLocalData.rejectButton === true) {
					oEditApproveButton = true;
					oRejectButton = true;
					oApproveButton = true;
					oEditButton = false;
					oApproveHistory = true;
					oApproveButtonType = "Accept";
					oRejectButtonType = "Reject";
					oEditApproveButtonType = "Accept";
					//gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/approveVisible", true);
				} else {
					oEditApproveButton = false;
					oEditButton = true;
					oRejectButton = false;
					oApproveButton = false;
					oApproveHistory = false;
					oApproveButtonType = "Accept";
					oRejectButtonType = "Reject";
					oEditApproveButtonType = "Accept";
				}
			} else {
				oEditApproveButton = false;
				oEditButton = true;
				oRejectButton = false;
				oApproveButton = false;
				oApproveHistory = false;
			}

			var oViewSettingModel = new sap.ui.model.json.JSONModel({
				MaxLengthPostalCode: 10,
				MaxDiscountPerce: 2.5,
				editMode: false,
				detailMode: true,
				reviewMode: false,
				messageLength: 0,
				ApproveHistory: oApproveHistory,
				HeaderObjectApprovalVisibility: false,
				approveButton: oApproveButton,
				rejectButton: oRejectButton,
				editApproveButton: oEditApproveButton,
				editButton: oEditButton,
				approveButtonType: oApproveButtonType,
				rejectButtonType: oRejectButtonType,
				editApproveButtonType: oEditApproveButtonType,
				DateFormat: oSSCommon.getDateFormat(),
				TableRowCount: 0,
				TableRowCountClassification: 0,

				pageHeader: oi18n.getText("CPDetail.Page.header"),
				TableRowCountTaxClassification: 0,
				TaxCatItemsCount: 0,
				TaxCatDDVisible: true,
				BasciDataTabVisible: true,
				SalesDataVisible: true,
				ChannelClassVisible: true,
				GroupTabVisible: true,
				InfraVisible: true,
				AlternateBillVisible: true,
				AdditionalDetailVisible: true,
				DeliverySchetblLength: 1,
				OpeningTime: "00:00",
				ClosingTime: "00:00",
				LunchTime: "00:00"
			});
			this._oComponent.setModel(oViewSettingModel, "LocalViewSettingDtl");

			if (this.setDefaultSettings_Exit) {
				this.setDefaultSettings_Exit();
			}
		},

		getCustomers: function (customer) {
			var that = this;
			that.setCustomerInputVisibility();
			if (this.sCustomerInputType !== "VH") {
				var oCustomerModel = that._oComponent.getModel("SFGW_MST");
				oCustomerModel.setUseBatch(false);
				that._oGetCustomers(oCustomerModel, "000002", "2", busyDialog, this._oComponent, function (Customers) {
					that.busyCount();
					if (Customers.length === 1) {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/Name", Customers[0].Name);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/CustomerNo", Customers[0].CustomerNo);

						that.getView().getModel("LocalViewSettingDtl").setProperty("/CPNo", Customers[0].CustomerNo);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/CPTypeID", Customers[0].CPTypeID);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/CPTypeIDMandat", Customers[0].CPTypeID);
						that._oComponent.getModel("ChannelPartners").setProperty("/CustomerNo", Customers[0].CustomerNo);

					}

					if (Customers[0].CPTypeID === "01") {
						that._oComponent.getModel("ChannelPartners").setProperty("/ParentID", Customers[0].CustomerNo);
					} else {

						var cpguid = that._oComponent.getModel("LocalViewSettingDtl").getData().gCPGUID;

						that._oComponent.getModel("ChannelPartners").setProperty("/ParentID", cpguid);
					}

					if (Customers.length > 0) {

						if (Customers[0].CPTypeID === "01") {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/FieldVisible", false);
						} else {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/FieldVisible", true);
						}
						if (that._oComponent.getModel("ChannelPartners")) {

							that._oComponent.getModel("ChannelPartners").setProperty("/ParentName", Customers[0].Name);
							that._oComponent.getModel("ChannelPartners").setProperty("/ParentTypeID", Customers[0].CPTypeID);

							that._oComponent.getModel("ChannelPartners").setProperty("/ParentTypDesc", Customers[0].CPTypeDesc);

						}
						//that.setChannelPartnerTypeDD(Customers[0].CPTypeID);

					}
				}, "create");
			}
		},

		_oGetCustomers: function (oCustomerModel, RoleID, UserType, busyDialog, view, requestCompleted, appType) {
			if (view.getModel("SSGW_MST")) {
				oCustomerModel = view.getModel("SSGW_MST");
			}
			var that = this;
			var aCustomers = new Array();
			var aCustomerFilters = new Array();
			oSSCommon.getCurrentLoggedUser({
				sServiceName: "UserChannelPartners",
				sRequestType: "read"
			}, function (LoginID) {
				aCustomerFilters = oPPCCommon.setODataModelReadFilter("", "", aCustomerFilters, "LoginID", "", [LoginID], false, false, false);
				var serviceName = "Customers";
				if (view.getModel("SSGW_MST")) {
					serviceName = "UserChannelPartners";
				}
				oCustomerModel.read("/" + serviceName, {
					filters: aCustomerFilters,
					success: function (oData) {
						if (oData.results.length > 0) {
							//	that.SalesPersonDD(oData.results[1].CPGUID);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/gCPGUID", oData.results[0].CPGUID);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/gCPTypeId", oData.results[0].CPTypeID);
							if (oData.results.length === 1) {

								if (oData.results[0].CPTypeID === "02") {
									that.DistributorDetails(oData.results[0].CPGUID);
								} else {
									that.CustomerDetails(oData.results[0].CPGUID);
								}
							}
							if (UserType === "2") {
								if (oData.results.length !== 1) {
									if (appType === "create") {
										aCustomers.push({
											CustomerNo: "",
											Name: "(None)"
										});
									} else {
										aCustomers.push({
											CustomerNo: "",
											Name: "(All)"
										});
									}
								}
								for (var i = 0; i < oData.results.length; i++) {
									if (view.getModel("SSGW_MST")) {
										aCustomers.push({
											CustomerNo: oData.results[i].CPNo,
											Name: oData.results[i].Name,
											Seperator: " - ",
											CPGUID: oData.results[i].CPGUID,
											CPUID: oData.results[i].CPUID,
											CPTypeID: oData.results[i].CPTypeID,
											CPTypeDesc: oData.results[i].CPTypeDesc
										});
									} else {
										aCustomers.push({
											CustomerNo: oData.results[i].CustomerNo,
											Name: oData.results[i].Name,
											Seperator: " - "
										});
									}
								}
								requestCompleted(aCustomers);
								var oCustomersModel = new sap.ui.model.json.JSONModel();
								oCustomersModel.setData(aCustomers);
								if (aCustomers.length > 0) {
									view.setModel(oCustomersModel, "Customers");
									if (view.byId("customer")) {
										view.byId("customer").setSelectedKey(aCustomers[0].CPNo);
										view.byId("customer").setTooltip(aCustomers[0].Name);
									}
								}
							} else {
								aCustomers = oData.results;
							}
							requestCompleted(aCustomers);
						}
					},
					error: function (error) {
						// 				busyDialog.close();
					}
				});
			});
		},
		showPopUp: function () {
			oPPCCommon.showMessagePopover(this.DynamicSideContent);
		},

		CustomerDetails: function (CustomerNo) {
			var view = this.getView();
			var oSSGW_MSTModel = view.getModel("SFGW_MST");
			var thisController = this;
			var LoginID = this.getCurrentUsers("ChannelPartners", "read");

			oSSGW_MSTModel.setUseBatch(true);

			oSSGW_MSTModel.setHeaders({
				"x-arteria-loginid": LoginID
			});

			oSSGW_MSTModel.read("/Customers(CustomerNo='" + CustomerNo + "')", {
				success: function (oData) {
					thisController.setDataFromParent(oData);
				},
				error: function (error) {}
			});

			if (this.DistributorDetails_Exit) {
				this.DistributorDetails_Exit();
			}
		},

		DistributorDetails: function (GUID) {
			GUID = GUID.substring(0, 8) + "-" + GUID.substring(8, 12) + "-" + GUID.substring(12, 16) + "-" + GUID.substring(16, 20) + "-" +
				GUID.substring(20, GUID.length);
			var that = this;
			var view = this.getView();
			var oSSGW_MSTModel = view.getModel("SSGW_MST");

			oSSGW_MSTModel.setUseBatch(true);
			var thisController = this;
			that.getCurrentUsers("ChannelPartners", "read", function (LoginID) {
				oSSGW_MSTModel.setHeaders({
					"x-arteria-loginid": LoginID
				});
				oSSGW_MSTModel.read("/ChannelPartners(CPGUID=guid'" + GUID + "')", {
					urlParameters: {
						"$expand": "CPDMSDivisions,CPPartnerFunctions"
					},
					success: function (oData) {
						thisController.setDataFromParent(oData);
					},
					error: function (error) {}
				});
			});
			if (this.DistributorDetails_Exit) {
				this.DistributorDetails_Exit();
			}
		},

		setDataFromParent: function (oData) {
			if (oData) {
				if (oData.Currency) {
					this.getView().getModel("ChannelPartners").setProperty("/Currency", oData.Currency);
				}
				gBasicDataBlock.byId("fCountryEdit").removeAllTokens();

				gBasicDataBlock.byId("fTownIDEdit").removeAllTokens();

				if (oData.CountryID) {
					gBasicDataBlock.byId("fCountryEdit").addToken(new sap.m.Token({
						key: oData.CountryID,
						text: oData.CountryDesc + " (" + oData.CountryID + ")"
					}));
					this.getPostalMaxLength(oData.CountryID);
				} else if (oData.Country) {
					gBasicDataBlock.byId("fCountryEdit").addToken(new sap.m.Token({
						key: oData.Country,
						text: oData.CountryName + " (" + oData.Country + ")"
					}));
					this.getPostalMaxLength(oData.CountryID);
				}
				if (oData.Region) {
					gBasicDataBlock.byId("fStateIDEdit").addToken(new sap.m.Token({
						key: oData.Region,
						text: oData.RegionDesc + " (" + oData.Region + ")"
					}));
				}
				if (oData.District) {
					gBasicDataBlock.byId("fDistrictIDEdit").addToken(new sap.m.Token({
						key: "9999",
						text: oData.District + " (9999)"
					}));
				}
				if (oData.DistrictID) {
					gBasicDataBlock.byId("fDistrictIDEdit").addToken(new sap.m.Token({
						key: oData.DistrictID,
						text: oData.DistrictDesc + " (" + oData.DistrictID + ")"
					}));
				}
				if (oData.City) {
					gBasicDataBlock.byId("fCityIDEdit").addToken(new sap.m.Token({
						key: "9999999999",
						text: oData.City + " (9999999999)"
					}));
				}
				if (oData.CityID) {
					gBasicDataBlock.byId("fCityIDEdit").addToken(new sap.m.Token({
						key: oData.CityID,
						text: oData.CityDesc + " (" + oData.CityID + ")"
					}));
				}
				// if (oData.Region) {
				// 	gBasicDataBlock.byId("fStateIDEdit").addToken(new sap.m.Token({
				// 		key: oData.Region,
				// 		text: oData.RegionDesc + " (" + oData.Region + ")"
				// 	}));
				// }
				// 	if(oData.City){
				// 		gBasicDataBlock.byId("fCityIDEdit").addToken(new sap.m.Token({
				// 		key: oData.City,
				// 		text: oData.City + " (" + oData.City + ")"
				// 	}));
				// }
				// 	if(oData.District){
				// 		gBasicDataBlock.byId("fDistrictIDEdit").addToken(new sap.m.Token({
				// 		key: oData.District,
				// 		text: oData.District + " (" + oData.District + ")"
				// 	}));
				// }
			}
			this.setstateModel();
			var oOwnDataModel = new sap.ui.model.json.JSONModel();
			oOwnDataModel.setData(oData);
			this._oComponent.setModel(oOwnDataModel, "OwnData");
		},

		getPostalMaxLength: function (CountryID) {
			var that = this;
			var view = this.getView();
			var oPCGWModel = view.getModel("PCGW");
			oPCGWModel.setUseBatch(false);
			oPCGWModel.read("/CountryByCountryID", {
				urlParameters: "CountryID='" + CountryID + "'",
				success: function (oData) {
					oPCGWModel.setUseBatch(true);
					if (oData && oData.CountryByCountryID && oData.CountryByCountryID.PostalCodeLength) {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/MaxLengthPostalCode", parseInt(oData.CountryByCountryID.PostalCodeLength));
					}
				},
				error: function (error) {
					oPCGWModel.setUseBatch(true);
				}
			});
			if (this.getPostalMaxLength_Exit) {
				this.getPostalMaxLength_Exit();
			}
		},

		// CountryModel: function() {
		// 	var that = this;

		// 	var aCityFilterArray = new Array();
		// 	aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "LoginID", "", [
		// 		that.getCurrentUsers("ChannelPartners", "read")
		// 	], false, false, false);
		// 	aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "ModelID", sap.ui
		// 		.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		// 	aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "EntityType", sap.ui
		// 		.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		// 	aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "PropName", sap.ui
		// 		.model.FilterOperator.EQ, ["Country"], false, false, false);

		// 	var sPCGWModel = that._oComponent.getModel("PCGW");

		// 	sPCGWModel.read("/ValueHelps", {
		// 		filters: aCityFilterArray,
		// 		urlParameters: {
		// 			"$select": "ID,Description"
		// 		},
		// 		success: function(oData) {
		// 			var SONosModel = new sap.ui.model.json.JSONModel();
		// 			SONosModel.setData(oData.results);
		// 			that._oComponent.setModel(SONosModel, "CountryModel");
		// 			//that.getCustomerDetail();
		// 		},
		// 		error: function(error) {
		// 			var SONosModel = new sap.ui.model.json.JSONModel();
		// 			SONosModel.setData([]);
		// 			that._oComponent.setModel(SONosModel, "CountryModel");
		// 		}
		// 	});
		// },
		// handleCountrySuggest: function(oEvent) {

		// 	oPPCCommon.handleSuggest({
		// 		oEvent: oEvent,
		// 		aProperties: ["ID", "Description"],
		// 		sBinding: "suggestionItems"
		// 	});
		// },

		// suggestionItemCountry: function(oEvent) {
		// 	var that = this;
		// 	oPPCCommon.suggestionItemSelected({
		// 			oEvent: oEvent,
		// 			thisController: this,
		// 			sModelName: "CountryModel",
		// 			//sKey: "ID",
		// 			sKey: "ID",
		// 			sDescription: "Description"
		// 		},
		// 		function(key, desc, jdata) {
		// 			that.setCountryDetails(jdata);

		// 			// that.getView().getModel("ChannelPartners").setProperty("/CityID", key);
		// 			//that.getView().getModel("ChannelPartners").setProperty("/CityDesc", desc);
		// 			oEvent.getSource().setValue("");
		// 		}
		// 	);
		// 	// this.getView().byId("inputMaterial").setValueState("None");
		// 	// this.getView().byId("inputMaterial").setValueStateText("");
		// },

		// setCountryDetails: function(tokens) {
		// 	var that = this;
		// 	this.getView().byId("fCountryEdit").setValueState(sap.ui.core.ValueState.None);
		// 	this.getView().byId("fCountryEdit").setValueStateText("");
		// 	oPPCCommon.removeMsgsInMsgMgrByMsgCode("fCountryEdit");
		// 	var countryID = tokens.ID;
		// 	var Desc = tokens.Description;
		// 	//this._oComponent.getModel("LocalViewSetting").setProperty("/Country", countryID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/Country", countryID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/CountryName", Desc);
		// 	that.setstateModel();
		// },

		setstateModel: function () {
			var that = this;

			var aCityFilterArray = new Array();
			var parentID = "000003" + oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fCountryEdit");
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "LoginID", "", [
				that.getCurrentUsers("ChannelPartners", "read")
			], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "ParentID", sap.ui
				.model.FilterOperator.EQ, [parentID], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "EntityType", sap.ui
				.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			aCityFilterArray = oPPCCommon.setODataModelReadFilter("", "", aCityFilterArray, "PropName", sap.ui
				.model.FilterOperator.EQ, ["StateID"], false, false, false);

			var sPCGWModel = this._oComponent.getModel("PCGW");

			sPCGWModel.read("/ValueHelps", {
				filters: aCityFilterArray,
				urlParameters: {
					"$select": "ID,Description"
				},
				success: function (oData) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData(oData.results);
					that._oComponent.setModel(SONosModel, "StateModel");
					//that.getCustomerDetail();
				},
				error: function (error) {
					var SONosModel = new sap.ui.model.json.JSONModel();
					SONosModel.setData([]);
					that._oComponent.setModel(SONosModel, "StateModel");
				}
			});
		},
		// handleStateSuggest: function(oEvent) {
		// 	oPPCCommon.handleSuggest({
		// 		oEvent: oEvent,
		// 		aProperties: ["ID", "Description"],
		// 		sBinding: "suggestionItems"
		// 	});
		// },
		// suggestionItemState: function(oEvent) {
		// 	var that = this;
		// 	oPPCCommon.suggestionItemSelected({
		// 			oEvent: oEvent,
		// 			thisController: this,
		// 			sModelName: "StateModel",
		// 			//sKey: "ID",
		// 			sKey: "ID",
		// 			sDescription: "Description"
		// 		},
		// 		function(key, desc, jdata) {
		// 			that.setStateDetails(jdata);
		// 			gBasicDataBlock.byId("fStateIDEdit").setValue("");
		// 		}
		// 	);
		// },
		// setStateDetails: function(tokens) {
		// 	var that = this;
		// 	gBasicDataBlock.byId("fStateIDEdit").setValueState(sap.ui.core.ValueState.None);
		// 	gBasicDataBlock.byId("fStateIDEdit").setValueStateText("");
		// 	oPPCCommon.removeMsgsInMsgMgrByMsgCode("fStateIDEdit");
		// 	var stateID = tokens.ID;
		// 	var Desc = tokens.Description;
		// 	this.getView().getModel("ChannelPartners").setProperty("/StateDesc", Desc);
		// 	that.setDistrictModel();
		// },
		// setDistrictModel: function() {
		// 	var that = this;
		// 	var parentID = oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
		// 		"fStateIDEdit");
		// 	var aStateArray = new Array();
		// 	aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "LoginID", "", [
		// 		that.getCurrentUsers("ChannelPartners", "read")
		// 	], false, false, false);
		// 	aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "ModelID", sap.ui
		// 		.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		// 	aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "ParentID", sap.ui
		// 		.model.FilterOperator.EQ, [parentID], false, false, false);
		// 	aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "EntityType", sap.ui
		// 		.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		// 	aStateArray = oPPCCommon.setODataModelReadFilter("", "", aStateArray, "PropName", sap.ui
		// 		.model.FilterOperator.EQ, ["DistrictID"], false, false, false);

		// 	var sPCGWModel = this._oComponent.getModel("PCGW");

		// 	sPCGWModel.read("/ValueHelps", {
		// 		filters: aStateArray,
		// 		urlParameters: {
		// 			"$select": "ID,Description"
		// 		},
		// 		success: function(oData) {
		// 			var SONosModel = new sap.ui.model.json.JSONModel();
		// 			SONosModel.setData(oData.results);
		// 			that._oComponent.setModel(SONosModel, "DistrictModel");
		// 			//that.getCustomerDetail();
		// 		},
		// 		error: function(error) {
		// 			var SONosModel = new sap.ui.model.json.JSONModel();
		// 			SONosModel.setData([]);
		// 			that._oComponent.setModel(SONosModel, "DistrictModel");
		// 		}
		// 	});
		// },
		// handleDistrictSuggest: function(oEvent) {
		// 	oPPCCommon.handleSuggest({
		// 		oEvent: oEvent,
		// 		aProperties: ["ID", "Description"],
		// 		sBinding: "suggestionItems"
		// 	});
		// },
		// suggestionItemDistrict: function(oEvent) {
		// 	var that = this;
		// 	oPPCCommon.suggestionItemSelected({
		// 			oEvent: oEvent,
		// 			thisController: this,
		// 			sModelName: "DistrictModel",
		// 			//sKey: "ID",
		// 			sKey: "ID",
		// 			sDescription: "Description"
		// 		},
		// 		function(key, desc, jdata) {
		// 			that.setDistrictDetails(jdata);

		// 			// that.getView().getModel("ChannelPartners").setProperty("/CityID", key);
		// 			//that.getView().getModel("ChannelPartners").setProperty("/CityDesc", desc);
		// 			oEvent.getSource().setValue("");
		// 		}
		// 	);
		// 	// this.getView().byId("inputMaterial").setValueState("None");
		// 	// this.getView().byId("inputMaterial").setValueStateText("");
		// },
		// setDistrictDetails: function(tokens) {
		// 	var that = this;
		// 	gBasicDataBlock.byId("fDistrictIDEdit").setValueState(sap.ui.core.ValueState.None);
		// 	gBasicDataBlock.byId("fDistrictIDEdit").setValueStateText("");
		// 	oPPCCommon.removeMsgsInMsgMgrByMsgCode("fDistrictIDEdit");
		// 	var stateID = tokens.ID;
		// 	var Desc = tokens.Description;
		// 	//this._oComponent.getModel("LocalViewSetting").setProperty("/Country", countryID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/DistrictID", stateID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/DistrictDesc", Desc);
		// 	that.setCityModel();
		// },
		// setCityModel: function() {
		// 	var that = this;
		// 	var parentID = oPPCCommon.getKeysFromTokens(this.getView(), "fCountryEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(),
		// 		"fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(this.getView(), "fDistrictIDEdit");
		// 	var aCityArray = new Array();
		// 	aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "LoginID", "", [
		// 		that.getCurrentUsers("ChannelPartners", "read")
		// 	], false, false, false);
		// 	aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "ModelID", sap.ui
		// 		.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		// 	aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "ParentID", sap.ui
		// 		.model.FilterOperator.EQ, [parentID], false, false, false);
		// 	aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "EntityType", sap.ui
		// 		.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		// 	aCityArray = oPPCCommon.setODataModelReadFilter("", "", aCityArray, "PropName", sap.ui
		// 		.model.FilterOperator.EQ, ["CityID"], false, false, false);

		// 	var sPCGWModel = this._oComponent.getModel("PCGW");

		// 	sPCGWModel.read("/ValueHelps", {
		// 		filters: aCityArray,
		// 		urlParameters: {
		// 			"$select": "ID,Description"
		// 		},
		// 		success: function(oData) {
		// 			var SONosModel = new sap.ui.model.json.JSONModel();
		// 			SONosModel.setData(oData.results);
		// 			that._oComponent.setModel(SONosModel, "CityModel");
		// 			//that.getCustomerDetail();
		// 		},
		// 		error: function(error) {
		// 			var SONosModel = new sap.ui.model.json.JSONModel();
		// 			SONosModel.setData([]);
		// 			that._oComponent.setModel(SONosModel, "CityModel");
		// 		}
		// 	});
		// },
		// handleCitySuggest: function(oEvent) {
		// 	oPPCCommon.handleSuggest({
		// 		oEvent: oEvent,
		// 		aProperties: ["ID", "Description"],
		// 		sBinding: "suggestionItems"
		// 	});
		// },
		// suggestionItemCity: function(oEvent) {
		// 	var that = this;
		// 	oPPCCommon.suggestionItemSelected({
		// 			oEvent: oEvent,
		// 			thisController: this,
		// 			sModelName: "CityModel",
		// 			//sKey: "ID",
		// 			sKey: "ID",
		// 			sDescription: "Description"
		// 		},
		// 		function(key, desc, jdata) {
		// 			that.setCityDetails(jdata);

		// 			// that.getView().getModel("ChannelPartners").setProperty("/CityID", key);
		// 			//that.getView().getModel("ChannelPartners").setProperty("/CityDesc", desc);
		// 			oEvent.getSource().setValue("");
		// 		}
		// 	);
		// 	// this.getView().byId("inputMaterial").setValueState("None");
		// 	// this.getView().byId("inputMaterial").setValueStateText("");
		// },

		// setCityDetails: function(tokens) {
		// 	var that = this;
		// 	gBasicDataBlock.byId("fCityIDEdit").setValueState(sap.ui.core.ValueState.None);
		// 	gBasicDataBlock.byId("fCityIDEdit").setValueStateText("");
		// 	oPPCCommon.removeMsgsInMsgMgrByMsgCode("fCityIDEdit");
		// 	var stateID = tokens.ID;
		// 	var Desc = tokens.Description;
		// 	//this._oComponent.getModel("LocalViewSetting").setProperty("/Country", countryID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/CityID", stateID);
		// 	this.getView().getModel("ChannelPartners").setProperty("/CityDesc", Desc);
		// 	that.setCityModel();
		// },

		getMaxDiscount: function () {
			var that = this;
			var view = this.getView();
			var oPCGWModel = view.getModel("PCGW");
			oPCGWModel.setUseBatch(true);
			oPCGWModel.read("/AttributeTypesetTypes", {
				"$filter": "Typeset eq 'DICPER'",
				success: function (oData) {
					if (oData && oData.Name) {
						that.getView().getModel("LocalViewSettingDtl").setProperty("/MaxDiscountPerce", parseInt(oData.Name));
					}
				},
				error: function (error) {}
			});
			if (this.getMaxDiscount_Exit) {
				this.getMaxDiscount_Exit();
			}
		},

		getDropDown: function (oModel, sEntitySet, oFilters, sKey, sText, busyDialog, view, modelName, defaultValue, requestCompleted,
			bLoginIDOptional, appKey, bMustAddNone, mParameters, newKey) {
			var aDDValue = new Array();
			oPPCCommon.getCurrentLoggedUser({
				sServiceName: sEntitySet,
				sRequestType: "read",
				Application: appKey
			}, function (LoginID) {
				oFilters = oPPCCommon.setODataModelReadFilter("", "", oFilters, "LoginID", "", [LoginID], false, false, false);
				oModel.read("/" + sEntitySet, {
					filters: oFilters,
					success: function (oData) {
						if (oData.results.length > 0) {
							if (defaultValue !== null && defaultValue !== undefined && defaultValue !== "" && (oData.results.length !== 1 || ((
									defaultValue === "None" || defaultValue === "Select") && bMustAddNone))) {
								aDDValue.push({
									Key: "",
									Text: "(" + defaultValue + ")"
								});
							}
							for (var i = 0; i < oData.results.length; i++) {
								aDDValue.push({
									Key: oData.results[i][sKey],
									Text: oData.results[i]["SPNo"] + " - " + oData.results[i][sText],
									Seperator: " - "
								});
							}
							var oDDModel = new sap.ui.model.json.JSONModel();
							oDDModel.setData(aDDValue);
							if (mParameters) {
								if (mParameters.bSetSizeLimit) {
									oDDModel.setSizeLimit(aDDValue.length);
								}
							}
							view.setModel(oDDModel, modelName);
						}
						if (requestCompleted) {
							requestCompleted(aDDValue);
						}
					},
					error: function (error) {
						busyDialog.close();
						oPPCCommon.showServiceErrorPopup(error);
					}
				});
			});

		}

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf webapp.view.CPCreate
		 */
		//	onExit: function() {

		//	}
	});
});