jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.cp.create1.util.CPStatusFormatter");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/CommonValueHelp"
], function (Controller, oSSCommonValueHelp) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var busyDialog = new sap.m.BusyDialog();

	return Controller.extend("com.arteriatech.ss.cp.create1.controller.CPInfradetails", {

		onInit: function () {
			this.onInitialHookUps();
		},

		onInitialHookUps: function () {
			gCPInfraView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gCPInfraView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.setDefaultSettings();
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},
		setDefaultSettings: function () {
			var LocalView = {
				VisibleRowCount: 0
			};
			var oJSONModel = new sap.ui.model.json.JSONModel(LocalView);
			this.getView().setModel(oJSONModel, "LocalViewForFragment");
		},

		onClose: function () {
			this._Dialog.close();
		},
		onAdd: function () {
			var that = this;
			oPPCCommon.removeAllMsgs();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			var mInfraModel = [];
			var mSelectedInfraCodeModel = this.getView().getModel("InfraCodeDD").getData();
			if (gCPInfraView.getModel("InfraDetailsModel")) {
				mInfraModel = gCPInfraView.getModel("InfraDetailsModel").getData();
			}

			var oTempArra = mInfraModel;
			for (var i = 0; i < mSelectedInfraCodeModel.length; i++) {
				var valid = true;
				if (mSelectedInfraCodeModel[i].Selected) {
					for (var j = 0; j < mInfraModel.length; j++) {
						if (mSelectedInfraCodeModel[i].Key === mInfraModel[j].InfraCode) {
							valid = false;
							that.addInfoMesaage(mSelectedInfraCodeModel[i].Key);
							break;
						}
					}
					if (valid) {
						var infraObject = that.getInfraObject(mSelectedInfraCodeModel[i]);
						oTempArra.push(infraObject);
					}
				}

			}
			var mModel = new sap.ui.model.json.JSONModel(oTempArra);
			this.getView().setModel(mModel, "InfraDetailsModel");
			this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCountInfradetails", oTempArra.length);
			that._Dialog.close();
			if (!oPPCCommon.doErrMessageExist()) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(gDynamicSideContent);
			}
		},
		addInfoMesaage: function (infraCode) {
			var msg = oi18n.getText("infra.info.message", infraCode);
			oPPCCommon.addMsg_MsgMgr(msg, "error");
		},
		getInfraObject: function (eachElement) {
			var aObject = {
				InfraCode: eachElement.Key,
				InfraCodeDesc: eachElement.Text,
				OwnedBy: "",
				OwnedByDesc: "",
				InfraQty: "1",
				InfraUOM: "",
				CP2GUID: oPPCCommon.generateUUID(),
				CPGUID: ""
			};
			return aObject;
		},

		resetFragmentView: function () {
			var infraCode = [];
			if (this.getView().getModel("InfraCodeDD")) {
				infraCode = this.getView().getModel("InfraCodeDD").getData();
			}

			infraCode.forEach(function (eachElement) {
				eachElement.Selected = false;
			});
			if (this.getView().getModel("InfraCodeDD")) {
				this.getView().getModel("InfraCodeDD").setProperty("/", infraCode);
			}
		},
		addInfraDetails: function () {
			this.callsCount = 3;
			this.getDropDowns();
		},
		callService: function () {
			var that = this;
			this.callsCount--;
			if (this.callsCount === 0) {
				if (that._Dialog) {
					that.resetFragmentView();
					that._Dialog.open();
				} else {
					that._Dialog = sap.ui.xmlfragment("com.arteriatech.ss.cp.create1.view.CPInfra", that);
					that.getView().addDependent(that._Dialog);
					that.resetFragmentView();
					that._Dialog.open();
				}
			}
		},
		getDropDowns: function () {
			if (!this.getView().getModel("OwnedByDD")) {
				this.InfraCodeDD();
			} else {
				this.callService();
			}

			if (!this.getView().getModel("OwnedByDD")) {
				this.OwnedByDD();
			} else {
				this.callService();
			}
			if (!this.getView().getModel("InfraUOMDD")) {
				this.InfraUOMDD();
			} else {
				this.callService();
			}
		},
		InfraCodeDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPINFRA"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"InfraCodeDD", "",
				function (addData) {
					that.getView().getModel("LocalViewForFragment").setProperty("/VisibleRowCount", addData.length);
					that.callService();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		InfraUOMDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPINUM"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"InfraUOMDD", "",
				function () {
					that.callService();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		OwnedByDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPOWNB"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"OwnedByDD", "Select",
				function () {
					that.callService();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		onDeleteItem: function (oEvent) {
			var idx = oEvent.getSource().getBindingContext("InfraDetailsModel").getPath().split("/")[1];
			var oInfraModel = gCPInfraView.getModel("InfraDetailsModel");
			var oModel = oInfraModel.getData();

			var infracode = oModel[idx].InfraCode;

			oModel.splice(idx, 1);
			oInfraModel.setData(oModel);
			oInfraModel.refresh();
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/TableRowCountInfradetails", oModel.length);

			this.UpdateSelectionCheckBoxForInfra(infracode);
		},
		UpdateSelectionCheckBoxForInfra: function (infracode) {
			var mInfraCodeModel = this.getView().getModel("InfraCodeDD").getData();
			mInfraCodeModel.forEach(function (eachElement) {
				if (eachElement.Key === infracode) {
					eachElement.Selected = false;
				}
			});
			this.getView().getModel("InfraCodeDD").setProperty("/", mInfraCodeModel);
		},
		validateNumeric: function (oEvent) {
			var value = oEvent.getSource().getValue();
			var currentValueEntered = value.substring(value.length - 1);
			var lastValueEnterd = value.substring(0, value.length - 1);
			var reg = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,<>\/a-z A-Z?]/;
			if (reg.test(currentValueEntered)) {
				oEvent.getSource().setValue(lastValueEnterd);
			}
		},
		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		onChangeInfraCode: function (oEvent) {
			var object = oEvent.getSource().getBindingContext("InfraDetailsModel").getObject();
			var infraDesc = oEvent.getParameters("selectedItem").selectedItem.getText().split("-")[1];
			object.InfraCodeDesc = infraDesc;
		},
		onChangeOwnedBy: function (oEvent) {
			var object = oEvent.getSource().getBindingContext("InfraDetailsModel").getObject();
			var OwnedByDesc = oEvent.getParameters("selectedItem").selectedItem.getText().split("-")[1];
			object.OwnedByDesc = OwnedByDesc;
		},
	});
});