sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ss/utils/js/UserMapping",
	"sap/m/MessageToast"
], function (Controller, oPPCCommon, oSSCommonValueHelp, oSSCommon, oSSUserMapping, MessageToast) {
	"use strict";
	var oi18n = "",
		oUtilsI18n = "";
	var statusOfTest = false;
	var busyDialog = new sap.m.BusyDialog();

	return Controller.extend("com.arteriatech.ss.cp.create1.controller.DeliverySchedules", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.beat.create1.view.SSBeatItemEdit
		 */
		onInit: function () {
			this.onInitHookup();
		},
		onInitHookup: function () {
			gDeliverySchedulesView = this.getView();
			// oPPCCommon.initMsgMangerObjects();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gDeliverySchedulesView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.setDefaultSettings();
			this.setCPScheduleDetails();

			if (this.onInitHookup_Exit) {
				this.onInitHookUp_Exit();
			}

		},
		setCPScheduleDetails: function () {
			var CPSchedule = [{
				MonSelected: false,
				TueSelected: false,
				WedSelected: false,
				ThurSelected: false,
				FriSelected: false,
				SatSelected: false,
				SunSelected: false
			}];
			var oJSONData = new sap.ui.model.json.JSONModel();
			oJSONData.setData(CPSchedule);
			gDeliverySchedulesView.setModel(oJSONData, "CPScheduleDetails");
		},
		onChangeFrequency: function () {
			this.setCPScheduleDetails();
		},
		setDefaultSettings: function () {
			var LocalViewSetting = {
				RSTableRowCount: 1,
				ScheduleTableVisible: true
			};
			var oJSOMModel = new sap.ui.model.json.JSONModel();
			oJSOMModel.setData(LocalViewSetting);
			gDeliverySchedulesView.setModel(oJSOMModel, "LocalViewSettingDtlSchedule");
		},

		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		onChangeMonday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = true;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].MonSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].MonSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeTuesday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = true;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].TueSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].TueSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeWednesday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = true;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].WedSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].WedSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeThursday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = true;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].ThurSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].ThurSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeFriday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = true;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].FriSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].FriSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeSaturday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = true;
					CPSchedules[0].SunSelected = false;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].SatSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].SatSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		onChangeSunday: function (oEvent) {
			var isSelected = oEvent.getSource().getSelected();
			var CPSchedules = gDeliverySchedulesView.getModel("CPScheduleDetails").getData();
			var count = this.numberOfDaysSelected(CPSchedules);
			var oFreqSelected = this._oComponent.getModel("CPDMSDivisionsTemp").getProperty("/0/FreqOfDispatch");
			if (isSelected) {
				if (oFreqSelected === "000001" || oFreqSelected === "000004") {
					CPSchedules[0].MonSelected = false;
					CPSchedules[0].TueSelected = false;
					CPSchedules[0].WedSelected = false;
					CPSchedules[0].ThurSelected = false;
					CPSchedules[0].FriSelected = false;
					CPSchedules[0].SatSelected = false;
					CPSchedules[0].SunSelected = true;
				}
				if (oFreqSelected === "000002") {
					if (!(count <= 2)) {
						CPSchedules[0].SunSelected = false;
						this.showMessageToast("2");
					}
				}
				if (oFreqSelected === "000003") {
					if (!(count <= 3)) {
						CPSchedules[0].SunSelected = false;
						this.showMessageToast("3");
					}
				}
			}

		},
		numberOfDaysSelected: function (CPSchedules) {
			var count = 0;
			if (CPSchedules[0].MonSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].TueSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].WedSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].ThurSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].FriSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].SatSelected) {
				count = count + 1;
			}
			if (CPSchedules[0].SunSelected) {
				count = count + 1;

			}
			return count;
		},
		showMessageToast: function (days) {
			var message = oi18n.getText("CPDetail.Schedule.CPDetail.Column.CantSelect", days);
			MessageToast.show(message);
		}
	})
});