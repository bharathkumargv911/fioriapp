jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/CommonValueHelp"
], function (Controller, oSSCommonValueHelp) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var contextPath = "";

	return Controller.extend("com.arteriatech.ss.cp.create1.controller.CPDetailClassficationChannales", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailClassficationChannales
		 */
		onInit: function () {
			this.onInitialHookUps();
		},

		onInitialHookUps: function () {
			gDMSDivisions = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.router = sap.ui.core.UIComponent.getRouterFor(this);

			this.setValueHelpProperty();
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},

		setValueHelpProperty: function () {
			/*this.routeTokenInput = this.getView().byId("fRouteIDEdit");
			this.aRouteKeys = ["ID", "Description"];
			
			this.DMSDivisionTokenInput = this.getView().byId("fDMSDivisionEdit");
			this.aDMSDivisionKeys = ["ID", "Description"];*/

			if (this.setValueHelpProperty_Exit) {
				this.setValueHelpProperty_Exit();
			}
		},

		//Route
		RouteF4: function (oEvent) {
			this.ObjectPageLayout = gCPDetailView.byId("ObjectPageLayout");
			var view = this.getView();
			oPPCCommon.removeAllMsgs();
			var errorCount = 0;
			sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();

			if (gBasicDataBlock.byId("fStateIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(view, "fStateIDEdit", oi18n.getText(
					"common.message.pleaseEnterValid", gBasicDataBlock.byId("lStateIDEdit").getText()));
				errorCount++;
			}
			if (gBasicDataBlock.byId("fDistrictIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(view, "fDistrictIDEdit", oi18n.getText(
					"common.message.pleaseEnterValid", gBasicDataBlock.byId("lDistrictIDEdit").getText()));
				errorCount++;
			}
			if (gBasicDataBlock.byId("fTownIDEdit").getTokens().length === 0) {

				sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").addErrorMessages(view, "fTownIDEdit", oi18n.getText(
					"common.message.pleaseEnterValid", gBasicDataBlock.byId("lTownIDEdit").getText()));
				errorCount++;
			}
			if (errorCount !== 0) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(this.ObjectPageLayout);
			} else {

				this.routeTokenInput = oEvent.getSource();
				oSSCommonValueHelp.setValueHelp({
					title: "Route",
					oController: this,
					controlID: "fRouteIDEdit",
					parentID: oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock,
						"fDistrictIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fTownIDEdit"),
					idLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.routeID"),
					descriptionLabel: oi18n.getText("ChannelPartnerCreate.ValueHelp.routeDesc"),
					oUtilsI18n: oUtilsI18n,
					modelID: "SSGW_MST",
					entityType: "ChannelPartner",
					propName: "RouteID",
					tokenInput: this.routeTokenInput,
					aKeys: this.aRouteKeys,
					defaultVisible: true,
					defaultLabel: "Town",
					defaultText: oPPCCommon.getTextFromTokens(gBasicDataBlock, "fTownIDEdit"),
					idVisible: false,
					groupTitle: "Town",
					fireOnLoad: true
				});
			}

			if (this.RouteF4_Exit) {
				this.RouteF4_Exit();
			}
		},

		AddClissificationChannels: function () {
			oPPCCommon.removeAllMsgs();
			var key = gBasicDataBlock.byId("Customer").getSelectedKey();
			var msgBox = sap.m.MessageBox;
			if (gBasicDataBlock.byId("Customer")) {
				if (key === "" || key === undefined || key === null) {
					msgBox.show(oi18n.getText("common.message.pleaseEnter",
						gBasicDataBlock.byId("customer").getText()));
					return false;
				}
			}
			gCPDetailView.oController.validateChannelClassification();
			if (oPPCCommon.doErrMessageExist()) {
				this.router.navTo("TaxCreate", {}, false);
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(gDynamicSideContent);
			}

			if (this.AddClissificationChannels_Exit) {
				this.AddClissificationChannels_Exit();
			}
		},

		setCPDMSDIVISIONTaxes: function (oData) {
			var aData = [];
			var taxItems = [];
			for (var i = 0; i < oData.length; i++) {

				if (oData[i].CPDMSDivisionTaxes.length === 0) {
					aData.push({

						"CPTaxGUID": oPPCCommon.generateUUID(),
						"CP1GUID": oData[i].CP1GUID,
						"DMSDivision": "",
						"DMSDIvisionDesc": "",
						"StatusID": "01",
						"TaxCategoryID": "",
						"TaxCategoryDesc": "",
						"TaxClassificationID": "",
						"TaxClassificationDesc": ""
					});
					oData[i].CPDMSDivisionTaxes = aData;
					taxItems.push(oData[i].CPDMSDivisionTaxes[0]);
				} else {
					taxItems.push(oData[i].CPDMSDivisionTaxes[0]);
				}

			}
			var oCPDMSDivisionTaxesModel = new sap.ui.model.json.JSONModel();

			oCPDMSDivisionTaxesModel.setData(taxItems);
			this._oComponent.setModel(oCPDMSDivisionTaxesModel, "CPDMSDivisionTaxes");

			this.getView().getModel("LocalViewSettingDtl").setProperty("/TaxCatItemsCount", oData.length);

		},

		DeleteClissificationChannels: function (oEvent) {

			this.ObjectPageLayout = gCPDetailView.byId("ObjectPageLayout");

			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("CPDMSDivisions").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));

			var oTable = gDMSDivisions.byId("CLASSIFICATIONCHANNELSTABLEEdit")
			if (oTable) {
				var aRows = oTable.getRows();
				for (var row = idx + 1; row < aRows.length; row++) {
					var aCells = aRows[row].getCells();
					var prevRow = aRows[row - 1].getCells();
					for (var cell = 0; cell < aCells.length; cell++) {
						var cellId = aCells[cell].getId();
						var prevRowCellID = prevRow[cell].getId();
						if (cellId.indexOf("fGroup3Edit") > -1) {
							if (gDMSDivisions.byId(prevRowCellID).getModel("Group3DD")) {
								gDMSDivisions.byId(prevRowCellID).getModel("Group3DD").setData([]);
							}
							if (gDMSDivisions.byId(cellId).getModel("Group3DD")) {
								if (gDMSDivisions.byId(prevRowCellID).getModel("Group3DD")) {
									gDMSDivisions.byId(prevRowCellID).getModel("Group3DD").setData(gDMSDivisions.byId(cellId).getModel("Group3DD").getData());
								} else {
									var oModel = new sap.ui.model.json.JSONModel();
									oModel.setData(gDMSDivisions.byId(cellId).getModel("Group3DD").getData());
									gDMSDivisions.byId(prevRowCellID).setModel(oModel, "Group3DD");
								}
								gDMSDivisions.byId(cellId).getModel("Group3DD").setData([])
							}
						}
					}
				}
			}

			//Remove Row from model
			var oItemModel = this.getView().getModel("CPDMSDivisions");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}

			//Update MessagManager message count 
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);

			//If no errors in message manager, hide popover
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			//Update Table count
			var iTotalLength = this.getView().getModel("CPDMSDivisions").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TableRowCountClassification", iTotalLength);
			}
			this.setCPDMSDIVISIONTaxes(oItemModelData);

			if (this.DeleteClissificationChannels_Exit) {
				this.DeleteClissificationChannels_Exit();
			}

		},
		DMSDivisionF4: function (oEvent) {
			this.DMSDivisionTokenInput = oEvent.getSource();

			var that = this;

			oSSCommonValueHelp.setValueHelp({
				title: "DMS Division",
				oController: this,
				controlID: "fRouteIDEdit",
				parentID: oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fStateIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock,
					"fDistrictIDEdit") + "/" + oPPCCommon.getKeysFromTokens(gBasicDataBlock, "fTownIDEdit"),
				idLabel: "DMS Division",
				descriptionLabel: "Description",
				oUtilsI18n: oUtilsI18n,
				modelID: "SSGW_MST",
				entityType: "ChannelPartner",
				propName: "DMSDiv",
				tokenInput: this.DMSDivisionTokenInput,
				aKeys: this.aDMSDivisionKeys,
				defaultVisible: false,
				defaultLabel: "",
				defaultText: oPPCCommon.getTextFromTokens(gBasicDataBlock, "fTownIDEdit"),
				idVisible: true,
				groupTitle: "DMS Division",
				fireOnLoad: true
			});
			if (this.DMSDivisionF4_Exit) {
				this.DMSDivisionF4_Exit();
			}
		},

		Group2DD: function (oEvent) {
			this.setDDDesciption(oEvent);
			var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();

			var view = gCPDetailView;
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP2"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);

			// var obj = this.getView().byId(oEvent.getSource().getId().replace("fGroup1Edit", "fGroup2Edit").replace("col2", "col3"));
			var obj = "",
				objGroup3 = "";
			var aCells = [];
			aCells = oEvent.getSource().getParent().getCells();
			for (var i = 0; i < aCells.length; i++) {
				if (aCells[i].getId() && aCells[i].getId().indexOf("fGroup2Edit") >= 0) {
					obj = this.getView().byId(aCells[i].getId());
				} else if (aCells[i].getId() && aCells[i].getId().indexOf("fGroup3Edit") >= 0) {
					objGroup3 = this.getView().byId(aCells[i].getId());
				}
			}
			if (obj.getModel("Group2DD")) {
				obj.getModel("Group2DD").setProperty("/", []);
			}
			obj.setProperty("selectedKey", "");
			obj.setTooltip("");
			// var objGroup3 = this.getView().byId(oEvent.getSource().getId().replace("fGroup1Edit", "fGroup3Edit").replace("col2", "col4"));
			if (objGroup3.getModel("Group3DD")) {
				objGroup3.getModel("Group3DD").setProperty("/", []);
			}
			objGroup3.setProperty("selectedKey", "");
			objGroup3.setTooltip("");
			if (id !== "" && id.trim() !== "") {
				oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj,
					"Group2DD", "Select",
					function () {
						// busyDialog.close();
						gCPDetailView.setBusy(false);
					}, true, "PD", true);
			}
			if (this.Group2DD_Exit) {
				this.Group2DD_Exit();
			}
		},

		Group3DD: function (oEvent) {
			this.setDDDesciption(oEvent);
			var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();

			var view = gCPDetailView;
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP3"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);

			// var obj = this.getView().byId(oEvent.getSource().getId().replace("fGroup2Edit", "fGroup3Edit").replace("col3", "col4"));
			var obj = "";
			var aCells = [];
			aCells = oEvent.getSource().getParent().getCells();
			for (var i = 0; i < aCells.length; i++) {
				if (aCells[i].getId() && aCells[i].getId().indexOf("fGroup3Edit") >= 0) {
					obj = this.getView().byId(aCells[i].getId());
				}
			}
			if (obj.getModel("Group3DD")) {
				obj.getModel("Group3DD").setProperty("/", []);
			}
			obj.setProperty("selectedKey", "");
			obj.setTooltip("");
			if (id !== "" && id.trim() !== "") {
				oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj,
					"Group3DD", "Select",
					function () {
						// busyDialog.close();
						gCPDetailView.setBusy(false);
					}, true, "PD", true);
			}

			if (this.Group3DD_Exit) {
				this.Group3DD_Exit();
			}
		},

		setDDDesciption: function (oEvent) {
			var text = oEvent.getSource().getSelectedItem().getText();
			if (text && text.trim() !== "") {
				// var aText = text.split(" - ");
				// if(aText.length > 0) {
				oEvent.getSource().setTooltip(text);
				// }
			} else {
				oEvent.getSource().setTooltip("");
			}

		},

		AddgroupDetails: function (oEvent) {
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(this.DynamicSideContent);
			gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData()
				.length);
			if (this._oComponent.getModel("CPDMSDivisions")) {
				this._oItems4 = jQuery.extend(true, [], this._oComponent.getModel("CPDMSDivisions").getData());
				var CPDMSDivisions = this._oComponent.getModel("CPDMSDivisions").getProperty("/");
			}
			var index = oEvent.getSource().getBindingContext("CPDMSDivisions").getPath().split("/")[1];

			var CPDMSDivisionsItems = this._oComponent.getModel("CPDMSDivisions").getProperty("/")[index];
			var aData = [];
			aData.push(CPDMSDivisionsItems);
			var oCPDMSDivisionsItemsDataModel = new sap.ui.model.json.JSONModel();
			oCPDMSDivisionsItemsDataModel.setData(aData);
			this._oComponent.setModel(oCPDMSDivisionsItemsDataModel, "CPDMSDivisionsTemp");
			// this.addCPScheduleDayModel(CPDMSDivisionsItems); // set CpSchedules data model
			this.router.navTo("TaxEdit", {}, false);

		},
		addCPScheduleDayModel: function (CPDMSDivisionsItems) {
			var Day1 = false;
			var Day2 = false;
			var Day3 = false;
			var Day4 = false;
			var Day5 = false;
			var Day6 = false;
			var Day7 = false;
			if (CPDMSDivisionsItems.Day1 === "X") {
				Day1 = true;
			}
			if (CPDMSDivisionsItems.Day2 === "X") {
				Day2 = true;
			}
			if (CPDMSDivisionsItems.Day3 === "X") {
				Day3 = true;
			}
			if (CPDMSDivisionsItems.Day4 === "X") {
				Day4 = true;
			}
			if (CPDMSDivisionsItems.Day5 === "X") {
				Day5 = true;
			}
			if (CPDMSDivisionsItems.Day6 === "X") {
				Day6 = true;
			}
			if (CPDMSDivisionsItems.Day7 === "X") {
				Day7 = true;
			}
			var aJSONData = [{
				MonSelected: Day1,
				TueSelected: Day2,
				WedSelected: Day3,
				ThurSelected: Day4,
				FriSelected: Day5,
				SatSelected: Day6,
				SunSelected: Day7
			}];
			var CPSCHedule = new sap.ui.model.json.JSONModel(aJSONData);
			gDeliverySchedulesView.setModel(CPSCHedule, "CPScheduleDetails");
		},
		//Geo
		AddGeo: function (oEvent) {

			var that = this;
			/*this.Content = new com.arteriatech.ss.cp.create1.block.DMSGeo({
				columnLayout: '4',
				formAdjustment: 'BlockColumns'
			});
			var dialog = new sap.m.Dialog({
				title: 'Add Geo',
				type: 'Message',
				content: this.Content,
				contentWidth: '50%',
				beginButton: new sap.m.Button({
					text: 'Save',
					press: function() {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
						// that.saveCP(dialog);
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						sap.ui.controller("com.arteriatech.ss.cp.create1.controller.CPCreate").clearAllErrors();
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});*/

			// create popover
			if (!this._oGeoDialog) {
				this._oGeoDialog = sap.ui.xmlfragment("com.arteriatech.ss.cp.create1.block.DMSGeo", this);
				this.getView().addDependent(this._oGeoDialog);
			}

			// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
			var oButton = oEvent.getSource();
			jQuery.sap.delayedCall(0, this, function () {
				this._oGeoDialog.openBy(oButton);
			});

			var oModel = this.getView().getModel("SSGW_MST");
			this._oGeoDialog.setModel(oModel, "SSGW_MST");

			var oLocalModelModelData = this.getView().getModel("LocalViewSettingDtl").getProperty("/");
			var oViewSettingModel = new sap.ui.model.json.JSONModel(oLocalModelModelData);
			this._oGeoDialog.setModel(oViewSettingModel, "LocalViewSettingDtl");

			var oOwnDataModelData = this.getView().getModel("OwnData").getProperty("/");
			var oOwnDataModel = new sap.ui.model.json.JSONModel(oOwnDataModelData);
			this._oGeoDialog.setModel(oOwnDataModel, "OwnData");

			var CPGUID = null,
				Name = "",
				CPTypeID = "",
				CPTypeDesc = "";
			if (that.getView().getModel("Customers")) {
				CPGUID = that.getView().getModel("Customers").getProperty("/0/CPGUID");
				Name = that.getView().getModel("Customers").getProperty("/0/Name");
				CPTypeID = that.getView().getModel("Customers").getProperty("/0/CPTypeID");
				CPTypeDesc = that.getView().getModel("Customers").getProperty("/0/CPTypeDesc");
			}

			// this._oGeoDialog.open();

			if (this.AddGeo_Exit) {
				this.AddGeo_Exit();
			}

		}

		/*DMSDivision: function(mParameters, requestCompleted) {
			if (mParameters.controlID === undefined || mParameters.controlID === null) {
				mParameters.controlID = "fDMSDivisionEdit";
			}
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.oi18n.getText("List.ValueHelp.DMSDivision.Header"),
				supportMultiselect: false,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.oController.aDMSDivisionKeys[0],
				descriptionKey: mParameters.oController.aDMSDivisionKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function(oControlEvent) {
					mParameters.oController.DMSDivisionTokenInput.setTokens(oControlEvent.getParameter("tokens"));
					// gPartnerMgrGUID = oControlEvent.getParameter("tokens")[0].getCustomData()[0].getValue().SPGUID;
					//	gCPDetailView.getModel("ChannelPartners").setProperty("/PartnerMgrGUID",spguid);
					mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
					mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
					if (requestCompleted) {
						requestCompleted(mParameters.tokenInput.getTokens());
					}

					oValueHelpDialog.close();
				},
				cancel: function(oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function() {
					oValueHelpDialog.destroy();
				}
			});
			this.DMSDivisionF4Columns(oValueHelpDialog, mParameters);
			this.DMSDivisionF4FilterBar(oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
		},
		DMSDivisionF4Columns: function(oValueHelpDialog, mParameters) {

			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: "DMSDivision",
				template: new sap.m.Text({
					text: "{DMSDivision}"
				}),
				sortProperty: "DMSDivision",
				filterProperty: "DMSDivision"
			}));
			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: "DMSDivisionDesc",
				template: new sap.m.Text({
					text: "{DMSDivisionDesc}"
				}),
				sortProperty: "DMSDivisionDesc",
				filterProperty: "DMSDivisionDesc"
			}));

			oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoItemSelected"));
		},
		DMSDivisionF4FilterBar: function(oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var firstName = new sap.m.Input({
				value: mParameters.oController.DMSDivisionTokenInput.getValue()
			});
			var lastName = new sap.m.Input({
				value: mParameters.oController.DMSDivisionTokenInput.getValue()
			});

			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "DMSDivision",
						groupName: "gn1",
						name: "n1",
						label: "DMSDivision",
						control: firstName
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "DMSDivision",
						groupName: "gn1",
						name: "n2",
						label: "DMSDivisionDesc",
						control: lastName
					})

				],
				search: function(oEvent) {

					var salesPersonFilterArray = new Array();
					salesPersonFilterArray = oPPCCommon.setODataModelReadFilter("", "", salesPersonFilterArray, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
						sServiceName: "DMSDivisions",
						sRequestType: "read"
					})], false, false, false);

					salesPersonFilterArray = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(),
						"", salesPersonFilterArray, "DMSDivision", "", [firstName.getValue()], false, false, false);
					salesPersonFilterArray = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(),
						"", salesPersonFilterArray, "DMSDivisionDesc", "", [lastName.getValue()], false, false, false);

					var SSGW_MSTModel = mParameters.oController._oComponent.getModel("SSGW_MST");
					SSGW_MSTModel.attachRequestSent(function() {
						busyDialog.open();
					});
					SSGW_MSTModel.attachRequestCompleted(function() {
						busyDialog.close();
					});
					SSGW_MSTModel.read("/CPDMSDivisions", {
						filters: salesPersonFilterArray,
						urlParameters: {
							"$select": "DMSDivision,DMSDivisionDesc"
						},
						success: function(oData) {

							var oModel = new sap.ui.model.json.JSONModel();
							oModel.setData(oData.results);
							oValueHelpDialog.getTable().setModel(oModel);
							oValueHelpDialog.getTable().bindRows("/");
							if (oData.results.length === 0) {
								oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
								oPPCCommon.dialogErrorMessage("No Data", "No Records Found");
							}
						},
						error: function(error) {
							if (oValueHelpDialog.getTable().getModel() !== undefined) {
								oValueHelpDialog.getTable().getModel().setProperty("/", {});
							}

							oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
							oPPCCommon.dialogErrorMessage(error, "No Records Found");
						}
					});
				},
				reset: function() {

				}
			}));
		}*/

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailClassficationChannales
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailClassficationChannales
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.cp.create1.view.CPDetailClassficationChannales
		 */
		//	onExit: function() {
		//
		//	}

	});

});