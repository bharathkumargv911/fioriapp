jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
jQuery.sap.require("com.arteriatech.ss.utils.js.Common");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/CommonValueHelp"
], function (Controller) {
	"use strict";
	var oi18n, oUtilsI18n;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var busyDialog = new sap.m.BusyDialog();

	return Controller.extend("com.arteriatech.ss.cp.create1.controller.TaxClassification", {
		onInit: function () {
			this.onInitialHookUps();
		},

		onInitialHookUps: function () {
			gTaxClassificationView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gCPDetailTaxClassification));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.getDropDowns();
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},
		getDropDowns: function () {
			this.TaxCategoryDD();
			// this.Group1DD();
			// this.Group4DD();
			// this.Group5DD();
			// this.Group6DD();
			// this.Group7DD();
			// this.Group8DD();
			// this.Group9DD();
			// this.Group10DD();
			// this.distanceUOMDD();
			// this.BillSeriesDD();
			this.DMSDivisionDD();
		},
		BillSeriesDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPBILS"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"BillSeriesDD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.BillSeriesDD_Exit) {
				this.BillSeriesDD_Exit();
			}
		},
		Group6DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP6"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group6DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group7DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP7"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group7DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group8DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP8"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group8DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group9DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP9"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group9DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		Group10DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGR10"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group10DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		distanceUOMDD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPDFUM"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"DstnceFromPUOMDD", "",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		SalesPersonDD: function (CPGUID, CPTypeId, DmsDivision) {
			// busyDialog.open();
			var that = this;
			var view = this.getView();
			var oModelData = this._oComponent.getModel("SSGW_MST");
			var oSalesGroupFilter = new Array();
			var dmsDivision = DmsDivision;
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "CPGUID", sap.ui
				.model.FilterOperator.EQ, [
					CPGUID
				], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "CPTypeID", sap.ui
				.model.FilterOperator.EQ, [
					CPTypeId
				], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "DMSDivision", sap.ui
				.model.FilterOperator.EQ, [
					DmsDivision
				], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "StatusID", sap.ui
				.model.FilterOperator.EQ, [
					"01"
				], false, false, false);
			this.getDropDown(oModelData, "SalesPersons", oSalesGroupFilter, "SPGUID", "FirstName", busyDialog, view,
				"SalesPersonDD", "Select",
				function () {
					that.getView().setBusy(false);
					// busyDialog.close();
					//gCPDetailView.setBusy(false);
				}, true, "PD", true, "SPNo");

			if (this.SalesPersonDD_Exit) {
				this.SalesPersonDD_Exit();
			}

		},
		Group4DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP4"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group4DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group4DD_Exit) {
				this.Group4DD_Exit();
			}
		},
		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		Group5DD: function () {
			// busyDialog.open();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, [
				"CPGRP5"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "LoginID", "", [this.getCurrentUsers(
				"ConfigTypesetTypes", "read")], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", busyDialog, this.getView(),
				"Group5DD", "Select",
				function () {
					// busyDialog.close();
				}, true, "PD", true);

			if (this.Group5DD_Exit) {
				this.Group5DD_Exit();
			}
		},
		Group1DD: function () {
			// busyDialog.open();
			var that = this;
			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP1"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"Group1DD", "Select",
				function () {
					// busyDialog.close();
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.Group1DD_Exit) {
				this.Group1DD_Exit();
			}
		},
		Group2DD: function (oEvent) {
			busyDialog.open();
			this.setDDDesciption(oEvent);

			oEvent.getSource().setValueState(null);
			oEvent.getSource().setValueStateText("");

			var Group1 = oEvent.getSource().getSelectedKey();
			var Group1Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group1Desc) {
				Group1Desc = Group1Desc.split("-")[1];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group1", Group1);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group1Desc", Group1Desc);

			var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
			var that = this;

			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP2"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);

			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"Group2DD", "Select",
				function () {
					busyDialog.close();
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.Group2DD_Exit) {
				this.Group2DD_Exit();
			}
		},

		Group3DD: function (oEvent) {
			this.setDDDesciption(oEvent);
			busyDialog.open();
			var Group2 = oEvent.getSource().getSelectedKey();
			var Group2Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group2Desc) {
				Group2Desc = Group2Desc.split("-")[1];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group2", Group2);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group2Desc", Group2Desc);

			var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
			var that = this;

			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CPGRP3"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);

			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"Group3DD", "Select",
				function (aData) {
					busyDialog.close();
					if (aData.length === 0) {
						that.getView().getModel("Group3DD").setProperty("/", aData);
					}
					that.getView().setBusy(false);
				}, false, "PD", true);

			if (this.Group3DD_Exit) {
				this.Group3DD_Exit();
			}
		},
		// onGroup6: function (oEvent) {
		// 	var Group = oEvent.getSource().getSelectedKey();
		// 	var GroupDesc = oEvent.getSource().getSelectedItem().getText();
		// 	if (GroupDesc) {
		// 		GroupDesc = GroupDesc.split("-")[1];
		// 	}
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group6", Group);
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group6Desc", GroupDesc);
		// },
		// onGroup7: function (oEvent) {
		// 	var Group = oEvent.getSource().getSelectedKey();
		// 	var GroupDesc = oEvent.getSource().getSelectedItem().getText();
		// 	if (GroupDesc) {
		// 		GroupDesc = GroupDesc.split("-")[1];
		// 	}
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group7", Group);
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group7Desc", GroupDesc);
		// },
		// onGroup8: function (oEvent) {
		// 	var Group = oEvent.getSource().getSelectedKey();
		// 	var GroupDesc = oEvent.getSource().getSelectedItem().getText();
		// 	if (GroupDesc) {
		// 		GroupDesc = GroupDesc.split("-")[1];
		// 	}
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group8", Group);
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group8Desc", GroupDesc);
		// },
		// onGroup9: function (oEvent) {
		// 	var Group = oEvent.getSource().getSelectedKey();
		// 	var GroupDesc = oEvent.getSource().getSelectedItem().getText();
		// 	if (GroupDesc) {
		// 		GroupDesc = GroupDesc.split("-")[1];
		// 	}
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group9", Group);
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group9Desc", GroupDesc);
		// },
		// onGroup10: function (oEvent) {
		// 	var Group = oEvent.getSource().getSelectedKey();
		// 	var GroupDesc = oEvent.getSource().getSelectedItem().getText();
		// 	if (GroupDesc) {
		// 		GroupDesc = GroupDesc.split("-")[1];
		// 	}
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group10", Group);
		// 	this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group10Desc", GroupDesc);
		// },
		setDDDesciption: function (oEvent) {
			var text = oEvent.getSource().getSelectedItem().getText();
			if (text && text.trim() !== "") {
				// var aText = text.split(" - ");
				// if(aText.length > 0) {
				oEvent.getSource().setTooltip(text);
				// }
			} else {
				oEvent.getSource().setTooltip("");
			}

		},
		DMSDivisionDD: function (oEvent) {
			// busyDialog.open();
			var view = this.getView();

			var oModelData = this._oComponent.getModel("PCGW");
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["DMSDiv"], false, false, false);

			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", busyDialog, view,
				"DMSDivisionDD", "Extend To All",
				function () {
					// busyDialog.close();
					gTaxClassificationView.setBusy(false);

				}, false, "PD", true);

			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}

		},
		TaxCategoryDD: function () {
			// busyDialog.open();
			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oTaxCategoryFilter = new Array();
			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["TaxCategory"], false, false, false);

			oTaxCategoryFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxCategoryFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			oSSCommon.getDropdown(oModelData, "ValueHelps", oTaxCategoryFilter, "ID", "Description", busyDialog, view,
				"TaxCategoryDD", "Select",
				function (aData) {
					view.setBusy(false);
					if (aData.length === 0) {
						if (gTaxClassificationView.getModel("TaxClassificationDD")) {
							gTaxClassificationView.getModel("TaxClassificationDD").setData([]);
						}
					}

				}, false, "PD", true);

			if (this.DMSDivisionDD_Exit) {
				this.DMSDivisionDD_Exit();
			}

		},

		routeF4: function () {
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			var that = this;
			this.RourTokenInput = this.getView().byId("fRouteID");
			//        this.aMaterialKeys = [
			//            "MaterialNo",
			//            "MaterialDesc"
			//        ];
			var sCPParentCode = that._oComponent.getModel("ChannelPartners").getProperty("/ParentID");

			if (!sCPParentCode) {
				MessageBox.error(
					"Please Select Customer "

				);
			} else {
				this.ChannelPartenerF4({
					oController: that,
					oi18n: oi18n,
					sCPParentCode: that._oComponent.getModel("ChannelPartners").getProperty("/ParentID"),
					sCPParentName: that._oComponent.getModel("LocalViewSettingDtl").getProperty("/Name"),
					oUtilsI18n: oUtilsI18n,
					controlID: "fRouteID",
					bMultiSelect: false
				}, function (tokens) {
					that.RourTokenInput.removeAllTokens();
					for (var j = 0; j < tokens.length; j++) {
						if (tokens[j].mProperties.key) {
							var oToken = new sap.m.Token({
								key: tokens[0].getCustomData()[0].getValue().RouteSchGUID,
								text: tokens[0].getCustomData()[0].getValue().Description + "(" + tokens[0].getCustomData()[0].getValue().RoutId + ")"
							});
							that.RourTokenInput.addToken(oToken);
							that.RourTokenInput.setValueState("None");
							that.RourTokenInput.setValueStateText("");
							that.RourTokenInput.setTooltip(tokens[j].mProperties.text);
							gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/oRouteguid", tokens[0].getCustomData()[0].getValue().RouteSchGUID);
							gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/oRouteId", tokens[0].getCustomData()[0].getValue().RoutId);
							gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/oRouteDesc", tokens[0].getCustomData()[0].getValue().Description);
							gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/SP", tokens[0].getCustomData()[0].getValue().SalesPersonID);
							gCPDetailView.getModel("LocalViewSettingDtl").setProperty("/SPName", tokens[0].getCustomData()[0].getValue().SalesPersonName);
						}
					}

					// var oToken = new sap.m.Token({
					// 	text: tokens[0].getCustomData()[0].mProperties.value.Text + "(" + tokens[0].getCustomData()[0].mProperties.value.RoutId + ")"
					// });
					var RoutId = tokens[0].mAggregations.customData[0].mProperties.value.RoutId;
					var Description = tokens[0].getCustomData()[0].getValue().Description;
					that.getView().getModel("ChannelPartners").setProperty("/RouteID", RoutId);
					that.getView().getModel("ChannelPartners").setProperty("/RouteDesc", Description);

				});
			}
		},
		ChannelPartenerF4: function (mParameters, requestCompleted) {

			if (mParameters.bMultiSelect === undefined || mParameters.bMultiSelect === null) {
				mParameters.bMultiSelect = true;
			}
			var sF4Heading = "Beat";

			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({

				title: sF4Heading,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: "RoutId",
				descriptionKey: "RouteTypDesc",
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					var tokens = oControlEvent.getParameter("tokens");

					// var oToken = tokens;
					// for (var i = 0; i < oToken.length; i++) {
					// 	var Text1 = oToken[i].mProperties.text.split("(")[0].trim();
					// 	Text = oToken[i].getCustomData()[0].mProperties.value.RoutId;
					// 	oToken[i].mProperties.text = Text + " (" + Text1 + ")";
					// 	oToken[i].setTooltip(Text + " (" + Text1 + ")");
					// }

					if (requestCompleted) {
						requestCompleted(tokens);
					}
					oValueHelpDialog.close();
				},
				cancel: function (oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			if (mParameters.showSelectedItemPanel === undefined || mParameters.showSelectedItemPanel) {
				if (oValueHelpDialog.getAggregation("content").length > 0) {
					if (oValueHelpDialog.getAggregation("content")[0].getAggregation("items").length > 2) {
						if (oValueHelpDialog.getAggregation("content")[0].getAggregation("items")[2].getAggregation("content").length > 0) {
							oValueHelpDialog.getAggregation("content")[0].getAggregation("items")[2].getAggregation("content")[0].setVisible(false);
						}
					}
				}
			}

			this.RouteF4Columns(oValueHelpDialog, mParameters);
			this.RouteF4FilterBar(oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
			if (mParameters.oController.CPTokenInput) {
				oValueHelpDialog.setTokens(mParameters.oController.CPTokenInput.getTokens());
			}

			if (this.ChannelPartenerF4_Exit) {
				this.ChannelPartenerF4_Exit(mParameters, requestCompleted);
			}
		},
		RouteF4Columns: function (oValueHelpDialog, mParameters) {
			var parentlabel = "",
				CPNoLabel = "Route ID",
				nameLabel = "Frequency Type",
				cpTypeLabel = "";
			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: new sap.m.Text({
					text: parentlabel
				}),
				template: new sap.m.Text({
					text: "{RoutId}"
				}),
				sortProperty: "RoutId",
				filterProperty: "RoutId"
			}));
			if (!mParameters.bCustomerDD) {
				if (mParameters.sCPParentCode === "") {
					oValueHelpDialog.getTable().getColumns()[0].setVisible(true);
				} else {
					oValueHelpDialog.getTable().getColumns()[0].setVisible(false);
				}
			}
			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: new sap.m.Text({
					text: CPNoLabel
				}),
				template: new sap.m.Text({
					text: "{Description} ({RoutId})"
				}),
				sortProperty: "RoutId",
				filterProperty: "RoutId"

			}));
			oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
				label: new sap.m.Text({
					text: nameLabel
				}),
				template: new sap.m.Text({
					text: "{RouteTypDesc}"
				}),
				sortProperty: "RouteTypDesc",
				filterProperty: "RouteTypDesc"
			}));
			oValueHelpDialog.getTable().setNoData(
				mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			if (this.ChannelPartenerF4Columns_Exit) {
				this.ChannelPartenerF4Columns_Exit(oValueHelpDialog, mParameters);
			}
		},
		RouteF4FilterBar: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var CPType = "";
			var parentlabel = "Customer",
				CPNoLabel = "Beat ID",
				nameLabel = "",
				cpTypeLabel = "";
			// var cpTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
			// 	groupName: "gn2",
			// 	name: "n6",
			// 	label: "",
			// 	control: new sap.m.Text({
			// 		text: ""
			// 	})
			// });
			var oTokenInputValue = "";
			if (mParameters.oController.CPTokenInput) {
				oTokenInputValue = mParameters.oController.CPTokenInput.getValue();
			}
			var code = new sap.m.Input({
				value: {
					path: "ChannelPartenerF4FilterBar>/ID",

					constraints: {
						search: '^[0-9*]+$'
					}
				}
			});
			var RouteDescription = new sap.m.Input({
				value: {
					path: "Routef4filterbar>/RouteDescription",
					type: 'sap.ui.model.type.String',
					constraints: {
						search: '^[A-Za-z*]+$'
					}
				}
				// maxLength: oPPCCommon.getMaxLengthFromMetadata({
				// 	oDataModel: mParameters.oController.getView().getModel("SFGW_SP"),
				// 	sEntityType: "RouteSchedule",
				// 	sPropertyName: "Description",
				// 	oUtilsI18n: mParameters.oUtilsI18n
				// })
			});

			RouteDescription.attachValidationError(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setValueState("Error");
				if (oElement.getValue().trim() === "") {
					oElement.setTooltip("");
					oElement.setValueState("None");
				}
			});

			RouteDescription.attachValidationSuccess(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setTooltip("");
				oElement.setValueState("None");
			});
			code.attachValidationError(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setValueState("Error");
				if (oElement.getValue().trim() === "") {
					oElement.setTooltip("");
					oElement.setValueState("None");
				}
			});
			code.attachValidationSuccess(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setTooltip("");
				oElement.setValueState("None");
			});

			if (mParameters.bCPType !== undefined && mParameters.bCPType !== "") {
				if (mParameters.bCPType) {
					var oCPTypeItemTemplate = new sap.ui.core.Item({
						key: "{Key}",
						text: "{Key}{Seperator}{Text}",
						tooltip: "{Key}{Seperator}{Text}"
					});
					CPType = new sap.m.MultiComboBox({
						items: {
							path: "/",
							template: oCPTypeItemTemplate
						}
					});
					CPType.setModel(mParameters.oController.getModel("ChannelPartnerType"));
					cpTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn2",
						name: "n4",
						label: cpTypeLabel,
						control: CPType
					});
				}
			}

			var sCPParentText = "";
			if (mParameters.sCPParentCode) {
				var aCPParentName = mParameters.sCPParentName.split("(");
				if (aCPParentName.length > 1) {
					sCPParentText = mParameters.sCPParentName;
				} else {
					sCPParentText = mParameters.sCPParentName + " (" + mParameters.sCPParentCode + ")";
				}
			} else {
				sCPParentText = mParameters.sCPParentName;
			}

			var CPParentValue = new sap.m.Text({
				text: sCPParentText
			});
			// var sFirstNameLbl = oPPCCommon.getLableFromMetadata({
			// 	oDataModel: mParameters.oController.getView().getModel("SFGW_SP"),
			// 	sEntityType: "RouteSchedule",
			// 	sPropertyName: "Description",
			// 	oUtilsI18n: mParameters.oUtilsI18n
			// });

			var sFirstNameLbl = "Route";
			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn1",
						name: "n1",
						label: parentlabel,
						control: CPParentValue
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupTitle: "",
						groupName: "gn1",
						name: "n2",
						label: sFirstNameLbl,
						control: RouteDescription
					})
					// new sap.ui.comp.filterbar.FilterGroupItem({
					// 	groupName: "gn1",
					// 	name: "n1",
					// 	label: CPNoLabel,
					// 	control: code
					// }),
				],
				search: function (oEvent) {
					var that = this;
					var codeValue = code.getValue();
					// var isMobileValid = true;
					// var isCPNoValid = true;
					// if (codeValue !== "" && codeValue !== undefined) {
					// 	if (isNaN(codeValue)) {}
					// }

					var aCPNoF4Filter = new Array();
					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
						sServiceName: "ChannelPartners",
						sRequestType: "read"
					})], false, false, false);
					var customer = "";
					if (mParameters.bCustomerDD) {
						customer = CPParentValue.getSelectedKey();
					} else {
						customer = mParameters.sCPParentCode;
					}
					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aCPNoF4Filter,
						"Description", sap.ui.model.FilterOperator.cp, [RouteDescription.getValue()], false, false, false);
					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aCPNoF4Filter, "CPGUID", sap
						.ui.model.FilterOperator.EQ, [mParameters.sCPParentCode], false, false, false);
					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aCPNoF4Filter, "ApprovalStatus",
						sap
						.ui.model.FilterOperator.EQ, ["03"], false, false, false);
					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aCPNoF4Filter, "StatusID",
						sap
						.ui.model.FilterOperator.EQ, ["01"], false, false, false);

					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aCPNoF4Filter, "Dmsdivision",
						sap
						.ui.model.FilterOperator.EQ, [mParameters.oController._oComponent.getModel("CPDMSDivisionsTemp").getProperty(
							"/0/DMSDivision")], false, false, false);
					aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aCPNoF4Filter, "SalesPersonID",
						sap
						.ui.model.FilterOperator.EQ, [mParameters.oController._oComponent.getModel("CPDMSDivisionsTemp").getProperty(
							"/0/PartnerMgrGUID")], false, false, false);

					var SFGW_MSTModel = mParameters.oController._oComponent.getModel("SFGW_SP");
					// SFGW_MSTModel.attachRequestSent(function () {
					// 	busyDialog.open();
					// });
					// SFGW_MSTModel.attachRequestCompleted(function () {
					// 	busyDialog.close();
					// });

					SFGW_MSTModel
						.read(
							"/RouteSchedules", {
								filters: aCPNoF4Filter,

								success: function (oData) {
									oData = oPPCCommon.formatItemsOData({
										oData: oData
									});
									for (var i = 0; i < oData.length; i++) {
										if (oData[i].RoutId) {
											//oData[i].ID = parseFloat(oData[i].ID);
											oData[i].RoutId = oData[i].RoutId;
										}
										if (oData[i].RouteTypDesc) {
											oData[i].RouteTypDesc = oData[i].RouteTypDesc;
										}
									}

									// oValueHelpDialog.getTable().clearSelection();

									var CPsModel = new sap.ui.model.json.JSONModel();
									// 	CPsModel.setData(oData);
									// 	oValueHelpDialog.getTable().setModel(CPsModel);
									// 	oValueHelpDialog.getTable().bindRows("/");
									// 	oValueHelpDialog.update();

									// 	if (oData.length === 0) {
									// 		oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									// 	}

									//--------------------------------

									if (oValueHelpDialog.getTable().bindRows) {
										oValueHelpDialog.getTable().clearSelection();
										CPsModel.setData(oData);
										oValueHelpDialog.getTable().setModel(CPsModel);
										oValueHelpDialog.getTable().bindRows("/");
										oValueHelpDialog.update();

										if (oData.length === 0) {
											oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
										}
									} else {
										oValueHelpDialog.getTable().getColumns()[2].setPopinDisplay("Inline");
										//Setting Rows for sap.m.Table....................................
										var oRowsModel = new sap.ui.model.json.JSONModel();
										oRowsModel.setData(oData);
										oValueHelpDialog.getTable().setModel(oRowsModel);
										if (oValueHelpDialog.getTable().bindItems) {
											var oTable = oValueHelpDialog.getTable();
											oTable.bindAggregation("items", "/", function () {
												var aCols = oTable.getModel("columns").getData().cols;
												return new sap.m.ColumnListItem({
													cells: aCols.map(function (column) {
														var colname = column.template;
														return new sap.m.Text({
															text: "{" + colname + "}",
															wrapping: true
														});
													})
												});
											});
										}

										if (oData.length === 0) {
											oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
										}
									}

									//----------------------------------------

								},
								error: function (error) {
									oValueHelpDialog.getTable().clearSelection();
									if (oValueHelpDialog.getTable().getModel() !== undefined) {
										oValueHelpDialog.getTable().getModel().setProperty("/", {});
									}
									oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									oSSCommonValueHelp.dialogErrorMessage(error, "No Data Found");
								}
							});

				},
				reset: function () {

				}
			}));
			var ChannelPartenerF4FilterBarMdl = new sap.ui.model.json.JSONModel();
			ChannelPartenerF4FilterBarMdl.setData({
				ID: "",
				Description: ""
			});
			oValueHelpDialog.setModel(ChannelPartenerF4FilterBarMdl, "ChannelPartenerF4FilterBar");

			if (this.ChannelPartenerF4FilterBar_Exit) {
				this.ChannelPartenerF4FilterBar_Exit(oValueHelpDialog, mParameters);
			}
		},

		onTaxClassificationID: function (oEvent) {
			var index = oEvent.getSource().getBindingContext("CPDMSDivisionTaxes").getPath().split("/")[1];
			var oData = this.getView().getModel("CPDMSDivisionTaxes").getProperty("/");

			oData[index].TaxClassificationID = oEvent.getSource().getSelectedKey();
			oData[index].TaxClassificationDesc = oEvent.getSource().getSelectedItem().getText().split("-")[1];
		},
		onTaxCategory: function (oEvent) {
			var index = oEvent.getSource().getBindingContext("CPDMSDivisionTaxes").getPath().split("/")[1];
			var oData = this.getView().getModel("CPDMSDivisionTaxes").getProperty("/");

			if (this.getView().getModel("TaxClassificationDD")) {
				this.getView().getModel("TaxClassificationDD").setProperty("/", []);
			}
			this.TaxCategory = oEvent.getSource().getSelectedKey();
			oData[index].TaxCategoryID = oEvent.getSource().getSelectedKey();
			oData[index].TaxCategoryDesc = oEvent.getSource().getSelectedItem().getText().split("-")[1];

			this.getView().byId("fTaxClassificationDDEdit").setSelectedKey("");
			this.TaxClassificationDD(this.TaxCategory, oEvent);
		},
		TaxClassificationDD: function (TaxCategory, oEvent) {
			this.setDDDesciption(oEvent);
			var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
			var view = gTaxClassificationView;
			var oModelData = view.getModel("PCGW");
			var oTaxClassificationFilter = new Array();
			oTaxClassificationFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxClassificationFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
			oTaxClassificationFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxClassificationFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
			oTaxClassificationFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxClassificationFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["TaxClassification"], false, false, false);
			oTaxClassificationFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxClassificationFilter, "ParentID", sap.ui
				.model.FilterOperator.EQ, [TaxCategory], false, false, false);

			oTaxClassificationFilter = oPPCCommon.setODataModelReadFilter(view, "", oTaxClassificationFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [this.getCurrentUsers("ValueHelps", "read")], false, false, false);

			var obj = "",
				objClassification = "";
			var aCells = [];
			aCells = oEvent.getSource().getParent().getCells();
			for (var i = 0; i < aCells.length; i++) {
				if (aCells[i].getId() && aCells[i].getId().indexOf("fTaxCategoryEdit") >= 0) {
					obj = this.getView().byId(aCells[i].getId());
				} else if (aCells[i].getId() && aCells[i].getId().indexOf("fTaxClassificationDDEdit") >= 0) {
					objClassification = this.getView().byId(aCells[i].getId());
				}
			}

			if (objClassification.getModel("TaxClassificationDD")) {
				objClassification.getModel("TaxClassificationDD").setProperty("/", []);
			}
			objClassification.setProperty("selectedKey", "");
			objClassification.setTooltip("");
			if (id !== "" && id.trim() !== "") {
				oSSCommon.getDropdown(oModelData, "ValueHelps", oTaxClassificationFilter, "ID", "Description", busyDialog, objClassification,
					"TaxClassificationDD", "None",
					function () {
						// busyDialog.close();

						gTaxClassificationView.setBusy(false);
					}, true, "PD", true);
			}

			if (this.TaxClassificationDD_Exit) {
				this.TaxClassificationDD_Exit();
			}

		},
		addTaxCategory: function (oEvent) {
			var oItemModel = this.getView().getModel("CPDMSDivisionTaxes");
			var oItemModelData = oItemModel.getData();
			var newItem = {
				"CPTaxGUID": oSSCommon.generateUUID(),
				"CP1GUID": oItemModelData[0].CP1GUID,
				"DMSDivision": "",
				"DMSDIvisionDesc": "",
				"StatusID": "",
				"TaxCategoryID": "",
				"TaxCategoryDesc": "",
				"TaxClassificationID": "",
				"TaxClassificationDesc": ""
			};

			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			var HeaderDate = this.getView().getModel("CPDMSDivisionsTemp").getProperty("/");
			HeaderDate[0].CPDMSDivisionTaxes = oItemModelData;
			this.getView().getModel("LocalViewSettingDtl").setProperty("/TaxCatDDVisible", true);
			//Update Table count
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TaxCatItemsCount", oItemModelData.length);
			}
			if (this.addNewItemToBasket_Exit) {
				this.addNewItemToBasket_Exit();
			}
		},
		getNewTaxCat: function () {

			return newItem;

		},
		deleteItem: function (oEvent) {
			var path = oEvent.getSource().getBindingContext("CPDMSDivisionTaxes").getPath();
			this.deleteItemFromPosition(path, oEvent);

			if (this.deleteItem_Exit) {
				this.deleteItem_Exit();
			}
		},
		deleteItemFromPosition: function (path, oEvent) {
			//Remove Row from model
			var oItemModel = this.getView().getModel("CPDMSDivisionTaxes");
			var oItemModelData = oItemModel.getData();
			var CPDMSDivisionTaxesTemp = path.split("/")[1];
			CPDMSDivisionTaxesTemp = parseFloat(CPDMSDivisionTaxesTemp);

			var oTable = this.getView().byId("TaxClassificationTableEdit");

			if (oTable) {
				var aRows = oTable.getRows();
				for (var row = CPDMSDivisionTaxesTemp + 1; row < aRows.length; row++) {
					var aCells = aRows[row].getCells();
					var prevRow = aRows[row - 1].getCells();
					for (var cell = 0; cell < aCells.length; cell++) {
						var cellId = aCells[cell].getId();
						var prevRowCellID = prevRow[cell].getId();
						if (cellId.indexOf("fTaxClassificationDDEdit") > -1) {
							if (this.getView().byId(prevRowCellID).getModel("TaxClassificationDD")) {
								this.getView().byId(prevRowCellID).getModel("TaxClassificationDD").setData([]);
							}
							if (this.getView().byId(cellId).getModel("TaxClassificationDD")) {
								if (this.getView().byId(prevRowCellID).getModel("TaxClassificationDD")) {
									this.getView().byId(prevRowCellID).getModel("TaxClassificationDD").setData(this.getView().byId(cellId).getModel(
										"TaxClassificationDD").getData());
								} else {
									var oModel = new sap.ui.model.json.JSONModel();
									oModel.setData(this.getView().byId(cellId).getModel("TaxClassificationDD").getData());
									this.getView().byId(prevRowCellID).setModel(oModel, "TaxClassificationDD");
								}
								this.getView().byId(cellId).getModel("TaxClassificationDD").setData([]);
							}
						}
					}
				}
			}
			for (var j = 0; j < oItemModelData.length; j++) {

				if (CPDMSDivisionTaxesTemp === j)

				{
					oItemModelData.splice(j, 1);

				}

			}
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			//Update Table count
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/TaxCatItemsCount", oItemModelData.length);
			}

			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + pos) > -1) {
					oSSCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				// oSSCommon.hideMessagePopover(this.ObjectPageLayout);
			}
		},
		getDropDown: function (oModel, sEntitySet, oFilters, sKey, sText, busyDialog, view, modelName, defaultValue, requestCompleted,
			bLoginIDOptional, appKey, bMustAddNone, mParameters, newKey) {
			var aDDValue = new Array();
			oSSCommon.getCurrentLoggedUser({
				sServiceName: sEntitySet,
				sRequestType: "read",
				Application: appKey
			}, function (LoginID) {
				oFilters = oPPCCommon.setODataModelReadFilter("", "", oFilters, "LoginID", "", [LoginID], false, false, false);
				oModel.read("/" + sEntitySet, {
					filters: oFilters,
					success: function (oData) {
						if (oData.results.length > 0) {
							if (defaultValue !== null && defaultValue !== undefined && defaultValue !== "" && (oData.results.length !== 1 || ((
									defaultValue === "None" || defaultValue === "Select") && bMustAddNone))) {
								aDDValue.push({
									Key: "",
									Text: "(" + defaultValue + ")"
								});
							}
							for (var i = 0; i < oData.results.length; i++) {
								aDDValue.push({
									Key: oData.results[i][sKey],
									Text: oData.results[i]["SPNo"] + " - " + oData.results[i][sText],
									Seperator: " - "
								});
							}
							var oDDModel = new sap.ui.model.json.JSONModel();
							oDDModel.setData(aDDValue);
							if (mParameters) {
								if (mParameters.bSetSizeLimit) {
									oDDModel.setSizeLimit(aDDValue.length);
								}
							}
							view.setModel(oDDModel, modelName);
						}
						if (requestCompleted) {
							requestCompleted(aDDValue);
						}
					},
					error: function (error) {
						busyDialog.close();
						oSSCommon.showServiceErrorPopup(error);
					}
				});
			});

		},
		onPartnerMgrNo: function (oEvent) {
			var Partner = oEvent.getSource().getSelectedItem().getText();
			if (Partner) {
				var PartnerMgrName = Partner.split("-")[1];
				var PartnerMgrNo = Partner.split("-")[0];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/PartnerMgrNo", PartnerMgrNo);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/PartnerMgrName", PartnerMgrName);
		},
		onDMSDivisionSelect: function (oEvent) {
			var DMSDivision = oEvent.getSource().getSelectedKey();
			var DMSDivisionDesc = oEvent.getSource().getSelectedItem().getText();
			this.getView().setBusy(true);
			this.SalesPersonDD(gCPDetailView.getModel("LocalViewSettingDtl").getProperty("/gCPGUID"), gCPDetailView.getModel(
				"LocalViewSettingDtl").getProperty("/gCPTypeId"), DMSDivision);
			if (DMSDivisionDesc) {
				DMSDivisionDesc = DMSDivisionDesc.split("-")[1];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/DMSDivision", DMSDivision);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/DMSDivisionDesc", DMSDivisionDesc);

		},
		onGroup3: function (oEvent) {
			var Group3 = oEvent.getSource().getSelectedKey();
			var Group3Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group3Desc) {
				Group3Desc = Group3Desc.split("-")[1];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group3", Group3);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group3Desc", Group3Desc);
		},
		onGroup4: function (oEvent) {
			var Group4 = oEvent.getSource().getSelectedKey();
			var Group4Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group4Desc) {
				Group4Desc = Group4Desc.split("-")[1];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group4", Group4);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group4Desc", Group4Desc);
		},
		onGroup5: function (oEvent) {
			var Group5 = oEvent.getSource().getSelectedKey();
			var Group5Desc = oEvent.getSource().getSelectedItem().getText();
			if (Group5Desc) {
				Group5Desc = Group5Desc.split("-")[1];
			}
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group5", Group5);
			this._oComponent.getModel("CPDMSDivisionsTemp").setProperty("/0/Group5Desc", Group5Desc);
		},
		validateNumeric: function (oEvent) {
			var value = oEvent.getSource().getValue();
			var currentValueEntered = value.substring(value.length - 1);
			var lastValueEnterd = value.substring(0, value.length - 1);
			var reg = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,<>\/a-z A-Z?]/;
			if (reg.test(currentValueEntered)) {
				oEvent.getSource().setValue(lastValueEnterd);
			}
		}

		// onTaxClassificationID: function(oEvent) {
		// 				var path = oEvent.getSource().getBindingContext("CPDMSDivisionTaxes").getPath();

		// 	this._oComponent.getModel("CPDMSDivisionTaxes").setProperty(path+"/TaxClassificationID", oEvent.getSource().getSelectedKey());
		// 	this._oComponent.getModel("CPDMSDivisionTaxes").setProperty(path+"/TaxClassificationDesc", oEvent.getSource().getSelectedItem().getText()
		// 		.split(
		// 			"-")[1]);
		// }

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.cp.create1.view.TaxClassification
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.cp.create1.view.TaxClassification
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.cp.create1.view.TaxClassification
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.cp.create1.view.TaxClassification
		 */
		//	onExit: function() {
		//
		//	}

	});

});