function getTokenForInput(args, F4Model, serviceName, f4Filters, key, value, control, errorText)//(args, oMultiInputObj, url, codeName, desc, view, controlId, errorText)
{
	var oDialog = new sap.m.BusyDialog();

	F4Model.attachRequestSent(
			function()
			{
				oDialog.open();
			}
	);  
	F4Model.attachRequestCompleted(function(){oDialog.close();});  
	F4Model.read("/"+serviceName, {
		async: false,	
		filters: f4Filters,
		success: function(oData){

			var aData = oData.results;
			var oToken = "";
			var oTokenKey = "";
			var oTokenText = "";

			if(key != "" && key != null && key != undefined){
				oTokenKey = aData[0][key];
				if(value != "" && value != null && value != undefined){
					if(aData[0][value] != undefined && aData[0][value] != "" ){
						oTokenText = aData[0][value]+" ("+aData[0][key]+")";
					}
				}
			}
			oToken = new sap.m.Token({key: oTokenKey, text: oTokenText});

			args.asyncCallback(oToken);
			oDialog.close();
			return sap.m.MultiInput.WaitForAsyncValidation;

			control.setValueState(sap.ui.core.ValueState.None);
			control.setValueStateText("");
			oDialog.close();
		}, 
		error: function(error){
			oDialog.close();
			control.setValueState(sap.ui.core.ValueState.Error);
			control.setValueStateText("Please enter valid "+errorText);
		}
	});
}
