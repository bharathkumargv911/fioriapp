sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"com/arteriatech/ss/utils/js/UserMapping"
], function (Controller, oPPCCommon,
	oSSCommon,
	oSSCommonValueHelp,
	oSSUserMapping) {
	"use strict";
	var oi18n = "",
		oPPCUtili18n = "";
	var oDevice = sap.ui.Device;
	var BusyDialog = new sap.m.BusyDialog();
	var contextPath;

	return Controller.extend("com.arteriatech.pc.cnfg.typeset.controller.DetailPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailPage
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gObjectPageLayout = this.getView().byId("ObjectPageLayout_ID");
			gDetailPage = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oPPCUtili18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
		},
		onRouteMatched: function (oEvent) {

			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oEvent.getParameter("name") !== "DetailPage") {
				return;
			}
			if (oHistory.getDirection() !== "Backwards") {
				this.setDefaultSettingsModel();
				contextPath = oEvent.getParameter("arguments").contextPath;
				this.getDetailData();
			}
		},
		setDefaultSettingsModel: function () {
			var json = {
				messageLength: 0,
				Detail: true,
				Edit: false,
				saveBtn: false,
				visibleRowCount: 0,
				ItemsCount: 0,
				visibleRowCountTypes: 0,
				ItemsCountTypes: 0,
				visibleRowCountEdit: 0,
				ItemsCountEdit: 0
			};
			var ojsonmodel = new sap.ui.model.json.JSONModel();
			ojsonmodel.setData(json);
			this.getView().setModel(ojsonmodel, "LocalViewSettingsDetail");

			ojsonmodel = new sap.ui.model.json.JSONModel();
			ojsonmodel.setData([]);
			this._oComponent.setModel(ojsonmodel, "DetailModel");

			ojsonmodel = new sap.ui.model.json.JSONModel();
			ojsonmodel.setData([]);
			this._oComponent.setModel(ojsonmodel, "DetailModelEdit");

			ojsonmodel = new sap.ui.model.json.JSONModel();
			ojsonmodel.setData([]);
			this.getView().setModel(ojsonmodel, "DetailModelTypesTypes");

		},
		getDetailData: function () {
			this.getTypesData();
			this.getTypevaluesData();

		},
		getTypesData: function () {
			var that = this;
			var AggregatorID = oPPCCommon.getPropertyValueFromContextPath(contextPath, "AggregatorID");
			var Typeset = oPPCCommon.getPropertyValueFromContextPath(contextPath, "Typeset");
			var oFilter = [];
			var oModel = this._oComponent.getModel("PCGWHANA");
			oFilter.push(new sap.ui.model.Filter("AggregatorID", "EQ", AggregatorID));
			oFilter.push(new sap.ui.model.Filter("Typeset", "EQ", Typeset));
			var data = {
				AggregatorID: AggregatorID,
				Typeset: Typeset
			};
			var Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/ConfigTypesets?AggregatorID=" +
				AggregatorID;
			Url = Url + "&Typeset=" + Typeset + "";

			// oModel.read("/ConfigTypesetTypes", {
			// 	filters: oFilter,
			// 	success: function (oData) {
			// 		BusyDialog.close();
			// 		that.getView().getModel("DetailModelTypesTypes").setProperty("/", oData.results);
			// 		that.setTableCountTypes(oData.results.length);
			// 	},
			// 	error: function () {
			// 		BusyDialog.close();
			// 		that.getView().getModel("DetailModelTypesTypes").setProperty("/", []);
			// 		that.setTableCountTypes(0);
			// 	}
			// });
			$.ajax({
				url: Url,
				type: "GET",
				// data: JSON.stringify(oData),
				data: {
					ConfigTypesets: JSON.stringify(data)
				},
				dataType: "JSON",
				async: true,
				// filters: oFilter,
				success: function (oData) {
					BusyDialog.close();
					that.getView().getModel("DetailModelTypesTypes").setProperty("/", oData);
					that.setTableCountTypes(oData.length);

				},
				error: function () {
					BusyDialog.close();
					that.getView().getModel("DetailModelTypesTypes").setProperty("/", []);
					that.setTableCountTypes(0);
				}
			});
		},
		getTypevaluesData: function () {
			var that = this;
			var AggregatorID = oPPCCommon.getPropertyValueFromContextPath(contextPath, "AggregatorID");
			var Typeset = oPPCCommon.getPropertyValueFromContextPath(contextPath, "Typeset");
			var oFilter = [];
			var oModel = this._oComponent.getModel("PCGWHANA");
			oFilter.push(new sap.ui.model.Filter("AggregatorID", "EQ", AggregatorID));
			oFilter.push(new sap.ui.model.Filter("Typeset", "EQ", Typeset));
			var data = {
				AggregatorID: AggregatorID,
				Typeset: Typeset
			};
			// oModel.read("/ConfigTypsetTypeValues", {
			// 	filters: oFilter,
			// 	success: function (oData) {
			// 		BusyDialog.close();
			// 		that._oComponent.getModel("DetailModel").setProperty("/", oData.results);
			// 		that.setTableCount(oData.results.length);
			// 	},
			// 	error: function () {
			// 		BusyDialog.close();
			// 		that._oComponent.getModel("DetailModel").setProperty("/", []);
			// 		that.setTableCount(0);
			// 	}
			// });
			$.ajax({
				url: "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/ConfigTypsetTypeValues",
				type: "GET",
				dataType: "JSON",
				data: {
					ConfigTypsetTypeValues: JSON.stringify(data)
				},
				async: true,
				// filters: oFilter,
				success: function (oData) {
					BusyDialog.close();
					that._oComponent.getModel("DetailModel").setProperty("/", oData);
					that.setTableCount(oData.length);
				},
				error: function () {
					BusyDialog.close();
					that._oComponent.getModel("DetailModel").setProperty("/", []);
					that.setTableCount(0);
				}
			});
		},
		setTableCount: function (sCount) {
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/visibleRowCount", sCount);
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/ItemsCount", sCount);
			if (sCount > 5) {
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/visibleRowCount", 5);
			}

		},
		setTableCountTypes: function (sCount) {
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/visibleRowCountTypes", sCount);
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/ItemsCountTypes", sCount);
			if (sCount > 5) {
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/visibleRowCountTypes", 5);
			}

		},
		onEdit: function () {

			this._oDetailModel = jQuery.extend(true, [], this._oComponent.getModel("DetailModel").getData());
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/saveBtn", false);
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/Edit", true);
			this.getView().getModel("LocalViewSettingsDetail").setProperty("/Detail", false);
		},
		validateItems: function () {
			if (this._oComponent.getModel("DetailModel").getData().length <= 0) {
				var msg = "No items to edit";
				oPPCCommon.addMsg_MsgMgr(msg, "error", "Quantity");
			}
		},
		validateNewItems: function () {
			var oData = this.getView().getModel("DetailModelEdit").getData();
			if (oData.length > 0) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].Types === "" || oData[i].Types === undefined || oData[i].Types === null) {
						var msg = "Enter Types for item" + (i + 1);
						oPPCCommon.addMsg_MsgMgr(msg, "error", "Quantity");
					}
					if (oData[i].Typesname === "" || oData[i].Typesname === undefined || oData[i].Typesname === null) {
						var msg = "Enter Typesname for item" + (i + 1);
						oPPCCommon.addMsg_MsgMgr(msg, "error", "Quantity");
					}
					if (oData[i].TypeValue === "" || oData[i].TypeValue === undefined || oData[i].TypeValue === null) {
						var msg = "Enter TypeValue for item" + (i + 1);
						oPPCCommon.addMsg_MsgMgr(msg, "error", "Quantity");
					}
				}
			}
		},

		onReview: function () {
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(gObjectPageLayout);
			this.validateItems();
			this.validateNewItems();
			if (oPPCCommon.doErrMessageExist()) {
				var OData1 = this.getView().getModel("DetailModel").getData();
				this._oDetailModel1 = jQuery.extend(true, [], OData1);

				var NewItems = this.getView().getModel("DetailModelEdit").getData();
				var ExtItems = this.getView().getModel("DetailModel").getData();
				// NewItems.forEach(function(eachElement){
				// 	ExtItems.push();
				// })
				// ExtItems.concat(NewItems);
				Array.prototype.push.apply(ExtItems, NewItems);
				this.getView().getModel("DetailModel").setProperty("/", ExtItems);
				this.setTableCount(ExtItems.length);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/saveBtn", true);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/Edit", false);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/Detail", true);
			} else {
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCCommon.showMessagePopover(gObjectPageLayout);
			}

		},
		showErrorPopUp: function () {
			oPPCCommon.showMessagePopover(gObjectPageLayout);
		},
		onUpdatedSuccess: function () {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: "Updated Successfully"
				}),
				buttons: [
					new sap.m.Button({
						text: 'OK',
						press: function () {
							dialog.close();
							that.getView().getModel("LocalViewSettingsDetail").setProperty("/Edit", false);
							that.getView().getModel("LocalViewSettingsDetail").setProperty("/Detail", true);
							that.getView().getModel("LocalViewSettingsDetail").setProperty("/saveBtn", false);
						}
					})
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onSave: function () {
			var that = this;
			BusyDialog.open();
			var oModel = this._oDetailModel1;
			var k = oModel.length;
			for (var i = 0; i < oModel.length; i++) {
				var oData = {
					AGGRID: oModel[i].AggregatorID,
					TYPESET: oModel[i].Typeset,
					TYPE_VALUE: oModel[i].TypeValue,
					TYPES: oModel[i].Types
				}
				var Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPVAL";
				// Url = Url + "(AGGRID='" + oData.AGGRID + "'" + ",TYPESET='" + oData.TYPESET + "',TYPES='" +
				// 	oData.TYPES +
				// 	"')";
				$.ajax({
					url: Url,
					type: "PUT",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {
						k--;
						if (k === 0) {
							BusyDialog.close();
							that.onCreateSuccess("Updated Successfully");
						}
					},
					error: function () {
						k--;
						if (k === 0) {
							BusyDialog.close();
							that.onError(oPPCCommon.getMsgsFromMsgMgr());
						}
					}
				});
			}
			for (var i = 0; i < oModel.length; i++) {
				var oData = {
					AGGRID: oModel[i].AggregatorID,
					TYPESET: oModel[i].Typeset,
					LANGUAGE: "E",
					TYPESNAME: oModel[i].Typesname,
					TYPES: oModel[i].Types
				}

				var Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPS_T";
				// Url = Url + "(AGGRID='" + oData.AGGRID + "'" + ",TYPESET='" + oData.TYPESET + "',TYPES='" +
				// 	oData.TYPES +
				// 	"',LANGUAGE='E')";
				$.ajax({
					url: Url,
					type: "PUT",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {
						// k--;
						// if (k === 0) {
						// 	BusyDialog.close();
						// 	that.onCreateSuccess("Updated Successfully");
						// }
					},
					error: function () {
						// k--;
						// if (k === 0) {
						// 	BusyDialog.close();
						// 	that.onError(oPPCCommon.getMsgsFromMsgMgr());
						// }
					}
				});
			}

			var oModel = this._oComponent.getModel("DetailModelEdit").getData();
			if (oModel.length > 0) {
				this.postTYPS_T();
				this.postTYPS();
				this.postTYPVAL();
			}

		},
		postTYPS_T: function () {
			// var that = this;
			// var oModel = this.getView().getModel("PCGWHANA");
			var TypesData = this.getView().getModel("DetailModelEdit").getData();
			// var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			for (var i = 0; i < TypesData.length; i++) {
				var oData = {
					AGGRID: TypesData[i].AggregatorID,
					TYPESET: this._oComponent.getModel("DetailModel").getProperty("/0/Typeset"),
					LANGUAGE: "E",
					TYPESNAME: TypesData[i].Typesname,
					TYPES: TypesData[i].Types
				}
				var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPS_T";
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {}
				});

			}
		},

		postTYPS: function () {
			var that = this;
			var oModel = this.getView().getModel("PCGWHANA");
			var TypesData = this.getView().getModel("DetailModelEdit").getData();
			// var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			for (var i = 0; i < TypesData.length; i++) {
				var oData = {
					AGGRID: TypesData[i].AggregatorID,
					TYPESET: this._oComponent.getModel("DetailModel").getProperty("/0/Typeset"),
					TYPES: TypesData[i].Types
				}
				var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPS";
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {}
				});

			}
		},
		postTYPVAL: function () {
			// var that = this;
			// BusyDialog.open();
			// var oModel = this.getView().getModel("PCGWHANA");
			var TypesData = this.getView().getModel("DetailModelEdit").getData();
			// var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			// var k = TypesData.length;
			for (var i = 0; i < TypesData.length; i++) {
				var oData = {
					AGGRID: TypesData[i].AggregatorID,
					TYPESET: this._oComponent.getModel("DetailModel").getProperty("/0/Typeset"),
					TYPE_VALUE: TypesData[i].TypeValue,
					TYPES: TypesData[i].Types
				}
				var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPVAL";
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {
						// k--;
						// if (k === 0) {
						// 	BusyDialog.close();
						// 	that.onCreateSuccess("Created Successfully");
						// }

					},
					error: function () {
						// k--;
						// if (k === 0) {
						// 	BusyDialog.close();
						// 	that.onError(oPPCCommon.getMsgsFromMsgMgr());
						// }

					}
				});
			}
		},

		onError: function (msg) {
			var that = this;
			that._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var dialog = new sap.m.Dialog({
				title: "Error",
				type: "Message",
				state: "Error",
				content: new sap.m.Text({
					text: msg
				}),

				buttons: [
					new sap.m.Button({
						icon: "sap-icon://home",
						text: "Home",
						press: function () {
							window.location = "#";

							dialog.close();
						}
					}),
					new sap.m.Button({
						text: 'OK',
						press: function () {
							that.TCounter = 1;
							oPPCCommon.navigateBack({
								router: that._oRouter,
								sDefaultView: "AttributeListPage"
							});
							dialog.close();
						}
					}),
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onCreateSuccess: function (msg) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: msg
				}),
				buttons: [
					new sap.m.Button({
						icon: "sap-icon://home",
						text: "Home",
						press: function () {
							window.location = "#";
							dialog.close();
						}
					}),
					new sap.m.Button({
						text: 'OK',
						press: function () {
							dialog.close();
							window.history.go(-1);
						}
					}),
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		onUpdateFailure: function (msg) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Failure",
				type: "Message",
				state: "Error",
				content: new sap.m.Text({
					text: msg
				}),
				buttons: [
					new sap.m.Button({
						text: 'OK',
						press: function () {
							dialog.close();
							that.getView().getModel("LocalViewSettingsDetail").setProperty("/Edit", false);
							that.getView().getModel("LocalViewSettingsDetail").setProperty("/Detail", true);
							that.getView().getModel("LocalViewSettingsDetail").setProperty("/saveBtn", false);
						}
					})
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onBack: function () {
			var that = this;
			if (this.getView().getModel("LocalViewSettingsDetail").getProperty("/saveBtn")) {
				this._oComponent.getModel("DetailModel").setProperty("/", this._oDetailModel1);
				this._oComponent.getModel("DetailModelEdit").setProperty("/", []);
				gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/visibleRowCountEdit", 0);
				gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/ItemsCountEdit", 0);
				this.setTableCount(this._oDetailModel1.length);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/Edit", true);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/Detail", false);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/saveBtn", false);
			} else if (this.getView().getModel("LocalViewSettingsDetail").getProperty("/Edit")) {
				this._oComponent.getModel("DetailModel").setProperty("/", this._oDetailModel);
				this._oComponent.getModel("DetailModelEdit").setProperty("/", []);
				gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/visibleRowCountEdit", 0);
				gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/ItemsCountEdit", 0);
				oPPCCommon.hideMessagePopover();
				oPPCCommon.removeAllMsgs();
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);

				this.getView().getModel("LocalViewSettingsDetail").setProperty("/Edit", false);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/Detail", true);
				this.getView().getModel("LocalViewSettingsDetail").setProperty("/saveBtn", false);
			} else if (this.getView().getModel("LocalViewSettingsDetail").getProperty("/Detail")) {

				window.history.go(-1);
			}

		},
		clearValueState: function (Array) {
			Array.forEach(function (eachElement) {
				gObjectPageLayout.byId(eachElement).setValueState("None");
				gObjectPageLayout.byId(eachElement).setValueStateText("");
			});
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});