sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"sap/m/MessageBox"
], function (Controller, oPPCCommon, MessageBox) {
	"use strict";
	var oi18n = "",
		oPPCUtili18n = "";
	var oDevice = sap.ui.Device;
	var BusyDialog = new sap.m.BusyDialog();
	var contextPath;

	return Controller.extend("com.arteriatech.pc.cnfg.typeset.controller.CreatePage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.CreatePage
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gObjectPageLayoutCrt = this.getView().byId("ObjectPageLayout_ID_Crt");
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oPPCUtili18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.getAggregators();
		},
		onRouteMatched: function (oEvent) {

			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oEvent.getParameter("name") !== "CreatePage") {
				return;
			}
			if (oHistory.getDirection() !== "Backwards") {
				this.setDefaultSettingsModel();
				contextPath = oEvent.getParameter("arguments").contextPath;
				// this.getDetailData();
			}
		},
		getAggregators: function (oValueHelpDialog, mParameters) {
			var that = this;
			// var oModel = this._oComponent.getModel("PYGWHANA");
			// oModel.read("/Aggregators", {
			// 	success: function (data, textStatus, jqXHR) {
			// 		if (data) {
			// 			var sAggregatorItems = data.results;
			// 			var sAggregatorModel = new sap.ui.model.json.JSONModel();
			// 			sAggregatorModel.setData(sAggregatorItems);
			// 			that._oComponent.setModel(sAggregatorModel, "AggregatorModel");
			// 		}
			// 	},
			// 	error: function (xhr, status, e) {
			// 		var sAggregatorModel = new sap.ui.model.json.JSONModel([]);
			// 		that._oComponent.setModel("AggregatorModel");
			// 	}
			// });
			$.ajax({
				url: "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/Aggregators",
				type: "GET",
				dataType: "JSON",
				async: true,
				success: function (data, textStatus, jqXHR) {
					if (data) {
						var sAggregatorItems = data;
						var sAggregatorModel = new sap.ui.model.json.JSONModel();
						sAggregatorModel.setData(sAggregatorItems);
						that._oComponent.setModel(sAggregatorModel, "AggregatorModel");
					}

				},
				error: function (xhr, status, e) {
					var sAggregatorModel = new sap.ui.model.json.JSONModel([]);
					that._oComponent.setModel("AggregatorModel");
				}
			});
		},

		setDefaultSettingsModel: function () {
			var json = {
				messageLength: 0,
				Detail: true,
				Edit: false,
				saveBtn: false,
				visibleRowCount: 0,
				ItemsCount: 0,
				visibleRowCountTypes: 0,
				ItemsCountTypes: 0,
				Edit: true,
				Review: false
			};
			var ojsonmodel = new sap.ui.model.json.JSONModel();
			ojsonmodel.setData(json);
			this.getView().setModel(ojsonmodel, "LocalViewSettingsCreate");
			var ojsonmodel = new sap.ui.model.json.JSONModel([]);
			this.getView().setModel(ojsonmodel, "ConfigCreateModel");
		},
		onBack: function () {
			if (this.getView().getModel("LocalViewSettingsCreate").getProperty("/Review")) {
				this.getView().getModel("LocalViewSettingsCreate").setProperty("/Review", false);
				this.getView().getModel("LocalViewSettingsCreate").setProperty("/Edit", true);
			} else {
				window.history.go(-1);
			}
		},
		onReview: function () {
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover(gObjectPageLayoutCrt);
			this.validateData();
			if (oPPCCommon.doErrMessageExist()) {
				this.getView().getModel("LocalViewSettingsCreate").setProperty("/Review", true);
				this.getView().getModel("LocalViewSettingsCreate").setProperty("/Edit", false);
			} else {
				this.getView().getModel("LocalViewSettingsCreate").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);
				oPPCCommon.showMessagePopover(gObjectPageLayoutCrt);
			}
		},
		validateData: function () {
			this.clearValueState([
				"Aggregator",
				"idTypeset",
				"idTypename"
			]);
			var oModel = this.getView().getModel("LocalViewSettingsCreate").getData();
			if (!oModel.AggregatorID) {
				gBasicCreate.byId("Aggregator").setValueState("Error");
				gBasicCreate.byId("Aggregator").setValueStateText("Please select Aggregator ID");
				oPPCCommon.addMsg_MsgMgr("Please select Aggregator ID", "error");
			}
			if (!oModel.TypeSet) {
				gBasicCreate.byId("idTypeset").setValueState("Error");
				gBasicCreate.byId("idTypeset").setValueStateText("Please enter Typeset");
				oPPCCommon.addMsg_MsgMgr("Please enter Typeset", "error");
			}
			if (!oModel.TypesetName) {
				gBasicCreate.byId("idTypename").setValueState("Error");
				gBasicCreate.byId("idTypename").setValueStateText("Please enter Typeset Name");
				oPPCCommon.addMsg_MsgMgr("Please enter Typeset Name", "error");
			}
			this.validateItems();

		},
		validateItems: function () {
			var items = this.getView().getModel("ConfigCreateModel").getData();
			if (items.length < 1) {
				oPPCCommon.addMsg_MsgMgr("Please add atleast one item", "error");
			}
			for (var i = 0; i < items.length; i++) {
				if (!items[i].Types) {
					oPPCCommon.addMsg_MsgMgr("Please enter Type for item " + (i + 1), "error");
				}

				if (!items[i].Typesname) {
					oPPCCommon.addMsg_MsgMgr("Please enter Typesname for item " + (i + 1), "error");
				}
				if (!items[i].TypeValue) {
					oPPCCommon.addMsg_MsgMgr("Please enter TypeValue for item " + (i + 1), "error");
				}
			}
		},
		clearValueState: function (Array) {
			Array.forEach(function (eachElement) {
				gBasicCreate.byId(eachElement).setValueState("None");
				gBasicCreate.byId(eachElement).setValueStateText("");
			});
		},
		showErrorPopUp: function () {
			oPPCCommon.showMessagePopover(gObjectPageLayoutCrt);
		},
		onSave: function () {
			this.postTSET_T();
			this.postTSET();
			this.postTYPS_T();
			this.postTYPS();
			this.postTYPVAL();
		},
		postTSET: function () {
			var that = this;
			var oModel = this.getView().getModel("PCGWHANA");
			var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			var oData = {
				AGGRID: LocalViewData.AggregatorID,
				TYPESET: LocalViewData.TypeSet
			}
			var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TSET";
			$.ajax({
				url: url,
				type: "POST",
				data: JSON.stringify(oData),
				dataType: "JSON",
				async: true,
				contentType: "application/json; charset=utf-8",
				success: function (data, textStatus, jqXHR) {}
			});
		},

		postTSET_T: function () {
			var that = this;
			var oModel = this.getView().getModel("PCGWHANA");
			var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			var oData = {
				AGGRID: LocalViewData.AggregatorID,
				TYPESET: LocalViewData.TypeSet,
				LANGUAGE: "E",
				TSETNAME: LocalViewData.TypesetName
			}
			var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TSET_T";
			$.ajax({
				url: url,
				type: "POST",
				data: JSON.stringify(oData),
				dataType: "JSON",
				async: true,
				contentType: "application/json; charset=utf-8",
				success: function (data, textStatus, jqXHR) {}
			});
		},
		postTYPS: function () {
			var that = this;
			var oModel = this.getView().getModel("PCGWHANA");
			var TypesData = this.getView().getModel("ConfigCreateModel").getData();
			var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			for (var i = 0; i < TypesData.length; i++) {
				var oData = {
					AGGRID: LocalViewData.AggregatorID,
					TYPESET: LocalViewData.TypeSet,
					TYPES: TypesData[i].Types
				}
				var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPS";
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {}
				});

			}
		},

		postTYPS_T: function () {
			var that = this;
			var oModel = this.getView().getModel("PCGWHANA");
			var TypesData = this.getView().getModel("ConfigCreateModel").getData();
			var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			for (var i = 0; i < TypesData.length; i++) {
				var oData = {
					AGGRID: LocalViewData.AggregatorID,
					TYPESET: LocalViewData.TypeSet,
					LANGUAGE: "E",
					TYPESNAME: TypesData[i].Typesname,
					TYPES: TypesData[i].Types
				}
				var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPS_T";
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {}
				});

			}
		},
		postTYPVAL: function () {
			var that = this;
			BusyDialog.open();
			var oModel = this.getView().getModel("PCGWHANA");
			var TypesData = this.getView().getModel("ConfigCreateModel").getData();
			var LocalViewData = this.getView().getModel("LocalViewSettingsCreate").getData();
			var k = TypesData.length;
			for (var i = 0; i < TypesData.length; i++) {
				var oData = {
					AGGRID: LocalViewData.AggregatorID,
					TYPESET: LocalViewData.TypeSet,
					TYPE_VALUE: TypesData[i].TypeValue,
					TYPES: TypesData[i].Types
				}
				var url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/TYPVAL";
				$.ajax({
					url: url,
					type: "POST",
					data: JSON.stringify(oData),
					dataType: "JSON",
					async: true,
					contentType: "application/json; charset=utf-8",
					success: function (data, textStatus, jqXHR) {
						k--;
						if (k === 0) {
							BusyDialog.close();
							that.onCreateSuccess("Created Successfully");
						}

					},
					error: function () {
						k--;
						if (k === 0) {
							BusyDialog.close();
							that.onError(oPPCCommon.getMsgsFromMsgMgr());
						}

					}
				});
			}
		},
		onError: function (msg) {
			var that = this;
			that._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var dialog = new sap.m.Dialog({
				title: "Error",
				type: "Message",
				state: "Error",
				content: new sap.m.Text({
					text: msg
				}),

				buttons: [
					new sap.m.Button({
						icon: "sap-icon://home",
						text: "Home",
						press: function () {
							window.location = "#";

							dialog.close();
						}
					}),
					new sap.m.Button({
						text: 'OK',
						press: function () {
							that.TCounter = 1;
							oPPCCommon.navigateBack({
								router: that._oRouter,
								sDefaultView: "AttributeListPage"
							});
							dialog.close();
						}
					}),
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},

		onCreateSuccess: function (msg) {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: "Success",
				type: "Message",
				state: "Success",
				content: new sap.m.Text({
					text: msg
				}),
				buttons: [
					new sap.m.Button({
						icon: "sap-icon://home",
						text: "Home",
						press: function () {
							window.location = "#";
							dialog.close();
						}
					}),
					new sap.m.Button({
						text: 'Create New',
						press: function () {
							//that.setDefaultSetting();
							dialog.close();
							that.onClear();

						}
					}),
				],
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		onClear: function () {
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/AggregatorID", "");
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/TypeSet", "");
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/Edit", true);
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/Review", false);
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/TypesetName", "");
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/visibleRowCount", 0);
			this.getView().getModel("LocalViewSettingsCreate").setProperty("/ItemsCount", 0);
			this.getView().getModel("ConfigCreateModel").setProperty("/", []);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.CreatePage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.CreatePage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.CreatePage
		 */
		//	onExit: function() {
		//
		//	}

	});

});