sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"com/arteriatech/ss/utils/js/UserMapping",
], function (Controller, oPPCCommon,
	oSSCommon,
	oSSCommonValueHelp,
	oSSUserMapping, ) {
	"use strict";
	var oi18n = "",
		oPPCUtili18n = "";
	var Device = sap.ui.Device;
	var BusyDialog = new sap.m.BusyDialog();

	return Controller.extend("com.arteriatech.pc.cnfg.typeset.controller.List", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.List
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gListPage = this.getView();
			// oPPCCommon.initMsgMangerObjects();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oPPCUtili18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			this.setDefaultSettings();
			this.getAggregators();
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},
		onRouteMatched: function (oEvent) {
			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oEvent.getParameter("name") !== "List") {
				return;
			}
			if (oHistory.getDirection() !== "Backwards") {}
		},

		getAggregators: function (oValueHelpDialog, mParameters) {
			var that = this;
			// var oModel = this._oComponent.getModel("PYGWHANA");
			// oModel.read("/Aggregators", {
			// 	success: function (data, textStatus, jqXHR) {
			// 		if (data) {
			// 			var sAggregatorItems = data.results;
			// 			var sAggregatorModel = new sap.ui.model.json.JSONModel();
			// 			sAggregatorModel.setData(sAggregatorItems);
			// 			that._oComponent.setModel(sAggregatorModel, "AggregatorModel");
			// 		}
			// 	},
			// 	error: function (xhr, status, e) {
			// 		var sAggregatorModel = new sap.ui.model.json.JSONModel([]);
			// 		that._oComponent.setModel("AggregatorModel");
			// 	}
			// });
			$.ajax({
				url: "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/Aggregators",
				type: "GET",
				dataType: "JSON",
				async: true,
				success: function (data, textStatus, jqXHR) {
					if (data) {
						var sAggregatorItems = data;
						var sAggregatorModel = new sap.ui.model.json.JSONModel();
						sAggregatorModel.setData(sAggregatorItems);
						that._oComponent.setModel(sAggregatorModel, "AggregatorModel");
					}

				},
				error: function (xhr, status, e) {
					var sAggregatorModel = new sap.ui.model.json.JSONModel([]);
					that._oComponent.setModel("AggregatorModel");
				}
			});
		},

		setDefaultSettings: function () {
			var json = {
				messageLength: 0,
				visibleRowCount: 0,
				ItemsCount: 0,
				AggrID: ""
			};
			var ojsonmodel = new sap.ui.model.json.JSONModel();
			ojsonmodel.setData(json);
			this.getView().setModel(ojsonmodel, "LocalViewSettings");
		},
		exportToExcel: function (oEvent) {
			var table = this.getView().byId("MAttributetable");
			var oModel = this.getView().getModel("ConfigTypes");
			var items, mParameters;
			items = table.getItems();
			if (items.length > 0) {
				if (Device.system.desktop) {
					oPPCCommon.copyAndApplySortingFilteringFromUITable({
						thisController: this,
						mTable: this.getView().byId("MAttributetable"),
						uiTable: this.getView().byId("UIAttributeTable")
					});
				}
			}
			oPPCCommon.exportToExcel(table, oModel, {
				bExportAll: false,
				oController: this,
				bLabelFromMetadata: false,
				sModel: "PYGW",
				sFileName: "Config Typeset",
				sEntityType: "SupplyChainFinanceControlsType",
				oUtilsI18n: oPPCUtili18n

			});
		},
		onSearch: function () {
			BusyDialog.open();
			var that = this;
			var Url = "";
			var AggrID;
			BusyDialog.open();
			AggrID = this.getView().byId("Aggregator").getSelectedKey();
			var typevalues = this.getView().byId("Typeset").getValue();
			// var oFilter = [];
			// var oModel = this._oComponent.getModel("PCGWHANA");
			// if (gListPage.byId("Aggregator").getSelectedKey()) {
			// 	oFilter.push(new sap.ui.model.Filter("AggregatorID", "EQ", gListPage.byId("Aggregator").getSelectedKey()));
			// }
			// if (this.getView().getModel("LocalViewSettings").getProperty("/Typeset")) {
			// 	oFilter.push(new sap.ui.model.Filter("Typeset", "EQ", this.getView().getModel("LocalViewSettings").getProperty("/Typeset")));
			// }

			// oModel.read("/ConfigTypesets", {
			// 	filters: oFilter,
			// 	success: function (oData) {
			// 		BusyDialog.close();
			// 		var json = new sap.ui.model.json.JSONModel(oData.results);
			// 		that.getView().setModel(json, "ConfigTypes");
			// 		that.setTableCount(oData.results.length);
			// 	},
			// 	error: function () {
			// 		BusyDialog.close();
			// 		var json = new sap.ui.model.json.JSONModel([]);
			// 		that.getView().setModel(json, "ConfigTypes");
			// 		that.setTableCount(0);
			// 	}
			// });
			if (!AggrID && typevalues) {
				Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/GetConfigTypesets?Typeset=" + typevalues + "";
			} else if (AggrID && typevalues) {
				Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/GetConfigTypesets?AggregatorId=" +
					AggrID;
				Url = Url + "&Typeset=" + typevalues + "";
			} else {
				if (AggrID) {
					Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/GetConfigTypesets?AggregatorId=" +
						AggrID + "";
				} else
					Url = "/sap/opu/odata/ARTEC/paymentgateway/PaymentGateway/GetConfigTypesets";
			}
			$.ajax({
				url: Url,
				type: "GET",
				// data: JSON.stringify(oData),
				// data: {
				// 	GetConfigTypesets: JSON.stringify(data)
				// },
				dataType: "JSON",
				async: true,
				success: function (oData) {
					BusyDialog.close();
					if (oData.Status == "000002") {
						var json = new sap.ui.model.json.JSONModel([]);
						that.getView().setModel(json, "ConfigTypes");
						that.setTableCount(0);
					} else {
						var json = new sap.ui.model.json.JSONModel(oData);
						that.getView().setModel(json, "ConfigTypes");
						that.setTableCount(oData.length);
					}
				},
				error: function () {
					BusyDialog.close();
					var json = new sap.ui.model.json.JSONModel([]);
					that.getView().setModel(json, "ConfigTypes");
					that.setTableCount(0);
				}
			});
		},
		setTableCount: function (sCount) {
			this.getView().getModel("LocalViewSettings").setProperty("/visibleRowCount", sCount);
			this.getView().getModel("LocalViewSettings").setProperty("/ItemsCount", sCount);
			if (sCount > 10) {
				this.getView().getModel("LocalViewSettings").setProperty("/visibleRowCount", 10);
			}

		},
		navToCreate: function () {
			this._oRouter.navTo("CreatePage", {}, false);
		},
		goToDetail: function (oEvent) {
			var object = oEvent.getSource().getBindingContext("ConfigTypes").getObject();
			var AggregatorID = object.AggregatorID;
			var Typeset = object.Typeset;
			var contextpath = "path(AggregatorID=" + AggregatorID + ",Typeset=" + Typeset + ")";
			// var contextpath = "test";
			this._oRouter.navTo("DetailPage", {
				contextPath: contextpath
			}, false);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.List
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.List
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.List
		 */
		//	onExit: function() {
		//
		//	}

	});

});