sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("com.arteriatech.pc.cnfg.typeset.controller.DetailTypevaluesEdit", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailTypevaluesEdit
		 */
		onInit: function () {

		},
		onAddTypes: function () {
			var oModel = gDetailPage.getModel("DetailModelEdit").getData();
			var obj = {
				AggregatorID: gDetailPage.getModel("DetailModel").getProperty("/0/AggregatorID"),
				Types: "",
				Typesname: "",
				TypeValue: ""
			};
			oModel.push(obj);
			gDetailPage.getModel("DetailModelEdit").setProperty("/", oModel);
			gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/visibleRowCountEdit", oModel.length);
			gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/ItemsCountEdit", oModel.length);

		},
		onCancel: function (oEvent) {
			var path = oEvent.getSource().getBindingContext("DetailModelEdit").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf("/") + 1));
			var m = this.getView().getModel("DetailModelEdit");
			var d = m.getData();
			d.splice(idx, 1);
			m.setData(d);
			m.refresh();
			gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/visibleRowCountEdit", d.length);
			gDetailPage.getModel("LocalViewSettingsDetail").setProperty("/ItemsCountEdit", d.length);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailTypevaluesEdit
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailTypevaluesEdit
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.pc.cnfg.typeset.view.DetailTypevaluesEdit
		 */
		//	onExit: function() {
		//
		//	}

	});

});