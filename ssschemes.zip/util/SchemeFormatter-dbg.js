jQuery.sap.declare("com.arteriatech.ss.schemes.util.SchemeFormatter");
jQuery.sap.require("sap.ca.ui.model.format.AmountFormat");
jQuery.sap.require('sap.m.MessageBox');
jQuery.sap.require("sap.ca.ui.message.message");
jQuery.sap.require("sap.ui.core.format.NumberFormat");
jQuery.sap.require("com.arteriatech.ppc.utils.js.Common");
//date format from Json format
var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
com.arteriatech.ss.schemes.util.SchemeFormatter = {};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatEmphasized = function(val) {
	try {
		val = parseFloat(val);
		if (val > 0) {
			return true;
		} else {
			return false;
		}
	} catch (err) {
		return false;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatText = function(desc, id) {
	var text;
	if ((id === "" && desc === "") || (id === undefined && desc === undefined) || (id === null && desc === null)) {
		text = "";
	} else {
		if (id === "" || id === undefined) {
			text = desc;
		} else {
			text = desc + " " + "(" + id + ")";
		}
	}
	return text;
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatDateRangeText = function(FromDate, ToDate) {
	FromDate = oPPCCommon.getFormattedDate(FromDate);
	ToDate = oPPCCommon.getFormattedDate(ToDate);
	var text;
	if ((FromDate === "" && ToDate === "") || (FromDate === undefined && ToDate === undefined) || (FromDate === null && ToDate === null)) {
		text = "";
	} else {
		if (FromDate === "" || FromDate === undefined || FromDate === null) {
			text = ToDate;
		} 
		else if(ToDate === "" || ToDate === undefined || ToDate === null) {
			text = FromDate;
		}
		else {
			text = FromDate + " - " + ToDate ;
		}
	}
	return text;
};

com.arteriatech.ss.schemes.util.SchemeFormatter.formatSubTitle = function(desc, id) {
			if (!id && !desc) {
				return "";
			} else if (id && desc) {
				return desc + " (" + id + ")";
			} else if (id && !desc) {
				return id;
			} else if (!id && desc) {
				return desc;
			}
		};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatObjectHeaderText = function(POTypeDesc, PONumber, POVersion) {
	var text;
	if (POVersion !== undefined && POVersion !== "") {
		text = POTypeDesc + ":" + " " + PONumber + ":" + " " + POVersion;
	} else {
		text = POTypeDesc + ":" + " " + PONumber;
	}
	return text;
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatItemNo = function(item) {
	if (typeof item === "string") {
		return parseInt(item, 10)
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatKeyDescription = function(key, desc) {
	var value = desc;
	try {
		if (key !== "") {
			value = desc + " (" + key + ")"
		}
	} catch (err) {
		return "";
	} finally {
		return value;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatKeyDescriptionNew = function(key, desc) {
	var value = desc;
	try {
		if (key !== "") {
			value = desc + " (" + key + ")";
		}
		if (value === "") {
			value = "-";
		}
	} catch (err) {
		return "";
	} finally {
		return value;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatSwitch = function(val) {
	try {
		if (val != null && val != undefined && val == 'X') {
			return true;
		} else {
			return false;
		}
	} catch (err) {
		return false;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatStatusImage = function(fValue) {
	var img;
	if (fValue === '01') {
		img = 'sap-icon://sys-enter';
		return img;
	}
	if (fValue === '02') {
		img = 'sap-icon://status-error';
		return img;
	}
	if (fValue === '03') {
		img = 'sap-icon://employee-rejections';
		return img;
	}
	
		if (fValue === '04') {
		img = 'sap-icon://pending';
		return img;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatStatusImageState = function(fValue) {
	var img;
	if (fValue === "01") {
		img = "Success";
		return img;
	}
	if (fValue === "02") {
		img = "Error";
		return img;
	}
	if (fValue === "03") {
		img = "Warning";
		return img;
	}
		if (fValue === '04') {
		img = 'Warning';
		return img;
		}
	
	else {
		return "None";
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatApprovalStatusImage = function(fValue) {
	var img;
	if (fValue === '01') {
		img = 'sap-icon://add-document';
		return img;
	}
	if (fValue === '02') {
		img = 'sap-icon://status-in-process';
		return img;
	}
	if (fValue === '03') {
		img = 'sap-icon://employee-approvals';
		return img;
	}
	if (fValue === '04') {
		img = 'sap-icon://employee-rejections';
		return img;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatApprovalStatusImageState = function(fValue) {
	var img;
	if (fValue === "01") {
		img = "None";
		return img;
	} else if (fValue === "02") {
		img = "Warning";
		return img;
	} else if (fValue === "03") {
		img = "Success";
		return img;
	} else if (fValue === "04") {
		img = "Error";
		return img;
	} else {
		return "None";
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatMaterialORService = function(ItemCatID, sCode, sDesc) {
	var sValue = sDesc;
	try {
		if (ItemCatID !== null && ItemCatID !== undefined) {
			if (ItemCatID !== '9') {
				if (sCode !== null && sCode !== undefined) {
					sValue = sValue + " (" + sCode + ")"
				}
			}
		}
	} catch (err) {
		sValue = "";
	} finally {
		return sValue;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatMaterialORServiceTooltip = function(ItemCatID) {
	var sValue = "Material";
	try {
		if (ItemCatID !== null && ItemCatID !== undefined) {
			if (ItemCatID === '9') {
				sValue = "Service";
			}
		}
	} catch (err) {
		sValue = "";
	} finally {
		return sValue;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatMaterialORServiceImage = function(ItemCatID) {
	var sValue = "product";
	try {
		if (ItemCatID !== null && ItemCatID !== undefined) {
			if (ItemCatID === '9') {
				sValue = "wrench";
			}
		}
	} catch (err) {
		sValue = "product";
	} finally {
		return sValue;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatMaterialORServiceColor = function(ItemCatID) {
	var sValue = "#00FF00";
	try {
		if (ItemCatID !== null && ItemCatID !== undefined) {
			if (ItemCatID === '9') {
				sValue = "#00FF00";
			}
		}
	} catch (err) {
		sValue = "#00FF00";
	} finally {
		return sValue;
	}
};
com.arteriatech.ss.schemes.util.SchemeFormatter.formatMaterialDocNo = function(HistoryType, MaterialDocNo, MaterialDocItemNo, MaterialDocYear) {
	var text = "";
	try {
		if (HistoryType === "A") {
			text = MaterialDocNo + " / " + MaterialDocItemNo;
		} else {
			text = MaterialDocNo + " (" + MaterialDocYear + ") / " + MaterialDocItemNo;
		}
	} catch (err) {
		text = MaterialDocNo + " (" + MaterialDocYear + ") / " + MaterialDocItemNo;
	}
	return text;
};