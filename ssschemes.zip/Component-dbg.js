jQuery.sap.declare("com.arteriatech.ss.schemes.Component");
jQuery.sap.require("sap.ui.Device");
var gListPageView, gSchemeDetails, goi18n, goUtilsI18n;
var gHeaderBlock, gRemarks, gBasicDataBlock, gSchemeGroupsBlock, gClaimDataBlock, gOtherDataBlock, gSchemeSalesAreaBlock,
	gRetailerCategoryBlock, gSchemeAttachments, gLinkPartenerCP,
	gSchemeGeographiesBlock, gSchemeCPsBlock, gSchemeItemsBlock, gSchemeSlabsBlock, gTempSchemeGeographiesBlock, gSchemeCostObjectBlock,
	gSchemeGroupsBlock, gSchemeGCount;
var gObjectPageLayout;
var gHoldBlockView;
var _aSCList = [];
// var cZone;
sap.ui.core.UIComponent.extend("com.arteriatech.ss.schemes.Component", {
	metadata: {
		manifest: "json"
	},
	init: function () {
		//Common Utils
		jQuery.sap.registerModulePath("com.arteriatech.ppc.utils", "/sap/bc/ui5_ui5/ARTEC/PPCUTIL/utils/");

		//Product Utils
		jQuery.sap.registerModulePath("com.arteriatech.prd.utils", "/sap/bc/ui5_ui5/ARTEC/SSUTIL/utils/");
		jQuery.sap.registerModulePath("com.arteriatech.ppc.utils", "/sap/bc/ui5_ui5/ARTEC/PPCUTIL/utils/");

		//Product Utils
		jQuery.sap.registerModulePath("com.arteriatech.ss.utils", "/sap/bc/ui5_ui5/ARTEC/SSUTIL/utils/");

		sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

		var Device = sap.ui.Device;
		var DeviceModel = new sap.ui.model.json.JSONModel(Device);
		DeviceModel.setDefaultBindingMode("OneWay");
		this.setModel(DeviceModel, "device");

		this.getRouter().initialize();
	}
});