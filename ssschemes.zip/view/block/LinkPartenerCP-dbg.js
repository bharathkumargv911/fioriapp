sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";
	var myBlock = BlockBase.extend("com.arteriatech.ss.schemes.view.block.LinkPartenerCP", {
		metadata: {}
	});
	return myBlock;
}, true);