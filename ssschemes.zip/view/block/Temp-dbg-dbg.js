sap.ui.define(['sap/uxap/BlockBase'], function (BlockBase) {
	"use strict";
	var GoalsBlock = BlockBase.extend("com.arteriatech.ss.schemes.view.block.Temp", {
		metadata: {
			views: {
				Collapsed: {
					viewName: "com.arteriatech.ss.schemes.view.block.Temp",
					type: "XML"
				},
				Expanded: {
					viewName: "com.arteriatech.ss.schemes.view.block.Temp",
					type: "XML"
				}
			}
		}
	});
	return GoalsBlock;
}, true);