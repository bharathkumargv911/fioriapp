sap.ui.define(["sap/uxap/BlockBase"], function (BlockBase) {
	"use strict";
	var myBlock = BlockBase.extend("com.arteriatech.ss.schemes.view.block.ClaimDataBlock", {
		metadata: {}
	});
	return myBlock;
}, true);