sap.ui.define([
    "sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ppc/utils/js/Common"
], function(Controller,oSSCommon, oPPCCommon) {
	"use strict";

	return Controller.extend("com.arteriatech.ss.schemes.controller.ListPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			gListPageView = this.getView();
		},
		
		onPrintPress: function() {
			var that = this;
			var tempLogid = oSSCommon.getCurrentUsers("SchemePrintPDF", "read");
			if (gListPageView.getModel("ListItems").getProperty("/").length > 0) {
				var oDataModel = gListPageView.getModel("SCGW");
				var SchemeNo = "";
				for (var i = 0; i < _aSCList.length; i++) {
					if (_aSCList[i]) {
						SchemeNo += "guid'" + _aSCList[i].toUpperCase() + "'";
						if (i !== _aSCList.length - 1)
							SchemeNo += ",";
					}
				}
				// oDataModel.setHeaders({
				// 	"x-arteria-printformat": Indicator,
				// 	"x-arteria-summary": isHSNSelected ? "X" : " "
				// });
				if (_aSCList.length > 0) {
					oDataModel.read("/SchemePrintPDF", {
						urlParameters: "SchemeGUID='" + SchemeNo + "'&LoginID='" + tempLogid + "'",
						success: function(oData) {
							var sPdf = oData.SchemePrintPDF.Pdf;

							var pdf = "data:application/pdf;base64, " + escape(sPdf);
							var dialog = new sap.m.Dialog({
								showHeader: false,
								contentHeight: "900px",
								contentWidth: "1100px",
								content: new sap.ui.core.HTML({
									content: "<iframe height='900px' width='1100px' src='" + pdf + "' />"
								}),
								beginButton: new sap.m.Button({
									text: 'Close',
									icon: 'sap-icon://decline',
									type: 'Reject',
									press: function() {
										dialog.close();
									}
								})
							});
							dialog.open();
						},
						error: function(error) {
							oPPCCommon.removeDuplicateMsgsInMsgMgr();
							var message = oPPCCommon.getMsgsFromMsgMgr();
							oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
						}

					});
				} else {
					oPPCCommon.displayMsg_MsgBox(that.getView(), "Please select Scheme", "error");
				}
			}
			
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});