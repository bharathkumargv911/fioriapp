sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/m/BusyDialog",
	"com/arteriatech/ss/schemes/controller/BaseController",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common",
	"com/arteriatech/prd/utils/js/UserMapping",
	"com/arteriatech/prd/utils/js/CommonValueHelp"
], function (Controller, JSONModel, History, BusyDialog, BaseController) {
	"use strict";
	var oi18n, oUtilsI18n;
	var Device = sap.ui.Device;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oProductCommon, oProductUserMapping, oCommonValueHelp;
	var product = "PD";
	var busyDialog = new sap.m.BusyDialog();
	var MessageBox = sap.m.MessageBox;
	return Controller.extend("com.arteriatech.ss.schemes.controller.List", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.List
		 */
		onInit: function () {
			this.onInitHookUp();
		},

		onInitHookUp: function () {
			this._oView = this.getView();
			/**
			 * Get reference of the Parent component i.e Component.js
			 */
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));

			oProductCommon = com.arteriatech.ss.utils.js.Common;
			oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
			oProductUserMapping = com.arteriatech.ss.utils.js.UserMapping;

			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			//Router Initialisation
			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			//Attach event for routing on view patter matched 
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.setDefaultSettings();
			// this.getCreatedOnDateDDValues();
			// this.getValidFromDateDDValues();
			this.setValuehelpProperty();

			if (this.onInitHookUp_Exit) {
				this.onInitHookUp_Exit();
			}
		},

		onRouteMatched: function (oEvent) {
			/**Check if the routing is "TO THE VIEW" or "FROM THE VIEW"
			 * If "TO THE VIEW" the value of oEvent.getParameter("name") will be same as view name registered in the routing(manifest.json)
			 * Only if "TO THE VIEW" execute the controller methods else just return from controller
			 */

			if (oEvent.getParameter("name") !== "ListPage" && oEvent.getParameter("name") !== "SearchListPage") {
				return;
			}
			if (oPPCCommon.getFLPTileAction() === "Approve") {
				this._oRouter.navTo("contractapprove", {}, true);
			} else {
				// this.setDefaultSettings();
				// if (oPPCCommon.getFLPTileAction() === "AplicableSchemes") {
				// 	this.getView().getModel("LocalViewSetting").setProperty("/AplicableSchemes", true);
				// }

				var selectedCustomer = "";
				var oDataModel = this.getView().getModel("PUGW");
				oProductCommon.setODataModel(oDataModel);
				var that = this;
				this.sCustomerInpuType = "DD";

				/**Check the History of the routing
				 * If routing history direction is Backwards it mean returning is back to the view from where you navigated.
				 * As the view is still not destroyed so no need to call any controller methods.
				 */
				//this.getView().byId("FilterBar").setBusy(true);
				var oHistory = sap.ui.core.routing.History.getInstance();
				this.contextPath = oEvent.getParameter("arguments").contextPath;
				oPPCCommon.removeAllMsgs();
				this.onReset();

				// if (oHistory.getDirection() !== "Backwards") {

				if (oPPCCommon.getFLPTileAction().split("&")[0] === "ApplicableSchemes") {
					this.getView().getModel("LocalViewSetting").setProperty("/AplicableSchemes", true);
				}
				if (!(gSchemeDetails && gSchemeDetails.getModel("LocalViewSettingDtl").getProperty("/backPress"))) {
					if (oEvent.getParameter("name") === "SearchListPage") {
						this.contextPath = oEvent.getParameter("arguments").contextPath;
						oProductCommon.getCustomerInputType(function (CustomerInputType) {
							that.sCustomerInpuType = CustomerInputType;
							that.getParametersFromContext(that.contextPath);
						});
					} else {
						if (sap.ui.Device.system.phone) {
							this.onSearch();
						} else {
							busyDialog.open();
							that.getCustomers("", function () {

								gListPageView.setBusy(false);
							});
							// oProductCommon.getCustomerInputType(function (CustomerInputType) {
							// 	that.sCustomerInpuType = CustomerInputType;

							// });
						}
					}

				}
				// else if (oEvent.getParameter("name") === "ListPage") {
				// 	//  busyDialog.open();
				// 	this.getSchemeItems();
				// 	// this.onReset();
				// 	// /[]
				// 	// selectedCustomer = "";
				// 	// this.setDefaultSettings();
				// 	// if (oPPCCommon.getFLPTileAction() === "ApplicableSchemes") {
				// 	// 	this.getView().getModel("LocalViewSetting").setProperty("/AplicableSchemes", true);
				// 	// }
				// 	// oProductCommon.getCustomerInputType(function (CustomerInputType) {
				// 	// 	that.sCustomerInpuType = CustomerInputType;
				// 	// 	that.getCustomers(selectedCustomer, function () {
				// 	// 		//that.getView().byId("FilterBar").setBusy(false);
				// 	// 		gListPageView.setBusy(false);
				// 	// 	});
				// 	// });
				// } 
				else {
					if (gSchemeDetails && gSchemeDetails.getModel("LocalViewSettingDtl")) {
						gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/backPress", false);
					}
					this.getSchemeItems();
					//this.getView().byId("FilterBar").setBusy(false);
					gListPageView.setBusy(false);
				}
			}
		},
		// onExit: function () {
		// 	if (gSchemeDetails) {
		// 		if (gSchemeDetails.getModel("LocalViewSettingDtl")) {
		// 			gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/", []);
		// 		}
		// 	}
		// },

		/* 
			1)Clear All Models.
			2)Reset all default selection fileds.
		*/
		onReset: function () {
			//Remove Tokens from all MultiInputs 
			var aValueHelpIDs = ["multiInputSchemes"]; //<ToAdd all ValueHelp IDs with cama seperation>
			this.clearTokens(aValueHelpIDs);

			//Clear Model
			if (this.getView().getModel("ListItems") !== undefined) {
				this.getView().getModel("ListItems").setProperty("/", {});
				this.resetUITable();
			}

			if (this.onReset_Exit) {
				this.onReset_Exit();
			}
		},
		onRowSCDetailSelect: function (oEvent) {
			_aSCList = [];
			var oItemModel = this.getView().getModel("ListItems").getProperty("/");
			for (var i = 0; i < oItemModel.length; i++) {
				if (oItemModel[i].Selected) {
					_aSCList.push(oItemModel[i].SchemeGUID);
				}
			}
		},
		resetUITable: function () {
			oPPCCommon.clearUITable(this.getView(), "UISchemesTable", "ListItems");

			if (this.resetUITable_Exit) {
				this.resetUITable_Exit();
			}
		},

		clearTokens: function (mParameters) {
			for (var i = 0; i < mParameters.length; i++) {
				this.getView().byId(mParameters[i]).removeAllTokens();
			}
		},

		setDefaultSettings: function () {
			var that = this;
			/**
			 * All view related local settings should be mapped in a Model and is called LocalViewSetting
			 */
			var oViewSettingModel = new sap.ui.model.json.JSONModel();
			this.viewSettingData = {
				ListItemsCount: 0,
				CustomerColumnVisibleInF4: true,
				CustomerDD: false,
				CustomerMC: false,
				CustomerVH: false,
				DateFormat: oSSCommon.getDateFormat(),
				AplicableSchemes: false,
				tokenTextLength: 10
					// that._oComponent.getModel("LocalViewSetting").setProperty("/ServerDate", ServerDate);
			};
			oViewSettingModel.setData(this.viewSettingData);
			this._oComponent.setModel(oViewSettingModel, "LocalViewSetting");

			if (this.setDefaultSettings_Exit) {
				this.setDefaultSettings_Exit();
			}
		},
		TextAbstract: function (text, key, length) {
			text = text + "(" + key + ")";
			if (text === null) {
				return "";
			}
			if (text.length <= length) {
				return text;
			}
			text = text.substring(0, length);
			// last = text.lastIndexOf(" ");
			// text = text.substring(0, last);
			return text + "...";
		},
		/*------------------------------------------Setting Date filter Model and Events---------------------------------------------------*/
		getCreatedOnDateDDValues: function () {
			var that = this;
			var sDateRange = "-30";
			this.CreatedOnDateDifference = sDateRange;
			this.PreviousSelectedKeyCreatedOnDate = this.CreatedOnDateDifference;

			this.getCurrentServerDate(this, function (Today) {
				that.getView().getModel("LocalViewSetting").setProperty("/Today", Today);
				var date = that.getView().getModel("LocalViewSetting").getProperty("/Today");
				window.localStorage.setItem('name', JSON.stringify(date));
				var oneMonthBackDate = that.getView().getModel("LocalViewSetting").getProperty("/Today");

				oneMonthBackDate.setDate(Today.getDate() + parseInt(that.PreviousSelectedKeyCreatedOnDate));

				var todate = window.localStorage.getItem('name');
				var a = todate;
				var b = a.replace(/"/g, '');

				that.CreatedOnDate = {
					FromDate: oneMonthBackDate,
					ToDate: new Date(b.split("T")[0])
				};
			});

			// var ServerDate = that._oComponent.getModel("LocalViewSetting").getProperty("/ServerDate");

			// window.localStorage.setItem('name', JSON.stringify(ServerDate));
			// //	var oneMonthBackDate = oPPCCommon.getCurrentServerDate(that);

			// var oneMonthBackDate = that._oComponent.getModel("LocalViewSetting").getProperty("/ServerDate");
			// oneMonthBackDate.setDate(oneMonthBackDate.getDate() + parseInt(this.CreatedOnDateDifference));

			// var todate = window.localStorage.getItem('name');
			// var a = todate;

			// var b = a.replace(/"/g, '');
			// this.CreatedOnDate = {
			// 	FromDate: oneMonthBackDate,
			// 	ToDate: new Date(b.split("T")[0])
			// };
			/*for CreatedOn Date*/
			if (this.getView().getModel("CreatedOnDateViewSetting")) {
				this.getView().getModel("CreatedOnDateViewSetting").setProperty("/", {});
			}
			var oDataDate = [{
				DateKey: "",
				DateDesc: "Any"
			}, {
				DateKey: "0",
				DateDesc: "Today"
			}, {
				DateKey: "-1",
				DateDesc: "Today and Yesterday"
			}, {
				DateKey: "-7",
				DateDesc: "Last Seven Days"
			}, {
				DateKey: "-30",
				DateDesc: "Last One Month"
			}, {
				DateKey: "MS",
				DateDesc: "Manual Selection"
			}];
			oPPCCommon.getDateDropDownValue(oDataDate, this, "inputCreatedOnDate", "CreatedOnDateViewSetting", this.CreatedOnDateDifference);

		},

		getCurrentServerDate: function (oController, callback) {
			//get odata model object from the ui5 app
			var oModelData = oController._oComponent.getModel("PCGW");
			// var sUrl = oModelData.sServiceUrl;
			// sUrl = sUrl + "/Today";
			// var currentDate = new Date();
			oModelData.read("/Today", {
				dataType: "json",
				success: function (data) {
					if (callback) {
						callback(data.Today.Today);
					}
				},
				error: function (error) {
					if (callback) {
						// callback();

						MessageBox.error(
							"Cannot laod Server Date", {
								styleClass: "sapUiSizeCompact"
							}
						);

					}
				}
			});

			// var oResponse = jQuery.sap.sjax({
			// 	url: sUrl,
			// 	dataType: "json"
			// });
			// try {
			// 	if (oResponse.success) {
			// 		//handle response and retrive the
			// 		var oServerCfg = {};
			// 		oServerCfg = oResponse.data;
			// 		var sJsonDate = oServerCfg.d.Today.Now;
			// 		currentDate = new Date(parseInt(sJsonDate.substr(6)));
			// 		if (callback) {
			// 			callback(currentDate);
			// 		}
			// 	} else {
			// 		currentDate = new Date();
			// 		if (callback) {
			// 			callback(currentDate);
			// 		}
			// 	}
			// } catch (error) {
			// 	//handle error
			// 	currentDate = new Date();
			// 	if (callback) {
			// 		callback(currentDate);
			// 	}
			// }

			//it will return server date
			// return currentDate;
		},

		onCreatedOnDateSelectionChanged: function (oEvent) {
			var that = this;
			var oDateSelect = oEvent.getSource();
			var dateFormat = this.getView().getModel("LocalViewSetting").getProperty("/DateFormat");
			var sSelectedKey = oEvent.getParameter("selectedItem").getKey();
			that.openManualDateSelectionDialog(this, sSelectedKey, oDateSelect, this.PreviousSelectedKeyCreatedOnDate,
				"CreatedOnDateViewSetting",
				oi18n,
				"inputCreatedOnDate",
				function (date) {
					that.CreatedOnDate.FromDate = date.fromDate;
					that.CreatedOnDate.ToDate = date.toDate;
				}, dateFormat);
			// this.PreviousSelectedKeyCreatedOnDate = oEvent.getParameter("selectedItem").getKey();
			if (oEvent.getParameter("selectedItem").getKey() !== "MS") {
				this.PreviousSelectedKeyCreatedOnDate = oEvent.getParameter("selectedItem").getKey();
			}
		},
		openManualDateSelectionDialog: function (that, sSelectedKey, oDateSelect, previousSelectedKey, model, oi18n, fieldId,
			requestCompleted, sFormatType) {
			that.dateRange = {
				fromDate: null,
				toDate: null
			};
			var view = that.getView();
			if (sSelectedKey === "MS") {
				var dateRangeSelectionDialog;
				that.OkButton = new sap.m.Button({
					text: 'OK',
					enabled: false,
					press: function () {
						if (that.DateRangeSelection.getDateValue() && that.DateRangeSelection.getSecondDateValue()) {
							var oData = view.getModel(model).getData();
							if (oData[oData.length - 1].DateKey === "SD") {
								oData.splice(oData.length - 1, 1);
							}
							view.getModel(model).setData(oData);

							that.DateManulaSeletedDesc = com.arteriatech.ppc.utils.js.Common.formatSelectedDate(that.DateRangeSelection.getDateValue(),
								that.DateRangeSelection.getSecondDateValue(), oi18n, sFormatType);
							var oDataLength = view.getModel(model).getData().length - 1;
							//						view.getModel(model).setProperty("/"+oDataLength+"/DateDesc", that.DateManulaSeletedDesc)
							var newData = view.getModel(model).getData();
							newData.push({
								DateKey: "SD",
								DateDesc: that.DateManulaSeletedDesc
							});
							view.getModel(model).setData(newData);
							view.byId(fieldId).setSelectedKey("SD");
							var fromDate = that.DateRangeSelection.getDateValue();
							//fromDate.setDate(fromDate.getDate() + 1);
							that.dateRange.fromDate = fromDate;
							var toDate = that.DateRangeSelection.getSecondDateValue();
							//toDate.setDate(toDate.getDate() + 1);
							that.dateRange.toDate = toDate;
							dateRangeSelectionDialog.close();
						}
						if (requestCompleted) requestCompleted(that.dateRange);
						return that.dateRange
					}

				});

				that.DateRangeSelection = new sap.m.DateRangeSelection({
					change: function () {
						if (that.DateRangeSelection.getDateValue() && that.DateRangeSelection.getSecondDateValue()) {
							that.OkButton.setEnabled(true);
						} else {
							that.OkButton.setEnabled(false);
						}
					},
					displayFormat: sFormatType
				});

				dateRangeSelectionDialog = new sap.m.Dialog({
					title: "Select Date Manually",
					type: 'Standard',
					resizable: true,
					draggable: true,
					content: [
						that.DateRangeSelection
					],
					beginButton: that.OkButton,
					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function () {
							var oData = view.getModel(model).getData();
							if (oData[oData.length - 1].DateKey === "SD") {
								view.byId(fieldId).setSelectedKey("SD");
							} else {
								view.byId(fieldId).setSelectedKey(previousSelectedKey);
								that.setASNDateRange(that, previousSelectedKey);
							}
							dateRangeSelectionDialog.close();
						}
					}),
					afterClose: function () {
						dateRangeSelectionDialog.destroy();
					}
				});
				if (!jQuery.support.touch) {
					dateRangeSelectionDialog.addStyleClass("sapUiSizeCompact");
				}
				dateRangeSelectionDialog.open();

			} else {
				var oData = that.getView().getModel(model).getData();
				if (oData[oData.length - 1].DateKey === "SD") {
					oData.splice(oData.length - 1, 1);
				}
				that.getView().getModel(model).setData(oData);
				that.dateValues = that.setASNDateRange(that, sSelectedKey);
				that.dateRange.fromDate = that.dateValues.fromDate;
				that.dateRange.toDate = that.dateValues.toDate;

				if (requestCompleted) requestCompleted(that.dateRange);
				return that.dateRange;
			}
		},
		setASNDateRange: function (that, sSelectedKey) {
			that.DateValue = {
				fromDate: null,
				toDate: null
			};
			sSelectedKey = parseInt(sSelectedKey);
			if (!isNaN(sSelectedKey)) {
				// that.getCurrentServerDate(this, function (Today) {
				var todate = window.localStorage.getItem('name');
				var a = todate;

				var b = a.replace(/"/g, '');
				that.DateValue.toDate = new Date(b.split("T")[0]);
				var fromDate = new Date(b.split("T")[0]);
				fromDate.setDate(fromDate.getDate() + sSelectedKey);
				that.DateValue.fromDate = fromDate;
				// });

			}
			return that.DateValue;
		},

		setChannelDD: function (customer) {
			var view = this.getView();
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oFilter = new Array();
			oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false,
				false, false);
			oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"],
				false, false, false);
			oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["DMSDiv"], false,
				false, false);
			oSSCommon.getDropdown(oModelData, "ValueHelps", oFilter, "ID", "Description", busyDialog, view, "DMSDivisionDD", "", function (
				aDDValue) {
				if (that.contextPath) {
					var sStatusID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "DmsDivision");
					if (sStatusID) {
						that.getView().byId("FDmsDivision").setSelectedKeys(sStatusID.split(";"));
					}
				}
			});
			if (that.setDMSDivisionDD_Exit) {
				that.setDMSDivisionDD_Exit();
			}
		},
		getValidFromDateDDValues: function () {
			var that = this;
			var sDateRange = "0";
			this.ValidFromDateDifference = sDateRange;
			this.PreviousSelectedKeyValidFromDate = this.ValidFromDateDifference;
			//	var today = oPPCCommon.getCurrentServerDate(that);

			this.getCurrentServerDate(this, function (Today) {
				var todate = window.localStorage.getItem('name');
				var a = todate;
				var b = a.replace(/"/g, '');
				var Today = new Date(b.split("T")[0]);
				// var Today = window.localStorage.getItem('name');
				that.getView().getModel("LocalViewSetting").setProperty("/Today", Today);
				var date = that.getView().getModel("LocalViewSetting").getProperty("/Today");
				window.localStorage.setItem('names', JSON.stringify(date));
				var oneMonthBackDate = that.getView().getModel("LocalViewSetting").getProperty("/Today");

				oneMonthBackDate.setDate(Today.getDate() + parseInt(that.PreviousSelectedKeyValidFromDate));

				var todate = window.localStorage.getItem('name');
				var a = todate;
				var b = a.replace(/"/g, '');

				that.ValidFromDate = {
					FromDate: new Date(b.split("T")[0]),
					ToDate: new Date(b.split("T")[0])
				};
			});

			// var today = window.localStorage.getItem('name');
			// var a = today;

			// var b = a.replace(/"/g, '');
			// this.ValidFromDate = {
			// 	FromDate: new Date(b.split("T")[0]),
			// 	ToDate: new Date(b.split("T")[0])
			// };
			/*for ValidFrom Date*/
			if (this.getView().getModel("ValidFromDateViewSetting")) {
				this.getView().getModel("ValidFromDateViewSetting").setProperty("/", {});
			}
			var oDataDate = [{
				DateKey: "",
				DateDesc: "Any"
			}, {
				DateKey: "0",
				DateDesc: "Today"
			}, {
				DateKey: "-1",
				DateDesc: "Expired"
			}, {
				DateKey: "1",
				DateDesc: "Yet to Start"
			}, {
				DateKey: "MS",
				DateDesc: "Manual Selection"
			}];
			oPPCCommon.getDateDropDownValue(oDataDate, this, "inputValidFromDate", "ValidFromDateViewSetting", this.ValidFromDateDifference);
		},
		onValidFromDateSelectionChanged: function (oEvent) {
			var that = this;
			var oDateSelect = oEvent.getSource();
			var dateFormat = this.getView().getModel("LocalViewSetting").getProperty("/DateFormat");
			var sSelectedKey = oEvent.getParameter("selectedItem").getKey();
			that.openManualDateSelectionDialogs(this, sSelectedKey, oDateSelect, this.PreviousSelectedKeyValidFromDate,
				"ValidFromDateViewSetting",
				oi18n,
				"inputValidFromDate",
				function (date) {
					that.ValidFromDate.FromDate = date.fromDate;
					that.ValidFromDate.ToDate = date.toDate;
				}, dateFormat);
			// this.PreviousSelectedKeyValidFromDate = oEvent.getParameter("selectedItem").getKey();
			if (oEvent.getParameter("selectedItem").getKey() !== "MS") {
				this.PreviousSelectedKeyValidFromDate = oEvent.getParameter("selectedItem").getKey();
			}
		},

		openManualDateSelectionDialogs: function (that, sSelectedKey, oDateSelect, previousSelectedKey, model, loi18n, fieldId,
			requestCompleted, sFormatType) {
			that.dateRange = {
				fromDate: null,
				toDate: null
			};
			var view = that.getView();
			if (sSelectedKey === "MS") {
				var dateRangeSelectionDialog;
				that.OkButton = new sap.m.Button({
					text: 'OK',
					enabled: false,
					press: function () {
						if (that.DateRangeSelection.getDateValue()) {
							var oData = view.getModel(model).getData();
							if (oData[oData.length - 1].DateKey === "SD") {
								oData.splice(oData.length - 1, 1);
							}
							view.getModel(model).setData(oData);

							that.DateManulaSeletedDesc = that.formatSelectedDate(that.DateRangeSelection.getDateValue(),
								null, oi18n, sFormatType);
							var oDataLength = view.getModel(model).getData().length - 1;

							var newData = view.getModel(model).getData();
							newData.push({
								DateKey: "SD",
								DateDesc: that.DateManulaSeletedDesc
							});
							view.getModel(model).setData(newData);
							view.byId(fieldId).setSelectedKey("SD");
							var fromDate = that.DateRangeSelection.getDateValue();
							//fromDate.setDate(fromDate.getDate() + 1);
							that.dateRange.fromDate = fromDate;
							var toDate = that.DateRangeSelection.getDateValue();
							//toDate.setDate(toDate.getDate() + 1);
							that.dateRange.toDate = toDate;
							dateRangeSelectionDialog.close();
						}
						if (requestCompleted) {
							requestCompleted(that.dateRange);
						}
						return that.dateRange;
					}

				});

				that.DateRangeSelection = new sap.m.DatePicker({
					change: function () {
						if (that.DateRangeSelection.getDateValue()) {
							that.OkButton.setEnabled(true);
						} else {
							that.OkButton.setEnabled(false);
						}
					},
					displayFormat: sFormatType
				});

				dateRangeSelectionDialog = new sap.m.Dialog({
					title: "Select Date Manually",
					type: 'Standard',
					resizable: true,
					draggable: true,
					content: [
						that.DateRangeSelection
					],
					beginButton: that.OkButton,
					endButton: new sap.m.Button({
						text: 'Cancel',
						press: function () {
							var oData = view.getModel(model).getData();
							if (oData[oData.length - 1].DateKey === "SD") {
								view.byId(fieldId).setSelectedKey("SD");
							} else {
								view.byId(fieldId).setSelectedKey(previousSelectedKey);
								that.setASNDateRanges(that, previousSelectedKey);
							}
							dateRangeSelectionDialog.close();
						}
					}),
					afterClose: function () {
						dateRangeSelectionDialog.destroy();
					}
				});
				if (!jQuery.support.touch) {
					dateRangeSelectionDialog.addStyleClass("sapUiSizeCompact");
				}
				dateRangeSelectionDialog.open();

			} else {
				var oData = that.getView().getModel(model).getData();
				if (oData[oData.length - 1].DateKey === "SD") {
					oData.splice(oData.length - 1, 1);
				}
				that.getView().getModel(model).setData(oData);
				that.dateValues = that.setASNDateRanges(that, sSelectedKey);
				that.dateRange.fromDate = that.dateValues.fromDate;
				that.dateRange.toDate = that.dateValues.toDate;

				if (requestCompleted) requestCompleted(that.dateRange);
				return that.dateRange;
			}
		},
		setASNDateRanges: function (that, sSelectedKey) {
			that.DateValue = {
				fromDate: null,
				toDate: null
			};
			sSelectedKey = parseInt(sSelectedKey);
			if (!isNaN(sSelectedKey)) {
				// that.getCurrentServerDate(this, function (Today) {
				var todate = window.localStorage.getItem('name');
				var a = todate;

				var b = a.replace(/"/g, '');
				that.DateValue.toDate = new Date(b.split("T")[0]);
				var fromDate = new Date(b.split("T")[0]);
				fromDate.setDate(fromDate.getDate() + sSelectedKey);
				that.DateValue.fromDate = fromDate;
				// });

			}
			return that.DateValue;
		},

		formatSelectedDate: function (f, s, loi18n, sFormatType) {
			jQuery.sap.require("sap.ca.ui.model.format.DateFormat");

			var d = "";
			if (sFormatType) {
				d = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: sFormatType
				});
			} else {
				d = sap.ca.ui.model.format.DateFormat.getInstance({
					style: 'medium'
				});
			}
			if (f && s) {
				f = d.format(f);
				s = d.format(s);
			} else if (!f) {
				s = d.format(s);
			} else if (!s) {
				f = d.format(f);
			}
			var dateRange = f;
			return dateRange;
			//		return (oi18n.getText("List.Filterbar.Date.fragment.dateRange", [f, s]))
		},

		setMaunalSelectedDate: function (that, fromDate, toDate, oModel, sField, sKey, loi18n, sFormatType) {
			var dDateFrom = new Date(fromDate);
			var dDateTo = new Date(toDate);
			dDateFrom = dDateFrom.setDate(dDateFrom.getDate());
			dDateTo = dDateTo.setDate(dDateTo.getDate());
			that.DateManulaSeletedDesc = this.formatSelectedDate(new Date(dDateFrom), null, oi18n, sFormatType);
			var newData = that.getView().getModel(oModel).getData();
			newData.push({
				DateKey: sKey,
				DateDesc: that.DateManulaSeletedDesc
			});
			that.getView().getModel(oModel).setData(newData);
			that.getView().byId(sField).setSelectedKey(sKey);
		},

		/*------------------------------------------Extracting Value from Contextpath------------------------*/
		getParametersFromContext: function () {
			var that = this;
			var tokenTextLength = that.getView().getModel("LocalViewSetting").getProperty("/tokenTextLength");
			this.iTotalValueHelps = 1;
			// var customer = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "Distributor");
			var sSchemeID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SchemeID");
			var sSchemeCat = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SchemeCatID");
			var sSchemeTypeID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SchemeTypeID");
			var dCreatedOn = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "CreatedOnDate");
			var dValidFrom = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "Validity");
			var sStatusID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "StatusID");
			if (!this.getView().getModel("LocalViewSetting").getProperty("/AplicableSchemes")) {
				var sApprovalStatusID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "ApprovalStatusID");
			}
			//Setting Multicombo
			if (sSchemeCat) {
				this.getView().byId("multiSchemeCatagory").setSelectedKeys(sSchemeCat.split(";"));
			}
			if (sSchemeTypeID) {
				this.getView().byId("multiSchemeType").setSelectedKeys(sSchemeTypeID.split(";"));
			}
			if (sStatusID) {
				this.getView().byId("multiStatusID").setSelectedKeys(sStatusID.split(";"));
			}
			if (sApprovalStatusID) {
				this.getView().byId("multiApprovalStatusID").setSelectedKeys(sApprovalStatusID.split(";"));
			}
			var DMSDivision = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "DmsDivision");
			if (DMSDivision) {
				this.getView().byId("FDmsDivision").setSelectedKeys(DMSDivision.split(";"));
			}
			// if (this.sCustomerInpuType === "VH") {
			// 	this.setCustomerInputVisibility();
			// 	that.callService();

			// } else {
			// 	that.getCustomers("", function () {}, true);
			// }
			if (sSchemeID !== "") {
				var SPNoFilters = new Array();
				SPNoFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "multiInputSchemes", SPNoFilters, "SchemeGUID", sap.ui.model.FilterOperator
					.EQ, sSchemeID.split(";"), true, false, false);
				var oSPNoModelData = this._oComponent.getModel("SCGW");
				oPPCCommon.createTokens(oSPNoModelData, "Schemes", SPNoFilters, "SchemeGUID", "SchemeName", this.getView().byId(
						"multiInputSchemes"),
					function (aData) {
						var aTokens = [];
						that.oSchemeTokenInput.removeAllTokens();
						aData.forEach(function (eachElement) {
							var oToken = new sap.m.Token({
								key: eachElement.SchemeGUID,
								tooltip: eachElement.SchemeName + "(" + eachElement.SchemeID + ")",
								text: that.TextAbstract(eachElement.SchemeName, eachElement.SchemeID, tokenTextLength)
							});
							aTokens.push(oToken);
						});
						that.oSchemeTokenInput.setTokens(aTokens);
						that.callService();
					}, "PD", "SchemeGUID");
			} else {
				that.callService();
			}
			// that.getView().byId("inputCreatedOnDate").setSelectedKey(dCreatedOn);
			// if (dCreatedOn !== "") {
			// 	var CreatedOnDateFrom = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "CreatedOnFromDate");
			// 	var CreatedOnDateTo = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "CreatedOnToDate");
			// 	this.CreatedOnDate = {
			// 		FromDate: new Date(CreatedOnDateFrom),
			// 		ToDate: new Date(CreatedOnDateTo)
			// 	};
			// 	that.callService();
			// 	if (dCreatedOn === "SD") {
			// 		var sFormatType = this.getView().getModel("LocalViewSetting").getProperty("/DateFormat");
			// 		oSSCommon.setMaunalSelectedDate(this, CreatedOnDateFrom, CreatedOnDateTo, "CreatedOnDateViewSetting", "inputCreatedOnDate",
			// 			dCreatedOn, oi18n, sFormatType);
			// 	}
			// } else {
			// 	this.CreatedOnDate = {
			// 		FromDate: null,
			// 		ToDate: null
			// 	};
			// 	that.callService();
			// }
			// that.getView().byId("inputValidFromDate").setSelectedKey(dValidFrom);
			// if (dValidFrom !== "") {
			// 	var ValidFromDateFrom = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "ValidFromDate");
			// 	var ValidFromDateTo = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "ValidFromToDate");
			// 	this.ValidFromDate = {
			// 		FromDate: new Date(ValidFromDateFrom),
			// 		ToDate: new Date(ValidFromDateTo)
			// 	};
			// 	that.callService();
			// 	if (dValidFrom === "SD") {
			// 		var ssFormatType = this.getView().getModel("LocalViewSetting").getProperty("/DateFormat");
			// 		this.setMaunalSelectedDate(this, ValidFromDateFrom, ValidFromDateTo, "ValidFromDateViewSetting", "inputValidFromDate",
			// 			dValidFrom, oi18n, ssFormatType);
			// 	}
			// } else {
			// 	this.ValidFromDate = {
			// 		FromDate: null,
			// 		ToDate: null
			// 	};

			// 	that.callService();
			// }

			if (this.getParametersFromContext_Exit) {
				this.getParametersFromContext_Exit();
			}
		},
		callService: function () {
			this.iTotalValueHelps--;
			if (this.iTotalValueHelps === 0) {
				//	this.getView().byId("FilterBar").setBusy(false);
				this.getSchemeItems();
			}
		},
		/*-----------------------------------------Search event on Go from Filterbar-------------------------*/
		onSearch: function () {
			if (this.checkValueState()) {
				this.validateMandatory();
				if (oPPCCommon.doErrMessageExist()) {
					var contextPath = this.prepareContext();
					//gListPageView.setBusy(true);
					// if (this.contextPath !== undefined && this.contextPath === contextPath) {
					if (true) {
						this.resetUITable();
						this.getSchemeItems();
					} else {
						this._oRouter.navTo("SearchListPage", {
							contextPath: contextPath
						}, false);
					}
				} else {
					oPPCCommon.displayMsg_MsgBox(this.getView(), oPPCCommon.getMsgsFromMsgMgr(), "error");
				}
			} else {
				oPPCCommon.displayMsg_MsgBox(this.getView(), oPPCCommon.getMsgsFromMsgMgr(), "error");
			}
		},
		getSchemeItems: function () {
			busyDialog.open();
			var oView = this.getView();
			var that = this;
			var SchemeItemsListModel = this._oComponent.getModel("SCGW");

			this.getCurrentUsers("Schemes", "read", function (LoginID) {
				SchemeItemsListModel.attachRequestSent(function () {
					//gListView.setBusy(true);
				});
				SchemeItemsListModel.attachRequestCompleted(function () {
					//gListView.setBusy(false);
				});

				SchemeItemsListModel.read("/Schemes", {
					filters: that.prepareSchemeODataFilter(LoginID),
					success: function (oData) {

						busyDialog.close();
						oData = oPPCCommon.formatItemsOData({
							oData: oData
						});
						if (oData.length > 0) {
							if (oData.length > 0) {
								for (var i = 0; i < oData.length; i++) {
									oData[i].OrderNo = parseFloat(oData[i].OrderNo);
								}
								that.setSchemeitemsData(oData);
								that.applyUITableGrouping(0);
								if (that.sCustomerInpuType === "DD") {
									//if (that.getView().byId("customer").getSelectedKey() === "")
									that.applyTableGrouping("CustomerNo", "Name", "Customer");
								} else if (that.sCustomerInpuType === "VH") {
									if (that.getView().byId("inputCustomerF4").getTokens().length === 0) {
										that.applyTableGrouping("CustomerNo", "Name", "Customer");
									}
								}
							}
						} else {
							that.setNodataFound();
						}
						busyDialog.close();
						gListPageView.setBusy(false);
					},
					error: function (error) {
						busyDialog.close();
						that.setNodataFound();
						oPPCCommon.dialogErrorMessage(error, oUtilsI18n.getText("common.Dialog.Error.ServiceError.Header"));
						gListPageView.setBusy(false);
					}

				});
			});
			if (this.getSalesOrders_Exit) {
				this.getSalesOrders_Exit();
			}
		},

		setSchemeitemsData: function (oData) {

			var oSchemeModel = new sap.ui.model.json.JSONModel();
			var DistListItems = [];
			// this.getView().getModel("LocalViewSetting").setProperty("/AplicableSchemes", true)
			if (this.getView().getModel("LocalViewSetting").getProperty("/AplicableSchemes")) {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i].ApprovalStatusID === "03") {
						DistListItems.push(oData[i]);
					}
				}
				oSchemeModel.setSizeLimit(DistListItems.length);
				oSchemeModel.setData(DistListItems);
				this.getView().getModel("LocalViewSetting").setProperty("/ListItemsCount", DistListItems.length);
			} else {

				oSchemeModel.setSizeLimit(oData.length);
				oSchemeModel.setData(oData);
				this.getView().getModel("LocalViewSetting").setProperty("/ListItemsCount", oData.length);
			}
			this._oComponent.setModel(oSchemeModel, "ListItems");

		},

		prepareSchemeODataFilter: function (LoginID) {
			var that = this;
			var ItemsFilters = new Array();
			var SchemeGUID = oPPCCommon.getKeysFromTokens(this.getView(), "multiInputSchemes");
			// var SchemeGUID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "SchemeID");
			/**
			 * Prepare filter for oDataRead by using Utils method setODataModelReadFilter
			 * Paremeters: 1)view 2)controlID 3)filterArray 4)path 5)operator 6)value array 7)isMultiValue 8)isToken 9)isAnd
			 */
			//          if (this.sCustomerInpuType === "DD") {
			// 	ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "Distributor", sap.ui.model.FilterOperator
			// 		.EQ, [this.getView().byId("customer").getSelectedKey()], false, false, false);
			// } else if (this.sCustomerInpuType === "VH") {
			// 	ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputCustomerF4", ItemsFilters, "Distributor", "",
			// 		"",
			// 		true, true, false);
			// }
			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "SchemeGUID",
				sap.ui.model.FilterOperator.EQ, SchemeGUID.split(";"), true, false, false);
			// ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "multiInputSchemes", ItemsFilters, "SchemeGUID", "", [SchemeGUID],
			// 	true,
			// 	true,
			// 	false);
			//if (ItemsFilters.length === 0) {
			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "CreatedOn", sap.ui.model.FilterOperator.BT, [
				this.CreatedOnDate.FromDate, this.CreatedOnDate.ToDate
			], false, false, false);

			var dValidFrom = this.getView().byId("inputValidFromDate").getSelectedKey();

			// var dValidFrom = oPPCCommon.getPropertyValueFromContextPath(this.contextPath, "Validity");
			if (dValidFrom === "1") {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "ValidFrom", sap.ui.model.FilterOperator.GE, [
					this.ValidFromDate.FromDate
				], false, false, false);
			} else if (dValidFrom === "-1") {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "ValidTo", sap.ui.model.FilterOperator.LE, [
					this.ValidFromDate.FromDate
				], false, false, false);
			} else {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "ValidFrom", sap.ui.model.FilterOperator.LE, [
					this.ValidFromDate.FromDate
				], false, false, false);
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "ValidTo", sap.ui.model.FilterOperator.GE, [
					this.ValidFromDate.FromDate
				], false, false, false);
			}
			//}
			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "LoginID", "", [LoginID], false, false,
				false);
			/*if (this.sCustomerInpuType === "DD") {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "VendorNo", sap.ui.model.FilterOperator.EQ, [
					this.getView().byId("customer").getSelectedKey()
				], false, false, false);
			} else if (this.sCustomerInpuType === "MC") {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ItemsFilters, "VendorNo", sap.ui.model.FilterOperator.EQ,
					this.getView().byId("partnerMultiCombo").getSelectedKeys(), true, false, false);
			} else if (this.sCustomerInpuType === "VH") {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "inputVendorF4", ItemsFilters, "VendorNo", "", "", true,
					true,
					false);
			}*/
			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "multiSchemeCatagory", ItemsFilters, "SchemeCatID", sap.ui.model
				.FilterOperator.EQ, this.getView().byId("multiSchemeCatagory").getSelectedKeys(), true, false, false);

			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "multiSchemeType", ItemsFilters, "SchemeTypeID", sap.ui.model.FilterOperator
				.EQ, this.getView().byId("multiSchemeType").getSelectedKeys(), true, false, false);
			if (!this.getView().getModel("LocalViewSetting").getProperty("/AplicableSchemes")) {
				ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "multiApprovalStatusID", ItemsFilters, "ApprovalStatusID", sap.ui
					.model
					.FilterOperator
					.EQ, this.getView().byId("multiApprovalStatusID").getSelectedKeys(), true, false, false);
			}
			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "multiStatusID", ItemsFilters, "StatusID", sap.ui.model
				.FilterOperator
				.EQ, this.getView().byId("multiStatusID").getSelectedKeys(), true, false, false);
			ItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "FDmsDivision", ItemsFilters, "DmsDivision", sap.ui.model.FilterOperator
				.EQ, this.getView().byId("FDmsDivision").getSelectedKeys(), true, false, false);

			if (this.preparePOItemsODataFilter_Exit) {
				ItemsFilters = this.prepareSchemeODataFilter_Exit(ItemsFilters);
			}
			return ItemsFilters;
		},

		setNodataFound: function () {
			var oView = this.getView();
			/** Clear Model of the view */
			if (oView.getModel("ListItems") !== undefined) {
				oView.getModel("ListItems").setProperty("/", {});
			}

			oView.byId("SchemesTable").setNoDataText(oUtilsI18n.getText("common.NoResultsFound"));
			oView.byId("UISchemesTable").setNoData(oUtilsI18n.getText("common.NoResultsFound"));
			oView.byId("UISchemesTable").setVisibleRowCount(2);
			oView.byId("UISchemesTable").setMinAutoRowCount(2);

			oView.getModel("LocalViewSetting").setProperty("/ListItemsCount", 0);
		},

		checkValueState: function () {
			//ToAdd all fileds ID of which ValueState to be checked
			/*if (this.getView().byId("inputPONumber").getValueState() === "Error" ||
				this.getView().byId("inputMaterial").getValueState() === "Error" ||
				this.getView().byId("inputCustomerF4").getValueState() === "Error") {
				return false;
			} else {
				return true;
			}*/
			return true; //Delete this line
		},

		validateMandatory: function () {
			oPPCCommon.removeAllMsgs();

			var dCreatedOnDate1 = this.getView().byId("inputCreatedOnDate").getSelectedKey();

			if (dCreatedOnDate1 === "") {
				if (this.getView().byId("multiInputSchemes").getTokens().length === 0) {
					this.byId("multiInputSchemes").setValueState(sap.ui.core.ValueState.Error);
					var msg = oi18n.getText("common.message.pleaseSelect", [this.getView().byId("SchemeNoValueHelp").getLabel()]);
					this.byId("multiInputSchemes").setValueStateText(msg);
					oPPCCommon.addMsg_MsgMgr(msg, "error", "FG_CustomerNo");
				}
			} else {
				this.byId("multiInputSchemes").setValueState(sap.ui.core.ValueState.None);
				this.byId("multiInputSchemes").setValueStateText("");
			}

			// if (this.sCustomerInpuType === "VH") {
			// 	if (this.getView().byId("inputCustomerF4").getTokens().length === 0) {
			// 		this.byId("inputCustomerF4").setValueState(sap.ui.core.ValueState.Error);
			// 		var msg = oi18n.getText("common.message.pleaseSelect", [this.getView().byId("customerValueHelp").getLabel()]);
			// 		this.byId("inputCustomerF4").setValueStateText(msg);
			// 		oPPCCommon.addMsg_MsgMgr(msg, "error", "FG_CustomerNo");
			// 	} 
			//else {
			// 		if (this.byId("inputCustomerF4").getValue() === "") {
			// 			this.byId("inputCustomerF4").setValueState(sap.ui.core.ValueState.None);
			// 			this.byId("inputCustomerF4").setValueStateText("");
			// 		}
			// 	}
			// }
			if (this.validateMandatory_Exit) {
				this.validateMandatory_Exit();
			}
		},

		prepareContext: function () {
			var contextPath = "";
			var customerNo = this.getSelectedCustomerCode();
			var sSchemeID = oPPCCommon.getKeysFromTokens(this.getView(), "multiInputSchemes");
			var DMSDivision = oPPCCommon.getKeysFromMultiCombo(this.getView(), "FDmsDivision");
			var sSchemeCat = oPPCCommon.getKeysFromMultiCombo(this.getView(), "multiSchemeCatagory");
			var sSchemeTypeID = oPPCCommon.getKeysFromMultiCombo(this.getView(), "multiSchemeType");
			var dCreatedOnDate = this.getView().byId("inputCreatedOnDate").getSelectedKey();
			var dValidFromDate = this.getView().byId("inputValidFromDate").getSelectedKey();
			var sStatusID = oPPCCommon.getKeysFromMultiCombo(this.getView(), "multiStatusID");
			if (!this.getView().getModel("LocalViewSetting").getProperty("/AplicableSchemes")) {
				var sApprovalStatusID = oPPCCommon.getKeysFromMultiCombo(this.getView(), "multiApprovalStatusID");
			}
			if (!this.getView().getModel("LocalViewSetting").getProperty("/AplicableSchemes")) {
				contextPath = "(SchemeID=" + sSchemeID + ",SchemeTypeID=" + sSchemeTypeID + ",SchemeCatID=" +
					sSchemeCat + ",DmsDivision=" + DMSDivision + ",CreatedOnDate=" + dCreatedOnDate + ",CreatedOnFromDate=" + this.CreatedOnDate.FromDate +
					",CreatedOnToDate=" +
					this.CreatedOnDate.ToDate + ",Validity=" + dValidFromDate + ",ValidFromDate=" + this.ValidFromDate.FromDate +
					",ValidFromToDate=" + this.ValidFromDate.ToDate + ",StatusID=" + sStatusID + ",ApprovalStatusID=" + sApprovalStatusID + ")";
			} else {
				contextPath = "(SchemeID=" + sSchemeID + ",SchemeTypeID=" + sSchemeTypeID + ",SchemeCatID=" +
					sSchemeCat + ",DmsDivision=" + DMSDivision + ",CreatedOnDate=" + dCreatedOnDate + ",CreatedOnFromDate=" + this.CreatedOnDate.FromDate +
					",CreatedOnToDate=" +
					this.CreatedOnDate.ToDate + ",Validity=" + dValidFromDate + ",ValidFromDate=" + this.ValidFromDate.FromDate +
					",ValidFromToDate=" + this.ValidFromDate.ToDate + ",StatusID=" + sStatusID + ")";
			}
			if (this.prepareContext_Exit) {
				contextPath = this.prepareContext_Exit(contextPath);
			}
			return contextPath;
		},

		applyTableGrouping: function (sPropertyKey, sPropertyText, sPropertyLabel, aDefaultSorter) {
			oPPCCommon.setGroupInTable(this.getView(), "SchemesTable", sPropertyKey, true, sPropertyLabel, sPropertyText, aDefaultSorter);
		},

		applyUITableGrouping: function (iPosition) {
			// oPPCCommon.setGroupInUITable(this.getView(), "UISchemesTable", iPosition);
		},

		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				oProductCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = oProductCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},

		/*-------------------------------------Customer/Customer Related Functions---------------------------*/
		getCustomers: function (selectedCustomer, callBack, callService) {
			/**
			 * set customer dropdown using utils method getCustomers
			 * Paremeters: 1)oDateModel 2)customer Type 3)User Type 4)busyDialog 5)view 6)callback function
			 */
			var that = this;
			this.setCustomerInputVisibility();

			// if (this.sCustomerInpuType !== "VH") {
			var oCustomerModel = this._oComponent.getModel("SFGW_MST");
			oProductUserMapping.getCustomers(oCustomerModel, "000002", "2", BusyDialog, that.getView(), function (aCustomerData) {
				that.getDropDowns();
				that.getCreatedOnDateDDValues();
				that.getValidFromDateDDValues();

				busyDialog.close();

				that.getCustomerName();
				// var ServerDate = oPPCCommon.getCurrentServerDate(that);
				// that._oComponent.getModel("LocalViewSetting").setProperty("/ServerDate", ServerDate);

				that.setCustomerColumnVisibility();
				if (callService) {
					that.callService();
				}
				if (callBack) {
					callBack();
				}
			});
			//	}
		},
		setCustomerInputVisibility: function () {
			if (this.sCustomerInpuType === "DD") {
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerDD", true);
			} else if (this.sCustomerInpuType === "MC") {
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerMC", true);
			} else if (this.sCustomerInpuType === "VH") {
				this.getView().getModel("LocalViewSetting").setProperty("/CustomerVH", true);
			}

			if (this.setCustomerInputVisibility_Exit) {
				this.setCustomerInputVisibility_Exit();
			}
		},
		getCustomerName: function () {
			if (this.getView().byId("customer").getSelectedItem() != null) {
				if (this.getView().byId("customer").getSelectedItem().getText().split("-").length > 1) {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInF4", false);
					return this.getView().byId("customer").getSelectedItem().getText().split("-")[1].trim();
				} else {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInF4", true);
					return this.getView().byId("customer").getSelectedItem().getText().split("-")[0].trim();
				}
			}
		},
		setCustomerColumnVisibility: function () {
			if (this.getView().byId("customer").getSelectedItem() != null) {
				if (this.getView().byId("customer").getSelectedItem().getText().split("-").length > 1) {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInResult", false);
				} else {
					this.getView().getModel("LocalViewSetting").setProperty("/CustomerColumnVisibleInResult", true);
				}
			}
		},

		getSelectedCustomerCode: function () {
			var CustomerCode;
			if (this.sCustomerInpuType === "DD") {
				CustomerCode = this.getView().byId("customer").getSelectedKey();
			} else if (this.sCustomerInpuType === "MC") {
				var aCustomer = this.getView().byId("partnerMultiCombo").getSelectedKeys();
				if (aCustomer.length > 0) {
					CustomerCode = aCustomer[0];
					for (var i = 1; i < aCustomer.length; i++) {
						if (aCustomer[i] !== "") {
							CustomerCode += ";" + aCustomer[i];
						}
					}
				}
			} else if (this.sCustomerInpuType === "VH") {
				CustomerCode = oPPCCommon.getKeysFromTokens(this.getView(), "inputCustomerF4");
			}

			return CustomerCode;
		},
		getAllSelectedCustomerName: function () {
			var CustomerName = "";
			if (this.sCustomerInpuType === "DD") {
				CustomerName = this.getCustomerName();
			} else if (this.sCustomerInpuType === "MC") {
				var aCustomer = this.getView().byId("partnerMultiCombo").getSelectedItems();
				if (aCustomer.length > 0) {
					CustomerName = aCustomer[0].getText().split(" - ")[1] + " (" + aCustomer[0].getText().split(" - ")[0] + ")";
					for (var i = 1; i < aCustomer.length; i++) {
						CustomerName += "; " + aCustomer[i].getText().split(" - ")[1] + " (" + aCustomer[i].getText().split(" - ")[0] + ")";
					}
				}
			} else if (this.sCustomerInpuType === "VH") {
				CustomerName = oPPCCommon.getTextFromTokens(this.getView(), "inputCustomerF4");
			}

			if (CustomerName === "") {
				CustomerName = "(All)";
			}
			return CustomerName;
		},

		/*------------------------------------Get Drop downs--------------------------------*/
		getDropDowns: function (selectedCustomer, callService) {

			this.setSchemesModel();
			this.setChannelDD();
			// this.getSchemeCategoryDD(selectedCustomer, callService);
			this.getSchemeTypeDD(selectedCustomer, callService);
			this.getSchemeStatusDD(selectedCustomer, callService);
			this.getSchemeAprrovalStatusDD(selectedCustomer, callService);
			if (this.getDropDowns_Exit) {
				this.getDropDowns_Exit();
			}
		},

		// getSchemeCategoryDD: function (selectedCustomer, callService) {
		// 	var oModelData = this._oComponent.getModel("PCGW");
		// 	var oStatusFilter = new Array();
		// 	var that = this;
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
		// 		"SCGW"
		// 	], true, false, false);
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
		// 		"Scheme"
		// 	], false, false, false);
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
		// 		"SchemeCat"
		// 	], false, false, false);
		// 	oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", BusyDialog, this.getView(),
		// 		"SchemeCatDD", "",
		// 		function () {
		// 			if (callService) {
		// 				that.callService();
		// 			}
		// 		}, false, "PD", true);
		// },
		getSchemeTypeDD: function (selectedCustomer, callService) {
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			var that = this;
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
				"SCGW"
			], true, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
				"Scheme"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
				"SchemeType"
			], false, false, false);
			oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", BusyDialog, this.getView(),
				"SchemeTypeDD", "",
				function () {
					if (callService) {
						that.callService();
					}
				}, false, "PD", true);
		},
		getSchemeStatusDD: function (selectedCustomer, callService) {
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			var that = this;
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
				"SCGW"
			], true, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
				"Scheme"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
				"Status"
			], false, false, false);
			oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", BusyDialog, this.getView(),
				"StatusDD", "",
				function () {
					if (callService) {
						that.callService();
					}
				}, false, "PD", true);
		},
		getSchemeAprrovalStatusDD: function (selectedCustomer, callService) {
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			var that = this;
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
				"SCGW"
			], true, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
				"Scheme"
			], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
				"ApprovalStatus"
			], false, false, false);
			oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", BusyDialog, this.getView(),
				"ApprovalStatusDD", "",
				function () {
					if (callService) {
						that.callService();
					}
				}, false, "PD", true);
		},
		/*------------------------------------------Value Help----------------------------------------*/
		/*--------Add Validator--------------*/
		setValuehelpProperty: function () {
			var that = this;

			//Scheme F4
			this.oSchemeTokenInput = this.getView().byId("multiInputSchemes");
			this.aSchemeKeys = ["SchemeGUID", "SchemeID"];
			/*var sSchemePreviousEnteredValue;
			this.oSchemeTokenInput.addValidator(function(args) {
				if (sSchemePreviousEnteredValue !== args.text) {
					sSchemePreviousEnteredValue = args.text;
					var oDataModel = that._oComponent.getModel("SCGW");
					args.text = args.text.toUpperCase();
					var SchemeF4Filters = new Array();
					var fSchemeNo = new sap.ui.model.Filter("SchemeGUID", sap.ui.model.FilterOperator.EQ, args.text);
					SchemeF4Filters.push(fSchemeNo);
					oProductCommon.getTokenForInput(args, oDataModel, "Schemes", SchemeF4Filters, "SchemeGUID", "SchemeName", that.oSchemeTokenInput,
						"Scheme",
						function(oToken, IsSuccess) {
							if (IsSuccess) {
								sSchemePreviousEnteredValue = "";
							}
						});
				}
			});*/

			//Customer F4
			// var that = this;
			var SPNoF4ValidatorValue = "";
			var custF4ValidatorValue = "";
			this.CustomerTokenInput = this.getView().byId("inputCustomerF4");
			this.aCustomerKeys = [
				"CustomerNo",
				"Name"
			];
			this.CustomerTokenInput.addValidator(function (args) {
				var oDataModel = that._oComponent.getModel("SSGW_MST");
				args.text = args.text.toUpperCase();
				var enteredVal = that.CustomerTokenInput.getValue();
				if (custF4ValidatorValue !== enteredVal) {
					custF4ValidatorValue = enteredVal;
					var customer = that.getView().byId("customer").getSelectedKey();
					var F4Filters = new Array();
					if (customer !== null && customer !== undefined && customer.trim() !== "") {
						var fCustomerNo = new sap.ui.model.Filter("CustomerNo", sap.ui.model.FilterOperator.EQ, customer);
						F4Filters.push(fCustomerNo);
					}
					oPPCCommon.getTokenForInput(args, oDataModel, "Customers", F4Filters, "CustomerNo", "Name", that.getView().byId(
						"inputCustomerNo"), "Customer", function () {
						custF4ValidatorValue = "";
					});
				}
			});

			if (this.setValuehelpPropety_Exit) {
				this.setValuehelpPropety_Exit();
			}
		},

		onValueHelpChange: function (oEvent) {
			if (oEvent.getSource().getValue() === "") {
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}
		},

		CustomerF4: function () {
			oCommonValueHelp.CustomerF4({
				oController: this,
				oi18n: oi18n,
				oUtilsI18n: oUtilsI18n,
				controlID: "inputCustomerNo",
				title: oi18n.getText("List.ValueHelp.Parent.header"),
				customerIDLabel: oi18n.getText("List.ValueHelp.Parent.parentNo"),
				customerNameLabel: oi18n.getText("List.ValueHelp.Parent.name")
			});
			if (this.CustomerF4_Exit) {
				this.CustomerF4_Exit();
			}
		},
		// setSchemesModel: function () {
		// 	var that = this;
		// 	var oSCGW_Model = this._oComponent.getModel("SCGW");
		// 	var aSchemeF4Filter = new Array();

		// 	aSchemeF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemeF4Filter, "LoginID", "", [
		// 		that.getCurrentUsers("Schemes", "read")
		// 	], false, false, false);

		// 	oSCGW_Model.read("/Schemes", {
		// 		filters: aSchemeF4Filter,
		// 		urlParameters: {
		// 			"$select": "SchemeID,SchemeName,SchemeGUID,SchemeTypeID,SchemeTypeDesc"
		// 		},
		// 		success: function (oData) {
		// 			oData = oPPCCommon.formatItemsOData({
		// 				oData: oData
		// 			});
		// 			var oSchemeModel = new sap.ui.model.json.JSONModel();
		// 			oSchemeModel.setData(oData);
		// 			that._oComponent.setModel(oSchemeModel, "SchemesNameSuggestorModel");
		// 		},
		// 		error: function (error) {}
		// 	});

		// 	if (this.setSchemeModel_Exit) {
		// 		this.setSchemeModel_Exit();
		// 	}
		// },

		setSchemesModel: function () {
			var that = this;
			var aSchemeF4Filter = new Array();
			oProductCommon.getCurrentLoggedUser({
				sServiceName: "Schemes",
				sRequestType: "read"
			}, function (LoginID) {

				aSchemeF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemeF4Filter, "LoginID", "", [LoginID], false, false, false);
				var oSCGW_Model = that.getView().getModel("SCGW");
				oSCGW_Model.read("/Schemes", {
					filters: aSchemeF4Filter,
					urlParameters: {
						"$select": "SchemeID,SchemeName,SchemeGUID,SchemeTypeID,SchemeTypeDesc"
					},
					success: function (oData) {
						oData = oPPCCommon.formatItemsOData({
							oData: oData
						});
						var oSchemeModel = new sap.ui.model.json.JSONModel();
						oSchemeModel.setData(oData);
						that._oComponent.setModel(oSchemeModel, "SchemesNameSuggestorModel");
					},
					error: function (error) {
						that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover();
					}
				});
			});

		},

		handleSchemeSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["SchemeGUID", "SchemeID", "SchemeName"],
				sBinding: "suggestionItems"
			});

			if (this.handleSchemeSuggest_Exit) {
				this.handleSchemeSuggest_Exit(oEvent);
			}
		},
		suggestionItemSelectedScheme: function (oEvent) {
			var that = this;
			that.suggestionItemSelected({
					oEvent: oEvent,
					thisController: that,
					sModelName: "SchemesNameSuggestorModel",
					sGUID: "SchemeGUID",
					sKey: "SchemeID",
					sDescription: "SchemeName"

				},
				function (key, desc, jData) {
					var SchemeGUID = jData.SchemeGUID;
					gListPageView.getModel("LocalViewSetting").setProperty("/SchemeGUID", SchemeGUID);
					// var aToken = [];
					// that.getView().byId("multiInputSchemes").removeAllTokens();
					// var oToken = new sap.m.Token({
					// 	key: key,
					// 	text: that.TextAbstract(desc, key, 10),
					// 	tooltip: desc + " (" + key + ")"
					// });
					// aToken.push(oToken);
					// that.getView().byId("multiInputSchemes").setTokens(aToken);
					that.getView().byId("inputCreatedOnDate").setSelectedKey("");
					that.CreatedOnDate.FromDate = null;
					that.CreatedOnDate.ToDate = null;

				}
			);
			this.getView().byId("multiInputSchemes").setValueState("None");
			this.getView().byId("multiInputSchemes").setValueStateText("");

			if (this.suggestionItemSelectedScheme_Exit) {
				this.suggestionItemSelectedScheme_Exit(oEvent);
			}
		},
		suggestionItemSelected: function (mParemeters, callBack) {
			mParemeters.oEvent.getSource().setValueState("None");
			mParemeters.oEvent.getSource().setValueStateText("");
			var sPath = mParemeters.oEvent.getParameter("selectedItem").getBindingContext(mParemeters.sModelName).getPath();
			if (mParemeters.sGUID) {
				var key = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty(sPath + "/" + mParemeters.sGUID);
				var text1 = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty(sPath + "/" + mParemeters.sKey);
				var desc = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty(sPath + "/" + mParemeters.sDescription);
				mParemeters.oEvent.getSource().removeAllTokens();
				mParemeters.oEvent.getSource().addToken(new sap.m.Token({
					key: key,
					text: this.TextAbstract(desc, text1, 10)
				}));
				mParemeters.oEvent.getSource().setValue("");
			} else {
				var key = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty(sPath + "/" + mParemeters.sKey);
				var desc = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty(sPath + "/" + mParemeters.sDescription);
				mParemeters.oEvent.getSource().removeAllTokens();
				mParemeters.oEvent.getSource().addToken(new sap.m.Token({
					key: key,
					text: this.TextAbstract(desc, key, 10)
				}));
				mParemeters.oEvent.getSource().setValue("");
			}
			var jData = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty(sPath);
			if (callBack) {
				callBack(key, desc, jData);
			}
		},

		onChangeSchemeF4: function (oEvent) {
			var that = this;
			this.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "SchemesNameSuggestorModel",
					sKey: "SchemeID",
					sDescription: "SchemeName",
					sGUID: "SchemeGUID"
				},
				function (enteredVal, bFound, key, desc, jData) {
					if (enteredVal !== "") {
						if (!bFound) {
							var msg = oi18n.getText("List.Filterbar.MultiInput.SchemeNoError", [gListPageView.byId("SchemeNoValueHelp").getLabel()]);
							oPPCCommon.displayMsg_MsgBox(that.getView(), msg, "error");
						}
						that.getView().byId("inputCreatedOnDate").setSelectedKey("");
						that.CreatedOnDate.FromDate = null;
						that.CreatedOnDate.ToDate = null;
						// var aToken = [];
						// that.getView().byId("multiInputSchemes").removeAllTokens();
						// var oToken = new sap.m.Token({
						// 	key: key,
						// 	text: that.TextAbstract(desc, key, 10),
						// 	tooltip: desc + " (" + key + ")"
						// });
						// aToken.push(oToken);
						// that.getView().byId("multiInputSchemes").setTokens(aToken);
					}
				}
			);

			if (this.onChangeSchemeF4_Exit) {
				this.onChangeSchemeF4_Exit(oEvent);
			}
		},
		suggestionOnChange: function (mParemeters, callBack) {
			var that = this;
			mParemeters.oEvent.getSource().setValueState("None");
			mParemeters.oEvent.getSource().setValueStateText("");
			var key = "",
				desc = "",
				jData = {};
			var enteredVal = mParemeters.oEvent.getSource().getValue();
			var oData = mParemeters.thisController.getView().getModel(mParemeters.sModelName).getProperty("/");
			var bFound = false;
			if (enteredVal !== "") {
				for (var i = 0; i < oData.length; i++) {
					if (oData[i][mParemeters.sKey] === enteredVal) {
						jData = oData[i];
						key = oData[i][mParemeters.sGUID];
						desc = oData[i][mParemeters.sDescription];
						mParemeters.oEvent.getSource().removeAllTokens();
						if (mParemeters.sGUID) {
							var tokens = new sap.m.Token({
								key: oData[i][mParemeters.sGUID],
								text: that.TextAbstract(oData[i][mParemeters.sDescription], oData[i][mParemeters.sKey], 10)
							});
						} else {
							var tokens = new sap.m.Token({
								key: oData[i][mParemeters.sGUID],
								text: that.TextAbstract(oData[i][mParemeters.sDescription], oData[i][mParemeters.sKey], 10),

							});
						}
						mParemeters.oEvent.getSource().setTooltip(oData[i][mParemeters.sDescription] + " (" + oData[i][mParemeters.sKey] + ")");
						mParemeters.oEvent.getSource().addToken(tokens);
						mParemeters.oEvent.getSource().setValue("");
						bFound = true;
						break;
					} else if (oData[i][mParemeters.sDescription] === enteredVal) {
						jData = oData[i];
						key = oData[i][mParemeters.sGUID];
						desc = oData[i][mParemeters.sDescription];
						mParemeters.oEvent.getSource().removeAllTokens();
						if (mParemeters.sGUID) {
							var tokens = new sap.m.Token({
								key: oData[i][mParemeters.sGUID],
								text: that.TextAbstract(oData[i][mParemeters.sDescription], oData[i][mParemeters.sKey], 10)
							});
						} else {
							var tokens = new sap.m.Token({
								key: oData[i][mParemeters.sGUID],
								text: that.TextAbstract(oData[i][mParemeters.sDescription], oData[i][mParemeters.sKey], 10),
							});
						}
						mParemeters.oEvent.getSource().setTooltip(oData[i][mParemeters.sDescription] + " (" + oData[i][mParemeters.sKey] + ")");
						mParemeters.oEvent.getSource().addToken(tokens);
						mParemeters.oEvent.getSource().setValue("");
						bFound = true;
						break;
					}
				}
				if (!bFound) {
					mParemeters.oEvent.getSource().setValueState("Error");
					mParemeters.oEvent.getSource().setValueStateText("Please enter valid " + mParemeters.sKey);
				}
			}
			if (callBack) {
				callBack(enteredVal, bFound, key, desc, jData);
			}
		},

		SchemeF4: function () {
			//var cpTypeArr = [];
			//cpTypeArr.push(this.getView().byId("CPTypeID").getSelectedKeys());
			var that = this;
			var tokenTextLength = that.getView().getModel("LocalViewSetting").getProperty("/tokenTextLength");
			if (!this.getView().getModel("SchemeTypeDD")) {
				var oModelData = this._oComponent.getModel("PCGW");
				var oSchemeTypeFilter = new Array();
				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "ModelID", sap.ui.model.FilterOperator
					.EQ, [
						"SCGW"
					], true, false, false);
				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "EntityType", sap.ui.model.FilterOperator
					.EQ, [
						"Scheme"
					], false, false, false);
				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "PropName", sap.ui.model.FilterOperator
					.EQ, [
						"SchemeTypeID"
					], false, false, false);
				oProductCommon.getDropdown(oModelData, "ValueHelps", oSchemeTypeFilter, "ID", "Description", BusyDialog, this.getView(),
					"SchemeTypeDD", "",
					function () {
						oCommonValueHelp.SchemeF4({
								oController: that,
								oi18n: oi18n,
								oUtilsI18n: oUtilsI18n,
								sCPParentCode: that.getSelectedCustomerCode(),
								sCPParentName: that.getAllSelectedCustomerName(),
								controlID: "multiInputSchemes",
								bCPTypeText: true,
								bCPGUIDKey: true,
								bApprovedNTRequired: true
							},
							function (oTokens) {
								oTokens.forEach(function (eachElement) {
									eachElement.mProperties.text = that.TextAbstract(eachElement.getTooltip().split("(")[0].trim(), eachElement.mProperties.key,
										tokenTextLength);
								});
								that.getView().byId("inputCreatedOnDate").setSelectedKey("");
								that.CreatedOnDate.FromDate = null;
								that.CreatedOnDate.ToDate = null;
							});
					});
			} else {
				oCommonValueHelp.SchemeF4({
						oController: this,
						oi18n: oi18n,
						oUtilsI18n: oUtilsI18n,
						sCPParentCode: that.getSelectedCustomerCode(),
						sCPParentName: that.getAllSelectedCustomerName(),
						controlID: "multiInputSchemes",
						bCPTypeText: true,
						bCPGUIDKey: true,
						bApprovedNTRequired: true
					},
					function (oTokens) {
						oTokens.forEach(function (eachElement) {
							eachElement.mProperties.text = that.TextAbstract(eachElement.getTooltip().split("(")[0].trim(), eachElement.mProperties.key,
								tokenTextLength);
						});
						that.getView().byId("inputCreatedOnDate").setSelectedKey("");
						that.CreatedOnDate.FromDate = null;
						that.CreatedOnDate.ToDate = null;
					});
			}

		},

		/*------------------------------------------Table Filter, Sorter & Export to EXCEL-------------------------------------*/
		handleViewSettingsDialogButtonPressed: function (oEvent) {
			if (!this.ListDialog) {
				this.ListDialog = sap.ui.xmlfragment("com.arteriatech.ss.schemes.util.Dialog", this);
			}
			var oModel = this.getView().getModel("<ToAdd Model Name> Eg: PSGW_PUR");
			this.ListDialog.setModel(oModel, "<ToAdd Model Name> Eg: PSGW_PUR");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this.ListDialog);
			this.ListDialog.open();
		},
		sortAndFilterTable: function (oEvent) {
			var oView = this.getView();
			var that = this;
			var table = this.getView().byId("SchemesTable");
			//ToAdd custom filters if any in XML
			var oCustomFilter;
			//Eg: oCustomFilter = new sap.ui.model.Filter("PurDocType", sap.ui.model.FilterOperator.EQ, "PO");
			oPPCCommon.sortAndFilterTable(table, oEvent, function (count, aDefaultSorter) {
				oView.getModel("LocalViewSetting").setProperty("/ListItemsCount", count);
				if (count <= 0) {
					oView.byId("SchemesTable").setNoDataText(oUtilsI18n.getText("common.NoResultsFound"));
				} else {
					oPPCCommon.setGroupInTable(oView, "SchemesTable", "", true, "", "", aDefaultSorter);
					if (that.sCustomerInpuType === "DD") {
						if (that.getView().byId("customer").getSelectedKey() === "") {
							oPPCCommon.setGroupInTable(oView, "SchemesTable", "CustomerNo", true, "Customer", "CustomerName", aDefaultSorter);
						}
					} else if (that.sCustomerInpuType === "MC") {
						if (that.getView().byId("partnerMultiCombo").getSelectedKeys().length !== 1) {
							oPPCCommon.setGroupInTable(oView, "SchemesTable", "CustomerNo", true, "Customer", "CustomerName", aDefaultSorter);
						}
					} else if (that.sCustomerInpuType === "VH") {
						if (that.getView().byId("inputCustomerF4").getTokens().length !== 1) {
							oPPCCommon.setGroupInTable(oView, "SchemesTable", "CustomerNo", true, "Customer", "CustomerName", aDefaultSorter);
						}
					}
				}
			}, oCustomFilter);
		},
		exportToExcel: function (oEvent) {
			if (Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SchemesTable"),
					uiTable: this.getView().byId("UISchemesTable")
				});
			}
			var table = this.getView().byId("SchemesTable");
			var oModel = this.getView().getModel("ListItems");
			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "Scheme",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		},

		/*
		 * ChannelPartener Value Help
		 */
		ChannelPartenerF4: function (mParameters, requestCompleted) {
			var that = this;
			if (mParameters.bMultiSelect === undefined || mParameters.bMultiSelect === null) {
				mParameters.bMultiSelect = true;
			}
			var sF4Heading = "";
			if (mParameters.si18nPropertyName) {
				sF4Heading = mParameters.oi18n.getText(mParameters.si18nPropertyName + ".Header");
			} else {
				sF4Heading = mParameters.oi18n.getText("ValueHelp.Scheme.Header");
			}
			sF4Heading = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeID",
				oUtilsI18n: mParameters.oUtilsI18n
			});

			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.oController.oSchemeTokenInput.getValue(),
				title: sF4Heading,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.oController.aSchemeKeys[0],
				descriptionKey: mParameters.oController.aSchemeKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					var tokens = oControlEvent.getParameter("tokens");
					if (mParameters.bCPGUIDKey) {
						var oToken = tokens;
						var sText = "";
						for (var i = 0; i < oToken.length; i++) {
							var Text1 = oToken[i].mProperties.text.split("(")[0].trim();
							sText = oToken[i].getCustomData()[0].mProperties.value.Name;
							oToken[i].mProperties.text = sText + " (" + Text1 + ")";
							oToken[i].setTooltip(sText + " (" + Text1 + ")");
						}
						//this.getView().byId("inputInvoiceNo").setTokens(oToken);
						mParameters.oController.oSchemeTokenInput.setTokens(oToken);
						mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
						mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
					} else {
						mParameters.oController.oSchemeTokenInput.setTokens(oControlEvent.getParameter("tokens"));
						mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
						mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
						oPPCCommon.removeMsgsInMsgMgrByMsgCode(mParameters.controlID);
						var tokens = oControlEvent.getParameter("tokens");
						mParameters.oController.oSchemeTokenInput.removeAllTokens();
						mParameters.oController.oSchemeTokenInput.setValue("");
						var aToken = [];
						for (var j = 0; j < tokens.length; j++) {
							if (tokens[j] && tokens[j].getCustomData() && tokens[j].getCustomData().length >= 0) {
								var sDesc = tokens[j].getCustomData()[0].getValue().SchemeID + " (" + tokens[j].getCustomData()[0].getValue().SchemeName +
									")";
								aToken.push(new sap.m.Token({
									key: tokens[j].getCustomData()[0].getValue().SchemeGUID,
									text: sDesc
								}));
							}
						}
						mParameters.oController.oSchemeTokenInput.setTokens(aToken);
					}

					if (requestCompleted) {
						requestCompleted(tokens);
					}
					oValueHelpDialog.close();
				},
				cancel: function (oControlEvent) {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});

			if (mParameters.showSelectedItemPanel === undefined || mParameters.showSelectedItemPanel) {
				oPPCCommon.setVHSelectedItemAreaVisibility({
					oValueHelpDialog: oValueHelpDialog
				});
			}
			that.SchemeF4Columns(oValueHelpDialog, mParameters);
			that.SchemeF4FilterBar(oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
			if (mParameters.oController.oSchemeTokenInput) {
				oValueHelpDialog.setTokens(mParameters.oController.oSchemeTokenInput.getTokens());
			}
		},

		/*
		 * Scheme Value Help Filterbar
		 */
		SchemeF4FilterBar: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var SchemesType = "";

			var SchemeNoLabel = "",
				SchemeNameLabel = "",
				SchemesTypeLabel = "";

			/*parentlabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "VendorCode",
				oUtilsI18n: mParameters.oUtilsI18n
			});*/
			SchemeNoLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemeNameLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeName",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeTypeID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			// initialising the filter group items
			var SchemeTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "gn2",
				name: "n6",
				label: "",
				control: new sap.m.Text({
					text: ""
				})
			});
			var oTokenInputValue = "";
			if (mParameters.oController.oSchemeTokenInput) {
				oTokenInputValue = mParameters.oController.oSchemeTokenInput.getValue();
			}
			var code = new sap.m.Input({
				value: {
					path: "SchemeF4FilterBar>/SchemeID",
					type: 'sap.ui.model.type.String'
				},

				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SCGW"),
					sEntityType: "Scheme",
					sPropertyName: "SchemeID",
					oUtilsI18n: mParameters.oUtilsI18n
				})
			});
			code.attachValidationError(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setValueState("Error");
				if (oElement.getValue().trim() === "") {
					oElement.setTooltip("");
					oElement.setValueState("None");
				}
			});
			code.attachValidationSuccess(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setTooltip("");
				oElement.setValueState("None");
			});
			var SchemeName = new sap.m.Input({
				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SCGW"),
					sEntityType: "Scheme",
					sPropertyName: "SchemeName",
					oUtilsI18n: mParameters.oUtilsI18n
				})

			});
			//if (mParameters.bSchemesType !== undefined && mParameters.bSchemesType !== "") {
			// mParameters.bSchemesType=true;
			//	if (mParameters.bSchemesType) {
			var oSchemesTypeItemTemplate = new sap.ui.core.Item({
				key: "{Key}",
				text: "{Key}{Seperator}{Text}",
				tooltip: "{Key}{Seperator}{Text}"
			});
			SchemesType = new sap.m.MultiComboBox({
				items: {
					path: "/",
					template: oSchemesTypeItemTemplate
				}
			});
			SchemesType.setModel(mParameters.oController.getView().getModel("SchemeTypeDD"));
			SchemeTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "gn2",
				name: "n4",
				label: SchemesTypeLabel,
				control: SchemesType
			});
			//	}
			//}

			/*var sSchemesParentText = "";
			if (mParameters.sCPParentCode) {
				var aCPParentName = mParameters.sCPParentName.split("(");
				if (aCPParentName.length > 1) {
					sSchemesParentText = mParameters.sCPParentName;
				} else {
					sSchemesParentText = mParameters.sCPParentName; // + " (" + mParameters.sCPParentCode + ")";
				}
			} else {
				sSchemesParentText = mParameters.sCPParentName;
			}
			var SchemeParentValue = new sap.m.Text({
				text: sSchemesParentText
			});
			
			if (mParameters.bCustomerDD) {
				SchemeParentValue = new sap.m.Select({
					change: function(oEvent) {
						if (oEvent.getSource().getSelectedKey() === "") {
							oValueHelpDialog.getTable().getColumns()[0].setVisible(true);
						} else {
							oValueHelpDialog.getTable().getColumns()[0].setVisible(false);
						}
					}
				});
				var oCustomerItem = new sap.ui.core.ListItem({
					key: "{CustomerNo}",
					text: "{CustomerNo}{Seperator}{Name}"
				});
				var oCustomerModel = new sap.ui.model.json.JSONModel(); //initialise your model from a JSON file&nbsp;&nbsp;
				var oCustomerDataModel = mParameters.oController._oComponent.getModel("SFGW_MST");
				oProductUserMapping.getCustomers(oCustomerDataModel, "000002", "2", busyDialog, mParameters.oController.getView(), function(
					aCustomer) {
					if (aCustomer.length > 0) {
						oCustomerModel.setData(aCustomer);
						SchemeParentValue.setModel(oCustomerModel); // set model your_data_model to Select element&nbsp;&nbsp;
						SchemeParentValue.bindAggregation("items", "/", oCustomerItem);
						if (aCustomer.length !== 1) {
							SchemeParentValue.setSelectedKey("");
						}
					}
				});
			}*/

			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					/*new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn1",
						name: "n1",
						label: parentlabel,
						control: SchemeParentValue
					}),*/
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn1",
						name: "n2",
						label: SchemeNoLabel,
						control: code
					}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn1",
						name: "n3",
						label: SchemeNameLabel,
						control: SchemeName
					}),
					SchemeTypeFilter
				],
				search: function (oEvent) {
					var codeValue = code.getValue();
					var SchemeNameValue = SchemeName.getValue();
					var isCPNoValid = true;
					if (isCPNoValid) {
						var aSchemesF4Filter = new Array();
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemesF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
							sServiceName: "Schemes",
							sRequestType: "read"
						})], false, false, false);
						/*var customer = "";
						if (mParameters.bCustomerDD) {
							customer = SchemeParentValue.getSelectedKey();
						} else {
							customer = mParameters.sCPParentCode;
						}*/
						/*aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "VendorCode",
							sap.ui.model
							.FilterOperator.EQ, [customer], false, false, false);*/

						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "SchemeID",
							"", [
								codeValue
							], false, false, false);
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "SchemeName",
							"", [
								SchemeNameValue
							], false, false, false);
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter,
							"SchemeTypeID", sap.ui
							.model.FilterOperator.EQ, SchemesType.getSelectedKeys(), true, false, false);

						var SCGWModel = mParameters.oController._oComponent.getModel("SCGW");
						SCGWModel.attachRequestSent(function () {
							busyDialog.open();
						});
						SCGWModel.attachRequestCompleted(function () {
							busyDialog.close();
						});
						SCGWModel.read("/Schemes", {
							filters: aSchemesF4Filter,
							success: function (oData) {
								var oSchemesModel = new sap.ui.model.json.JSONModel();
								if (oValueHelpDialog.getTable().bindRows) {
									oValueHelpDialog.getTable().clearSelection();
									oSchemesModel.setData(oData.results);
									oValueHelpDialog.getTable().setModel(oSchemesModel);
									oValueHelpDialog.getTable().bindRows("/");
									if (oData.results.length === 0) {
										oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									}
								} else {
									var oRowsModel = new sap.ui.model.json.JSONModel();
									oRowsModel.setData(oData.results);
									oValueHelpDialog.getTable().setModel(oRowsModel);
									if (oValueHelpDialog.getTable().bindItems) {
										var oTable = oValueHelpDialog.getTable();
										oTable.bindAggregation("items", "/", function () {
											var aCols = oTable.getModel("columns").getData().cols;
											return new sap.m.ColumnListItem({
												cells: aCols.map(function (column) {
													var colname = column.template;
													return new sap.m.Text({
														text: "{" + colname + "}",
														wrapping: true
													});
												})
											});
										});
									}
									if (oData.results.length === 0) {
										oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									}
								}
								oValueHelpDialog.update();
							},
							error: function (error) {
								oValueHelpDialog.getTable().clearSelection();
								if (oValueHelpDialog.getTable().getModel() !== undefined) {
									oValueHelpDialog.getTable().getModel().setProperty("/", {});
								}
								oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
								oPPCCommon.dialogErrorMessage(error, "No Data Found");
							}
						});
					}
				},
				reset: function () {}
			}));
			var SchemeF4FilterBarMdl = new sap.ui.model.json.JSONModel();
			SchemeF4FilterBarMdl.setData({
				SchemeID: "",
				SchemeName: ""
			});
			oValueHelpDialog.setModel(SchemeF4FilterBarMdl, "SchemeF4FilterBar");
		},

		/*
		 * Scheme Value Help columns
		 */
		SchemeF4Columns: function (oValueHelpDialog, mParameters) {
			var SchemeNoLabel = "",
				SchemeNameLabel = "",
				SchemesTypeLabel = "";

			SchemeNoLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemeNameLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeName",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "Scheme",
				sPropertyName: "SchemeTypeID",
				oUtilsI18n: mParameters.oUtilsI18n
			});

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: SchemeNoLabel,
						template: "SchemeID"
					}, {
						label: SchemeNameLabel,
						template: "SchemeName"
					}, {
						label: SchemesTypeLabel,
						template: "SchemeTypeID",
						demandPopin: true
					}]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

				//Setting Visibility of Customer Column...................
				/*if (!mParameters.bCustomerDD) {
					if (mParameters.sCPParentCode === "") {
						oValueHelpDialog.getTable().getColumns()[3].setVisible(true);
					} else {
						oValueHelpDialog.getTable().getColumns()[3].setVisible(false);
					}
				}*/
			} else {

				/*oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: parentlabel
					}),
					template: new sap.m.Text({
						text: "{VendorCodeDesc} ({VendorCode})"
					}),
					sortProperty: "VendorCodeDesc",
					filterProperty: "VendorCodeDesc"
				}));*/
				// if (!mParameters.bCustomerDD) {
				/*if (mParameters.sCPParentCode === "") {
					oValueHelpDialog.getTable().getColumns()[0].setVisible(true);
				} else {
					oValueHelpDialog.getTable().getColumns()[0].setVisible(false);
				}*/
				// }
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemeNoLabel
					}),
					template: new sap.m.Text({
						text: "{SchemeID}"
					}),
					sortProperty: "SchemeID",
					filterProperty: "SchemeID"
				}));
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemeNameLabel
					}),
					template: new sap.m.Text({
						text: "{SchemeName}"
					}),
					sortProperty: "SchemeName",
					filterProperty: "SchemeName"
				}));
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemesTypeLabel
					}),
					template: new sap.m.Text({
						text: "{SchemeTypeID}"
					}),
					sortProperty: "SchemeTypeID",
					filterProperty: "SchemeTypeID"
				}));
				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}
		},

		/*----------------------------------------------Navigation-------------------------------------------------------*/
		gotoDetails: function (oEvent) {
			var path = "";
			var oModelContext = oEvent.getSource().getBindingContext("ListItems");
			/**
			 * Check for the Multi-Origin of the service
			 * If true pass Multi-Origin Property in the routing
			 */

			//ToAdd uncomment below line and update the path
			if (oPPCCommon.isMultiOrigin(oModelContext)) {
				var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
				path = "Schemes(SchemeGUID='" + oModelContext.getProperty("SchemeGUID") + "'," +
					SAPMultiOriginPropertyName + "='" + oModelContext.getProperty(SAPMultiOriginPropertyName) + "')";
			} else {
				path = "Schemes(SchemeGUID='" + oModelContext.getProperty("SchemeGUID") + "')";
			}

			this._oRouter.navTo("DetailPage", {
				contextPath: path
			}, false);
		},
		removeSchemes: function (oEvent) {
				var that = this;
				if (oEvent.mParameters.type == "removed") {
					this.getView().byId("multiInputSchemes").removeAllTokens();
					this.getView().byId("multiInputSchemes").setSelectedKey("");
					gListPageView.getModel("LocalViewSetting").setProperty("/SchemeGUID", "");
					if (this.getView().byId("multiInputSchemes").getTokens().length === 0) {
						this.getView().byId("inputCreatedOnDate").setSelectedKey("-30");
						oSSCommon.openManualDateSelectionDialog(this, -30, "", this.PreviousSelectedKeyInvDate,
							"CreatedOnDateViewSetting", oi18n, "inputCreatedOnDate",
							function (date) {
								that.CreatedOnDate.FromDate = date.fromDate;
								that.CreatedOnDate.ToDate = date.toDate;
							});
						that.getView().byId("inputCreatedOnDate").setSelectedKey("-30");
					}
				}
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.arteriatech.ss.schemes.view.List
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.List
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.List
		 */

	});

});