sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common",
	"com/arteriatech/prd/utils/js/UserMapping",
	"com/arteriatech/prd/utils/js/CommonValueHelp"
], function(Controller, JSONModel, History) {
	"use strict";
	var oi18n, oUtilsI18n;
	var Device = sap.ui.Device;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oProductCommon, oCommonValueHelp;
	oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
	var product = "PD";
	return Controller.extend("com.arteriatech.ss.schemes.controller.ViewPage", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ViewPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			if (product === "PPS") {
				oProductCommon = com.arteriatech.pps.utils.js.Common;
				oCommonValueHelp = com.arteriatech.pps.utils.js.CommonValueHelp;
			} else if (product === "PD") {
				oProductCommon = com.arteriatech.ss.utils.js.Common;
				oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
			} else if (product === "CL") {
				oProductCommon = com.arteriatech.cl.utils.js.Common;
				oCommonValueHelp = com.arteriatech.cl.utils.js.CommonValueHelp;
			}
			/*else {
								//<ToAdd if any new product> 
			}*/

			this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);

			this.TokenInput = this.getView().byId("ViewPageValueHelp");
			this.byId("ViewPageValueHelp").setValueState(sap.ui.core.ValueState.None);
			this.byId("ViewPageValueHelp").setValueStateText("");

			var that = this;

			var that = this;

			//Scheme F4
			this.oSchemeTokenInput = this.getView().byId("ViewPageValueHelp");
			this.aSchemeKeys = ["SchemeGUID", "SchemeID"];
			var sSchemePreviousEnteredValue;
			this.oSchemeTokenInput.addValidator(function(args) {
				if (sSchemePreviousEnteredValue !== args.text) {
					sSchemePreviousEnteredValue = args.text;
					var oDataModel = that._oComponent.getModel("SCGW");
					args.text = args.text.toUpperCase();
					var SchemeF4Filters = new Array();
					var fSchemeNo = new sap.ui.model.Filter("SchemeGUID", sap.ui.model.FilterOperator.EQ, args.text);
					SchemeF4Filters.push(fSchemeNo);
					oProductCommon.getTokenForInput(args, oDataModel, "Schemes", SchemeF4Filters, "SchemeGUID", "SchemeName", that.oSchemeTokenInput,
						"Scheme",
						function(oToken, IsSuccess) {
							if (IsSuccess) {
								sSchemePreviousEnteredValue = "";
							}
						}, that, oUtilsI18n, "ViewPageValueHelp");
				}
			});

			if (this.onInitHookUp_Exit) {
				this.onInitHookUp();
			}
		},

		/*onRouteMatched: function(evt) {

		},*/

		ViewPageF4: function() {
			//var cpTypeArr = [];
			//cpTypeArr.push(this.getView().byId("CPTypeID").getSelectedKeys());
			var that = this;
			if (!this.getView().getModel("SchemeTypeDD")) {
				var oModelData = this._oComponent.getModel("PCGW");
				var oSchemeTypeFilter = new Array();
				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "ModelID", sap.ui.model.FilterOperator
					.EQ, [
						"SCGW"
					], true, false, false);
				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "EntityType", sap.ui.model.FilterOperator
					.EQ, [
						"Scheme"
					], false, false, false);
				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "PropName", sap.ui.model.FilterOperator
					.EQ, [
						"SchemeTypeID"
					], false, false, false);
				oProductCommon.getDropdown(oModelData, "ValueHelps", oSchemeTypeFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
					"SchemeTypeDD", "",
					function() {
						oCommonValueHelp.SchemeF4({
								oController: that,
								oi18n: oi18n,
								oUtilsI18n: oUtilsI18n,
								sCPParentCode: "",
								sCPParentName: "",
								controlID: "ViewPageValueHelp",
								bCPTypeText: true,
								bCPGUIDKey: true,
								bApprovedNTRequired: true
							},
							function(token) {});
					});
			} else {
				oCommonValueHelp.SchemeF4({
					oController: this,
					oi18n: oi18n,
					oUtilsI18n: oUtilsI18n,
					sCPParentCode: that.getSelectedCustomerCode(),
					sCPParentName: that.getAllSelectedCustomerName(),
					controlID: "multiInputSchemes",
					bCPTypeText: true,
					bCPGUIDKey: true,
					bApprovedNTRequired: true
				});
			}

		},
		onF4Change: function(oEvent) {
			if (oEvent.getSource().getValue() === "") {
				oPPCCommon.removeMsgsInMsgMgrByMsgCode("Err_ValueHelp");
				oEvent.getSource().setValueState("None");
				oEvent.getSource().setValueStateText("");
			}
		},
		gotoDetail: function(oEvent) {
				if (this.byId("ViewPageValueHelp").getTokens().length > 0) {
					this.byId("ViewPageValueHelp").setValueState(sap.ui.core.ValueState.None);
					this.byId("ViewPageValueHelp").setValueStateText("");
					var path = "";
					/**
					 * Check for the Multi-Origin of the service
					 * If true pass Multi-Origin Property in the routing  
					 */
					var selectedNumber = this.byId("ViewPageValueHelp").getTokens()[0].getKey();

					path = "Schemes(SchemeGUID='" + selectedNumber + "')";
					this._oRouter.navTo("DetailPage", {
						contextPath: path
					}, false);

				} else {
					this.byId("ViewPageValueHelp").setValueState(sap.ui.core.ValueState.Error);
					this.byId("ViewPageValueHelp").setValueStateText("Please select valid Scheme");
					sap.m.MessageBox.error(
						"Please select valid Scheme", {
							styleClass: sap.ui.Device.support.touch ? "" : "sapUiSizeCompact"
						}
					);
				}
			}
			/**
			 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
			 * (NOT before the first rendering! onInit() is used for that one!).
			 * @memberOf com.arteriatech.ss.schemes.view.ViewPage
			 */
			//	onBeforeRendering: function() {
			//
			//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ViewPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ViewPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});