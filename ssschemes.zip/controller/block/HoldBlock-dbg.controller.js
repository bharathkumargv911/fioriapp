sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function (Controller) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.HoldBlock", {

		onInit: function () {
			this.onInitHookUp();
		},

		onInitHookUp: function () {
			gHoldBlockView = this.getView();
			gHoldBlockView.setBusy(false);
			var SchemeHold = new sap.ui.model.json.JSONModel();
			SchemeHold.setData([]);
			gHoldBlockView.setModel(SchemeHold, "SchemeHold");
		},
		addNew: function (oEvent) {
			var CDate = new Date();
			var newItem = {
				"SchemeHoldGUID": oPPCCommon.generateUUID(),
				"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
				"HoldFrom": null,
				"HoldTo": null
			};
			var oItemModel = gHoldBlockView.getModel("SchemeHold");
			var oItemModelData = oItemModel.getData();

			if (oItemModelData.length > 0) {
				for (var z = 0; z < oItemModelData.length; z++) {
					if (oItemModelData[z].HoldFrom === null && oItemModelData[z].HoldTo === null) {
						var msg = "Please Enter FromHold Date and ToHold Date";
					}
				}
				if (msg) {
					oPPCCommon.displayMsg_MsgBox(this.getView(), msg, "warning");
					var oItemModelData = oItemModel.getData();
					oItemModelData.splice(z, 1);
					oItemModel.setData(oItemModelData);
					oItemModel.refresh();
					return;
				} else {
					oItemModelData.push(newItem);
					oItemModel.setData(oItemModelData);
					oItemModelData[0].holdFromMinDate = CDate;
					oItemModelData[0].holdToMinDate = CDate;
					if (oItemModelData.length > 1 && z != 0) {
						oItemModelData[z].holdFromMinDate = oItemModelData[z - 1].HoldTo;
						oItemModelData[z].holdToMinDate = oItemModelData[z - 1].HoldTo;
					}
				}
				oItemModel.refresh();
			} else {
				oItemModelData.push(newItem);
				oItemModel.setData(oItemModelData);
				oItemModelData[0].holdFromMinDate = CDate;
				oItemModelData[0].holdToMinDate = CDate;
				if (oItemModelData.length > 1 && z != 0) {
					oItemModelData[z].holdFromMinDate = oItemModelData[z - 1].HoldTo;
					oItemModelData[z].holdToMinDate = oItemModelData[z - 1].HoldTo;
				}
			}

			var iTotalLength = this.getView().getModel("SchemeHold").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/HoldCount", iTotalLength);
			}

			if (this.addNew_Exit) {
				this.addNew_Exit();
			}
		},
		onChangeHoldTo: function (oevent) {
			var FromDate = oevent.mParameters.value;
			var FromDateFormated = new Date(FromDate);
			var HoldDate = oSSCommon.getFormattedDate(FromDateFormated);
			var schemeholddata = this.getView().getModel("SchemeHold").getData();
			// for (var z = 1; z < schemeholddata.length; z++) {
			// 	if (schemeholddata[z].HoldFrom != "") {
			// 		var msg = "Plese Delete the correct record and Add required Date Range";
			// 		oPPCCommon.displayMsg_MsgBox(this.getView(), msg, "warning");
			// 		return;
			// 	}
			// 	schemeholddata[z].holdFromMinDate = HoldDate;
			// 	schemeholddata[z].holdToMinDate = HoldDate;
			// 	// if (HoldDate === oSSCommon.getFormattedDate(schemeholddata[z].HoldTo)) {
			// 	// 	var msg = "Please Select Valid DateRange";
			// 	// 	oPPCCommon.displayMsg_MsgBox(this.getView(), msg, "warning");
			// 	// 	return;

			// }
			// var y = new Date(z);
			// y.setHours(0, 0, 0, 0);
			// this.getView().getModel("LocalViewSettingDtl").setProperty("/minDate", y);

		},
		onChangeHoldFrom: function (oevent) {
			var FromDate = oevent.mParameters.value;
			var FromDateFormated = new Date(FromDate);

			var HoldDate = oSSCommon.getFormattedDate(FromDateFormated)
			var schemeholddata = this.getView().getModel("SchemeHold").getData();
			var schemehold = schemeholddata.length;

			// var y = new Date(z);
			// y.setHours(0, 0, 0, 0);
			// this.getView().getModel("LocalViewSettingDtl").setProperty("/minDate", y);

		},

		deleteItem: function (oEvent) {
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");
			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("SchemeHold").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));

			//Remove Row from model
			var oItemModel = this.getView().getModel("SchemeHold");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			//Update Table count
			var iTotalLength = this.getView().getModel("SchemeHold").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/HoldCount", iTotalLength);
			}

			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			if (this.deleteItem_Exit) {
				this.deleteItem_Exit();
			}
		},
	});

});