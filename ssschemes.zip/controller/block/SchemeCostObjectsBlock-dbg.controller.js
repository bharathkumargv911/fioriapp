sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function(Controller) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oProductCommon = com.arteriatech.ss.utils.js.Common;
	var oi18n, oUtilsI18n;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.SchemeCostObjectsBlock", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			gSchemeCostObjectBlock = this.getView();
		},

		addNew: function(oEvent) {
			// var EntityName =["SchemeCostObject"];
			// var PropertyName =["CostObjType", "GLCode"];
		 //   sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").callDropDown1(EntityName,PropertyName); 
			var newItem = {
				"CostObjGUID": oPPCCommon.generateUUID(),
				"LoginID": "",
				"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
				"GLCode": "",
				"CostObjID": "",
				"CostObjDesc": "",
				"CostObjTypeID": "",
				"CostObjTypeDesc": "",
				"PercOfAlloction": 0,
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT18H57M31S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				"Source": "",
				"ExternalRefID": "",
				"ExternalRefKey": ""
			};

			//Pus new row to model
			var oItemModel = this.getView().getModel("SchemeCostObjects");
			var oItemModelData = oItemModel.getData();
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			gSchemeCostObjectBlock.byId("UISchemeCostObjectsTable_ADDBtnEdit").setType("Emphasized");

			//Update Table count
			var iTotalLength = this.getView().getModel("SchemeCostObjects").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeCostObjectsCount", iTotalLength);
			}
			if (this.AddClissificationChannels_Exit) {
				this.AddClissificationChannels_Exit();
			}

		},

		deleteItem: function(oEvent) {
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");

			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("SchemeCostObjects").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));

			//Remove Row from model
			var oItemModel = this.getView().getModel("SchemeCostObjects");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			//Update Table count
			var iTotalLength = this.getView().getModel("SchemeCostObjects").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeCostObjectsCount", iTotalLength);
			}

			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			if (this.deleteItem_Exit) {
				this.deleteItem_Exit();
			}
		},
        onPercAlcnChange : function(oEvent){
         	oPPCCommon.hideMessagePopover();
			oPPCCommon.removeAllMsgs();
			var Path = oEvent.getSource().getBindingContext("SchemeCostObjects").getPath().split("/")[1];
			var index = parseInt(Path);
			var CodtObjectItem = this.getView().getModel("SchemeCostObjects");
			var oItemModel = CodtObjectItem.getProperty('/');
			var totalPerc = 0;
			for(var perc=0 ; perc < oItemModel.length ; perc++ ){
			    totalPerc =totalPerc + parseFloat(oItemModel[perc].PercOfAlloction); 
			}
			if(totalPerc > 100){
					var msg = "Cost Objects total percentage of allocation should not be more than 100";
						oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fPercOfAlloctionEdit");
						oItemModel[index].PercOfAlloction = 0;
						oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
			}
		},
		onCostObjSelect: function(oEvent) {
			var view = gSchemeDetails;
			var path = oEvent.getSource().getBindingInfo("selectedKey").binding.getContext().getPath();
			var pos = path[path.length - 1];
			var oModelData = view.getModel("SchemeCostObjects").getProperty("/");
			var selectedKey = oEvent.getSource().getSelectedKey();
			if (selectedKey && selectedKey !== "" && selectedKey.trim() !== "" && oModelData) {
				for (var i = 0; i < oModelData.length; i++) {
					if (pos && parseInt(pos) !== i && selectedKey === oModelData[i].CostObjID) {
						var j = i + 1;
						sap.m.MessageToast.show("Cost Object '" + oModelData[i].CostObjDesc +
							" (" + oModelData[i].CostObjID + ")' Duplicated from " + j + " Item");
						oEvent.getSource().setSelectedKey("");
						break;
					}
				}
			}
			oPPCCommon.setDDDesciption(oEvent, view);
		},

		onCostObjTypeChange: function(oEvent) {
			var that = this;
			var view = gSchemeDetails;
			oPPCCommon.setDDDesciption(oEvent, view);
			var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
			var oModelData = this.getView().getModel("PCGW");
			
			var oSalesGroupFilter = new Array();
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
				.model.FilterOperator.EQ, ["SCGW"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
				.ui.model.FilterOperator.EQ, ["SchemeCostObject"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
				.model.FilterOperator.EQ, ["CostObject"], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
				.model.FilterOperator.EQ, [id], false, false, false);
			oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui
				.model.FilterOperator.EQ, [that.getCurrentUsers("SchemeCostObjects", "read")], false, false, false);
				
			var obj = "";
			var aCells = [];
			aCells = oEvent.getSource().getParent().getCells();
			for (var i = 0; i < aCells.length; i++) {
				if (aCells[i].getId() && aCells[i].getId().indexOf("fCostObjIDEdit") >= 0) {
					obj = this.getView().byId(aCells[i].getId());
					break;
				}
			}
			if (obj) {
				if (obj.getModel("CostObjectDD")) {
					obj.getModel("CostObjectDD").setProperty("/", []);
				}
				obj.setProperty("selectedKey", "");
				obj.setTooltip("");
				if (id && id !== "" && id.trim() !== "") {
					oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj,
						"CostObjectDD", "Select",
						function() {
							// busyDialog.close();
						}, true, "PD", true);
				}
			}
			if (this.onCostObjTypeChange_Exit) {
				this.onCostObjTypeChange_Exit();
			}
		},
		
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				oProductCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = oProductCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},

		exportToExcel: function(oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SchemeCostObjectsTable"),
					uiTable: this.getView().byId("UISchemeCostObjectsTable")
				});
			}
			var table = this.getView().byId("SchemeCostObjectsTable");
			var oModel = this.getView().getModel("SchemeCostObjects");

			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeCostObject",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});