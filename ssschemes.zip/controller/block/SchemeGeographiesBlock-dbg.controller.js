sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/Label",
	"sap/m/Link",
	"sap/m/MessageToast",
	"sap/m/Text",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function(Controller, JSONModel, Label, Link, MessageToast, Text) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oi18n, oUtilsI18n;
	// var aZoneSelectedList = [];
	// var oGreographyListCtrl;
	// var aChilds = [];
	var crumbHistory = [];
	var oAreaArray = [];
	var oDepotArray = [];
	var TempDepotArray = [];
	var aZone;
	var bZone;
	var aDepot;
	var bDepot;
	var cZone;
	var sIndex = 0;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.SchemeGeographiesBlock", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			gSchemeGeographiesBlock = this.getView();
			//i18n
			oi18n = goi18n;
			oUtilsI18n = goUtilsI18n;
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			// this.GeographyTab();
		},

		setAreaDepot: function(oEvent) {

			// var EntityName =["SchemeGeo"];
			//   var PropertyName =["SchemeScope", "SchemeLevel","SchemeType111","SchemeValue"];
			//   sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").callDropDown1(EntityName,PropertyName);
			sIndex = oEvent.getParameter("selectedIndex");
			if (oEvent.getParameter("selectedIndex") === 0) {
				this.getView().getModel('LocalViewSettingDtl').setProperty('/AreaOrDepot', goi18n.getText("Geography.Area"));
			} else if (oEvent.getParameter("selectedIndex") === 1) {
				this.getView().getModel('LocalViewSettingDtl').setProperty('/AreaOrDepot', goi18n.getText("Geography.Depot"));
			}
			crumbHistory = [];
			oAreaArray = [];
			this.GeographyTab();
			sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").copyGeoDetails();
		},

		onSelectCheckbox: function(oEvent) {
			var that = this;
			var status = oEvent.getParameter("selected");
			if (status) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/Selected", true);
				for (var i = 0; i < this.getView().getModel("oZones").getData().length; i++) {
					this.getView().getModel("oZones").setProperty("/" + i + "/AreaSelected", true);
				}
			} else {
				for (var i = 0; i < this.getView().getModel("oZones").getData().length; i++) {
					this.getView().getModel("oZones").setProperty("/" + i + "/AreaSelected", false);
				}
			}

		},
		
		exportToExcel: function(oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SchemeGeographiesTable"),
					uiTable: this.getView().byId("UISchemeGeographiesTable")
				});
			}
			var table = this.getView().byId("SchemeGeographiesTable");
			var oModel = this.getView().getModel("SchemeGeographies");

			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeGeography",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		},

		/* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ For Geography Tab  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ */

		GeographyTab: function() {
			this.sCollection = "/ProductHierarchy";
			this.aCrumbs = ["Zones", "Regions", "Areas"];
			this.mInitialOrderState = {
				products: {},
				count: 0,
				hasCounts: false
			};
			var sPath = "";
			// this.updateSampleVariable();
			/*	aZone = this.updateSampleVariable(aZone);
				bZone = this.updateSampleVariable(bZone);
				cZone = this.updateSampleVariable(cZone);
				var oModel1 = new JSONModel();
				oModel1.setData(bZone);
				this.getView().setModel(oModel1, "ZoneModel");

				this._oTable = this.byId("idZonesTable");
				this.setDefaultSettings1();
				this._setAggregation(sPath);
				this.resetCrumbHistory();*/
		},

		_setAggregation: function(sPath, oNextBinding) {
			var oSchemeDetailView = gSchemeDetails;
			if (sIndex === 0) {
				var ZoneData = oSchemeDetailView.getModel("oZones").getData();
				var oZoneSelectedModel = new sap.ui.model.json.JSONModel();
				//var oZoneData=this.getView().getModel("ZoneModel");
				oZoneSelectedModel.setData(ZoneData);
				oSchemeDetailView.setModel(oZoneSelectedModel, "oZones");
			} else {
				var DepotData = this.getView().getModel("oZones").getData();
				var oDepotSelectedModel = new sap.ui.model.json.JSONModel();
				//var oZoneData=this.getView().getModel("ZoneModel");
				oDepotSelectedModel.setData(DepotData);
				oSchemeDetailView.getModel("oZones").setProperty("/", DepotData);
			}

			this._maintainCrumbLinks(sPath);
		},
		
		handleLinkPress: function(oEvent) {
			this.setSelectedCrumb(oEvent);
		},
		
		setSelectedCrumb: function(oEvent) {
			var newCrumbHistory = [];
			var tempDeleteArray = [];
			var tempAddArray = [];
			var CrumbName = oEvent.getSource().getText();
			for (var i = 0; i < crumbHistory.length; i++) {
				if (crumbHistory[i].CrumbName === CrumbName) {
					var localArray = crumbHistory[i].Data;
					if (CrumbName === "Zones") {
						newCrumbHistory.push(crumbHistory[i]);
						break;
					}
				}
				newCrumbHistory.push(crumbHistory[i]);
			}
			for (var j = 0; j < localArray.length; j++) {
				if (localArray[j].Level === 1) {
					tempAddArray.push(localArray[j]);
				} else {
					tempAddArray.push(localArray[j]);
				}
			}
			crumbHistory = newCrumbHistory;
			gSchemeDetails.getModel("oZones").setData(tempAddArray);
			this._maintainCrumbLinks("", false, CrumbName);
		},

		handleSelectionChange: function(oEvent) {
			var tempDeleteArray = [];
			var tempAddArray = [];
			var sPath;
			if (oEvent.getParameter("listItem")) {
				sPath = oEvent.getParameter("listItem").getBindingContext("oZones").getPath();
			} else {
				sPath = oEvent.getSource().getParent().getBindingContext("oZones").getPath();
			}
			var aPath = sPath.split("/");
			var index = parseFloat(aPath[1]);
			var ZoneData = jQuery.extend(true, [], this.getView().getModel("oZones").getData());

			if (ZoneData[index].results !== undefined && ZoneData[index].results.length > 0) {
				var nextLevelData = ZoneData[index].results;
				if (nextLevelData[0].CrumbName !== "Areas") {
					for (var j = 0; j < nextLevelData.length; j++) {

						tempAddArray.push(nextLevelData[j]);

					}
					this.getView().getModel("oZones").setData(tempAddArray);
				} else {
					this.getView().getModel("oZones").setData(nextLevelData);
				}
				//Deselection of all data in Zone table..................
				var UpdatedZoneData = this.getView().getModel("oZones").getData();
				for (var final = 0; final < UpdatedZoneData.length; final++) {
					UpdatedZoneData[final].AreaSelected = false;
					if (UpdatedZoneData[final].results !== undefined) {
						if (UpdatedZoneData[final].results.length > 0) {
							UpdatedZoneData[final].HaveChild = true;
						} else {
							UpdatedZoneData[final].HaveChild = false;
						}
					}
				}
				this.getView().getModel("oZones").setData(UpdatedZoneData);

				if (nextLevelData.length > 0) {
					var name = nextLevelData[0].CrumbName;
					var CrumbSelected = this.validateSelectedCrumb(nextLevelData[0].CrumbName, nextLevelData);
					if (CrumbSelected === 0) {
						crumbHistory.push({
							"CrumbName": name,
							Data: nextLevelData
						});
					}
				}
			}
			var aDefaultSorter = [];
			var Path = new sap.ui.model.Sorter("Position", false);
			aDefaultSorter.push(Path);
			var oTable = this.getView().byId("idZonesTable");
			var oBinding = oTable.getBinding("items");
			oBinding.sort(aDefaultSorter);
			this._maintainCrumbLinks(sPath, false);
			gSchemeGeographiesBlock.byId("idAreas").focus();
		},
		
		validateSelectedCrumb: function(SelectedCrumb, nextLevelData) {
			var seen = 0;
			for (var i = 0; i < crumbHistory.length; i++) {
				if (crumbHistory[i].CrumbName === SelectedCrumb) {
					seen++;
				}
			}
			return seen;
		},
		
		onBtnAsign: function(oEvent) {

			var Selected = false;
			var oZoneSelectedData = this.getView().getModel("oZoneSelectedLists").getData();
			var childTempArray = [];
			var childDeleteArray = [];
			var childs = jQuery.extend(true, [], this.getView().getModel("oZones").getData());

			if (sIndex === 0) {
				for (var i = 0; i < childs.length; i++) {
					if (childs[i].AreaSelected) {
						//childs[i].AreaSelected = false;
						childTempArray.push(childs[i]);

						Selected = true;
						//Level one.....................................
						for (var level1 = 0; level1 < cZone.length; level1++) {
							if (childs[i].Level === 1) {
								if (cZone[level1].ID === childs[i].ID) {
									oZoneSelectedData.push(cZone[level1]);
								}
							} else {
								if (cZone[level1].results !== undefined) {
									//Level Two.............................................
									for (var level2 = 0; level2 < cZone[level1].results.length; level2++) {
										var sPath = childs[i].Path.split("/");
										if (childs[i].Level === 2) {
											if (cZone[level1].results[level2].ID === childs[i].ID && level1 === parseInt(sPath[1])) {
												if (oZoneSelectedData === undefined || oZoneSelectedData.length === 0) {
													oZoneSelectedData.push(cZone[level1]);
													oZoneSelectedData[oZoneSelectedData.length - 1].results = childTempArray;
												} else {
													oZoneSelectedData[oZoneSelectedData.length - 1].results = childTempArray;
												}
											}
										} else {
											if (cZone[level1].results[level2].results !== undefined) {
												if (childs[i].Level === 3) {
													//Level Three...................................................
													for (var level3 = 0; level3 < cZone[level1].results[level2].results.length; level3++) {
														var sPath = childs[i].Path.split("/");
														if (cZone[level1].results[level2].results[level3].ID === childs[i].ID && level2 === parseInt(sPath[3]) && level1 ===
															parseInt(sPath[1])) {
															if (oZoneSelectedData === undefined || oZoneSelectedData.length === 0) {
																oZoneSelectedData.push(cZone[level1]);
																var level2Data = [];
																level2Data.push(cZone[level1].results[level2]);
																oZoneSelectedData[oZoneSelectedData.length - 1].results = level2Data;
																oZoneSelectedData[oZoneSelectedData.length - 1].results[oZoneSelectedData[oZoneSelectedData.length - 1].results.length -
																	1].results = childTempArray;
															} else {
																oZoneSelectedData[oZoneSelectedData.length - 1].results[oZoneSelectedData[oZoneSelectedData.length - 1].results.length -
																	1].results = childTempArray;
															}
															// cZone = this.updateSampleVariable(cZone);
															cZone = jQuery.extend(true, [], this.zone);
															// this.zone
														}
													}
												}
											}
										}
									}
								}
							}
						}
					} else {
						childDeleteArray.push(childs[i]);
					}
				}
			} else {
				for (var m = 0; m < childs.length; m++) {
					if (childs[m].AreaSelected) {
						childTempArray.push(childs[m]);
						Selected = true;
						for (var n = 0; n < bDepot.length; n++) {
							if (bDepot[n].ID === childs[m].ID) {
								oZoneSelectedData.push(bDepot[n]);
							}
						}
					} else {
						childDeleteArray.push(childs[m]);
					}
				}
			}

			if (!Selected) {
				var msg = oi18n.getText("Geography.Message.SelectToMove");
				MessageToast.show(msg);
			} else {
				//Geography.Message.SelectToMove
				var zoneSeen = 0;
				var regionSeen = 0;
				var areaSeen = 0;
				var depotSeen = 0;
				var tempArray = [];
				//var child = false;
				//var superChild = false;
				if (oAreaArray.length > 0) {
					for (var a = 0; a < childTempArray.length; a++) {
						//var sArrayPath = childTempArray[a].Path.split("/");
						if (sIndex === 0) {
							for (var b = 0; b < oAreaArray.length; b++) {
								if (childTempArray[a].ID === oAreaArray[b].ID || childTempArray[a].ParentID === oAreaArray[b].ID || childTempArray[a].SuperParentID ===
									oAreaArray[b].ID) {
									zoneSeen++;
									//child = true;
									if (oAreaArray[b].results !== undefined) {
										for (var c = 0; c < oAreaArray[b].results.length; c++) {
											if (childTempArray[a].ID === oAreaArray[b].results[c].ID || childTempArray[a].ParentID === oAreaArray[b].results[c].ID) {
												regionSeen++;
												//superChild = true;
												if (oAreaArray[b].results[c].results !== undefined) {
													for (var d = 0; d < oAreaArray[b].results[c].results; d++) {
														if (childTempArray[a].ID === oAreaArray[b].results[c].results[d].ID) {
															areaSeen++;
														}
													}
													if (areaSeen === 0) {
														oAreaArray[b].results[c].results.push(childTempArray[a]);
													}
												}
											}
										}
										if (regionSeen === 0) {
											var ParentArray = [];
											if ((childTempArray[a].Path.split("/")).length > 4) {
												ParentArray.push(oZoneSelectedData[oZoneSelectedData.length - 1].results[oZoneSelectedData[oZoneSelectedData.length - 1]
													.results
													.length - 1]);
												ParentArray[ParentArray.length - 1].results = childTempArray;
												oAreaArray[b].results.push(ParentArray[0]);
											} else {
												oAreaArray[b].results.push(childTempArray[a]);
											}
										}
									}

								}
							}
							if (zoneSeen === 0) {
								oAreaArray.push(oZoneSelectedData[0]);
								break;
							}
						} else {
							tempArray = [];
							for (var e = 0; e < childTempArray.length; e++) {
								var valid = 0;
								for (var k = 0; k < oAreaArray.length; k++) {
									if (childTempArray[a].ID !== oAreaArray[k].ID) {
										valid++;
										if (valid === 1) {
											tempArray.push(childTempArray[e]);
										}
									}
								}
							}
						}

					}
					if (tempArray.length > 0) {
						for (var d = 0; d < tempArray.length; d++) {
							oAreaArray.push(tempArray[d]);
						}

					}
				} else {
					for (var final = 0; final < oZoneSelectedData.length; final++) {
						oAreaArray.push(oZoneSelectedData[final]);
					}
				}

				this.getView().getModel("oZoneSelectedLists").setProperty("/", oAreaArray);
				this.getView().byId("treeTable").expandToLevel(2);
				this.getView().getModel("oZones").setProperty("/", childDeleteArray);
				//this.updateCrumbHistory(childs[0].ParentPath);

				this.resetCrumbHistory();
				cZone = jQuery.extend(true, [], this.zone); //this.updateSampleVariable(cZone);
				// cZone = cZone;
			}
			this.byId("treeTable").clearSelection();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/Selected", false);
			sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").copyGeoDetails();
		},
		
		updateCrumbHistory: function(Path) {
			crumbHistory = [];
			// if (aZone[parseFloat(sPath[1])] === undefined) {
			// 	aZone = this.updateSampleVariable(aZone);
			// }
			var currentCrumb = this.byId("idCrumbToolbar").getContent()[this.byId("idCrumbToolbar").getContent().length - 1].getText();
			if (Path !== undefined) {
				//var localArray=[];
				var sPath = Path.split("/");
				//var regionIndex;
				var zoneIndex = parseFloat(sPath[1]);
				for (var a = 0; a < aZone.length; a++) {
					if (aZone[a].Path === "/" + sPath[1]) {
						zoneIndex = a;
						// for(var b = 0; b < aZone[a].results.length; b++)
						// {
						// 	if(aZone[a].results[b].Path === "/" + sPath[1] + "/results" + sPath[3]+"/results")
						// 	{
						// 		regionIndex = b;
						// 	}
						// }
					}
				}
				if (currentCrumb === "Zones") {
					crumbHistory.push({
						"CrumbName": "Zones",
						"Data": aZone
					});
				} else if (currentCrumb === "Regions") {
					crumbHistory.push({
						"CrumbName": "Zones",
						"Data": aZone
					});
					crumbHistory.push({
						"CrumbName": currentCrumb,
						Data: aZone[zoneIndex].results
					});
				} else if (currentCrumb === "Areas") {
					crumbHistory.push({
						"CrumbName": "Zones",
						"Data": aZone
					});
					crumbHistory.push({
						"CrumbName": "Regions",
						Data: aZone[zoneIndex].results
					});
					crumbHistory.push({
						"CrumbName": currentCrumb,
						Data: aZone[zoneIndex].results[parseFloat(sPath[3])].results
					});
				}
			} else {
				if (currentCrumb === "Zones") {
					crumbHistory.push({
						"CrumbName": "Zones",
						"Data": aZone
					});
				}
			}
			// var copyOfCrumbHistory = [];
			// copyOfCrumbHistory.push(crumbHistory[0]);
			// crumbHistory = copyOfCrumbHistory;
			// this._maintainCrumbLinks(sPath, false);
		},
		
		resetCrumbHistory: function(sPath) {
			var currentCrumb = gSchemeGeographiesBlock.byId("idCrumbToolbar").getContent()[gSchemeGeographiesBlock.byId("idCrumbToolbar").getContent()
				.length - 1].getText();
			for (var i = 0; i < crumbHistory.length; i++) {
				if (currentCrumb === "Zones" && currentCrumb === crumbHistory[i].CrumbName) {
					if (gSchemeDetails.getModel("oZones").getProperty("/").length === 0) {
						crumbHistory[i].Data = [];
					} else {
						crumbHistory[i].Data = gSchemeDetails.getModel("oZones").getProperty("/");
					}
				} else if (currentCrumb === "Regions" && currentCrumb === crumbHistory[i].CrumbName) {
					var parentIndex; //= crumbHistory[i].Data[0].Path.split("/")[1];
					for (var a = 0; a < crumbHistory[i - 1].Data.length; a++) {
						if (crumbHistory[i].Data[0].ParentID === crumbHistory[i - 1].Data[a].ID) {
							parentIndex = a;
						}
					}
					crumbHistory[i].Data = crumbHistory[i - 1].Data[parentIndex].results;
					if (gSchemeDetails.getModel("oZones").getProperty("/").length === 0) {
						//var parentIndex = crumbHistory[i].Data[0].Path.split("/")[1];

						crumbHistory[i - 1].Data[parentIndex].HaveChild = false;
						crumbHistory[i - 1].Data[parentIndex].results = [];
						crumbHistory[i - 1].Data.splice(parentIndex, 1);
						crumbHistory.splice(i, 1);
					} else {
						crumbHistory[i].Data = gSchemeDetails.getModel("oZones").getProperty("/");
						crumbHistory[i - 1].Data[parentIndex].results = crumbHistory[i].Data;
					}
				} else if (currentCrumb === "Areas" && currentCrumb === crumbHistory[i].CrumbName) {
					var parentOfParentIndex; //= crumbHistory[i].Data[0].Path.split("/")[1];
					var parentIndex2;
					//getting Parent Index......................................................
					for (var b = 0; b < crumbHistory[i - 1].Data.length; b++) {
						if (crumbHistory[i - 1].Data[b].ID === crumbHistory[i].Data[0].ParentID) {
							parentIndex2 = b;
						}
					}
					//getting Parent of Parent Index......................................................
					for (var c = 0; c < crumbHistory[i - 2].Data.length; c++) {
						if (crumbHistory[i - 2].Data[c].ID === crumbHistory[i].Data[0].SuperParentID) {
							parentOfParentIndex = c;
						}
					}
					// var parentIndex = crumbHistory[i].Data[0].Path.split("/")[3];

					//update immediate parent.............................................
					if (gSchemeDetails.getModel("oZones").getProperty("/").length === 0) {
						crumbHistory[i - 1].Data[parentIndex2].HaveChild = false;
						crumbHistory[i - 1].Data[parentIndex2].results = [];
						// var copyOfRegionData = jQuery.extend({}, crumbHistory[i - 1].Data);
						// copyOfRegionData.splice(parentIndex2, 1);
						// crumbHistory[i - 1].Data = copyOfRegionData;
						crumbHistory.splice(i, 1);

					} else {
						crumbHistory[i].Data = gSchemeDetails.getModel("oZones").getProperty("/");
						crumbHistory[i - 1].Data[parentIndex2].results = crumbHistory[i].Data;
					}

					//update parent of parent.............................................

					if (gSchemeDetails.getModel("oZones").getProperty("/").length === 0) {
						crumbHistory[i - 2].Data[parentOfParentIndex].results[parentIndex2].HaveChild = false;
						crumbHistory[i - 2].Data[parentOfParentIndex].results[parentIndex2].results = [];
						var resultCount = 0;
						for (var d = 0; d < crumbHistory[i - 2].Data[parentOfParentIndex].results.length; d++) {
							if (crumbHistory[i - 2].Data[parentOfParentIndex].results[d].results.length > 0) {
								resultCount++;
							}
						}
						if (resultCount === 0) {
							crumbHistory[i - 2].Data[parentOfParentIndex].HaveChild = false;
							crumbHistory[i - 2].Data[parentOfParentIndex].results = [];
							//crumbHistory[i - 2].Data.splice(parentOfParentIndex, 1);

						}
					} else {
						crumbHistory[i].Data = gSchemeDetails.getModel("oZones").getProperty("/");
						crumbHistory[i - 2].Data[parentOfParentIndex].results[parentIndex2].results = crumbHistory[i].Data;
					}
				}
			}

		},
		
		onDeleteFromArea: function(oEvent) {

			var copyOfCrumbHistory = [];
			copyOfCrumbHistory.push(crumbHistory[0]);
			crumbHistory = copyOfCrumbHistory;
			var SelectedArray = [];
			var SelectedRowData = [];
			var deletionPath = [];
			var selectedIndices = this.byId("treeTable").getSelectedIndices();
			this.byId("treeTable").clearSelection();
			if (selectedIndices.length > 0) {
				// for (var s = 0; s < selectedIndices.length; s++) {
				for (var s = selectedIndices.length - 1; s >= 0; s--) {
					var selectedIndex = selectedIndices[s];
					var sPath = this.byId("treeTable").getContextByIndex(selectedIndex).sPath;
					var Data = this.byId("treeTable").getContextByIndex(selectedIndex).getModel().getProperty(sPath);

					var hasParentOrSuperParentSelected = this.updateSelectedIndices(Data, s);
					if (hasParentOrSuperParentSelected) {
						continue;
					}
					deletionPath.push(this.byId("treeTable").getContextByIndex(selectedIndex).sPath);
					if (sPath.split("/").length > 2) {
						SelectedArray.push(jQuery.extend({}, this.byId("treeTable").getContextByIndex(selectedIndex).getModel().getProperty(sPath.split(
							"results")[0])));
					} else {
						SelectedArray.push(jQuery.extend({}, this.byId("treeTable").getContextByIndex(selectedIndex).getModel().getProperty(sPath)));
					}
					SelectedRowData.push(jQuery.extend({}, this.byId("treeTable").getContextByIndex(selectedIndex).getModel().getProperty(sPath)));
					SelectedArray = this.updateSelectedArray(SelectedRowData[SelectedRowData.length - 1], sPath);
					if (sIndex === 0) {
						if (crumbHistory.length > 0) {
							var zoneSeen = 0;
							var regionSeen = 0;
							var areaSeen = 0;
							Loop1: for (var j = 0; j < crumbHistory[0].Data.length; j++) {
								if ((SelectedRowData[SelectedRowData.length - 1].ID === crumbHistory[0].Data[j].ID || SelectedRowData[SelectedRowData.length -
											1].ParentID === crumbHistory[0].Data[j].ID ||
										SelectedRowData[SelectedRowData.length - 1].SuperParentID === crumbHistory[0].Data[j].ID) && crumbHistory[0].Data[j].results
									.length !==
									0) {
									zoneSeen++;
									if (crumbHistory[0].Data[j].results !== undefined) {
										Loop2: for (var k = 0; k < crumbHistory[0].Data[j].results.length; k++) {
											if (SelectedRowData[SelectedRowData.length - 1].ID === crumbHistory[0].Data[j].results[k].ID || SelectedRowData[
													SelectedRowData.length - 1].ParentID === crumbHistory[0].Data[j]
												.results[k].ID) {
												regionSeen++;
												if (crumbHistory[0].Data[j].results[k].results !== undefined) {
													Loop3: for (var l = 0; l < crumbHistory[0].Data[j].results[k].results.length; l++) {
														if (SelectedRowData[SelectedRowData.length - 1].ID === crumbHistory[0].Data[j].results[k].results[l].ID) {
															areaSeen++;
														}
													}
													if (areaSeen === 0) {
														if (SelectedRowData[SelectedRowData.length - 1].results) {
															for (var res = 0; res < SelectedRowData[SelectedRowData.length - 1].results.length; res++) {
																crumbHistory[0].Data[j].results[k].results.push(SelectedRowData[SelectedRowData.length - 1].results[res]);
															}
														} else {
															crumbHistory[0].Data[j].results[k].results.push(SelectedRowData[SelectedRowData.length - 1]);
														}
														break Loop1;
													}
												}
											}
										}
										if (regionSeen === 0) {
											//var ParentArray = [];
											if ((SelectedRowData[SelectedRowData.length - 1].Path.split("/")).length > 4) {
												var ParentArray = SelectedArray[SelectedArray.length - 1].results;
												//ParentArray[ParentArray.length - 1].results.push(SelectedRowData[SelectedRowData.length - 1]);
												crumbHistory[0].Data[j].results.push(ParentArray[0]);
											} else {
												if (crumbHistory[0].Data[j].results[0].ParentID === SelectedRowData[SelectedRowData.length - 1].ParentID) {
													crumbHistory[0].Data[j].results.push(SelectedRowData[SelectedRowData.length - 1]);
													crumbHistory[0].Data[j].results.HaveChild = true;
													crumbHistory[0].Data[j].results.AreaSelected = false;
												} else {
													var ParentArray = SelectedArray[SelectedArray.length - 1].results;
													//ParentArray[ParentArray.length - 1].results.push(SelectedRowData[SelectedRowData.length - 1]);
													crumbHistory[0].Data[j].results.push(ParentArray[0]);
													crumbHistory[0].Data[j].results.HaveChild = true;
													crumbHistory[0].Data[j].results.AreaSelected = false;
												}
											}
											break Loop1;
										}
									}
								}
							}
							if (zoneSeen === 0) {
								if (SelectedRowData[SelectedRowData.length - 1].ID !== undefined) {
									crumbHistory[0].Data.push(SelectedArray[SelectedArray.length - 1]);
									crumbHistory[0].Data[crumbHistory[0].Data.length - 1].HaveChild = true;
									crumbHistory[0].Data[crumbHistory[0].Data.length - 1].AreaSelected = false;
								}
							}
						} else {
							crumbHistory.push({
								"CrumbName": "Zones",
								"Data": [],
								"Path": ""
							});
							crumbHistory[crumbHistory.length - 1].Data.push(SelectedArray[SelectedArray.length - 1]);
						}
					}
					for (var final = 0; final < crumbHistory[0].Data.length; final++) {
						crumbHistory[0].Data[final].AreaSelected = false;
						if (!crumbHistory[0].Data[final].HaveChild) {
							crumbHistory[0].Data.splice(final, 1);
						}
					}
				}

				this.updateAreaTable(deletionPath, SelectedRowData);
				if (sIndex === 1) {
					TempDepotArray = [];
					TempDepotArray = this.getView().getModel("oZones").getData();
					for (var m = 0; m < SelectedRowData.length; m++) {
						TempDepotArray.push(SelectedRowData[m]);
					}
					this.getView().getModel("oZones").setData(TempDepotArray);
				} else {
					this.getView().getModel("oZones").setData(crumbHistory[0].Data);
					this._maintainCrumbLinks("", false);
				}
				var aDefaultSorter = [];
				var Path = new sap.ui.model.Sorter("Position", false);
				aDefaultSorter.push(Path);
				var oTable = this.getView().byId("idZonesTable");
				var oBinding = oTable.getBinding("items");
				oBinding.sort(aDefaultSorter);
				// oPPCCommon.setGroupInTable(this.getView(), "idZonesTable", "", false, "", "", aDefaultSorter);
				sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").copyGeoDetails();
			} else {
				var msg = oi18n.getText("Geography.Message.SelectToMove");
				MessageToast.show(msg);
			}
		},
		
		updateAreaTable: function(deletionPath, SelectedRowData) {

			//Deleting Data from Area table...................

			for (var i = 0; i < deletionPath.length; i++) {
				var oZonesArray = jQuery.extend(true, [], this.getView().getModel("oZones").getProperty("/"));
				var deletionArray = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty("/"));
				this.getView().getModel("oZones").setProperty("/", {});
				//this.getView().getModel("oZoneSelectedLists").setProperty("/", {});
				var splittedPath = deletionPath[i].split("/");
				if (splittedPath.length === 6) {
					var localPath = "/" + splittedPath[1] + "/results/" + splittedPath[3] + "/results";
					var resultsLevel1 = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty(localPath));
					resultsLevel1.splice(splittedPath[5], 1);
					deletionArray[parseFloat(splittedPath[1])].results[parseFloat(splittedPath[3])].results = resultsLevel1;
					if (deletionArray[parseFloat(splittedPath[1])].results[parseFloat(splittedPath[3])].results.length === 0) {
						var parentPath = "/" + splittedPath[1] + "/results/";
						var parentData = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty(parentPath));
						parentData.splice(splittedPath[3], 1);
						deletionArray[parseFloat(splittedPath[1])].results = parentData;
						if (deletionArray[parseFloat(splittedPath[1])].results.length === 0) {
							var superParentData = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty("/"));
							superParentData.splice(splittedPath[1], 1);
							deletionArray = superParentData;
						}
					}
				}
				if (splittedPath.length === 4) {
					var level2ParentPath = "/" + parseFloat(splittedPath[1]) + "/results";
					var results = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty(level2ParentPath));

					results.splice(parseFloat(splittedPath[3]), 1);
					deletionArray[parseFloat(splittedPath[1])].results = [];
					deletionArray[parseFloat(splittedPath[1])].results = results;
					if (results.length === 0) {
						deletionArray.splice(parseFloat(splittedPath[1]), 1);
					}
				}
				if (splittedPath.length === 2) {
					if (SelectedRowData[i].ID !== undefined) {
						var superParentData2 = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty("/"));
						superParentData2.splice(splittedPath[1], 1);
						deletionArray = superParentData2;
					}
				}
				this.getView().getModel("oZoneSelectedLists").setProperty("/", deletionArray);
				this.getView().getModel("oZones").setProperty("/", oZonesArray);
				oAreaArray = this.getView().getModel("oZoneSelectedLists").getProperty("/");
				this.getView().getModel("oZoneSelectedLists").refresh();
				this.byId("treeTable").setSelectionMode("MultiToggle");
			}

		},
		
		updateSelectedArray: function(SelectedRowData1, sPath) {
			var SelectedRowData = [];
			SelectedRowData.push(SelectedRowData1);
			var splittedPath = sPath.split("/");
			var resultsLevel;
			var localPath;
			var selectedRegionPath;
			var finalArray;
			var SelectedArray = [];
			if (splittedPath.length === 6) {
				localPath = "/" + splittedPath[1] + "/results/" + splittedPath[3] + "/results";
				resultsLevel = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty(localPath));
				resultsLevel = SelectedRowData;
				selectedRegionPath = "/" + splittedPath[1] + "/results/" + splittedPath[3];
				//resultsLevel.push(SelectedRowData);
				var selectedRegion = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty(selectedRegionPath));
				selectedRegion.results = resultsLevel;
				finalArray = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty("/" + splittedPath[1]));
				finalArray.results = [];
				finalArray.results.push(selectedRegion);
				resultsLevel = finalArray;
				//finalArray.results.push(selectedRegion);
			}
			if (splittedPath.length === 4) {
				var level2ParentPath = "/" + parseFloat(splittedPath[1]);
				resultsLevel = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty(level2ParentPath));
				resultsLevel.results = SelectedRowData;
				//finalArray = jQuery.extend([], this.getView().getModel("oZoneSelectedLists").getProperty("/" + splittedPath[1]));
				//finalArray.results = resultsLevel;
				//resultsLevel.push(SelectedRowData);
			}
			if (splittedPath.length === 2) {
				//var level2ParentPath = "/" + parseFloat(splittedPath[1]) + "/results";
				resultsLevel = jQuery.extend(true, [], this.getView().getModel("oZoneSelectedLists").getProperty("/"));
				resultsLevel = [];
				resultsLevel = SelectedRowData[0];
			}
			SelectedArray.push(resultsLevel);
			return SelectedArray;
		},
		// onTreeHierarchyChange:function(oEvent)
		// {
		// 	var a=0;
		// },
		updateSelectedIndices: function(currentSelectedData, currentIndex) {
			var seen = false;
			var selectedIndices = this.byId("treeTable").getSelectedIndices();
			for (var i = 0; i < selectedIndices.length; i++) {
				var selectedIndex = selectedIndices[i];
				var sPath = this.byId("treeTable").getContextByIndex(selectedIndex).sPath;
				var Data = this.byId("treeTable").getContextByIndex(selectedIndex).getModel().getProperty(sPath);
				if (currentSelectedData.ParentID !== undefined && currentSelectedData.SuperParentID !== undefined) {
					if ((currentSelectedData.ParentID === Data.ID || currentSelectedData.SuperParentID === Data.ID) && this.byId("treeTable").isIndexSelected(
							selectedIndex)) {
						seen = true;
						break;
					}
				} else {
					break;
				}
			}
			return seen;
		},
		// Build the crumb links for display in the toolbar
		_maintainCrumbLinks: function(sPath, Updated, SelectedCrumb) {

			var sText;
			// Re-build crumb toolbar based on trail parts
			var oCrumbToolbar = gSchemeGeographiesBlock.byId("idCrumbToolbar");
			oCrumbToolbar.destroyContent();
			if (crumbHistory.length === 1) {
				// Special case for 1st crumb: fixed text
				sText = crumbHistory[0].CrumbName;
				var oCrumb = new Text({
					text: sText
				}).addStyleClass("crumbLast");
				oCrumbToolbar.addContent(oCrumb);
			} else {
				for (var i = 0; i < crumbHistory.length; i++) {
					sText = crumbHistory[i].CrumbName;
					if (SelectedCrumb === undefined || SelectedCrumb !== sText) {
						if (i < crumbHistory.length - 1) {
							var oCrumb = new Link({
								text: sText,
								press: [this.handleLinkPress, this]
							});
						} else {
							var oCrumb = new Text({
								text: sText
							});
						}
						oCrumbToolbar.addContent(oCrumb);
						if (i < crumbHistory.length - 1) {
							var oArrow = new Label({
								textAlign: "Center",
								text: ">"
							}).addStyleClass("crumbArrow");
							oCrumbToolbar.addContent(oArrow);
						}
					} else {
						var oCrumb = new Text({
							text: sText
						});
						oCrumbToolbar.addContent(oCrumb);
						break;
					}
				}
			}
		},
		
		setDefaultSettings1: function() {
			var oSchemeDetailView = gSchemeDetails;
			var oLocalViewModel = new sap.ui.model.json.JSONModel();
			this.localModelData = {
				oNextBtnVisibility: true
			};
			oLocalViewModel.setData(this.localModelData);
			oSchemeDetailView.setModel(oLocalViewModel, "oLocalViewSetting");
			if (sIndex === 0) {
				var ZoneData = jQuery.extend(true, [], oSchemeDetailView.getModel("ZoneModel").getData());
				var oZoneModel = new sap.ui.model.json.JSONModel();
				//var oZoneData=this.getView().getModel("ZoneModel");
				oZoneModel.setData(ZoneData);
				oSchemeDetailView.setModel(oZoneModel, "oZones");

				var ZoneData1 = jQuery.extend(true, [], oSchemeDetailView.getModel("ZoneModel").getData());
				crumbHistory.push({
					"CrumbName": "Zones",
					"Data": ZoneData1,
					"Path": ""
				});
				var oZoneSelectedModel = new sap.ui.model.json.JSONModel();
				oZoneSelectedModel.setData(oAreaArray);
				oSchemeDetailView.setModel(oZoneSelectedModel, "oZoneSelectedLists");
				gSchemeGeographiesBlock.byId("treeTable").expandToLevel(2);
			} else {
				var DepotData = jQuery.extend(true, [], oSchemeDetailView.getModel("DepotModel").getData());
				var oDepotModel = new sap.ui.model.json.JSONModel();
				//var oZoneData=this.getView().getModel("ZoneModel");
				oDepotModel.setData(DepotData);
				oSchemeDetailView.getModel("oZones").setProperty("/", DepotData);

				var DepotData1 = jQuery.extend(true, [], oSchemeDetailViews.getModel("DepotModel").getData());
				crumbHistory.push({
					"CrumbName": "Depots",
					"Data": DepotData1,
					"Path": ""
				});
				var oDepotSelectedModel = new sap.ui.model.json.JSONModel();
				oDepotSelectedModel.setData(oAreaArray);
				oSchemeDetailView.setModel(oDepotSelectedModel, "oZoneSelectedLists");
				// 	// this.getView().byId("treeTable").expandToLevel(2);

			}

			/*var tempArray = jQuery.extend(true, [], ZoneData[0]);
			oAreaArray.push(tempArray);
			oAreaArray[0].results.splice(1, 2);
			ZoneData[0].results.splice(0, 1);
				
			tempArray = jQuery.extend(true, [], ZoneData[1]);
			oAreaArray.push(tempArray);
			oAreaArray[1].results[1].results.splice(0, 1);
			ZoneData[1].results[1].results.splice(1, 2);
			oAreaArray[1].results.splice(0, 1);

			aZone = ZoneData;
			bZone = ZoneData;
			cZone = ZoneData;*/

		},
		
		getCurrentUsers: function(sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		
		updateSampleVariable: function(aDetailGeo, oController) {
			var oView = oController.getView();
			var oSchemeDetailView = gSchemeDetails;
			var that = this;
			var geoModel = oSchemeDetailView.getModel("SCGW");
			var GeoFiltersArray = new Array();
			GeoFiltersArray = oPPCCommon.setODataModelReadFilter(oSchemeDetailView, "", GeoFiltersArray, "LoginID", "", [
				this.getCurrentUsers("Geographies", "read")
			], false, false, false);

			geoModel.read("/Geographies", {
				filters: GeoFiltersArray,
				success: function(oData) {
					var aData = oData.results;
					var aTempArray = [];
					var TreeTableTempArray = [];
					if (sIndex === 0) {
						var aZones = [];
						var aRegions = [];
						var aAreas = [];
						for (var i = 0; i < aData.length; i++) {
							if (aData[i].GeographyTypeID === "0000000001") {
								aZones.push({
									"ID": aData[i].GeographyValueID,
									"Level": 1,
									"Name": aData[i].GeographyValueDesc,
									"CurrencyCode": "EUR",
									"HaveChild": true,
									"Path": "/" + i,
									"Position": i,
									"GeographyTypeID": aData[i].GeographyTypeID,
									"GeographyParentTypeID": aData[i].GeographyParentTypeID
								});
							} else if (aData[i].GeographyTypeID === "0000000002") {
								aRegions.push({
									"ID": aData[i].GeographyValueID,
									"Level": 2,
									"Name": aData[i].GeographyValueDesc,
									"CurrencyCode": "EUR",
									"CrumbName": "Regions",
									"HaveChild": true,
									"Path": "/0/results",
									"Position": "0",
									"ParentPath": "/0/results",
									"ParentID": aData[i].GeographyParentTypeValueID,
									"SuperParentID": "",
									"GeographyTypeID": aData[i].GeographyTypeID,
									"GeographyParentTypeID": aData[i].GeographyParentTypeID
								});
							} else if (aData[i].GeographyTypeID === "0000000003") {
								aAreas.push({
									"ID": aData[i].GeographyValueID,
									"Level": 3,
									"Name": aData[i].GeographyValueDesc,
									"CrumbName": "Areas",
									"HaveChild": true,
									"Path": "/0/results/0/results",
									"Position": "0",
									"ParentPath": "/0/results/0/results",
									"ParentID": aData[i].GeographyParentTypeValueID,
									"SuperParentID": "W&S",
									"GeographyTypeID": aData[i].GeographyTypeID,
									"GeographyParentTypeID": aData[i].GeographyParentTypeID
								});
							}

						}

						//maintain super parent id in areas array
						var zone = [];
						var region = [];
						var area = [];
						for (var j = 0; j < aZones.length; j++) {
							region = [];

							var level2 = 0;
							for (var k = 0; k < aRegions.length; k++) {
								area = [];
								if (aZones[j].ID === aRegions[k].ParentID) {
									if (level2 !== 0) {
										level2 = level2 + 1;
									}
									var level3 = 0;
									for (var l = 0; l < aAreas.length; l++) {
										if (aRegions[k].ID === aAreas[l].ParentID) {
											if (level3 !== 0) {
												level3 = level3 + 1;
											}
											area.push({
												"ID": aAreas[l].ID,
												"Level": 3,
												"Name": aAreas[l].Name,
												"CrumbName": "Areas",
												"HaveChild": true,
												"Path": "/" + j + "/results/" + level2 + "/results",
												"Position": level3,
												"ParentPath": "/" + j + "/results/" + level2 + "/results",
												"ParentID": aAreas[l].ParentID,
												"SuperParentID": aZones[j].ID,
												"GeographyTypeID": aAreas[l].GeographyTypeID,
												"GeographyParentTypeID": aAreas[l].GeographyParentTypeID
											});
										}
									}

									region.push({
										"ID": aRegions[k].ID,
										"Level": 2,
										"Name": aRegions[k].Name,
										"CurrencyCode": "EUR",
										"CrumbName": "Regions",
										"HaveChild": true,
										"Path": "/" + j + "/results",
										"Position": level2,
										"ParentPath": "/" + j + "/results",
										"ParentID": aRegions[k].ParentID,
										"SuperParentID": "",
										"GeographyTypeID": aRegions[k].GeographyTypeID,
										"GeographyParentTypeID": aRegions[k].GeographyParentTypeID,
										"results": area
									});
								}
							}

							zone.push({
								"ID": aZones[j].ID,
								"Level": 1,
								"Name": aZones[j].Name,
								"CurrencyCode": "EUR",
								"HaveChild": true,
								"Path": "/" + j,
								"Position": j,
								"GeographyTypeID": aZones[j].GeographyTypeID,
								"GeographyParentTypeID": aZones[j].GeographyParentTypeID,
								"results": region
							});
						}
						cZone = jQuery.extend(true, [], zone);
						aZone = jQuery.extend(true, [], aLocalZone);
						that.zone = jQuery.extend(true, [], aLocalZone);
						if (aDetailGeo) {
							for (var i = 0; i < aData.length; i++) {
								var bSeen = false;
								for (var j = 0; j < aDetailGeo.length; j++) {
									if (aData[i].GeographyValueID === aDetailGeo[j].GeographyValueID) {
										bSeen = true;
										break;
									}
								}
								if (!bSeen) {
									aTempArray.push(aData[i]);
								}
							}

							aData = aTempArray;
							var aLocalZone = that.formatGeographyZones(aData);
						}
						var sPath = "";
						bZone = aLocalZone;
						var oModel1 = new JSONModel();
						oModel1.setData(bZone);
						oSchemeDetailView.setModel(oModel1, "ZoneModel");

						that._oTable = gSchemeGeographiesBlock.byId("idZonesTable");

					} else {

						var aDepot = [];

						for (var k = 0; k < aData.length; k++) {
							if (aData[k].GeographyTypeID === "0000000005") {
								aDepot.push({
									"ID": aData[k].GeographyValueID,
									"Name": aData[k].GeographyValueDesc,
									"CurrencyCode": "EUR",
									"HaveChild": true,
									"Path": "/" + k,
									"Position": k,
									"GeographyTypeID": aData[k].GeographyTypeID,
									"GeographyParentTypeID": aData[k].GeographyParentTypeID
								});
							}

						}

						//maintain super parent id in areas array
						var depot = [];

						for (var l = 0; l < aDepot.length; l++) {

							depot.push({
								"ID": aDepot[l].ID,
								"Level": 1,
								"Name": aDepot[l].Name,
								"CurrencyCode": "EUR",
								"HaveChild": true,
								"Path": "/" + l,
								"Position": l,
								"GeographyTypeID": aDepot[l].GeographyTypeID,
								"GeographyParentTypeID": aDepot[l].GeographyParentTypeID,
								"results": region
							});
						}

						var sPath = "";
						aDepot = jQuery.extend(true, [], depot);
						bDepot = depot;
						// cDepot = jQuery.extend(true, [], depot);
						// cZone = jQuery.extend(true, [], zone);
						that.depot = jQuery.extend(true, [], depot);
						var oModel1 = new JSONModel();
						oModel1.setData(bDepot);
						oSchemeDetailView.setModel(oModel1, "DepotModel");

						that._oTable = gSchemeGeographiesBlock.byId("idZonesTable");
					}

					that.setDefaultSettings1();
					that._setAggregation(sPath);
					that.resetCrumbHistory();
				},
				error: function(error) {}
			});
		},
		
		formatGeographyZones: function(aData) {
			var aZones = [];
			var aRegions = [];
			var aAreas = [];
			for (var i = 0; i < aData.length; i++) {
				if (aData[i].GeographyTypeID === "0000000001") {
					aZones.push({
						"ID": aData[i].GeographyValueID,
						"Level": 1,
						"Name": aData[i].GeographyValueDesc,
						"CurrencyCode": "EUR",
						"HaveChild": true,
						"Path": "/" + i,
						"Position": i,
						"GeographyTypeID": aData[i].GeographyTypeID,
						"GeographyParentTypeID": aData[i].GeographyParentTypeID
					});
				} else if (aData[i].GeographyTypeID === "0000000002") {
					aRegions.push({
						"ID": aData[i].GeographyValueID,
						"Level": 2,
						"Name": aData[i].GeographyValueDesc,
						"CurrencyCode": "EUR",
						"CrumbName": "Regions",
						"HaveChild": true,
						"Path": "/0/results",
						"Position": "0",
						"ParentPath": "/0/results",
						"ParentID": aData[i].GeographyParentTypeValueID,
						"SuperParentID": "",
						"GeographyTypeID": aData[i].GeographyTypeID,
						"GeographyParentTypeID": aData[i].GeographyParentTypeID
					});
				} else if (aData[i].GeographyTypeID === "0000000003") {
					aAreas.push({
						"ID": aData[i].GeographyValueID,
						"Level": 3,
						"Name": aData[i].GeographyValueDesc,
						"CrumbName": "Areas",
						"HaveChild": true,
						"Path": "/0/results/0/results",
						"Position": "0",
						"ParentPath": "/0/results/0/results",
						"ParentID": aData[i].GeographyParentTypeValueID,
						"SuperParentID": "W&S",
						"GeographyTypeID": aData[i].GeographyTypeID,
						"GeographyParentTypeID": aData[i].GeographyParentTypeID
					});
				}

			}

			//maintain super parent id in areas array
			var zone = [];
			var region = [];
			var area = [];
			for (var j = 0; j < aZones.length; j++) {
				region = [];

				var level2 = 0;
				for (var k = 0; k < aRegions.length; k++) {
					area = [];
					if (aZones[j].ID === aRegions[k].ParentID) {
						if (level2 !== 0) {
							level2 = level2 + 1;
						}
						var level3 = 0;
						for (var l = 0; l < aAreas.length; l++) {
							if (aRegions[k].ID === aAreas[l].ParentID) {
								if (level3 !== 0) {
									level3 = level3 + 1;
								}
								area.push({
									"ID": aAreas[l].ID,
									"Level": 3,
									"Name": aAreas[l].Name,
									"CrumbName": "Areas",
									"HaveChild": true,
									"Path": "/" + j + "/results/" + level2 + "/results",
									"Position": level3,
									"ParentPath": "/" + j + "/results/" + level2 + "/results",
									"ParentID": aAreas[l].ParentID,
									"SuperParentID": aZones[j].ID,
									"GeographyTypeID": aAreas[l].GeographyTypeID,
									"GeographyParentTypeID": aAreas[l].GeographyParentTypeID
								});
							}
						}

						region.push({
							"ID": aRegions[k].ID,
							"Level": 2,
							"Name": aRegions[k].Name,
							"CurrencyCode": "EUR",
							"CrumbName": "Regions",
							"HaveChild": true,
							"Path": "/" + j + "/results",
							"Position": level2,
							"ParentPath": "/" + j + "/results",
							"ParentID": aRegions[k].ParentID,
							"SuperParentID": "",
							"GeographyTypeID": aRegions[k].GeographyTypeID,
							"GeographyParentTypeID": aRegions[k].GeographyParentTypeID,
							"results": area
						});
					}
				}

				zone.push({
					"ID": aZones[j].ID,
					"Level": 1,
					"Name": aZones[j].Name,
					"CurrencyCode": "EUR",
					"HaveChild": true,
					"Path": "/" + j,
					"Position": j,
					"GeographyTypeID": aZones[j].GeographyTypeID,
					"GeographyParentTypeID": aZones[j].GeographyParentTypeID,
					"results": region
				});
			}

			return zone;
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});