jQuery.sap.require("com.arteriatech.ss.schemes.view.block.LinkPartenerCP");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function(Controller) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oi18n, oUtilsI18n;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.SchemeCPsBlock", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			gSchemeCPsBlock = this.getView();
		},

		//Distributors
		addDistributors: function() {
			var that = this;
			this.Content = new com.arteriatech.ss.schemes.view.block.LinkPartenerCP({
				columnLayout: '4',
				formAdjustment: 'BlockColumns'
			});
			var dialog = new sap.m.Dialog({
				title: 'Add Distributors',
				type: 'Message',
				content: this.Content,
				contentWidth: '70%',
				beginButton: new sap.m.Button({
					text: 'Save',
					press: function() {
						that.addNewDistributors(dialog);
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			var oModel = this.getView().getModel("SSGW_MST");
			dialog.setModel(oModel, "SSGW_MST");
				var oSchemeSalesAreasModel = new sap.ui.model.json.JSONModel();
						oSchemeSalesAreasModel.setData({
							CPNoLbl: "Distributor"
						});
						dialog.setModel(oSchemeSalesAreasModel, "LinkPartnerLocalViewSettings");
			this.getDistributors(dialog, "01");
			if (sap.ui.Device.support.touch === false) {
				dialog.addStyleClass("sapUiSizeCompact");
			}
			if (this.LinkAlternateBillings_Exit) {
				this.LinkAlternateBillings_Exit();
			}
		},
		
		formatGeography: function(oMainData) {
			var ChidArray = [];

			for (var r = 0; r < oMainData.length; r++) {
            	ChidArray.push(oMainData[r]);
				if (oMainData[r].results) {
					if (oMainData[r].results.length > 0) {
						for (var k = 0; k < oMainData[r].results.length; k++) {
							ChidArray.push(oMainData[r].results[k]);
							if (oMainData[r].results[k].results.length > 0) {
								for (var l = 0; l < oMainData[r].results[k].results.length; l++) {
									ChidArray.push(oMainData[r].results[k].results[l]);
									// if (oMainData[r].results[k].results[l].results.length > 0) {
									// 	for (var j = 0; j < oMainData[r].results[k].results[l].results.length; j++) {
									// 		ChidArray.push(oMainData.results[k].results[l].results[j]);
									// 	}
									// }
								}
							}
						}
					}
				}

			}
			return ChidArray;
		},
		
		getDistributors: function(dialog) {
		    var zoneData = gTempSchemeGeographiesBlock.byId("fZoneIDEdit").getSelectedKeys();
			var RegionData = gTempSchemeGeographiesBlock.byId("fRegionIDEdit").getSelectedKeys();
			var AreaData = gTempSchemeGeographiesBlock.byId("fAreaIDEdit").getSelectedKeys();
			var HQData = gTempSchemeGeographiesBlock.byId("fHeadQuarterIDEdit").getSelectedKeys();
			var oView = gSchemeDetails;
			oView.setBusy(true);
			var aCPNoF4Filter = [];
			if (zoneData.length > 0) {
				for (var i = 0; i < zoneData.length; i++) {
                   	aCPNoF4Filter.push(new sap.ui.model.Filter("Geo1", sap.ui.model.FilterOperator.EQ, zoneData[i]));
				}
			}
			if (RegionData.length > 0) {
				for (var j = 0; j < RegionData.length; j++) {
                  	aCPNoF4Filter.push(new sap.ui.model.Filter("Geo2", sap.ui.model.FilterOperator.EQ, RegionData[j]));
				}
			}
			if (AreaData.length > 0) {
				for (var k = 0; k < AreaData.length; k++) {

					aCPNoF4Filter.push(new sap.ui.model.Filter("Geo3", sap.ui.model.FilterOperator.EQ, AreaData[k]));
				}
			}
			if (HQData.length > 0) {
				for (var n = 0; n < HQData.length; n++) {
					if(HQData[n] !== ""){
					aCPNoF4Filter.push(new sap.ui.model.Filter("Geo4", sap.ui.model.FilterOperator.EQ, HQData[n]));
					}
				}
			}
			
			aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "ParentID",
				sap.ui.model.FilterOperator.EQ, [this.getView().getModel("Schemes").getProperty("/ParentID")],
				false, false, false);
			aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
				sServiceName: "Customers",
				sRequestType: "read"
			})], false, false, false);

			var oModel = this.getView().getModel("SchemeSalesAreas");
			var oData = oModel.getProperty("/");
			if (oData.length > 0) {
				for (var i = 0; i < oData.length; i++) {}
			}

			var SFGW_MSTModel = oView.getModel("SFGW_MST");
			SFGW_MSTModel.read(
				"/Customers", {
					filters: aCPNoF4Filter,
					success: function(oData) {
						var aSelected = [];
						aSelected = oView.getModel("Distributors").getProperty("/");
						var oNewCPModel = new sap.ui.model.json.JSONModel();
						for (var i = 0; i < oData.results.length; i++) {
							oData.results[i].Selected = false;
							oData.results[i].CPNo = oData.results[i].CustomerNo;
							oData.results[i].CPGUID = oData.results[i].CustomerNo;
							oData.results[i].CPName = oData.results[i].Name;
							for (var g = 0; g < aSelected.length; g++) {
								if (oData.results[i].CustomerNo === aSelected[g].CPNo) {
									oData.results.splice(i, 1);
									i = i - 1;
									break;
								}
							}
						}
						oNewCPModel.setData(oData.results);
						dialog.setModel(oNewCPModel, "CPs");
						oView.setBusy(false);
						/*	var oSchemeSalesAreasModel = new sap.ui.model.json.JSONModel();
							oSchemeSalesAreasModel.setData({
								CPNoLbl: "Distributor"
							});
							dialog.setModel(oSchemeSalesAreasModel, "LinkPartnerLocalViewSettings");*/

						dialog.open();
					},
					error: function(error) {
						var oNewCPModel = new sap.ui.model.json.JSONModel();
						oNewCPModel.setData([]);
						dialog.setModel(oNewCPModel, "CPs");
						oView.setBusy(false);
						dialog.open();
					}
				});
			if (this.getCPs_Exit) {
				this.getCPs_Exit();
			}
		},
		
		addNewDistributors: function(dialog) {
			var duplicatedCPs = "";
			var oItemModel = this.getView().getModel("Distributors");
			var oItemModelData = oItemModel.getData();
			var aSelectedIndices = this.getSelectedIndices(dialog);//gLinkPartenerCP.byId("UICPTable").getSelectedIndices();
			for (var i = 0; i < aSelectedIndices.length; i++) {
				var isNew = true;
				for (var j = 0; j < oItemModelData.length; j++) {
					if (oItemModelData[j].CPNo === dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo")) {
						if (duplicatedCPs === "") {
							duplicatedCPs = dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name") + " (" + dialog.getModel("CPs").getProperty(
								"/" + aSelectedIndices[i] + "/CPNo") + ")";
						} else {
							duplicatedCPs = duplicatedCPs + ", " + dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name") + " (" + dialog.getModel(
								"CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo") + ")";
						}
						isNew = false;
					}
				}
				if (isNew) {
					var CPGUID = dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPGUID");
					if(CPGUID) {
						CPGUID = CPGUID.replace("-", "");
						CPGUID = CPGUID.replace("-", "");
						CPGUID = CPGUID.replace("-", "");
						CPGUID = CPGUID.replace("-", "");
					}
					var newItem = {
						"SchemeCPGUID": oPPCCommon.generateUUID(),
						"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
						"LoginID": "",
						"CPTypeID": "10",
						"CPTypeDesc": "Distributors",
						"CPGUID": CPGUID,
						"CPNo": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo"),
						"CPName": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name"),
						"IsExcluded": "",
						"EnrollmentDate": null,
						"RegistrationDate": null,
						"Remarks": "",
						"CreatedBy": "",
						"CreatedOn": null,
						"CreatedAt": "PT18H37M35S",
						"ChangedBy": "",
						"ChangedOn": null,
						"ChangedAt": "PT12H08M26S",
						"Source": "",
						"ExternalRefID": "",
						"ExternalRefKey": ""
					};
					//Pus new row to model
					oItemModelData.push(newItem);
				}
			}
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Update Table count
			var iTotalLength = this.getView().getModel("Distributors").getProperty("/").length;
			if(iTotalLength === 0) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeCp", false);
			}
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/DistributorsCount", iTotalLength);
			}
				gSchemeDetails.byId("SchemeCPsDeatils").focus();
			dialog.close();
			if (duplicatedCPs !== "") {
				sap.m.MessageToast.show("Duplicated!  Could't add Distributors: " + duplicatedCPs + "");
			}
			if (this.addNew_Exit) {
				this.addNew_Exit();
			}
		},
		
		getSelectedIndices: function(dialog) {
			var oData = dialog.getModel("CPs").getProperty("/");
			var aSelectedIndices = [];
			for(var i=0; i<oData.length; i++) {
				if(oData[i].Selected) {
					aSelectedIndices.push(i);
				}
			}	
			return aSelectedIndices;
		},

		deleteDistributorsItem: function(oEvent) {
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");

			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("Distributors").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
			//Remove Row from model
			var oItemModel = this.getView().getModel("Distributors");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			//Update Table count
			var iTotalLength = this.getView().getModel("Distributors").getProperty("/").length;
			if(iTotalLength === 0) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeCp", false);
			}
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/DistributorsCount", iTotalLength);
				
			}
			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			if (this.deleteDistributorsItem_Exit) {
				this.deleteDistributorsItem_Exit();
			}
		},
        
        
		//Retailers
		addRetailers: function() {
			var that = this;
			this.Content = new com.arteriatech.ss.schemes.view.block.LinkPartenerCP({
				columnLayout: '4',
				formAdjustment: 'BlockColumns'
			});
			var dialog = new sap.m.Dialog({
				title: 'Add Retailers',
				type: 'Message',
				content: this.Content,
				contentWidth: '70%',
				beginButton: new sap.m.Button({
					text: 'Save',
					press: function() {
						that.addNewRetailers(dialog);
					}
				}),
				endButton: new sap.m.Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});
			var oModel = this.getView().getModel("SSGW_MST");
			dialog.setModel(oModel, "SSGW_MST");
			
				dialog.setModel(gSchemeDetails.getModel("ChannelPartnerType"), "ChannelPartnerType");
				
				
					var oSchemeSalesAreasModel = new sap.ui.model.json.JSONModel();
						oSchemeSalesAreasModel.setData({
							CPNoLbl: "Retailer",
								CPTypeID: "20"
						});
						dialog.setModel(oSchemeSalesAreasModel, "LinkPartnerLocalViewSettings");
			this.getCPs(dialog, "20");
			if (sap.ui.Device.support.touch === false) {
				dialog.addStyleClass("sapUiSizeCompact");
			}
			if (this.LinkAlternateBillings_Exit) {
				this.LinkAlternateBillings_Exit();
			}
		},
		
		addNewRetailers: function(dialog) {
			var duplicatedCPs = "";
			var oItemModel = this.getView().getModel("Retailers");
			var oItemModelData = oItemModel.getData();
			var aSelectedIndices = this.getSelectedIndices(dialog); //gLinkPartenerCP.byId("UICPTable").getSelectedIndices();
			for (var i = 0; i < aSelectedIndices.length; i++) {
				var isNew = true;
				for (var j = 0; j < oItemModelData.length; j++) {
					if (oItemModelData[j].CPNo === dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo")) {
						if (duplicatedCPs === "") {
							duplicatedCPs = dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name") + " (" + dialog.getModel("CPs").getProperty(
								"/" + aSelectedIndices[i] + "/CPNo") + ")";
						} else {
							duplicatedCPs = duplicatedCPs + ", " + dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name") + " (" + dialog.getModel(
								"CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo") + ")";
						}
						isNew = false;
					}
				}
				if (isNew) {
					var CPGUID = dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPGUID");
					if(CPGUID) {
						CPGUID = CPGUID.replace("-", "");
						CPGUID = CPGUID.replace("-", "");
						CPGUID = CPGUID.replace("-", "");
						CPGUID = CPGUID.replace("-", "");
					}
						var linkPartnerMdlData = dialog.getModel("LinkPartnerLocalViewSettings").getData();
					var newItem = {
						"SchemeCPGUID": oPPCCommon.generateUUID(),
						"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
						"LoginID": "",
						"CPTypeID": linkPartnerMdlData.CPTypeID,
						"CPTypeDesc": "Retailers",
						"CPGUID": CPGUID,
						"CPNo": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/CPNo"),
						"CPName": dialog.getModel("CPs").getProperty("/" + aSelectedIndices[i] + "/Name"),
						"IsExcluded": "",
						"EnrollmentDate": null,
						"RegistrationDate": null,
						"Remarks": "",
						"CreatedBy": "",
						"CreatedOn": null,
						"CreatedAt": "PT18H37M35S",
						"ChangedBy": "",
						"ChangedOn": null,
						"ChangedAt": "PT12H08M26S",
						"Source": "",
						"ExternalRefID": "",
						"ExternalRefKey": ""
					};
					//Pus new row to model
					oItemModelData.push(newItem);
				}
			}
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			//Update Table count
			var iTotalLength = this.getView().getModel("Retailers").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/RetailersCount", iTotalLength);
			}
				gSchemeDetails.byId("SchemeCPsDeatils").focus();
			dialog.close();
			if (duplicatedCPs !== "") {
				sap.m.MessageToast.show("Duplicated!  Could't add Retailers: " + duplicatedCPs + "");
			}
			if (this.addNew_Exit) {
				this.addNew_Exit();
			}
		},

		deleteRetailersItem: function(oEvent) {
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");

			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("Retailers").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));
			//Remove Row from model
			var oItemModel = this.getView().getModel("Retailers");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			//Update Table count
			var iTotalLength = this.getView().getModel("Retailers").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/RetailersCount", iTotalLength);
			}
			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			if (this.deleteRetailersItem_Exit) {
				this.deleteRetailersItem_Exit();
			}
		},

		getCPs: function(dialog, sCPTypeID) {
			var oView = gSchemeDetails;
			oView.setBusy(true);
			var aCPNoF4Filter = [];
			var items = oView.getModel("Distributors").getData();
			var ParentNos = [];
			var parentType = [];

			if (items.length > 0) {
				for (var i = 0; i < items.length; i++) {
					ParentNos.push(items[i].CPGUID);
					parentType.push(items[i].CPTypeID);
					aCPNoF4Filter.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, ParentNos[i]));
					aCPNoF4Filter.push(new sap.ui.model.Filter("ParentTypeID", sap.ui.model.FilterOperator.EQ, parentType[i]));
				}
			} 
			aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
				sServiceName: "ChannelPartners",
				sRequestType: "read"
			})], false, false, false);
			aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "CPTypeID", "", [sCPTypeID], false, false, false);
			var SFGW_MSTModel = oView.getModel("SSGW_MST");
			SFGW_MSTModel.read(
				"/CPDMSDivisions", {
					filters: aCPNoF4Filter,
					success: function(oData) {
						var aSelected = [];
						if (sCPTypeID === "01") {
							aSelected = oView.getModel("Distributors").getProperty("/");
						} else if (sCPTypeID === "20") {
							aSelected = oView.getModel("Retailers").getProperty("/");
						}
						var oNewCPModel = new sap.ui.model.json.JSONModel();
						for (var i = 0; i < oData.results.length; i++) {
							oData.results[i].Selected = false;
							var bSelected = false;
							for (var g = 0; g < aSelected.length; g++) {
								if (oData.results[i].CPNo === aSelected[g].CPNo) {
									bSelected = true;
									oData.results.splice(i, 1);
									i = i - 1;
									break;
								}
							}
							if (!bSelected) {
								for (var j = i + 1; j < oData.results.length; j++) {
									if (oData.results[i].CPUID === oData.results[j].CPUID) {
										oData.results.splice(j, 1);
										j = j - 1;
									}
								}
							}
						}
						oNewCPModel.setData(oData.results);
						dialog.setModel(oNewCPModel, "CPs");
						oView.setBusy(false);

						/*	var oSchemeSalesAreasModel = new sap.ui.model.json.JSONModel();
							oSchemeSalesAreasModel.setData({
								CPNoLbl: "Retailer",
								CPTypeID: "20"
							});
							dialog.setModel(oSchemeSalesAreasModel, "LinkPartnerLocalViewSettings");*/
						dialog.open();
					},
					error: function(error) {
						var oNewCPModel = new sap.ui.model.json.JSONModel();
						oNewCPModel.setData([]);
						dialog.setModel(oNewCPModel, "CPs");
						oView.setBusy(false);
						dialog.open();
					}
				});
			if (this.getCPs_Exit) {
				this.getCPs_Exit();
			}
		},

		exportToExcelDistributors: function(oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("DistributorsTable"),
					uiTable: this.getView().byId("UIDistributorsTable")
				});
			}
			var table = this.getView().byId("DistributorsTable");
			var oModel = this.getView().getModel("Distributors");

			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeCP",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		},
		
		setDistributorsIsExcluded: function(oEvent) {
			var path = oEvent.getSource().getBindingInfo("state").binding.aBindings[0].getContext().getPath();
			if(oEvent.getSource().getState()) {
				this.getView().getModel("Distributors").setProperty(path+"/IsExcluded", "");
			}else {
				this.getView().getModel("Distributors").setProperty(path+"/IsExcluded", "X");
			}
		},
		
		setRetailersIsExcluded: function(oEvent) {
			var path = oEvent.getSource().getBindingInfo("state").binding.aBindings[0].getContext().getPath();
			if(oEvent.getSource().getState()) {
				this.getView().getModel("Retailers").setProperty(path+"/IsExcluded", "");
			}else {
				this.getView().getModel("Retailers").setProperty(path+"/IsExcluded", "X");
			}
		},
		
		exportToExcelRetailers: function(oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("RetailersTable"),
					uiTable: this.getView().byId("UIRetailersTable")
				});
			}
			var table = this.getView().byId("RetailersTable");
			var oModel = this.getView().getModel("Retailers");

			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeCP",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});