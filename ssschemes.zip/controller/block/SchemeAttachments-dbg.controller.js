sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	var oi18n, oUtilsI18n;
		var oProductCommon, oCommonValueHelp;
		var oi18n = "",
		oUtilsI18n = "";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
    var vIndex = 0;
	var busyDialog = new sap.m.BusyDialog();
	var ContractUploadFileList = [];
	var aDialog;
	var aFlag;
	var oUtilsI18n;
	var DocumentStore;
	var oDialog = new sap.m.BusyDialog();
	var indexOfPattern;
	var vMaximumFileSize;
	var SchemeGUID;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.SchemeAttachments", {

	onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			this._oView = this.getView();
			gSchemeAttachments = this.getView();
				this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
            
			oProductCommon = com.arteriatech.ss.utils.js.Common;;
			oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
			
			//i18n
		
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.create.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.create.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.create.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}
		
		
			getCurrentUsers: function(sServiceName, sRequestType) {
			var sLoginID = oProductCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
			getDocumentStore: function () {
			var that = this;
			var view = this.getView();
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();

			oStatusFilter = oPPCCommon.setODataModelReadFilter(view, "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator
				.EQ, ["PC"], false, false, false);
			oStatusFilter = oPPCCommon.setODataModelReadFilter(view, "", oStatusFilter, "Types", sap.ui.model.FilterOperator
				.EQ, ["DMSSTORE"], false, false, false);

			oPPCCommon.getDropdown(oModelData, "ConfigTypsetTypeValues", oStatusFilter, "TypeValue", "Types", busyDialog, this.getView(),
				"DocumentStore", "",
				function (aDDValue) {
					// that.getView().getModel("LocalViewSettingDt2").setProperty("/DocumentStore", aDDValue[0].Key);
					DocumentStore = aDDValue[0].Key;
					
				});
		},
			selectDocumentType: function(oEvent) {
			// alert("Hai");
			var that = this;
			that.getDocumentStore();
			var oPanel = new sap.m.Panel();
			var DocTypeLabel = new sap.m.Label({
				text: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.DoumentType"),
				required: true
			});
			//DocTypeLabel.addStyleClass("sapUiMediumMarginBegin");
			DocTypeLabel.addStyleClass("sapUiTinyMarginEnd");
			DocTypeLabel.addStyleClass("sapUiTinyMarginTop");
			//var FileChooserLabel=new sap.m.Label({id:"label" , text:"Select File:"});
			var DocTypeHBox = new sap.m.HBox();
			DocTypeHBox.addStyleClass("sapUiTinyMarginTop");
			//var FileChooser=new sap.m.HBox();
			var VBox = new sap.m.VBox();
			var Text = new sap.m.Text({
				text: ""
			});
			var oDocTypeItemTemplate = new sap.ui.core.Item({
				key: "{Key}",
				text: "{Key}{Seperator}{Text}{Mandatory}",
				tooltip: "{Key}{Seperator}{Text}"
			});
			this.DocType = new sap.m.Select({
				items: {
					path: "/",
					template: oDocTypeItemTemplate
				}
			});
			// this.DocType.setModel(this.getView().getModel("DocTypeDD"));
			// this.DocType.addStyleClass("sapUiTinyMarginBegin");
			var UploadCollection = new sap.m.UploadCollection({
				width: "100%",
				maximumFilenameLength: 55,
				maximumFileSize: 10,
				multiple: false,
				sameFilenameAllowed: false,
				instantUpload: false,
				showSeparators: "All",
				noDataText: oUtilsI18n.getText("common.NoAttachments"),
				change: function(oEvent) {
					that.onChange(oEvent);
				},
				fileDeleted: function(oEvent) {
					that.onFileDeleted(oEvent);
				},
				filenameLengthExceed: function(oEvent) {
					that.onFilenameLengthExceed(oEvent);
				},
				fileSizeExceed: function(oEvent) {
					that.onFileSizeExceed(oEvent);
				},
				typeMissmatch: function(oEvent) {
					that.onTypeMissmatch(oEvent);
				},
				beforeUploadStarts: function(oEvent) {
					that.onBeforeUploadStarts(oEvent);
				},
				uploadComplete: function(oEvent) {
					that.onUploadComplete(oEvent);
				},
				uploadUrl: "/sap/opu/odata/ARTEC/SCGW/SchemeDocuments"
			});
			DocTypeHBox.addItem(DocTypeLabel);
			DocTypeHBox.addItem(this.DocType);
			// if (DocumentStore === "A") {
			// 	VBox.addItem(DocTypeHBox);
			// 	VBox.addItem(Text);
			// }
			VBox.addItem(UploadCollection);
			VBox.addStyleClass("sapUiTinyMargin");
			oPanel.addContent(VBox);
			this.dialog = new sap.m.Dialog({
				title: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.Title"),
				type: 'Standard',
				width: "50%",
				height: "50%",
				resizable: true,
				contentWidth: "50%",
				contentHeight: "50%",
				state: 'None',
				icon: 'sap-icon://attachment',
				draggable: true,
				content: oPanel,
				buttons: [new sap.m.Button({
						text: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.Title"),
						press: function() {
							oPPCCommon.removeAllMsgs();
							if (that.validateContractAttachments(UploadCollection)) {
								that.startUpload(UploadCollection);
								that.dialog.close();
							} else {
								var message = oPPCCommon.getMsgsFromMsgMgr();
								oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
							}
						}
					}),
					new sap.m.Button({
						text: oi18n.getText("ContractAttachments.Page.UploadCollection.Dialog.Button.Cancel"),
						press: function() {
							//that.getInvoiceContractDocumentss(that._oComponent);
							that.dialog.close();
						}
					})
				],
				afterClose: function() {
					//that.dialog.destroy();
				}
			});
			aDialog = that.dialog;
			that.dialog.open();
			if (sap.ui.Device.support.touch === false) {
				that.dialog.addStyleClass("sapUiSizeCompact");
			}
		},
		
		
			onChange: function(oEvent) {

			var token = this._oComponent.getModel("SCGW").getSecurityToken();
			var oUploadCollection = this.getView().byId('UploadCollectionView');
			var url = this._oComponent.getModel("SCGW").sServiceUrl + "/SchemeDocuments";
			var sLoginID = this.getCurrentUsers("SchemeDocuments", "write");
			var oHeaderLoginId = new sap.m.UploadCollectionParameter({
				name: "x-arteria-loginid",
				value: sLoginID
			});
			var oHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});
			var oHeaderMethod = new sap.m.UploadCollectionParameter({
				name: "type",
				value: "POST"
			});
			var sFileName = oEvent.getParameter("mParameters").files[0].name;

			var oHeaderSlug;

			// var DocTypeID = this.getView().getModel("DocTypeDD").getData()[0].Key;
			// DocumentStore ="A";
			SchemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
			oHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: "SchemeGUID:" + SchemeGUID + ",DocumentStore:" + DocumentStore +  ",FileName:" +
					sFileName +
					",LoginID:" + sLoginID
			});

			oUploadCollection.setUploadUrl(url);
			oUploadCollection.addHeaderParameter(oHeaderLoginId);
			oUploadCollection.addHeaderParameter(oHeaderSlug);
			oUploadCollection.addHeaderParameter(oHeaderToken);
			oUploadCollection.addHeaderParameter(oHeaderMethod);
		},
		onFileDeleted: function(oEvent) {
			gSchemeAttachments.setBusy(true);
			oPPCCommon.removeAllMsgs();
			var that = this;
			var URL;
			var DocumentDeleteModel = this._oComponent.getModel("SCGW");
			var sLoginID = this.getCurrentUsers("SchemeDocuments", "delete");
			// DocumentDeleteModel.setUseBatch(false);
			DocumentDeleteModel.setHeaders({
				"x-arteria-loginid": sLoginID
			});
			var token = this._oComponent.getModel("SCGW").getSecurityToken();
			DocumentDeleteModel.setHeaders({
				"x-csrf-token": token
			});
			SchemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
			var SchemeGuid = "guid'" + SchemeGUID + "'";
			URL = "SchemeDocuments(SchemeGUID=" + SchemeGuid + ",DocumentID='" + escape(oEvent.getParameters().documentId) +"',DocumentStore='" + DocumentStore + "')";
			DocumentDeleteModel.remove("/" + URL, {
				headers: {
					"x-arteria-loginid": sLoginID
				},
				success: function() {
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					var message = oPPCCommon.getMsgsFromMsgMgr();
					vIndex++;
					that.getContractDocumentss(that._oComponent, oi18n.getText(
						"ContractAttachments.message.deleted"));

				},
				error: function(error) {
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					var message = oPPCCommon.getMsgsFromMsgMgr();
					oPPCCommon.displayMsg_MsgBox(that.getView(), message, "error");
					oDialog.close();
				}
			});
		},
	        onFilenameLengthExceed: function(UploadCollection) {
			if (UploadCollection.mParameters.mParameters.fileName.length > 55) {
				var msg1 = oi18n.getText("File name Length Exceeded");
				oPPCCommon.displayMsg_MsgBox(this.getView(), msg1, "error");
			}
			if (this.onFilenameLengthExceed_Exit) {
				this.onFilenameLengthExceed_Exit();
			}
		},
		    onBeforeUploadStarts: function(oEvent) {
			var sLoginID = this.getCurrentUsers("SchemeDocuments", "write");
			var oHeaderLoginId = new sap.m.UploadCollectionParameter({
				name: "x-arteria-loginid",
				value: sLoginID
			});
			var oHeaderSlug;
			var token = this._oComponent.getModel("SCGW").getSecurityToken();

			var oHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});

			var DocTypeID = "ZARTEC_SCH";
			vIndex++;
			// var DocTypeDesc = this.DocType.getSelectedItem().getText().split(" - ")[1].trim();
			var sFileName = oEvent.mParameters.fileName;
			// ContractNo = this.getView().getModel("Contracts").getProperty("/ContractNo");
				SchemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
				SchemeGUID = SchemeGUID.split("-").join('');
			// var DocTypeID = this.getView().getModel("DocTypeDD").getData()[0].Key;
			 var DocumentID = oPPCCommon.generateUUID().toUpperCase();
			   DocumentID = DocumentID.split("-").join('');
			  oHeaderSlug = new sap.m.UploadCollectionParameter({
				name: "SLUG",
				value: "SchemeGUID:" + SchemeGUID + ",DocumentStore:" + DocumentStore + ",DocumentID:" + DocumentID + ",DocumentTypeID:" + DocTypeID + ",FileName:" +
					sFileName +
					",LoginID:" + sLoginID
			});
			oEvent.getParameters().addHeaderParameter(oHeaderToken);
			oEvent.getParameters().addHeaderParameter(oHeaderLoginId);
			oEvent.getParameters().addHeaderParameter(oHeaderSlug);

		},
			onUploadComplete: function(oEvent) {
			if (oEvent.getParameter("files")[0].status === 201) {
				this.getContractDocumentss(this._oComponent, oi18n.getText(
					"ContractAttachments.message.uploaded"));
				gSchemeAttachments.setBusy(false);
			} else {
				var message = "";
				var response = oEvent.getParameter("files")[0].responseRaw;
				message = oPPCCommon.parseoDataXMLErrorMessage(response);
				this.getContractDocumentss(this._oComponent, oi18n.getText(
					"ContractAttachments.message.notuploaded") + message);
				gSchemeAttachments.setBusy(false);
			}
		},
            getContractDocumentss: function(component, message) {
             var that = this;
          	var SchemeDetails = gSchemeDetails;
			var controllerthis = this;
			var mandatoryDocs = "";
			var DocumentTypeID = [];
			this.DynamicSideContent = gSchemeDetails.byId("ObjectPageLayout");
			var ContractDocumentsModel = component.getModel("SCGW");
			var LoginID = controllerthis.getCurrentUsers("SchemeDocuments", "read");
			ContractDocumentsModel.attachRequestSent(
				function() {});
			ContractDocumentsModel.attachRequestCompleted(function() {});
			ContractDocumentsModel.setHeaders({
				"x-arteria-loginid": LoginID
			});

			ContractDocumentsModel.read("/SchemeDocuments", {
				filters: controllerthis.prepareContractDocumentsODataFilter(component, LoginID),
				success: function(oData) {
					oPPCCommon.removeAllMsgs();
				    oPPCCommon.hideMessagePopover(that.DynamicSideContent);
					SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData().length);
					if (oData.results.length > 0) {
						var DocsModel = new sap.ui.model.json.JSONModel();
						for (var i = 0; i < oData.results.length; i++) {
							var sServiceURL = SchemeDetails.getModel("SCGW").sServiceUrl;
								var SchemeGuid = "guid'" + oData.results[i].SchemeGUID + "'";
							var sUrl = sServiceURL + "/SchemeDocuments(SchemeGUID=" + SchemeGuid + ",DocumentID='" +
								oData.results[i].DocumentID + "',DocumentStore='" + oData.results[i].DocumentStore +
								"')/$value";
							oData.results[i].DocumentUrl = oPPCCommon.getDocumentURL({
								sServiceUrl: sUrl

							});
						}
						DocsModel.setData(oData.results);
							SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AttachmentCount", oData.results.length);
						if (component.getModel("SchemeCPDocuments")) {
							component.getModel("SchemeCPDocuments").setProperty("/", {});
						}
						component.setModel(DocsModel, "SchemeCPDocuments");

					} else {
					if (component.getModel("SchemeCPDocuments")) {
							component.getModel("SchemeCPDocuments").setProperty("/", {});
							SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AttachmentCount", 0);

						}
					}
					vIndex--;
					if (vIndex === 0) {
						if (message) {
							setTimeout(function() {
								sap.m.MessageToast.show(message);
							}, 10);
						}
						gSchemeAttachments.setBusy(false);

						oDialog.close();
					}

				},
				error: function(error) {
					if (component.getModel("SchemeDocuments")) {
						component.getModel("SchemeDocuments").setProperty("/", {});
					}
					oPPCCommon.removeAllMsgs();
					if (message) {
						setTimeout(function() {
							sap.m.MessageToast.show(message);
						}, 10);
					}
					if (DocumentStore === "A") {
						controllerthis.setMessageStrip(mandatoryDocs, component);

					}
					gSchemeAttachments.setBusy(false);
					oDialog.close();
				}
			});
		},
		setMessageStrip: function(mandatoryDocs, component) {
			for (var k = 0; k < mandatoryDocs.length; k++) {
				if (mandatoryDocs[k].Count === 0) {
					if (mandatoryDocs === "") {
						mandatoryDocs = "'" + mandatoryDocs[k].Text + "'";
					} else {
						mandatoryDocs = mandatoryDocs + "," + "'" + mandatoryDocs[k].Text + "'";
					}
				}
			}

			if (mandatoryDocs === "") {
				component.getModel("LocalAttachmentModel").setProperty("/MessageStripVisible", false);
			} else {
				var i18nProperty = "ContractAttachmentsA.ContractDocuments.DocTypeAttachmentMandatoryError";
				var msg = oi18n.getText(i18nProperty, mandatoryDocs);
				component.getModel("LocalAttachmentModel").setProperty("/MessageStripVisible", true);
				component.getModel("LocalAttachmentModel").setProperty("/MessageStripMessage", msg);
			}
		},
			prepareContractDocumentsODataFilter: function(component, LoginID) {
			var	schemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
			// schemeGUID = "guid'" + schemeGUID + "'";
			var that = this;
			var oModelData = component.getModel("SCGW");
        
			var ContractDocumentsFilters = new Array();
			 ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "LoginID", "", [LoginID],
				false, false, false);
			ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "SchemeGUID", sap.ui.model
				.FilterOperator.EQ, [schemeGUID], true, false, false);

			ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui
				.model
				.FilterOperator.EQ, [DocumentStore], true, false, false);
			// ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui
			// 	.model
			// 	.FilterOperator.EQ, [DocumentStore], true, false, false);
			// ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui
			// 	.model
			// 	.FilterOperator.EQ, [DocumentStore], true, false, false);

			return ContractDocumentsFilters;
		},
		
			validateContractAttachments: function(UploadCollection) {
			var valid = true;
		 if (UploadCollection.getItems().length === 0) {
				var msg2 = oi18n.getText("ContractAttachmentsA.Page.Upload.AttachmentErrorMsg");
				var msgObj = oPPCCommon.addMsg_MsgMgr(msg2, "error", "FGroup_Attachment");
				valid = false;
			}
			return valid;
		},
		
			startUpload: function(UploadCollectionControl) {
			gSchemeAttachments.setBusy(true);
			var oUploadCollection = UploadCollectionControl;
			var oHeaderMethod = new sap.m.UploadCollectionParameter({
				name: "type",
				value: "POST"
			});
			oUploadCollection.addHeaderParameter(oHeaderMethod);
			var url = this._oComponent.getModel("SCGW").sServiceUrl + "/SchemeDocuments";
			var token = this._oComponent.getModel("SCGW").getSecurityToken();

			var oHeaderToken = new sap.m.UploadCollectionParameter({
				name: "x-csrf-token",
				value: token
			});

			oUploadCollection.addHeaderParameter(oHeaderToken);
			oUploadCollection.addHeaderParameter(oHeaderMethod);
			oUploadCollection.setUploadUrl(url);
			oUploadCollection.upload();
		},
		

	});

});