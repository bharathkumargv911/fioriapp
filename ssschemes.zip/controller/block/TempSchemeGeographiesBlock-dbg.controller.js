sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/m/Text",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function(Controller, JSONModel, MessageToast, Text) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oi18n, oUtilsI18n;
	var sIndex = 0;
	var aZones = [];
	var aRegions = [];
	var aAreas = [];
	var aHeadQuarter = [];
	var aDepot = [];
	var aZone = [];
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.TempSchemeGeographiesBlock", {

		onInit: function() {
			this.onInitHookUp();
		},
		onInitHookUp: function() {
			gTempSchemeGeographiesBlock = this.getView();
			//i18n
			oi18n = goi18n;
			oUtilsI18n = goUtilsI18n;
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			this.updateSampleVariable();
		},
		setAreaDepot: function(oEvent) {
			sIndex = oEvent.getParameter("selectedIndex");
			if (oEvent.getParameter("selectedIndex") === 0) {
				this.getView().getModel('LocalViewSettingDtl').setProperty('/selectedDepot', false);
				this.getView().getModel('LocalViewSettingDtl').setProperty('/selectedArea', true);
				this.getView().getModel('LocalViewSettingDtl').setProperty('/AreaOrDepot', goi18n.getText("Geography.Area"));
				this.getView().byId("fDepotIDEdit").setSelectedKeys([]);

			} else if (oEvent.getParameter("selectedIndex") === 1) {
				this.getView().getModel('LocalViewSettingDtl').setProperty('/selectedDepot', true);
				this.getView().getModel('LocalViewSettingDtl').setProperty('/selectedArea', false);
				this.getView().getModel('LocalViewSettingDtl').setProperty('/AreaOrDepot', goi18n.getText("Geography.Depot"));
				this.getView().byId("fZoneIDEdit").setSelectedKeys([]);
				this.getView().byId("fRegionIDEdit").setSelectedKeys([]);
				this.getView().byId("fAreaIDEdit").setSelectedKeys([]);
				this.getView().byId("fHeadQuarterIDEdit").setSelectedKeys([]);
			}

		},
		getCurrentUsers: function(sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		updateSampleVariable: function() {
			var oView = this.getView();
			var that = this;

			var geoModel = this._oComponent.getModel("SCGW");
			var GeoFiltersArray = new Array();
			GeoFiltersArray = oPPCCommon.setODataModelReadFilter(this.getView(), "", GeoFiltersArray, "LoginID", "", [
				this.getCurrentUsers("Geographies", "read")
			], false, false, false);

			   geoModel.read("/Geographies", {
				  filters: GeoFiltersArray,
				  success: function(oData) {
                    var aData = oData.results;
					that.getZoneDropdown(aData);
					that.createModels();
					// that.setGeographymodel(aData);
					var oGeoGraphyModel = new sap.ui.model.json.JSONModel();
					oGeoGraphyModel.setData(aData);
					that._oComponent.setModel(oGeoGraphyModel, "GeoGraphy");

				}
			});
		},
		createModels: function() {
			var oRegionDDModel = new sap.ui.model.json.JSONModel();
			oRegionDDModel.setData([]);
			this._oComponent.setModel(oRegionDDModel, "RegionDD");
			var oAreaDDModel = new sap.ui.model.json.JSONModel();
			oAreaDDModel.setData([]);
			this._oComponent.setModel(oAreaDDModel, "AreaDD");
			var oHeadQuarterDDModel = new sap.ui.model.json.JSONModel();
			oHeadQuarterDDModel.setData([]);
			this._oComponent.setModel(oHeadQuarterDDModel, "HeadQuarterDD");

		},
		getZoneDropdown: function(aData) {
			aZones = [];
			aRegions = [];
			aAreas = [];
			aHeadQuarter = [];
			aDepot = [];
			for (var i = 0; i < aData.length; i++) {
				if (aData[i].GeographyTypeID === "0000000001") {
					aZones.push(aData[i]);
				}
				// if (aZones.length > 0) {
					if (aData[i].GeographyTypeID === "0000000002") {
						aRegions.push(aData[i]);
					}
					if (aData[i].GeographyTypeID === "0000000003") {
						aAreas.push(aData[i]);
					}
					if (aData[i].GeographyTypeID === "0000000004") {
						aHeadQuarter.push(aData[i]);
					}
					if (aData[i].GeographyTypeID === "0000000005") {
						aDepot.push(aData[i]);
					}
				}
			
			var oOwnDataModel = new sap.ui.model.json.JSONModel();
			oOwnDataModel.setData(aZones);
			this._oComponent.setModel(oOwnDataModel, "ZoneDD");
			if (aDepot.length > 0) {
				aDepot.unshift({
					"GeographyValueID": "",
					"GeographyValueDesc": "Select All"
				});
			}
			var oDepotDataModel = new sap.ui.model.json.JSONModel();
			oDepotDataModel.setData(aDepot);
			this._oComponent.setModel(oDepotDataModel, "DepotDD");
		},
		onSelectAll: function(oEvent) {
           //var SelectedKeys = this.getView().byId("fDepotIDEdit").getSelectedKeys();
			var changedItem = oEvent.getParameter("changedItem");
			var isSelected = oEvent.getParameter("selected");
			var state = "Selected";

			if (!isSelected) {
				state = "Deselected";
			}

			//Check if "Selected All is selected
			if ((changedItem.mProperties.text).trim() === "Select All") {
				var oName, res;

				//If it is Selected
				if (state == "Selected") {

					var oItems = oEvent.oSource.mAggregations.items;
					for (var i = 0; i < oItems.length; i++) {
						if (i == 0) {
							oName = oItems[i].mProperties.key;
						} else {
							oName = oName + ',' + oItems[i].mProperties.key;
						} //If i == 0									
					} //End of For Loop

					res = oName.split(",");
					oEvent.oSource.setSelectedKeys(res);

				} else {
					res = null;
					oEvent.oSource.setSelectedKeys(res);
				}
			}
			// gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeGeographiesCount", SelectedKeys);
		},
            
		onZoneChange: function(oEvent,array) {
			// var event = oEvent;
   //          this.onSelectAll(event);
			var that = this;
			var SelectedKeys = "";
			if(array){
			SelectedKeys = array;
			}
			else{
			SelectedKeys=gTempSchemeGeographiesBlock.byId("fZoneIDEdit").getSelectedKeys();
			}
			// if (this._oComponent.getModel("RegionDD")) {
			//     this._oComponent.getModel("RegionDD").setProperty("/", []);
			// }
			if (SelectedKeys.length > 0) {
				var RequiredRegion = [];
				for (var z = 0; z < SelectedKeys.length; z++) {
					for (var r = 0; r < aRegions.length; r++) {
						if (aRegions[r].GeographyParentTypeValueID === SelectedKeys[z]) {
							RequiredRegion.push(aRegions[r]);
						}

					}
				}
				gTempSchemeGeographiesBlock.getModel("RegionDD").setProperty("/", RequiredRegion);

			} else {
				if (gTempSchemeGeographiesBlock.getModel("RegionDD")) {
					gTempSchemeGeographiesBlock.getModel("RegionDD").setProperty("/", []);
				}
			}
			if(!array){
			this.onRegionChange();
			}
		},
		onRegionChange: function(oEvent,array) {
				// var event = oEvent;
    //          this.onSelectAll(event);
			var that = this;
			var SelectedKeys = "";
			if(array){
			SelectedKeys = array;
			}
			else{
		     SelectedKeys = gTempSchemeGeographiesBlock.byId("fRegionIDEdit").getSelectedKeys();
			}
			
			if (SelectedKeys.length > 0) {
				var RequiredArea = [];
				for (var z = 0; z < SelectedKeys.length; z++) {
					for (var r = 0; r < aAreas.length; r++) {
						if (aAreas[r].GeographyParentTypeValueID === SelectedKeys[z]) {
							RequiredArea.push(aAreas[r]);
						}

					}
				}
				gTempSchemeGeographiesBlock.getModel("AreaDD").setProperty("/", RequiredArea);

			} else {
				if (gTempSchemeGeographiesBlock.getModel("AreaDD")) {
					gTempSchemeGeographiesBlock.getModel("AreaDD").setProperty("/", []);
				}
			}
			if(!array){
			this.onAreaChange();
			}
		},
		onAreaChange: function(oEvent,array) {
			// var event = oEvent;
   //          this.onSelectAll(event);
			var that = this;
			var SelectedKeys = "";
			if(array){
			  SelectedKeys = array;
			}
			else{
		     SelectedKeys = gTempSchemeGeographiesBlock.byId("fAreaIDEdit").getSelectedKeys();
			}
			if (SelectedKeys.length > 0) {
				var RequiredHQ = [];
				for (var z = 0; z < SelectedKeys.length; z++) {
					for (var r = 0; r < aHeadQuarter.length; r++) {
						if (aHeadQuarter[r].GeographyParentTypeValueID === SelectedKeys[z]) {
							RequiredHQ.push(aHeadQuarter[r]);
						}

					}
				}
			if (RequiredHQ.length > 1) {
				RequiredHQ.unshift({
					"GeographyValueID": "",
					"GeographyValueDesc": "Select All"
				});
			}
				gTempSchemeGeographiesBlock.getModel("HeadQuarterDD").setProperty("/", RequiredHQ);

			} else {
				if (gTempSchemeGeographiesBlock.getModel("HeadQuarterDD")) {
					gTempSchemeGeographiesBlock.getModel("HeadQuarterDD").setProperty("/", []);
				}
			}
		},
		onDepotChange: function(oEvent) {
           //var SelectedKeys = this.getView().byId("fDepotIDEdit").getSelectedKeys();
           var event = oEvent;
           this.onSelectAll(event);
           
		},
		onHeadQuarterChange: function(oEvent) {
           //var SelectedKeys = this.getView().byId("fDepotIDEdit").getSelectedKeys();
           var event = oEvent;
           this.onSelectAll(event);
           
		}
	});

});