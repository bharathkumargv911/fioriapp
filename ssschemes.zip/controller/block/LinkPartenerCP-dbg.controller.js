sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function(Controller) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oi18n, oUtilsI18n;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.LinkPartenerCP", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			gLinkPartenerCP = this.getView();
		},

		onPartnerCPSelect: function(oEvent) {
			var aCPs = this.getView().getModel("CPs").getData();
			for (var i = 0; i < aCPs.length; i++) {
				if (oEvent.getSource().getSelected() === true) {
					aCPs[i].Selected = true;
				} else {
					aCPs[i].Selected = false;
				}
			}

			this.getView().getModel("CPs").setProperty("/", aCPs);
		},

		onLinkPartnerSearch: function() {

			var oView = gLinkPartenerCP;
			var linkPartnerMdlData = this.getView().getModel("LinkPartnerLocalViewSettings").getData();
			if (this.getView().getModel("LinkPartnerLocalViewSettings")) {

			}

			if (linkPartnerMdlData.CPNoLbl === "Distributor") {
				oView.setBusy(true);
				var aCPNoF4Filter = [];
				var zoneData = gTempSchemeGeographiesBlock.byId("fZoneIDEdit").getSelectedKeys();
				var RegionData = gTempSchemeGeographiesBlock.byId("fRegionIDEdit").getSelectedKeys();
				var AreaData = gTempSchemeGeographiesBlock.byId("fAreaIDEdit").getSelectedKeys();
				var HQData = gTempSchemeGeographiesBlock.byId("fHeadQuarterIDEdit").getSelectedKeys();

				if (zoneData.length > 0) {
					for (var i = 0; i < zoneData.length; i++) {
						aCPNoF4Filter.push(new sap.ui.model.Filter("Geo1", sap.ui.model.FilterOperator.EQ, zoneData[i]));
					}
				}
				if (RegionData.length > 0) {
					for (var j = 0; j < RegionData.length; j++) {
						aCPNoF4Filter.push(new sap.ui.model.Filter("Geo2", sap.ui.model.FilterOperator.EQ, RegionData[j]));
					}
				}
				if (AreaData.length > 0) {
					for (var k = 0; k < AreaData.length; k++) {

						aCPNoF4Filter.push(new sap.ui.model.Filter("Geo3", sap.ui.model.FilterOperator.EQ, AreaData[k]));
					}
				}
				if (HQData.length > 0) {
					for (var n = 0; n < HQData.length; n++) {
						if (HQData[n] !== "") {
							aCPNoF4Filter.push(new sap.ui.model.Filter("Geo4", sap.ui.model.FilterOperator.EQ, HQData[n]));
						}
					}
				}
				oView.setBusy(true);
				var aCPNoF4Filter = [];
				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "ParentID",
					sap.ui.model.FilterOperator.EQ, [gSchemeCPsBlock.getModel("Schemes").getProperty("/ParentID")],
					false, false, false);
				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
					sServiceName: "Customers",
					sRequestType: "read"
				})], false, false, false);

				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "CustomerNo",
					sap.ui.model.FilterOperator.EQ, [linkPartnerMdlData.FCPNo],
					false, false, false);

				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "Name",
					sap.ui.model.FilterOperator.EQ, [linkPartnerMdlData.FName],
					false, false, false);

				var SFGW_MSTModel = gSchemeDetails.getModel("SFGW_MST");
				SFGW_MSTModel.read(
					"/Customers", {
						filters: aCPNoF4Filter,
						success: function(oData) {
							var aSelected = [];
							aSelected = gSchemeDetails.getModel("Distributors").getProperty("/");
							for (var i = 0; i < oData.results.length; i++) {
								oData.results[i].Selected = false;
								oData.results[i].CPNo = oData.results[i].CustomerNo;
								oData.results[i].CPGUID = oData.results[i].CustomerNo;
								oData.results[i].CPName = oData.results[i].Name;
								for (var g = 0; g < aSelected.length; g++) {
									if (oData.results[i].CustomerNo === aSelected[g].CPNo) {
										oData.results.splice(i, 1);
										i = i - 1;
										break;
									}
								}
							}
							oView.getModel("CPs").setProperty("/", oData.results);
							oView.setBusy(false);

						},
						error: function(error) {
							oView.getModel("CPs").setProperty("/", []);
						}
					});
			} else {

				oView.setBusy(true);
				var aCPNoF4Filter = [];
				var items = gSchemeDetails.getModel("Distributors").getData();
				var ParentNos = [];
				if (items.length > 0) {
					for (var i = 0; i < items.length; i++) {
						ParentNos.push(items[i].CPGUID);
						aCPNoF4Filter.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, ParentNos[i]));
					}
				} 
				// aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "ParentID",
				// 	sap.ui.model.FilterOperator.EQ, [gSchemeCPsBlock.getModel("Schemes").getProperty("/ParentID")],
				// 	false, false, false);
				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
					sServiceName: "ChannelPartners",
					sRequestType: "read"
				})], false, false, false);
               if(linkPartnerMdlData.CPTypeID){
               	linkPartnerMdlData.CPTypeID=linkPartnerMdlData.CPTypeID;
               }else{
               	linkPartnerMdlData.CPTypeID ="02";
               }
				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter("", "", aCPNoF4Filter, "CPTypeID", "", [linkPartnerMdlData.CPTypeID], false,
					false, false);

				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "CPNo",
					sap.ui.model.FilterOperator.EQ, [linkPartnerMdlData.FCPNo],
					false, false, false);

				aCPNoF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aCPNoF4Filter, "Name",
					sap.ui.model.FilterOperator.EQ, [linkPartnerMdlData.FName],
					false, false, false);

				var SFGW_MSTModel = gSchemeDetails.getModel("SSGW_MST");
				SFGW_MSTModel.read(
					"/CPDMSDivisions", {
						filters: aCPNoF4Filter,
						success: function(oData) {
							var aSelected = [];
							aSelected = gSchemeDetails.getModel("Retailers").getProperty("/");
							for (var i = 0; i < oData.results.length; i++) {
								oData.results[i].Selected = false;
								var bSelected = false;
								for (var g = 0; g < aSelected.length; g++) {
									if (oData.results[i].CPNo === aSelected[g].CPNo) {
										bSelected = true;
										oData.results.splice(i, 1);
										i = i - 1;
										break;
									}
								}
								if (!bSelected) {
									for (var j = i + 1; j < oData.results.length; j++) {
										if (oData.results[i].CPUID === oData.results[j].CPUID) {
											oData.results.splice(j, 1);
											j = j - 1;
										}
									}
								}
							}
							oView.getModel("CPs").setProperty("/", oData.results);
							oView.setBusy(false);

						},
						error: function(error) {
							oView.getModel("CPs").setProperty("/", []);
						}
					});

			}

		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});