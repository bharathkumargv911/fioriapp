sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common",
	"com/arteriatech/prd/utils/js/CommonValueHelp"
], function (Controller) {
	"use strict";
	// var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oProductCommon = com.arteriatech.ss.utils.js.Common;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oi18n, oUtilsI18n;

	return Controller.extend("com.arteriatech.ss.schemes.controller.block.SchemeSlabsBlock", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function () {
			this.onInitHookUp();
		},

		onInitHookUp: function () {
			gSchemeSlabsBlock = this.getView();
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

		},

		// getItemNo: function(aItems) {
		// 	var sItemNo = "0001";
		// 	var iIncreament = 1;
		// 	if (aItems && aItems.length > 0) {
		// 		var lastItemNo = aItems[aItems.length - 1].SubItem;
		// 		if (lastItemNo && !isNaN(lastItemNo)) {
		// 			lastItemNo = parseInt(lastItemNo) + iIncreament;
		// 			if (lastItemNo < 10) {
		// 				sItemNo = "000" + lastItemNo;
		// 			} else if (lastItemNo < 100) {
		// 				sItemNo = "00" + lastItemNo;
		// 			} else if (lastItemNo < 1000) {
		// 				sItemNo = "0" + lastItemNo;
		// 			} else if (lastItemNo >= 1000) {
		// 				sItemNo = "" + lastItemNo;
		// 			}
		// 		}
		// 	}
		// 	return sItemNo;
		// },
		onChangeSlabOrdMat: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var SSInvoiceItem = this.getView().getModel("OrderMaterialGroupDD");
			var aItems = SSInvoiceItem.getProperty("/");
			var bKeyFound = false;
			var bTextFound = false;
			var enteredVal = oEvent.getParameter("value");
			var enteredValId = enteredVal.split("-")[0].trim();
			var enteredText = "";
			var oPath = oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1];
			var SubItem = oEvent.getSource().getBindingContext("SchemeSlabs").getModel().getData()[oPath].SubItem;
			for (var j = enteredVal.split("-").length - 1; j >= 1; j--) {
				enteredText = enteredVal.split("-")[j] + "-" + enteredText;
			}
			if (enteredText) {
				enteredText = enteredText.substring(0, enteredText.length - 1).trim();
			}
			for (var i = 0; i < aItems.length; i++) {
				if (enteredValId) {
					if (aItems[i].Key.trim() === enteredValId) {
						bKeyFound = true;
						if (aItems[i].Text.trim() === enteredText) {
							bTextFound = true;
							break;
						}

					}
				}
			}
			if (!bKeyFound || !bTextFound) {
				if (enteredVal) {
					var msg = "Please Enter Valid Order Material Group for Item No #" + SubItem;
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fOrderMaterialGroupIDEdit");
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					that.getView().getModel("SchemeSlabs").setProperty("/" + oPath + "/OrderMaterialGroupID", "");
					that.getView().getModel("SchemeSlabs").setProperty("/" + oPath + "/OrderMaterialGroupDesc", "");
					oEvent.getSource().setSelectedKey("");
				}
			} else {
				that.getView().getModel("SchemeSlabs").setProperty("/" + oPath + "/OrderMaterialGroupDesc", enteredText);
				that.getView().getModel("SchemeSlabs").setProperty("/" + oPath + "/OrderMaterialGroupID", enteredValId);
			}
		},
		setItemNo: function () {
			var countOfM = 10;
			var count = 0;
			var aItem = this.getView().getModel("SchemeSlabs").getProperty("/");
			for (var i = 0; i < aItem.length; i++) {
				if (i > 9) {
					countOfM = countOfM + 1;
					var itemNo = (countOfM) * 1;
					itemNo = ('00' + itemNo).slice(-6);
					aItem[i].SubItem = itemNo;
				} else {
					//if (aItem[i].ItemCategory !== "TANN") {
					var itemNo = (count + 1) * 1;
					itemNo = ('000' + itemNo).slice(-6);
					aItem[i].SubItem = itemNo;
					count = count + 1;
					//}
				}
			}
			this.getView().getModel("SchemeSlabs").setProperty("/", aItem);
		},

		// addNew: function(oEvent) {
		// 	// var EntityName =["SchemeSlab"];
		// 	// var PropertyName =["OperandType","SlabType", "SlabRule","DiscountOn","SlabCat","SaleUnit","ReimbursementMode"];
		// 	//   sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").callDropDown1(EntityName,PropertyName);
		// 	var oItemModel = this.getView().getModel("SchemeSlabs");
		// 	var oItemModelData = oItemModel.getData();
		// 	var itemNo = this.getItemNo(oItemModelData);
		// 	var newItem = {
		// 		"SlabGUID": oPPCCommon.generateUUID(),
		// 		"LoginID": "",
		// 		"SchemeItemGUID": "00000000-0000-0000-0000-000000000000",
		// 		"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
		// 		"MainItem": "00000",
		// 		"SubItem": itemNo,
		// 		"FromQty": 0,
		// 		"ToQty": 0,
		// 		"FromValue": 0,
		// 		"ToValue": 0,
		// 		"FromDate": null,
		// 		"ToDate": null,
		// 		"PayoutPerc": 0,
		// 		"PayoutAmount": 0,
		// 		"UOM": this.getView().getModel("Schemes").getProperty("/UOM"),
		// 		"Currency": this.getView().getModel("Schemes").getProperty("/CurrencyID"),
		// 		"BranchID": "",
		// 		"BranchDesc": "",
		// 		"MaterialNo": "",
		// 		"MaterialDesc": "",
		// 		"OperandTypeID": "",
		// 		"OperandTypeDesc": "",
		// 		"RatePerQty": 0,
		// 		"MaterialGroupID": "",
		// 		"MaterialGroupDesc": "",
		// 		"MaterialSeriesID": "",
		// 		"MaterialSeriesDesc": "",
		// 		"SlabRuleID": "",
		// 		"SlabRuleDesc": "",
		// 		"SlabTypeID": "",
		// 		"SlabTypeDesc": "",
		// 		"SaleUnitID": "",
		// 		"SaleUnitDesc": "",
		// 		"OrderMaterialGroupID": "",
		// 		"OrderMaterialGroupDesc": "",
		// 		"SKUGroupID": "",
		// 		"SKUGroupDesc": "",
		// 		"FreeQty": 0,
		// 		"FreeArticle": "",
		// 		"ReimbursementModeID": "",
		// 		"ReimbursementModeDesc": "",
		// 		"OtherAmount": 0,
		// 		"Sequence": 0,
		// 		"NoOfCards": 0,
		// 		"CardTitle": "",
		// 		"CreatedBy": "",
		// 		"CreatedOn": null,
		// 		"CreatedAt": "PT00H00M00S",
		// 		"ChangedBy": "",
		// 		"ChangedOn": null,
		// 		"ChangedAt": "PT00H00M00S",
		// 		"Source": "",
		// 		"ExternalRefID": "",
		// 		"ExternalRefKey": ""
		// 	};

		// 	//Pus new row to model
		// 	oItemModelData.push(newItem);
		// 	oItemModel.setData(oItemModelData);
		// 	oItemModel.refresh();
		// 	this.getView().byId("UISchemeSlabsTable_ADDBtnEdit").setType("Emphasized");

		// 	//Update Table count
		// 	var iTotalLength = this.getView().getModel("SchemeSlabs").getProperty("/").length;
		// 	if (this.getView().getModel("LocalViewSettingDtl")) {
		// 		this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSlabsCount", iTotalLength);
		// 	}
		// 	if (this.addNew_Exit) {
		// 		this.addNew_Exit();
		// 	}

		// },
		// addNew: function(oEvent) {
		// 	// var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
		// 	// var sPath = oBindingContext.getPath();
		// 	// var Index = parseInt(sPath.split("/")[1]);
		// 	oEvent.preventDefault();
		// 	gSchemeSlabsBlock.setBusy(true);
		// 	var EntityName = ["SchemeSlab"];
		// 	var PropertyName = ["OperandType", "SlabType", "SlabRule", "DiscountOn", "SlabCat", "SaleUnit", "ReimbursementMode", "Material"];
		// 	if (!gSchemeDetails.getModel("SlabTypeDD")) {
		// 		sap.ui.controller("com.arteriatech.ss.schemes.create.controller.CreatePage").callDropDown1(EntityName, PropertyName);
		// 	}
		// 	//var itemNo = this.getItemNo(oItemModelData);
		// 	gSchemeSlabsBlock.setBusy(false);

		// 	var newItem = {
		// 		"SlabGUID": oPPCCommon.generateUUID(),
		// 		"LoginID": "",
		// 		"SchemeItemGUID": "00000000-0000-0000-0000-000000000000",
		// 		"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
		// 		"MainItem": "00000",
		// 		"SubItem": "",
		// 		"FromQty": 0,
		// 		"ToQty": 0,
		// 		"FromValue": 0,
		// 		"ToValue": 0,
		// 		"FromDate": null,
		// 		"ToDate": null,
		// 		"PayoutPerc": 0,
		// 		"PayoutAmount": 0,
		// 		"UOM": this.getView().getModel("Schemes").getProperty("/UOM"),
		// 		"Currency": this.getView().getModel("Schemes").getProperty("/CurrencyID"),
		// 		"BranchID": "",
		// 		"BranchDesc": "",
		// 		"MaterialNo": "",
		// 		"MaterialDesc": "",
		// 		"OperandTypeID": "",
		// 		"OperandTypeDesc": "",
		// 		"RatePerQty": 0,
		// 		"MaterialGroupID": "",
		// 		"MaterialGroupDesc": "",
		// 		"MaterialSeriesID": "",
		// 		"MaterialSeriesDesc": "",
		// 		"SlabRuleID": "",
		// 		"SlabRuleDesc": "",
		// 		"SlabTypeID": "",
		// 		"SlabTypeDesc": "",
		// 		"SaleUnitID": "",
		// 		"SaleUnitDesc": "",
		// 		"OrderMaterialGroupID": "",
		// 		"OrderMaterialGroupDesc": "",
		// 		"SKUGroupID": "",
		// 		"SKUGroupDesc": "",
		// 		"FreeQty": 0,
		// 		"FreeArticle": "",
		// 		"ReimbursementModeID": "",
		// 		"ReimbursementModeDesc": "",
		// 		"OtherAmount": 0,
		// 		"Sequence": 0,
		// 		"NoOfCards": 0,
		// 		"CardTitle": "",
		// 		"CreatedBy": "",
		// 		"CreatedOn": null,
		// 		"CreatedAt": "PT00H00M00S",
		// 		"ChangedBy": "",
		// 		"ChangedOn": null,
		// 		"ChangedAt": "PT00H00M00S",
		// 		"Source": "",
		// 		"ExternalRefID": "",
		// 		"ExternalRefKey": ""
		// 	};

		// 	var oItemModel = this.getView().getModel("SchemeSlabs");
		// 	var oItemModelData = oItemModel.getData();
		// 	//var itemNo = this.getItemNo(oItemModelData);
		// 	//Pus new row to model
		// 	oItemModelData.push(newItem);
		// 	oItemModel.setData(oItemModelData);
		// 	oItemModel.setSizeLimit(oItemModelData.length);
		// 	//oItemModel.refresh();
		// 	this.setItemNo();

		// 	this.getView().byId("UISchemeSlabsTable_ADDBtnEdit").setType("Emphasized");
		// 	// this.removeMaterialTokenByIndex();
		// 	//Update Table count
		// 	var iTotalLength = this.getView().getModel("SchemeSlabs").getProperty("/").length;
		// 	if (this.getView().getModel("LocalViewSettingDtl")) {
		// 		this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSlabsCount", iTotalLength);
		// 	}
		// 	if (this.addNew_Exit) {
		// 		this.addNew_Exit();
		// 	}

		// },
		handleOrdMatSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: [
					"Key",
					"Text"
				],
				sBinding: "suggestionItems"
			});
		},
		addNew: function (oEvent) {
			oEvent.preventDefault();
			gSchemeSlabsBlock.setBusy(true);
			var EntityName = ["SchemeSlab"];
			var PropertyName = [
				"OperandType",
				"SlabType",
				"SlabRule",
				"DiscountOn",
				"SlabCat",
				"SaleUnit",
				"ReimbursementMode",
				"Material"
			];
			if (!gSchemeDetails.getModel("SlabTypeDD")) {
				sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").callDropDown1(EntityName, PropertyName);
			}
			gSchemeSlabsBlock.setBusy(false);
			var newItem = {
				"SlabGUID": oPPCCommon.generateUUID(),
				"LoginID": "",
				"SchemeItemGUID": "00000000-0000-0000-0000-000000000000",
				"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
				"MainItem": "00000",
				"SubItem": "",
				"FromQty": "",
				"ToQty": "",
				"FromValue": "",
				"ToValue": "",
				"FromDate": null,
				"ToDate": null,
				"PayoutPerc": 0,
				"PayoutAmount": 0,
				"ReimbursePerc": 0,
				"ReimburseAmount": 0,
				"UOM": this.getView().getModel("Schemes").getProperty("/UOM"),
				"Currency": this.getView().getModel("Schemes").getProperty("/CurrencyID"),
				"BranchID": "",
				"BranchDesc": "",
				"MaterialNo": "",
				"MaterialDesc": "",
				"OperandTypeID": "",
				"OperandTypeDesc": "",
				"RatePerQty": 0,
				"MaterialGroupID": "",
				"MaterialGroupDesc": "",
				"MaterialSeriesID": "",
				"MaterialSeriesDesc": "",
				"SlabRuleID": "",
				"SlabRuleDesc": "",
				"SlabTypeID": "",
				"SlabTypeDesc": "",
				"SaleUnitID": "",
				"SaleUnitDesc": "",
				"OrderMaterialGroupID": "",
				"OrderMaterialGroupDesc": "",
				"SKUGroupID": "",
				"SKUGroupDesc": "",
				"FreeQty": 0,
				"FreeArticle": "",
				"FreeArticleDesc": "",
				"ReimbursementModeID": "",
				"ReimbursementModeDesc": "",
				"FreeQtyUOM": "",
				"OtherAmount": 0,
				"Sequence": 0,
				"NoOfCards": 0,
				"CardTitle": "",
				"ScratchCardDesc": "",
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT00H00M00S",
				"ChangedBy": "",
				"ChangedOn": null,
				"ChangedAt": "PT00H00M00S",
				"Source": "",
				"ExternalRefID": "",
				"ExternalRefKey": "",
				"PointsPerUnit": "",
				"PayoutPerPoint": ""
			};
			var oItemModel = this.getView().getModel("SchemeSlabs");
			var oItemModelData = oItemModel.getData();
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.setSizeLimit(oItemModelData.length);
			this.setItemNo();
			this.getView().byId("UISchemeSlabsTable_ADDBtnEdit").setType("Emphasized");
			var iTotalLength = this.getView().getModel("SchemeSlabs").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSlabsCount", iTotalLength);
			}
			if (this.addNew_Exit) {
				this.addNew_Exit();
			}
		},
		onSlabRuleChange: function (oEvent) {
			var that = this;
			var text = oEvent.getSource().getSelectedItem().getText();
			var selectedtext = "";
			for (var j = text.split("-").length - 1; j >= 1; j--) {
				selectedtext = text.split("-")[j] + "-" + selectedtext;
			}
			if (selectedtext) {
				selectedtext = selectedtext.substring(0, selectedtext.length - 1).trim();
			}
			var selectedKey = oEvent.getSource().getSelectedKey();
			var oItemModel = this.getView().getModel("SchemeSlabs");
			var oItemModelData = oItemModel.getData();
			// if (selectedKey === "000007") {
			// if (!gSchemeDetails.getModel("SchemeFreeMatGrpMaterialsDD")) {
			// 	this.SchemeFreeMatGrpMaterialsDD();	
			// }
			// }
			// if (selectedKey === "000001") {
			// gSchemeSlabsBlock.setBusy(true);
			// var EntityName = ["SchemeSlab"];
			// var PropertyName = ["Material"];
			// if (!gSchemeDetails.getModel("MaterialDD")) {
			// 	sap.ui.controller("com.arteriatech.ss.schemes.create.controller.CreatePage").callDropDown1(EntityName, PropertyName);
			// }
			// gSchemeSlabsBlock.setBusy(false);
			// }
			for (var i = 0; i < oItemModelData.length; i++) {
				var rows1 = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows();
				var cells1 = rows1[i].getCells();
				oItemModelData[i].FreeQtyUOM = "";
				if (selectedKey !== "000001") {
					var MatId1 = "";
					for (var m = 0; m < cells1.length; m++) {
						if (cells1[m].getId().indexOf("inputMaterial") > 0) {
							MatId1 = gSchemeSlabsBlock.byId(cells1[m].getId());
						}
					}
					if (MatId1) {
						MatId1.removeAllTokens();
					}
					oItemModelData[i].FreeQty = 0;
					oItemModelData[i].MaterialNo = "";
					oItemModelData[i].MaterialDesc = "";
					oItemModelData[i].ReimbursementModeID = "";
					oItemModelData[i].ReimbursementModeDesc = "";

				}
				if (selectedKey !== "000002") {
					oItemModelData[i].FreeQty = 0;
					oItemModelData[i].OrderMaterialGroupID = "";
					oItemModelData[i].OrderMaterialGroupDesc = "";
				}
				if (selectedKey !== "000003") {
					oItemModelData[i].PayoutPerc = 0;
				}
				if (selectedKey !== "000004") {
					oItemModelData[i].PayoutAmount = 0;
				}
				if (selectedKey !== "000005") {
					oItemModelData[i].NoOfCards = 0;
					oItemModelData[i].CardTitle = "";
				}
				if (selectedKey !== "000006") {
					oItemModelData[i].FreeArticle = "";
					oItemModelData[i].FreeQty = 0;
				}
				if (selectedKey !== "000007") {
					var MatId2 = "";
					for (var n = 0; n < cells1.length; n++) {
						if (cells1[n].getId().indexOf("inputFreeMat") > 0) {
							MatId2 = gSchemeSlabsBlock.byId(cells1[n].getId());
						}
					}
					if (MatId2) {
						MatId2.removeAllTokens();
					}
					oItemModelData[i].SKUGroupID = "";
					oItemModelData[i].SKUGroupDesc = "";
					oItemModelData[i].FreeQty = 0;
				}
				that.getView().getModel("SchemeSlabs").setProperty("/" + i + "/SlabRuleDesc", selectedtext);
				that.getView().getModel("SchemeSlabs").setProperty("/" + i + "/SlabRuleID", selectedKey);
			}
		},
		onReimbursePercChange: function (oEvent) {
			oPPCCommon.hideMessagePopover();
			oPPCCommon.removeAllMsgs();
			var Path = oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1];
			var index = parseInt(Path);
			var SchemeSlabs = this.getView().getModel("SchemeSlabs");
			var oItemModel = SchemeSlabs.getProperty('/');
			var enteredVal = oEvent.getParameter("value");
			if (isNaN(enteredVal)) {
				var msg = "Please enter valid Reimburse Percentage";
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fReimbursePercEdit");
				oItemModel[index].ReimbursePerc = 0;
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
			} else if (oItemModel[index].PayoutPerc < oItemModel[index].ReimbursePerc) {
				// var msg = "Cost Objects total percentage of allocation should not be more than 100";
				var msg = "Reimburse Percentange shouldn't be  greater than Payout Percentange";
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fReimbursePercEdit");
				oItemModel[index].ReimbursePerc = 0;
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
			}
		},
		onReimburseAmountChange: function (oEvent) {
			oPPCCommon.hideMessagePopover();
			oPPCCommon.removeAllMsgs();
			var Path = oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1];
			var index = parseInt(Path);
			var SchemeSlabs = this.getView().getModel("SchemeSlabs");
			var oItemModel = SchemeSlabs.getProperty('/');
			var enteredVal = oEvent.getParameter("value");
			if (isNaN(enteredVal)) {
				var msg = "Please enter valid Reimburse Amount";
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fPayoutAmountEdit");
				oItemModel[index].ReimburseAmount = 0;
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
			} else if (oItemModel[index].PayoutAmount < oItemModel[index].ReimburseAmount) {
				// var msg = "Cost Objects total percentage of allocation should not be more than 100";
				var msg = "Reimburse Amount shouldn't be  greater than Payout Amount";
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fPayoutAmountEdit");
				oItemModel[index].ReimburseAmount = 0;
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
			}

		},
		onFromValueChange: function (oEvent) {
			oPPCCommon.hideMessagePopover();
			oPPCCommon.removeAllMsgs();
			var path = oEvent.getSource().getBindingContext("SchemeSlabs").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf("/") + 1));
			var oItemModel = this.getView().getModel("SchemeSlabs").getProperty("/");
			var FromValue = parseFloat(oItemModel[idx].FromValue);
			var isGreater = true;
			var isLesser = true;
			if (FromValue) {
				oItemModel[idx].FromValue = parseFloat(FromValue).toFixed(3);
			}
			var ItemNo = oItemModel[idx].SubItem;
			if ((FromValue !== "") && (idx === (oItemModel.length - 1)) && (!isNaN(parseFloat(FromValue)))) {
				this.getView().getModel("SchemeSlabs").getProperty("/idx/FromValueValueState", "None");
				this.getView().getModel("SchemeSlabs").getProperty("/idx/FromValueValueStateText", "");
				oItemModel[idx].ToValue = parseFloat(99999999.000).toFixed(3);

				if (idx !== 0) {
					if (oItemModel[idx].FromValue) {
						oItemModel[idx - 1].ToValue = parseFloat(parseFloat(oItemModel[idx].FromValue) - 0.001).toFixed(3);
					} else {
						oItemModel[idx - 1].ToValue = "";
					}

				}
			} else if ((FromValue !== "") && (isNaN(parseFloat(FromValue)))) {
				var msg = "Please Enter Valid Number in Sub Item No #" + ItemNo;
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromValueEdit");
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				oItemModel[idx].FromValue = "";
			} else {
				if (oItemModel.length > 0) {
					if (FromValue !== "" && (!isNaN(parseFloat(FromValue)))) {
						for (var j = 0; j < oItemModel.length; j++) {
							if (j !== 0) {
								if (oItemModel[j].FromValue) {
									oItemModel[j - 1].ToValue = parseFloat(parseFloat(oItemModel[j].FromValue) - 0.001).toFixed(3);
								} else {
									oItemModel[j - 1].ToValue = "";
								}
							}
							if (j === (oItemModel.length - 1)) {
								oItemModel[j].ToValue = parseFloat(99999999.000).toFixed(3);
							}
						}
					} else {
						var msg = "Please Enter Valid Number in Sub Item No #" + ItemNo;
						oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromValueEdit");
						oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
						oItemModel[idx].FromValue = "";
					}
				}

			}
			var x = 0;
			var y = 0;
			if (idx !== 0) {
				if ((FromValue !== "") && (!isNaN(parseFloat(FromValue)))) {

					for (var v = 0; v < oItemModel.length; v++) {
						if (idx === (oItemModel.length - 1)) {
							if (v !== idx) {
								if (!(FromValue > parseFloat(oItemModel[v].FromValue))) {
									isLesser = false;
									break;
								} else if ((FromValue === parseFloat(oItemModel[v].FromQty))) {
									isLesser = false;
									break;
								}
							}
						} else {
							if (v !== idx) {
								x = oItemModel[idx - 1].FromValue;
								y = oItemModel[idx + 1].FromValue;
								if (!(FromValue < parseFloat(y) && FromValue > parseFloat(x))) {
									isGreater = false;
									break;
								} else if ((FromValue === parseFloat(y) || FromValue === parseFloat(x))) {
									isLesser = false;
									break;

								}
							}
						}
					}
				}
			}
			if (!isLesser) {
				msg = "Invalid Entry in SubItem #" + ItemNo;
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromValueEdit");
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				oItemModel[idx].FromValue = "";
				oItemModel[idx].ToValue = "";
				oItemModel[idx - 1].ToValue = parseFloat(99999999.000).toFixed(3);
			}
			if (!isGreater) {
				msg = "Invalid Entry in SubItem #" + ItemNo;
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromValueEdit");
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				oItemModel[idx].FromQty = "";
			}

		},
		onFromQtyChange: function (oEvent) {
			oPPCCommon.hideMessagePopover();
			oPPCCommon.removeAllMsgs();
			var path = oEvent.getSource().getBindingContext("SchemeSlabs").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf("/") + 1));
			var oItemModel = this.getView().getModel("SchemeSlabs").getProperty("/");
			var FromQty = parseFloat(oItemModel[idx].FromQty);
			var isGreater = true;
			var isLesser = true;
			if (FromQty) {
				oItemModel[idx].FromQty = parseFloat(FromQty).toFixed(3);
			}
			var ItemNo = oItemModel[idx].SubItem;
			if ((FromQty !== "") && (idx === (oItemModel.length - 1)) && (!isNaN(parseFloat(FromQty)))) {
				this.getView().getModel("SchemeSlabs").getProperty("/idx/FromQtyValueState", "None");
				this.getView().getModel("SchemeSlabs").getProperty("/idx/FromQtyValueStateText", "");
				oItemModel[idx].ToQty = parseFloat(99999999.000).toFixed(3);
				if (idx !== 0) {
					if (oItemModel[idx - 1].FromQty) {
						oItemModel[idx - 1].ToQty = parseFloat(parseFloat(oItemModel[idx].FromQty) - 0.001).toFixed(3);
					} else {
						oItemModel[idx - 1].ToQty = "";
					}
				}
			} else if ((FromQty !== "") && (isNaN(parseFloat(FromQty)))) {
				var msg = "Please Enter Valid Number in Sub Item No #" + ItemNo;
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromQtyEdit");
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				oItemModel[idx].FromQty = "";
			} else {
				if (oItemModel.length > 0) {
					if (FromQty !== "" && (!isNaN(parseFloat(FromQty)))) {
						for (var j = 0; j < oItemModel.length; j++) {
							if (j !== 0) {
								if (oItemModel[j].FromQty) {
									oItemModel[j - 1].ToQty = parseFloat(parseFloat(oItemModel[j].FromQty) - 0.001).toFixed(3);
								} else {
									oItemModel[j - 1].ToQty = "";
								}
							}
							if (j === (oItemModel.length - 1)) {
								oItemModel[j].ToQty = parseFloat(99999999.000).toFixed(3);
							}
						}
					} else {
						var msg = "Please Enter Valid Number in Sub Item No #" + ItemNo;
						oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromQtyEdit");
						oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
						oItemModel[idx].FromQty = "";
					}
				}

			}
			var x = 0;
			var y = 0;
			if (idx !== 0) {
				if ((FromQty !== "") && (!isNaN(parseFloat(FromQty)))) {

					for (var v = 0; v < oItemModel.length; v++) {
						if (idx === (oItemModel.length - 1)) {
							if (v !== idx) {
								if (!(FromQty > parseFloat(oItemModel[v].FromQty))) {
									isLesser = false;
									break;
								} else if ((FromQty === parseFloat(oItemModel[v].FromQty))) {
									isLesser = false;
									break;
								}

							}
						} else {
							if (v !== idx) {
								x = oItemModel[idx - 1].FromQty;
								y = oItemModel[idx + 1].FromQty;
								if (!(FromQty < parseFloat(y) && FromQty > parseFloat(x))) {
									isGreater = false;
									break;
								}
							} else if ((FromQty === parseFloat(y) || FromQty === parseFloat(x))) {
								isLesser = false;
								break;

							}
						}
					}
				}
			}
			if (!isLesser) {
				msg = "Invalid Entry in SubItem #" + ItemNo;
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromQtyEdit");
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				oItemModel[idx].FromQty = "";
				oItemModel[idx].ToQty = "";
				oItemModel[idx - 1].ToQty = parseFloat(99999999.000).toFixed(3);
			}
			if (!isGreater) {
				msg = "Invalid Entry in SubItem #" + ItemNo;
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fFromQtyEdit");
				oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				oItemModel[idx].FromQty = "";
			}

		},

		MaterialF4: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();

			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			this.aMaterialKeys = ["ID", "Description"];

			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

			//to get the index of the table using table Id
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);

			oSSCommonValueHelp.setValueHelp({
				title: "Material",
				oController: this,
				controlID: "inputMaterial",
				idLabel: oi18n.getText("SchemeSlabsBlock.ValueHelp.Material"),
				descriptionLabel: oi18n.getText("SchemeSlabsBlock.ValueHelp.MaterialName"),
				oUtilsI18n: oUtilsI18n,
				modelID: "SCGW",
				entityType: "SchemeItemDetail",
				propName: "Material",
				tokenInput: this.MaterialTokenInput,
				aKeys: this.aMaterialKeys,
				// defaultLabel: "Ship To Party",
				// defaultText: oPPCCommon.getTextFromTokens(this.getView(), "FShipToParty"),
				defaultVisible: false,
				idVisible: true,
				groupTitle: "Material",
				fireOnLoad: false
					// partnerNo: this.getView().getModel("SOs").getProperty("/CustomerNo")
			}, function (oControlEvent) {
				var tokens = oControlEvent.getParameter("tokens")
				var jData = tokens[0].getCustomData()[0].getValue();
				var bValidMaterial = that.validateMaterial(jData, that.MaterialTokenInput, itemIndex);
				if (bValidMaterial) {
					// that.getView().byId("UISchemeItemsTableEdit").getRows()[itemIndex].getAggregation("cells")[1].setTokens(tokens);
					that.setSelectedMaterialToTable(jData, oBindingContext, aItems, itemIndex, true);
				} else {
					that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
				}
			});
			// }
		},

		SchemeMatGrpF4: function (oEvent) {
			var that = this;
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var ItemNo = oEvent.getSource().getBindingContext("SchemeSlabs").getModel().getData()[itemIndex].SubItem;
			//get selected item num

			this.oSchemeMatGrpTokenInput = oEvent.getSource();
			this.aSchemeMaterialGrpKeys = ["SchFreeMatGrpGUID", "MaterialGrp"];
			var sSchemePreviousEnteredValue;

			oSSCommonValueHelp.SchemeFreeMatGrpF4({
					oController: this,
					oi18n: oi18n,
					oUtilsI18n: oUtilsI18n,
					controlID: "inputFreeMat",
					bSchMatGrpGUIDKey: true,
					bMultiSelect: false
				},
				function (tokens) {
					var oToken = tokens;
					var jData = tokens[0].getCustomData()[0].getValue();
					// var bValidMaterial = that.validateFreeMat(jData, that.oSchemeMatGrpTokenInput, itemIndex);

					if (oToken.length > 0) {
						var Key = oToken[0].getProperty("key");
						Key = Key.split("-").join("");
						var Text = oToken[0].getProperty("text");
						var rows = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows();
						var groupId = "";
						var cells = rows[itemIndex].getCells();
						for (var m = 0; m < cells.length; m++) {
							if (cells[m].getId().indexOf("inputFreeMat") > 0) {
								groupId = gSchemeSlabsBlock.byId(cells[m].getId());
							}
						}

						if (groupId) {
							groupId.removeAllTokens();
							groupId.setValue("");
							if (groupId instanceof sap.m.MultiInput) {
								groupId.addToken(new sap.m.Token({
									key: Key,
									text: Text
								}));
								groupId.setTooltip(Text);

							}
							var SKUGroupID = Key.toUpperCase();
							// var SKUGroupCode = Text.split("").join();
							// var SKUGroupDesc = Key.split("-").join();
							that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/SKUGroupID", SKUGroupID);
							that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/SKUGroupCode", jData.MaterialGrp);
							that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/SKUGroupDesc", jData.MaterialGrpDesc);
						}
					}

				});

		},

		FreeArticleF4: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			that.FreeArticleTokenInput = oEvent.getSource();
			if (!this.FreeArticleTokenInput.getValue()) {
				this.FreeArticleTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.FreeArticleTokenInput.setValueStateText("");
			}
			this.aFreeArticleKeys = ["ID", "Description"];

			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var SSSchemeSlabs = this.getView().getModel("SchemeSlabs");
			var aItems = SSSchemeSlabs.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

			//to get the index of the table using table Id
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);

			this.setValueHelp({
				title: "FreeArticle",
				oController: this,
				controlID: "fFreeArticleEdit",
				idLabel: oi18n.getText("SchemeSlabsBlock.ValueHelp.FreeArticle"),
				descriptionLabel: oi18n.getText("SchemeSlabsBlock.ValueHelp.FreeArticleName"),
				oUtilsI18n: oUtilsI18n,
				modelID: "SCGW",
				entityType: "SchemeSlab",
				propName: "Freearticle",
				tokenInput: this.FreeArticleTokenInput,
				aKeys: this.aFreeArticleKeys,
				defaultVisible: false,
				idVisible: true,
				groupTitle: "FreeArticle",
				fireOnLoad: false
			}, function (oControlEvent) {
				var tokens = oControlEvent.getParameter("tokens");
				var jData = tokens[0].getCustomData()[0].getValue();
				if (tokens.length > 0) {
					var Key = tokens[0].getProperty("key");
					Key = Key.split("-").join("");
					var Text = tokens[0].getProperty("text");
					var rows = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows();
					var groupId = "";
					var cells = rows[itemIndex].getCells();
					for (var m = 0; m < cells.length; m++) {
						if (cells[m].getId().indexOf("fFreeArticleEdit") > 0) {
							groupId = gSchemeSlabsBlock.byId(cells[m].getId());
						}
					}
					if (groupId) {
						groupId.removeAllTokens();
						groupId.setValue("");
						if (groupId instanceof sap.m.MultiInput) {
							groupId.addToken(new sap.m.Token({
								key: Key,
								text: Text
							}));
							groupId.setTooltip(Text);

						}
						that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/FreeArticle", Key);
						that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/FreeArticleDesc", Text);
					}
				}
			});
			// }
		},

		setValueHelp: function (
			mParameters, requestCompleted) {
			var that = this;

			if (mParameters.bMultiSelect === undefined ||
				mParameters.bMultiSelect === null) {
				mParameters.bMultiSelect = false;
			}
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.title,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.aKeys[0],
				descriptionKey: mParameters.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					mParameters.tokenInput.setTokens(oControlEvent.getParameter("tokens"));
					mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
					mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
					if (requestCompleted) {
						requestCompleted(oControlEvent);
					}

					oValueHelpDialog.close();
				},
				cancel: function () {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			that.setValueHelpColumns(
				oValueHelpDialog, mParameters);
			that.setValueHelpFilterBar(
				oValueHelpDialog, mParameters);

			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}

			oValueHelpDialog.open();
			if (mParameters.oController.tokenInput) {
				oValueHelpDialog.setTokens(mParameters.oController.tokenInput.getTokens());
			}
			if (mParameters.fireOnLoad && sap.ui.getCore().byId(mParameters.controlID)) {
				sap.ui.getCore().byId(mParameters.controlID).fireSearch();
			}
		},
		/* Common Value Help Cloumns */
		setValueHelpColumns: function (
			oValueHelpDialog, mParameters) {

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
						label: mParameters.idLabel,
						template: "ID"
					}, {
						label: mParameters.descriptionLabel,
						template: "Description"
					}]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

			} else {

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: mParameters.idLabel
					}),
					template: new sap.m.Text({
						text: "{ID}"
					}),
					sortProperty: "ID",
					filterProperty: "ID"
				}));

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new com.arteriatech.ppc.utils.control.TableHeaderText({
						text: mParameters.descriptionLabel
					}),
					template: new sap.m.Text({
						text: "{Description}"
					}),
					sortProperty: "Description",
					filterProperty: "Description"
				}));

				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}

		},
		/* Common Value Help Filter */
		setValueHelpFilterBar: function (
			oValueHelpDialog, mParameters) {
			var that = this;
			var busyDialog = new sap.m.BusyDialog();
			var oTokenInputValue = "";
			if (mParameters.oController.tokenInput) {
				oTokenInputValue = mParameters.oController.tokenInput.getValue();
			}
			var code = new sap.m.Input({

			});
			var desc = new sap.m.Input({

			});
			oValueHelpDialog
				.setFilterBar(new sap.ui.comp.filterbar.FilterBar({

					advancedMode: true,
					filterGroupItems: [
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: mParameters.groupTitle,
							groupName: "gn1",
							name: "n1",
							label: mParameters.idLabel,
							control: code,
							visible: mParameters.idVisible
						}),
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: "",
							groupName: "gn1",
							name: "n2",
							label: mParameters.descriptionLabel,
							control: desc,
							visible: mParameters.descriptionVisible
						}),
						new sap.ui.comp.filterbar.FilterGroupItem({
							groupTitle: ".",
							groupName: "gn2",
							name: "n3",
							label: mParameters.defaultLabel,
							control: new sap.m.Text({
								text: mParameters.defaultText
							}),
							visible: mParameters.defaultVisible
						})
					],

					//--clear setvaluehelp---------

					clear: function () {
						code.setValue("");
						desc.setValue("");
					},

					search: function () {
						var parentIDs = "";
						if (mParameters.propName === "ScratchCard") {
							parentIDs = that.getView().getModel("ScratchCardTS").getProperty("/");
						} else {
							parentIDs = that.getView().getModel("FreearticleTS").getProperty("/");
						}
						var codeValue = code.getValue();
						var descValue = desc.getValue();
						var filterArray = new Array();
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								"",
								"",
								filterArray,
								"LoginID",
								"", [oSSCommon
									.getCurrentLoggedUser({
										sServiceName: "ValueHelps",
										sRequestType: "read"
									})
								], false, false,
								false);
						// filterArray = oPPCCommon
						// 	.setODataModelReadFilter(
						// 		mParameters.oController
						// 		.getView(), "",
						// 		filterArray, "ParentID",
						// 		sap.ui.model.FilterOperator.EQ, [mParameters.parentID], true,
						// 		false, false);

						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "ModelID",
								sap.ui.model.FilterOperator.EQ, [mParameters.modelID], true,
								false, false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "EntityType",
								sap.ui.model.FilterOperator.EQ, [mParameters.entityType],
								false, false, false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "PropName",
								sap.ui.model.FilterOperator.EQ, [mParameters.propName],
								false, false, false);

						if (parentIDs.length > 0) {
							for (var i = 0; i < parentIDs.length; i++) {
								filterArray.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentIDs[i].Key));
							}
						}
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "PartnerNo",
								sap.ui.model.FilterOperator.EQ, [mParameters.partnerNo],
								false, false, false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "ID", "", [codeValue], false, false,
								false);
						filterArray = oPPCCommon
							.setODataModelReadFilter(
								mParameters.oController
								.getView(), "",
								filterArray, "Description", "", [descValue], true, false,
								false);
						var PCGWModel = mParameters.oController._oComponent
							.getModel("PCGW");
						PCGWModel.attachRequestSent(function () {
							busyDialog.open();
						});
						PCGWModel.attachRequestCompleted(function () {
							busyDialog.close();
						});
						PCGWModel
							.read(
								"/ValueHelps", {
									filters: filterArray,
									success: function (oData) {
										var ValueHelpsModel = new sap.ui.model.json.JSONModel();
										if (oValueHelpDialog.getTable().bindRows) {
											oValueHelpDialog.getTable().clearSelection();
											ValueHelpsModel
												.setData(oData.results);
											oValueHelpDialog
												.getTable()
												.setModel(
													ValueHelpsModel);
											oValueHelpDialog
												.getTable()
												.bindRows("/");

											if (oData.results.length == 0) {
												oValueHelpDialog
													.getTable()
													.setNoData(
														mParameters.oUtilsI18n
														.getText("common.NoResultsFound"));

											}
										} else {

											//Setting Rows for sap.m.Table....................................
											var oRowsModel = new sap.ui.model.json.JSONModel();
											oRowsModel.setData(oData.results);
											oValueHelpDialog.getTable().setModel(oRowsModel);
											if (oValueHelpDialog.getTable().bindItems) {
												var oTable = oValueHelpDialog.getTable();
												oTable.bindAggregation("items", "/", function () {
													var aCols = oTable.getModel("columns").getData().cols;
													return new sap.m.ColumnListItem({
														cells: aCols.map(function (column) {
															var colname = column.template;
															return new sap.m.Text({
																text: "{" + colname + "}",
																wrapping: true
															});
														})
													});
												});
											}

											if (oData.results.length === 0) {
												oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
											}

										}
										if (oData.results.length > 0) {
											oValueHelpDialog.update();
										}
									},
									error: function (error) {
										oValueHelpDialog.getTable().clearSelection();
										if (oValueHelpDialog
											.getTable()
											.getModel() != undefined)
											oValueHelpDialog
											.getTable()
											.getModel()
											.setProperty(
												"/", {});
										oValueHelpDialog
											.getTable()
											.setNoData(
												mParameters.oUtilsI18n
												.getText("common.NoResultsFound"));
										com.arteriatech.ss.utils.js.CommonValueHelp
											.dialogErrorMessage(
												error,
												"No Data Found");
									}
								});
					}

				}));
		},

		onChangeFreeArticle: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var that = this;
			that.FreeArticleTokenInput = oEvent.getSource();
			if (!this.FreeArticleTokenInput.getValue()) {
				this.FreeArticleTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.FreeArticleTokenInput.setValueStateText("");
			}
			var SSSchemeSlabs = this.getView().getModel("SchemeSlabs");
			var aItems = SSSchemeSlabs.getProperty('/');
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "FreearticleVH",
					sKey: "Key",
					sDescription: "Text"
				},
				function (enteredVal, bFound, key, desc, jData) {
					if (enteredVal !== "") {
						if (bFound) {
							if (jData) {
								aItems[itemIndex].FreeArticle = jData.Key;
								aItems[itemIndex].FreeArticleDesc = jData.Text;
								that.getView().getModel("SchemeSlabs").setProperty("/", aItems);

							} else {
								that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData()
									.length);
								oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
							}
						}

					}
				}
			);
		},

		handleFreeArticleSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["Key", "Text"],
				sBinding: "suggestionItems"
			});
		},

		suggestionFreeArticleItemSelected: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var that = this;
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "FreearticleVH",
					sKey: "Key",
					sDescription: "Text"
				},
				function (key, desc, jData) {
					if (jData) {
						aItems[itemIndex].FreeArticle = jData.Key;
						aItems[itemIndex].FreeArticleDesc = jData.Text;
					}
				}
			);
		},

		handleFreeArticleTokenRemove: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			if (oEvent.getSource().getBindingContext("SchemeSlabs")) {
				index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
				var itemIndex = parseInt(index);
				var that = this;
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				oEvent.getSource().setValueStateText("");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/FreeArticle");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/FreeArticle-" + itemIndex);
				oPPCCommon.hideMessagePopover();
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);

				var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
				var aItems = SSInvoiceItem.getProperty('/');
				var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

				var type = oEvent.getParameter("type");
				if (type === "removed") {
					aItems[itemIndex].FreeArticle = "";
					aItems[itemIndex].FreeArticleDesc = "";

					that.getView().getModel("SchemeSlabs").setProperty("/", aItems);

					var SSInvoiceItem = gSchemeItemsBlock.getModel("SchemeSlabs");
					var aItems = SSInvoiceItem.getProperty("/");
					for (var i = 0; i < aItems.length; i++) {
						if (itemIndex !== i) {
							var MatId = gSchemeItemsBlock.byId(gSchemeItemsBlock.getId() + "--fFreeArticleEdit-" + gSchemeItemsBlock.getId() +
								"--UISchemeSlabsTableEdit-" + i);
							MatId.setValue("");
							MatId.setValueState(sap.ui.core.ValueState.None);
							MatId.setValueStateText("");
						}
					}
					oPPCCommon.removeMsgsInMsgMgrById("/UI/FreeArticle");
					oPPCCommon.hideMessagePopover();
					this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);

				}
			}
		},

		// getScratchCardVH: function(sloginid) {
		// 	var that = this;
		// 	var oModelData = gSchemeSlabsBlock.getModel("PCGW");
		// 	var oStatusFilter = new Array();
		// 	var busyDialog = new sap.m.BusyDialog();
		// 	var model = "SCGW";
		// 	var parentIDs = gSchemeSlabsBlock.getModel("ScratchCardTS").getProperty("/");
		// 	var sloginid = sloginid
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
		// 		model
		// 	], true, false, false);
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
		// 		"SchemeSlab"
		// 	], false, false, false);
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
		// 		"ScratchCard"
		// 	], false, false, false);
		// 	if (parentIDs.length > 0) {
		// 		for (var i = 0; i < parentIDs.length; i++) {
		// 			oStatusFilter.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentIDs[i].Key));
		// 		}
		// 	}
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "LoginID", sap.ui.model.FilterOperator.EQ, [
		// 		sloginid
		// 	], false, false, false);
		// 	oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", new sap.m.BusyDialog(), gSchemeSlabsBlock,
		// 		"ScratchCardVH", "",
		// 		function(aDDValues) {
		// 			gSchemeDetails.setBusy(false);
		// 		}, false, "PD", false);
		// },

		ScratchCardF4: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			that.ScratchCardTokenInput = oEvent.getSource();
			if (!this.ScratchCardTokenInput.getValue()) {
				this.ScratchCardTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.ScratchCardTokenInput.setValueStateText("");
			}
			this.aScratchCardKeys = ["ID", "Description"];

			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var SSSchemeSlabs = this.getView().getModel("SchemeSlabs");
			var aItems = SSSchemeSlabs.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

			//to get the index of the table using table Id
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);

			this.setValueHelp({
				title: "ScratchCard",
				oController: this,
				controlID: "fCardTitleEdit",
				idLabel: oi18n.getText("SchemeSlabsBlock.ValueHelp.ScratchCard"),
				descriptionLabel: oi18n.getText("SchemeSlabsBlock.ValueHelp.ScratchCardName"),
				oUtilsI18n: oUtilsI18n,
				modelID: "SCGW",
				entityType: "SchemeSlab",
				propName: "ScratchCard",
				tokenInput: this.ScratchCardTokenInput,
				aKeys: this.aScratchCardKeys,
				defaultVisible: false,
				idVisible: true,
				groupTitle: "ScratchCard",
				fireOnLoad: false
			}, function (oControlEvent) {
				var tokens = oControlEvent.getParameter("tokens");
				var jData = tokens[0].getCustomData()[0].getValue();
				if (tokens.length > 0) {
					var Key = tokens[0].getProperty("key");
					Key = Key.split("-").join("");
					var Text = tokens[0].getProperty("text");
					var rows = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows();
					var groupId = "";
					var cells = rows[itemIndex].getCells();
					for (var m = 0; m < cells.length; m++) {
						if (cells[m].getId().indexOf("fCardTitleEdit") > 0) {
							groupId = gSchemeSlabsBlock.byId(cells[m].getId());
						}
					}
					if (groupId) {
						groupId.removeAllTokens();
						groupId.setValue("");
						if (groupId instanceof sap.m.MultiInput) {
							groupId.addToken(new sap.m.Token({
								key: Key,
								text: Text
							}));
							groupId.setTooltip(Text);

						}
						that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/CardTitle", Key);
						that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/ScratchCardDesc", Text);
					}
				}
			});
			// }
		},

		onChangeScratchCard: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var that = this;
			that.ScratchCardTokenInput = oEvent.getSource();
			if (!this.ScratchCardTokenInput.getValue()) {
				this.ScratchCardTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.ScratchCardTokenInput.setValueStateText("");
			}
			var SSSchemeSlabs = this.getView().getModel("SchemeSlabs");
			var aItems = SSSchemeSlabs.getProperty('/');
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "ScratchCardVH",
					sKey: "Key",
					sDescription: "Text"
				},
				function (enteredVal, bFound, key, desc, jData) {
					if (enteredVal !== "") {
						if (bFound) {
							if (jData) {
								aItems[itemIndex].CardTitle = jData.Key;
								aItems[itemIndex].ScratchCardDesc = jData.Text;
								that.getView().getModel("SchemeSlabs").setProperty("/", aItems);

							} else {
								that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData()
									.length);
								oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
							}
						}

					}
				}
			);
		},

		handleScratchCardSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["Key", "Text"],
				sBinding: "suggestionItems"
			});
		},

		suggestionScratchCardItemSelected: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var that = this;
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "ScratchCardVH",
					sKey: "Key",
					sDescription: "Text"
				},
				function (key, desc, jData) {
					if (jData) {
						aItems[itemIndex].CardTitle = jData.Key;
						aItems[itemIndex].ScratchCardDesc = jData.Text;
					}
				}
			);
		},

		handleScratchCardTokenRemove: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			if (oEvent.getSource().getBindingContext("SchemeSlabs")) {
				index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
				var itemIndex = parseInt(index);
				var that = this;
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				oEvent.getSource().setValueStateText("");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/CardTitle");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/CardTitle-" + itemIndex);
				oPPCCommon.hideMessagePopover();
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);

				var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
				var aItems = SSInvoiceItem.getProperty('/');
				var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

				var type = oEvent.getParameter("type");
				if (type === "removed") {
					aItems[itemIndex].CardTitle = "";
					aItems[itemIndex].ScratchCardDesc = "";

					that.getView().getModel("SchemeSlabs").setProperty("/", aItems);

					var SSInvoiceItem = gSchemeItemsBlock.getModel("SchemeSlabs");
					var aItems = SSInvoiceItem.getProperty("/");
					for (var i = 0; i < aItems.length; i++) {
						if (itemIndex !== i) {
							var MatId = gSchemeItemsBlock.byId(gSchemeItemsBlock.getId() + "--fCardTitleEdit-" + gSchemeItemsBlock.getId() +
								"--UISchemeSlabsTableEdit-" + i);
							MatId.setValue("");
							MatId.setValueState(sap.ui.core.ValueState.None);
							MatId.setValueStateText("");
						}
					}
					oPPCCommon.removeMsgsInMsgMgrById("/UI/CardTitle");
					oPPCCommon.hideMessagePopover();
					this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);

				}
			}
		},

		// getFreearticleVH: function(sloginid) {
		// 	var that = this;
		// 	var oModelData = gSchemeSlabsBlock.getModel("PCGW");
		// 	var oStatusFilter = new Array();
		// 	var model = "SCGW";
		// 	var parentIDs = gSchemeSlabsBlock.getModel("FreearticleTS").getProperty("/");
		// 	var loginid = sloginid;
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
		// 		model
		// 	], true, false, false);
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
		// 		"SchemeSlab"
		// 	], false, false, false);
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
		// 		"Freearticle"
		// 	], false, false, false);
		// 	if (parentIDs.length > 0) {
		// 		for (var i = 0; i < parentIDs.length; i++) {
		// 			oStatusFilter.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentIDs[i].Key));
		// 		}
		// 	}
		// 	oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeSlabsBlock, "", oStatusFilter, "LoginID", sap.ui.model.FilterOperator.EQ, [
		// 		loginid
		// 	], false, false, false);
		// 	oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", new sap.m.BusyDialog(), gSchemeSlabsBlock,
		// 		"FreearticleVH", "",
		// 		function(aDDValues) {}, false, "PD", false);
		// },

		handleMaterialSuggest: function (oEvent) {
			/*oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData()
				.length);*/
			// this.clearAllErrors();
			// this.validateHeader();
			// if (oPPCCommon.doErrMessageExist()) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["Key", "Text"],
				sBinding: "suggestionItems"
			});
			// } else {
			/*	this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData()
					.length);
				oPPCCommon.showMessagePopover(gObjectPageLayout);*/
			// }
		},

		suggestionItemSelected: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var that = this;
			that.MaterialTokenInput = oEvent.getSource();
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "MaterialDD",
					sKey: "Key",
					sDescription: "Text"
				},
				function (key, desc, jData) {
					if (jData) {
						var bValidMaterial = that.validateMaterial(jData, oEvent.getSource(), itemIndex);
						if (bValidMaterial) {
							that.setSelectedMaterialToTable(jData, oBindingContext, aItems, itemIndex);
						} else {
							that.MaterialTokenInput.removeAllTokens();
							that.MaterialTokenInput.setValue(jData.MaterialNo);
							that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
								.getData()
								.length);
							oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
						}
					}
				}
			);
		},

		onChangeMaterial: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var that = this;
			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "MaterialDD",
					sKey: "Key",
					sDescription: "Text"
				},
				function (enteredVal, bFound, key, desc, jData) {
					if (enteredVal !== "") {
						if (bFound) {
							if (jData) {
								var bValidMaterial = that.validateMaterial(jData, oEvent.getSource(), itemIndex);
								if (bValidMaterial) {
									that.setSelectedMaterialToTable(jData, oBindingContext, aItems, itemIndex);
								} else {
									that.MaterialTokenInput.removeAllTokens();
									that.MaterialTokenInput.setValue(jData.MaterialNo);
									that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
										.getData()
										.length);
									oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
								}
							}
						}
					}
				}
			);
		},

		suggestionMaterialItemSelected: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var that = this;
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "MaterialDD",
					sKey: "Key",
					sDescription: "Text"
				},
				function (key, desc, jData) {
					if (jData) {
						var bValidMaterial = that.validateMaterial(jData, oEvent.getSource(), itemIndex);
						if (bValidMaterial) {
							that.setSelectedMaterialToTable(jData, oBindingContext, aItems, itemIndex);
						} else {
							that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
								.getData()
								.length);
							oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
						}
					}
				}
			);
		},

		handleMaterialTokenRemove: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			if (oEvent.getSource().getBindingContext("SchemeSlabs")) {
				index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
				var itemIndex = parseInt(index);
				var that = this;
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				oEvent.getSource().setValueStateText("");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/MaterialNo");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/Material-" + itemIndex);
				oPPCCommon.hideMessagePopover();
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);

				var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
				var aItems = SSInvoiceItem.getProperty('/');
				var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

				var type = oEvent.getParameter("type");
				if (type === "removed") {
					aItems[itemIndex].MaterialNo = "";
					aItems[itemIndex].MaterialDesc = "";

					that.getView().getModel("SchemeSlabs").setProperty("/", aItems);

					var SSInvoiceItem = gSchemeItemsBlock.getModel("SchemeSlabs");
					var aItems = SSInvoiceItem.getProperty("/");
					for (var i = 0; i < aItems.length; i++) {
						if (itemIndex !== i) {
							var MatId = gSchemeItemsBlock.byId(gSchemeItemsBlock.getId() + "--inputMaterial-" + gSchemeItemsBlock.getId() +
								"--UISchemeSlabsTableEdit-" + i);
							MatId.setValue("");
							MatId.setValueState(sap.ui.core.ValueState.None);
							MatId.setValueStateText("");
						}
					}
					oPPCCommon.removeMsgsInMsgMgrById("/UI/MaterialNo");
					oPPCCommon.hideMessagePopover();
					this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);

				}
			}
		},

		setSelectedMaterialToTable: function (jData, oBindingContext, aItems, itemIndex, bFromF4) {
			// if(bFromF4){
			// aItems[itemIndex].MaterialNo = jData.ID;
			// aItems[itemIndex].MaterialDesc = jData.Description;
			// }else{
			// 	aItems[itemIndex].MaterialNo = jData.Key;
			// aItems[itemIndex].MaterialDesc = jData.Text;
			// }
			if (bFromF4) {
				var path = "";
				if (aItems[itemIndex].isBasket) {
					path = oBindingContext.getPath().split("/")[3];
					aItems[itemIndex].root[path].MaterialNo = jData.ID;
					aItems[itemIndex].root[path].MaterialDesc = jData.Description;
				} else {
					aItems[itemIndex].MaterialNo = jData.ID;
					aItems[itemIndex].MaterialDesc = jData.Description;
				}
			} else {
				if (aItems[itemIndex].isBasket) {
					path = oBindingContext.getPath().split("/")[3];
					aItems[itemIndex].root[path].MaterialNo = jData.Key;
					aItems[itemIndex].root[path].MaterialDesc = jData.Text;
				} else {
					aItems[itemIndex].MaterialNo = jData.Key;
					aItems[itemIndex].MaterialDesc = jData.Text;
				}
			}
			this.getView().getModel("SchemeSlabs").setProperty("/", aItems);

			// var cpStockGuid = jData.CPStockItemGUID;
			// var spStockGuid = jData.SPStockItemGUID;
			// that.getStockSerialNos(cpStockGuid, spStockGuid, oBindingContext, itemIndex);
			// this.setTabCount(this.getView().getModel("SSInvoiceItem").getProperty("/"), this);

			// var sItemNo = oBindingContext.getProperty("ItemNo");
			// this.removeSerialNosByMaterialChange(sItemNo);

		},

		validateMaterial: function (jData, oMaterial, itemIndex) {
			oMaterial.setValueState(sap.ui.core.ValueState.None);
			oMaterial.setValueStateText("");
			oPPCCommon.removeMsgsInMsgMgrById("/UI/MaterialNo");
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			var itemNo = "";
			var bValidMaterial = true;
			var MaterialNo = jData.MaterialNo;
			if (MaterialNo) {
				var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
				var aItems = SSInvoiceItem.getProperty("/");
				aItems[itemIndex].MaterialNo = jData.MaterialNo;
				for (var i = 0; i < aItems.length; i++) {
					if (itemIndex !== i) {
						if (aItems[i].MaterialNo === MaterialNo) {
							bValidMaterial = false;
							itemNo = aItems[i].SubItem;
							break;
						}
					}
				}
			}

			if (!bValidMaterial) {
				oMaterial.setValueState(sap.ui.core.ValueState.Error);
				var msg = oi18n.getText("SchemeItemsBlock.Message.MaterialRepeat", itemNo);
				oMaterial.setValueStateText(msg);
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/MaterialNo");
			}
			return bValidMaterial;
		},

		// validateFreeMat: function(jData, oMaterial, itemIndex, Key) {
		// 	var that = this;
		// 	oMaterial.setValueState(sap.ui.core.ValueState.None);
		// 	oMaterial.setValueStateText("");
		// 	oPPCCommon.removeMsgsInMsgMgrById("/UI/SKUGroupID");
		// 	oPPCCommon.hideMessagePopover();
		// 	this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
		// 		.getData()
		// 		.length);

		// 	var bValidMaterial = true;
		// 	var SKUGroupID = "";
		// 	if (Key) {
		// 		SKUGroupID = Key;
		// 	} else {
		// 		SKUGroupID = jData.MaterialGrp;
		// 	}
		// 	var itemNo = "";
		// 	if (SKUGroupID) {
		// 		var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
		// 		var aItems = SSInvoiceItem.getProperty("/");
		// 		aItems[itemIndex].SKUGroupCode = jData.MaterialGrp;
		// 		for (var i = 0; i < aItems.length; i++) {
		// 			if (itemIndex !== i) {
		// 				if (aItems[i].SKUGroupCode === SKUGroupID) {
		// 					bValidMaterial = false;
		// 					itemNo = aItems[i].SubItem;
		// 					break;
		// 				}
		// 			}
		// 		}
		// 	}

		// 	// if (!bValidMaterial) {

		// 	// }
		// 	return bValidMaterial;
		// },

		deleteItem: function (oEvent) {
			var that = this;
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");
			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("SchemeSlabs").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf("/") + 1));
			this.removeMaterialTokenByIndex(idx);
			var oItemModel = this.getView().getModel("SchemeSlabs");
			var oItemModelData = oItemModel.getData();
			if (oItemModelData.length > 1 && idx === 0) {
				oItemModelData[idx + 1].SlabRuleID = oItemModelData[idx].SlabRuleID;
				oItemModelData[idx + 1].SlabRuleDesc = oItemModelData[idx].SlabRuleDesc.trim();
				oItemModelData[idx + 1].SlabTypeID = oItemModelData[idx].SlabTypeID;
				oItemModelData[idx + 1].SlabTypeDesc = oItemModelData[idx].SlabTypeDesc.trim();
				oItemModelData[idx + 1].SaleUnitID = oItemModelData[idx].SaleUnitID;
				oItemModelData[idx + 1].SaleUnitDesc = oItemModelData[idx].SaleUnitDesc.trim();
			}
			if (idx !== 0 && oItemModelData[idx - 1].FromQty && (parseFloat(oItemModelData[idx].ToQty) === 99999999)) {
				oItemModelData[idx - 1].ToQty = parseFloat(99999999.000).toFixed(3);
			}
			if (idx !== 0 && oItemModelData[idx - 1].FromValue && (parseFloat(oItemModelData[idx].ToValue) === 99999999)) {
				oItemModelData[idx - 1].ToValue = parseFloat(99999999.000).toFixed(3);
			}
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			setTimeout(function () {
				that.addTokensTotable();
			}, 500);
			var iTotalLength = this.getView().getModel("SchemeSlabs").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSlabsCount", iTotalLength);
			}
			that.setItemNo();
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			if (this.deleteItem_Exit) {
				this.deleteItem_Exit();
			}
		},

		setIsIncludingPrimary: function (oEvent) {
			if (oEvent.getSource().getState()) {
				this.getView().getModel("Schemes").setProperty("/IsIncludingPrimary", "X");
			} else {
				this.getView().getModel("Schemes").setProperty("/IsIncludingPrimary", "");
			}
		},

		exportToExcel: function (oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SchemeSlabsTable"),
					uiTable: this.getView().byId("UISchemeSlabsTable")
				});
			}
			var table = this.getView().byId("SchemeSlabsTable");
			var oModel = this.getView().getModel("SchemeSlabs");

			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeSlab",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		},

		removeMaterialTokenByIndex: function (idx) {

			if (sap.ui.Device.system.tablet || sap.ui.Device.system.phone) {
				var MatId = gSchemeSlabsBlock.byId(gSchemeSlabsBlock.getId() + "--inputFreeMat-" + gSchemeSlabsBlock.getId() +
					"--UISchemeSlabsTable_ADDBtnEdit-" + j);
				if (MatId) {
					if (MatId instanceof sap.m.MultiInput) {
						MatId.removeAllTokens();
					}
				}

			} else {
				var dataLength = gSchemeSlabsBlock.getModel("SchemeSlabs").getProperty("/").length;
				for (var i = 0; i < dataLength; i++) {
					var cells = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows()[i].getCells();
					var matCellId = "";
					var materialId = "";
					var FreearticleID = "";
					var ScratchCardID = "";
					for (var j = 0; j < cells.length; j++) {
						if (cells[j].getId().indexOf("inputFreeMat") !== -1) {
							matCellId = cells[j].getId();
						}
						if (cells[j].getId().indexOf("inputMaterial") !== -1) {
							materialId = cells[j].getId();
						}
						if (cells[j].getId().indexOf("fFreeArticleEdit") !== -1) {
							FreearticleID = cells[j].getId();
						}
						if (cells[j].getId().indexOf("fCardTitleEdit") !== -1) {
							ScratchCardID = cells[j].getId();
						}
					}
					if (matCellId) {
						gSchemeSlabsBlock.byId(matCellId).removeAllTokens();
					}
					if (materialId) {
						gSchemeSlabsBlock.byId(materialId).removeAllTokens();
					}
					if (FreearticleID) {
						gSchemeSlabsBlock.byId(FreearticleID).removeAllTokens();
					}
					if (ScratchCardID) {
						gSchemeSlabsBlock.byId(ScratchCardID).removeAllTokens();
					}

				}
			}
		},

		handleFreeMatSuggest: function (oEvent) {

			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: ["Key", "Text"],
				sBinding: "suggestionItems"
			});

		},

		// addTokensTotable: function() {
		// 	var dataLength = this.getView().getModel("SchemeSlabs").getProperty("/");
		// 	for (var i = 0; i < dataLength.length; i++) {
		// 		var cells = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows()[i].getCells();
		// 		var matCellId = "";
		// 		var materialCellId = "";
		// 		for (var j = 0; j < cells.length; j++) {
		// 			if (cells[j].getId().indexOf("inputFreeMat") !== -1) {
		// 				matCellId = cells[j].getId();
		// 			}
		// 			if (cells[j].getId().indexOf("inputMaterial") !== -1) {
		// 				materialCellId = cells[j].getId();
		// 			}

		// 		}
		// 		if (matCellId) {
		// 			var oToken = new sap.m.Token({
		// 				key: dataLength[i].SKUGroupID,
		// 				text: dataLength[i].SKUGroupDesc + "(" + dataLength[i].SKUGroupCode + ")"
		// 			});
		// 			gSchemeSlabsBlock.byId(matCellId).addToken(oToken);
		// 		}
		// 		if (materialCellId) {
		// 			var oTokenm = new sap.m.Token({
		// 				key: dataLength[i].MaterialNo,
		// 				text: dataLength[i].MaterialDesc
		// 			});
		// 			gSchemeSlabsBlock.byId(materialCellId).addToken(oTokenm);
		// 		}
		// 	}

		// },
		addTokensTotable: function () {
			var dataLength = this.getView().getModel("SchemeSlabs").getProperty("/");
			for (var i = 0; i < dataLength.length; i++) {
				var cells = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows()[i].getCells();
				var matCellId = "";
				var materialCellId = "";
				var FreeArticle = "";
				var ScratchCard = "";
				for (var j = 0; j < cells.length; j++) {
					if (cells[j].getId().indexOf("inputFreeMat") !== -1) {
						matCellId = cells[j].getId();
					}
					if (cells[j].getId().indexOf("inputMaterial") !== -1) {
						materialCellId = cells[j].getId();
					}
					if (cells[j].getId().indexOf("fFreeArticleEdit") !== -1) {
						FreeArticle = cells[j].getId();
					}
					if (cells[j].getId().indexOf("fCardTitleEdit") !== -1) {
						ScratchCard = cells[j].getId();
					}
				}
				if (matCellId && dataLength[i].SKUGroupID) {
					var oToken = new sap.m.Token({
						key: dataLength[i].SKUGroupID,
						text: dataLength[i].SKUGroupDesc + "(" + dataLength[i].SKUGroupCode + ")"
					});
					gSchemeSlabsBlock.byId(matCellId).addToken(oToken);
					gSchemeSlabsBlock.byId(matCellId).setTooltip(dataLength[i].SKUGroupDesc);
				}
				if (materialCellId && dataLength[i].MaterialNo) {
					var oTokenm = new sap.m.Token({
						key: dataLength[i].MaterialNo,
						text: dataLength[i].MaterialDesc + "(" + dataLength[i].MaterialDesc + ")"
					});
					gSchemeSlabsBlock.byId(materialCellId).addToken(oTokenm);
					gSchemeSlabsBlock.byId(materialCellId).setTooltip(dataLength[i].MaterialDesc)
				}
				if (FreeArticle && dataLength[i].FreeArticle) {
					var oTokenm = new sap.m.Token({
						key: dataLength[i].FreeArticle,
						text: dataLength[i].FreeArticleDesc + "(" + dataLength[i].FreeArticle + ")"
					});
					gSchemeSlabsBlock.byId(FreeArticle).addToken(oTokenm);
					gSchemeSlabsBlock.byId(FreeArticle).setTooltip(dataLength[i].FreeArticle)
				}
				if (ScratchCard && dataLength[i].CardTitle) {
					var oTokenz = new sap.m.Token({
						key: dataLength[i].CardTitle,
						text: dataLength[i].ScratchCardDesc + "(" + dataLength[i].CardTitle + ")"
					});
					gSchemeSlabsBlock.byId(CardTitle).addToken(oTokenz);
					gSchemeSlabsBlock.byId(CardTitle).setTooltip(dataLength[i].ScratchCardDesc)
				}
			}
		},

		onChangeFreeMat: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var path = "";
			var that = this;
			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionOnChange({
					oEvent: oEvent,
					thisController: this,
					sModelName: "SchemeFreeMatGrpMaterialsDD",
					sKey: "Key",
					sDescription: "Text"
				},
				function (enteredVal, bFound, key, desc, jData) {
					if (enteredVal !== "") {
						if (bFound) {
							if (jData) {
								// var bValidMaterial = that.validateFreeMat(jData, oEvent.getSource(), itemIndex);
								// if (bValidMaterial) {
								path = sPath.split("/")[3];
								aItems[itemIndex].SKUGroupCode = jData.MaterialGrp;
								aItems[itemIndex].SKUGroupDesc = jData.MaterialGrpDesc;
								that.getView().getModel("SchemeSlabs").setProperty("/", aItems);
								// } else {
								// 	that.MaterialTokenInput.removeAllTokens();
								// 	that.MaterialTokenInput.setValue(jData.MaterialGrp);
								// 	that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
								// 		.getData()
								// 		.length);
								// 	oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));

								// }
							}
						}
					}
				}
			);
		},

		suggestionFreeMatItemSelected: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
			var itemIndex = parseInt(index);
			var path = "";
			var that = this;
			var ItemNo = oEvent.getSource().getBindingContext("SchemeSlabs").getModel().getData()[itemIndex].SubItem;
			var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
			var aItems = SSInvoiceItem.getProperty('/');
			//get selected item num
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");
			var sPath = oBindingContext.getPath();
			oPPCCommon.suggestionItemSelected({
					oEvent: oEvent,
					thisController: this,
					sModelName: "SchemeFreeMatGrpMaterialsDD",
					sKey: "Key",
					sDescription: "Text"
				},
				function (key, desc, jData) {
					if (jData) {
						var Partner = desc;
						if (Partner) {
							var PartnerMgr = Partner.split("-");
							if (PartnerMgr.length > 2) {
								var PartnerMgrName = Partner.split("-")[2];
								var PartnerMgrNo1 = Partner.split("-")[0];
								var PartnerMgrNo2 = Partner.split("-")[1];
								PartnerMgrNo1 = PartnerMgrNo1 + "-";
								var PartnerMgrNo = PartnerMgrNo1.concat(PartnerMgrNo2);
							} else {
								PartnerMgrName = Partner.split("-")[1];
								PartnerMgrNo = Partner.split("-")[0];
							}
						}
						PartnerMgrName = PartnerMgrName.trim();
						PartnerMgrNo = PartnerMgrNo.trim();
						var Key = key.split("-").join("");
						var rows = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows();
						var groupId = "";
						var cells = rows[itemIndex].getCells();

						for (var m = 0; m < cells.length; m++) {
							if (cells[m].getId().indexOf("inputFreeMat") > 0) {
								groupId = gSchemeSlabsBlock.byId(cells[m].getId());
							}
						}
						// var bValidMaterial = that.validateFreeMat(jData, oEvent.getSource(), itemIndex, PartnerMgrNo);
						// if (bValidMaterial) {
						if (groupId) {
							groupId.removeAllTokens();
							groupId.setValue("");
							if (groupId instanceof sap.m.MultiInput) {
								groupId.addToken(new sap.m.Token({
									key: Key,
									text: PartnerMgrName + "(" + PartnerMgrNo + ")"
								}));
								groupId.setTooltip(PartnerMgrName + "(" + PartnerMgrNo + ")");
							}
							var SKUGroupCode = PartnerMgrNo;
							var SKUGroupDesc = PartnerMgrName;
							that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/SKUGroupID", Key.toUpperCase());
							that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/SKUGroupCode", SKUGroupCode);
							that.getView().getModel("SchemeSlabs").setProperty("/" + itemIndex + "/SKUGroupDesc", SKUGroupDesc);
						}
						// } else {
						// 	groupId.removeAllTokens();
						// 	groupId.setValueState(sap.ui.core.ValueState.Error);
						// 	var msg = oi18n.getText("SchemeItemsBlock.Message.MaterialRepeat", ItemNo);
						// 	groupId.setValueStateText(msg);
						// 	oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/SKUGroupID");
						// 	that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						// 		.getData()
						// 		.length);
						// 	oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));

						// }
					}
				}
			);
		},

		handleFreeMatTokenRemove: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			if (oEvent.getSource().getBindingContext("SchemeSlabs")) {
				index = parseInt(oEvent.getSource().getBindingContext("SchemeSlabs").getPath().split("/")[1]);
				var itemIndex = parseInt(index);
				var that = this;
				oEvent.getSource().setValueState(sap.ui.core.ValueState.None);
				oEvent.getSource().setValueStateText("");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/SKUGroupID");
				oPPCCommon.removeMsgsInMsgMgrById("/UI/SKUGroupID-" + itemIndex);
				oPPCCommon.hideMessagePopover();
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);

				var SSInvoiceItem = this.getView().getModel("SchemeSlabs");
				var aItems = SSInvoiceItem.getProperty('/');
				var oBindingContext = oEvent.getSource().getBindingContext("SchemeSlabs");

				var type = oEvent.getParameter("type");
				if (type === "removed") {
					aItems[itemIndex].SKUGroupCode = "";
					aItems[itemIndex].SKUGroupDesc = "";

					that.getView().getModel("SchemeSlabs").setProperty("/", aItems);

					var SSInvoiceItem = gSchemeItemsBlock.getModel("SchemeSlabs");
					var aItems = SSInvoiceItem.getProperty("/");
					var MatId = "";
					for (var i = 0; i < aItems.length; i++) {
						if (itemIndex !== i) {
							MatId = gSchemeItemsBlock.byId(gSchemeItemsBlock.getId() + "--inputFreeMat-" + gSchemeSlabsBlock.getId() +
								"--UISchemeSlabsTable_ADDBtnEdit-" + i);
							if (MatId) {
								MatId.setValue("");
								MatId.setValueState(sap.ui.core.ValueState.None);
								MatId.setValueStateText("");
							}
						}
					}
					oPPCCommon.removeMsgsInMsgMgrById("/UI/SKUGroupID");
					oPPCCommon.hideMessagePopover();
					this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData()
						.length);

				}
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});