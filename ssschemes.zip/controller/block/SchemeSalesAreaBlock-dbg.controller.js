sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function(Controller) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oi18n, oUtilsI18n;
	return Controller.extend("com.arteriatech.ss.schemes.controller.block.SchemeSalesAreaBlock", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		onInit: function() {
			this.onInitHookUp();
		},

		onInitHookUp: function() {
			if (this.getView().sViewName === "com.arteriatech.ss.schemes.view.block.SchemeSalesAreaBlock") {
				gSchemeSalesAreaBlock = this.getView();
			} else {
				gRetailerCategoryBlock = this.getView();
			}
		},

		addNew: function(oEvent) {
			// var EntityName =["SchemeSalesArea"];
			// var PropertyName =["SalesOrg", "Division","DistChannel","CPGroup1","CPGroup4"];
		 //   sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").callDropDown1(EntityName,PropertyName);
			var newItem = {
				"SalesAreaGUID": oPPCCommon.generateUUID(),
				"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
				"LoginID": "",
				"SalesOrgID": "",
				"SalesOrgDesc": "",
				"DistributionChannelID": "",
				"DistributionChannelDesc": "",
				"SalesAreaID": "",
				"SalesAreaDesc": "",
				"DivisionID": "",
				"DivisionDesc": "",
				"DMSDivisionID": "",
				"DMSDivisionDesc": "",
				"CPGroup1ID": "",
				"CPGroup1Desc": "",
				"CPGroup2ID": "",
				"CPGroup2Desc": "",
				"CPGroup3ID": "",
				"CPGroup3Desc": "",
				"CPGroup4ID": "",
				"CPGroup4Desc": "",
				"CPGroup5ID": "",
				"CPGroup5Desc": "",
				"CreatedBy": "",
				"CreatedOn": null,
				"CreatedAt": "PT18H37M35S",
				"ChangedBy": "CFA_USR01",
				"ChangedOn": null,
				"ChangedAt": "PT12H08M26S",
				"Source": "",
				"ExternalRefID": "",
				"ExternalRefKey": ""
			};

			//Pus new row to model
			var oItemModel = this.getView().getModel("SchemeSalesAreas");
			var oItemModelData = oItemModel.getData();
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();

			gSchemeSalesAreaBlock.byId("UISchemeSalesAreasTable_ADDBtnEdit").setType("Emphasized");
			gRetailerCategoryBlock.byId("UISchemeSalesAreasTable_ADDBtnEdit").setType("Emphasized");

			//Update Table count
			var iTotalLength = this.getView().getModel("SchemeSalesAreas").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSalesAreasCount", iTotalLength);
			}
			if (this.addNew_Exit) {
				this.addNew_Exit();
			}

		},

		deleteItem: function(oEvent) {
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");

			var source = oEvent.getSource().getId().split("-");
			oPPCCommon.removeMsgsInMsgMgrById("ItemDelete");
			var path = oEvent.getSource().getBindingContext("SchemeSalesAreas").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf('/') + 1));

			//Remove Row from model
			var oItemModel = this.getView().getModel("SchemeSalesAreas");
			var oItemModelData = oItemModel.getData();
			oItemModelData.splice(idx, 1);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			//Update Table count
			var iTotalLength = this.getView().getModel("SchemeSalesAreas").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSalesAreasCount", iTotalLength);
			}

			//Remove messages from message manager  
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + source[source.length - 1]) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData()
				.length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}

			if (this.deleteItem_Exit) {
				this.deleteItem_Exit();
			}
		},

		onDMSDivisionSelect: function(oEvent) {
			var view = gSchemeDetails;
			var path = oEvent.getSource().getBindingInfo("selectedKey").binding.getContext().getPath();
			var pos = path[path.length - 1];
			var oModelData = view.getModel("SchemeSalesAreas").getProperty("/");
			var selectedKey = oEvent.getSource().getSelectedKey();
			if (selectedKey && selectedKey !== "" && selectedKey.trim() !== "" && oModelData) {
				for (var i = 0; i < oModelData.length; i++) {
					if (pos && parseInt(pos) !== i && selectedKey === oModelData[i].DMSDivisionID) {
						var j = i + 1;
						sap.m.MessageToast.show("DMS Division '" + oModelData[i].DMSDivisionDesc +
							" (" + oModelData[i].DMSDivisionID + ")' Duplicated from " + j + " Item");
						oEvent.getSource().setSelectedKey("");
						break;
					}
				}
			}
			oPPCCommon.setDDDesciption(oEvent, view);
		},

		// Group2DD: function(oEvent) {
		// 	var view = gSchemeDetails;
		// 	var that = this;
		// 	oPPCCommon.setDDDesciption(oEvent, view);
		// 	var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
		// 	var oModelData = this.getView().getModel("PCGW");
		// 	var oSalesGroupFilter = new Array();
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
		// 		.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
		// 		.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
		// 		.model.FilterOperator.EQ, ["CPGRP2"], false, false, false);
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
		// 		.model.FilterOperator.EQ, [id], false, false, false);

		// 	// var obj = this.getView().byId(oEvent.getSource().getId().replace("fCPGroup1IDEdit", "fCPGroup2IDEdit").replace("col4", "col5"));
		// 	var obj = "",
		// 		objGroup3 = "";
		// 	var aCells = [];
		// 	aCells = oEvent.getSource().getParent().getCells();
		// 	for (var i = 0; i < aCells.length; i++) {
		// 		if (aCells[i].getId() && aCells[i].getId().indexOf("fCPGroup2IDEdit") >= 0) {
		// 			obj = this.getView().byId(aCells[i].getId());
		// 		} else if (aCells[i].getId() && aCells[i].getId().indexOf("fCPGroup3IDEdit") >= 0) {
		// 			objGroup3 = this.getView().byId(aCells[i].getId());
		// 		}
		// 	}
		// 	if (obj) {
		// 		if (obj.getModel("CPGroup2DD")) {
		// 			obj.getModel("CPGroup2DD").setProperty("/", []);
		// 		}
		// 		obj.setProperty("selectedKey", "");
		// 		obj.setTooltip("");
		// 		// var objGroup3 = this.getView().byId(oEvent.getSource().getId().replace("fCPGroup1IDEdit", "fCPGroup3IDEdit").replace("col4", "col6"));
		// 		if (objGroup3.getModel("CPGroup3DD")) {
		// 			objGroup3.getModel("CPGroup3DD").setProperty("/", []);
		// 		}
		// 		objGroup3.setProperty("selectedKey", "");
		// 		objGroup3.setTooltip("");
		// 		if (id && id !== "" && id.trim() !== "") {
		// 			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj,
		// 				"CPGroup2DD", "All",
		// 				function(oData) {
		// 					if(oData && oData.length === 1) {
		// 						that.Group3DD(oEvent, oData[0].Key, objGroup3);
		// 					}
		// 					// busyDialog.close();
		// 				}, true, "PD", true);
		// 		}
		// 	}
		// 	if (this.Group2DD_Exit) {
		// 		this.Group2DD_Exit();
		// 	}
		// },
		// Group3DD: function(oEvent, idFromGroup2DD, objGroup3) {
		// 	var view = gSchemeDetails;
		// 	var id = "";
		// 	if(!idFromGroup2DD) {
		// 		oPPCCommon.setDDDesciption(oEvent, view);
		// 		id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
		// 	}else {
		// 		id = idFromGroup2DD;
		// 	}
		// 	var oModelData = this.getView().getModel("PCGW");
		// 	var oSalesGroupFilter = new Array();
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui
		// 		.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap
		// 		.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui
		// 		.model.FilterOperator.EQ, ["CPGRP3"], false, false, false);
		// 	oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui
		// 		.model.FilterOperator.EQ, [id], false, false, false);

		// 	//var obj = this.getView().byId(oEvent.getSource().getId().replace("fCPGroup2IDEdit", "fCPGroup3IDEdit").replace("col5", "col6"));
		// 	var obj = "";
		// 	if(!objGroup3) {
		// 		var aCells = [];
		// 		aCells = oEvent.getSource().getParent().getCells();
		// 		for (var i = 0; i < aCells.length; i++) {
		// 			if (aCells[i].getId() && aCells[i].getId().indexOf("fCPGroup3IDEdit") >= 0) {
		// 				obj = this.getView().byId(aCells[i].getId());
		// 				break;
		// 			}
		// 		}
		// 	}else {
		// 		obj = objGroup3;
		// 	}
		// 	if (obj) {
		// 		if (obj.getModel("CPGroup3DD")) {
		// 			obj.getModel("CPGroup3DD").setProperty("/", []);
		// 		}
		// 		obj.setProperty("selectedKey", "");
		// 		obj.setTooltip("");
		// 		if (id && id !== "" && id.trim() !== "") {
		// 			oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj,
		// 				"CPGroup3DD", "All",
		// 				function() {
		// 					// busyDialog.close();
		// 				}, true, "PD", true);
		// 		}
		// 	}

		// 	if (this.Group3DD_Exit) {
		// 		this.Group3DD_Exit();
		// 	}
		// },
	 Group2DD: function (oEvent) {
		        var view = gSchemeDetails;
		        var that = this;
		        var oPath = oEvent.getSource().getBindingContext("SchemeSalesAreas").getPath().split("/")[1];
		        oPPCCommon.setDDDesciption(oEvent, view);
		        var id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
		        var sloginid = sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").getCurrentUsers("ChannelPartners", "read");
		        var oModelData = this.getView().getModel("PCGW");
		        var oSalesGroupFilter = new Array();
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CPGRP2"], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui.model.FilterOperator.EQ, [id], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui.model.FilterOperator.EQ, [sloginid], false, false, false);
		        var obj = "", objGroup3 = "";
		        var aCells = [];
		        aCells = oEvent.getSource().getParent().getCells();
		        for (var i = 0; i < aCells.length; i++) {
		            if (aCells[i].getId() && aCells[i].getId().indexOf("fCPGroup2IDEdit") >= 0) {
		                obj = this.getView().byId(aCells[i].getId());
		            } else if (aCells[i].getId() && aCells[i].getId().indexOf("fCPGroup3IDEdit") >= 0) {
		                objGroup3 = this.getView().byId(aCells[i].getId());
		            }
		        }
		        if (obj) {
		            if (obj.getModel("CPGroup2DD")) {
		                obj.getModel("CPGroup2DD").setProperty("/", []);
		            }
		            obj.setProperty("selectedKey", "");
		            obj.setTooltip("");
		            if (objGroup3.getModel("CPGroup3DD")) {
		                objGroup3.getModel("CPGroup3DD").setProperty("/", []);
		            }
		            objGroup3.setProperty("selectedKey", "");
		            objGroup3.setTooltip("");
		            if (id && id !== "" && id.trim() !== "") {
		                oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj, "CPGroup2DD", "All", function (oData) {
		                    if (oData && oData.length === 1) {
		                        that.Group3DD(oEvent, oData[0].Key, objGroup3,oPath);
		                        that.getView().getModel("SchemeSalesAreas").setProperty("/" + oPath + "/CPGroup2Desc", oData[0].Text);
		                        that.getView().getModel("SchemeSalesAreas").setProperty("/" + oPath + "/CPGroup2ID", oData[0].Key);
		                    } else if (oData && oData.length > 1) {
		                        that.getView().getModel("SchemeSalesAreas").setProperty("/" + oPath + "/CPGroup2Desc", oData[0].Text);
		                    }
		                }, true, "PD", true);
		            }
		        }
		        if (this.Group2DD_Exit) {
		            this.Group2DD_Exit();
		        }
		    },
		    Group3DD: function (oEvent, idFromGroup2DD, objGroup3,aPath) {
		        var view = gSchemeDetails;
		        var id = "";
		        var that = this;
		        var oPath ="";
		        if(!aPath){
		         oPath = oEvent.getSource().getBindingContext("SchemeSalesAreas").getPath().split("/")[1];	
		        }
		        else{
		         oPath=aPath;
		        }
		         
		        var sloginid = sap.ui.controller("com.arteriatech.ss.schemes.controller.DetailPage").getCurrentUsers("ChannelPartners", "read");
		        if (!idFromGroup2DD) {
		            oPPCCommon.setDDDesciption(oEvent, view);
		            id = this.getView().byId(oEvent.getSource().getId()).getSelectedKey();
		        } else {
		            id = idFromGroup2DD;
		        }
		        var oModelData = this.getView().getModel("PCGW");
		        var oSalesGroupFilter = new Array();
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CPGRP3"], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ID", sap.ui.model.FilterOperator.EQ, [id], false, false, false);
		        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "LoginID", sap.ui.model.FilterOperator.EQ, [sloginid], false, false, false);
		        var obj = "";
		        if(!aPath){
		        if (!objGroup3) {
		            var aCells = [];
		            aCells = oEvent.getSource().getParent().getCells();
		            for (var i = 0; i < aCells.length; i++) {
		                if (aCells[i].getId() && aCells[i].getId().indexOf("fCPGroup3IDEdit") >= 0) {
		                    obj = this.getView().byId(aCells[i].getId());
		                    break;
		                }
		            }
		        } else {
		            obj = objGroup3;
		        }
		        if (obj) {
		            if (obj.getModel("CPGroup3DD")) {
		                obj.getModel("CPGroup3DD").setProperty("/", []);
		            }
		            obj.setProperty("selectedKey", "");
		            obj.setTooltip("");
		            if (id && id !== "" && id.trim() !== "") {
		                oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj, "CPGroup3DD", "All", function (oData) {
		                    if (oData && oData.length > 1) {
		                        that.getView().getModel("SchemeSalesAreas").setProperty("/" + oPath + "/CPGroup3Desc", oData[0].Text);
		                    }
		                }, true, "PD", true);
		            }
		        }
		        }
		        else{
		        	 obj = objGroup3;
		        	 if (id && id !== "" && id.trim() !== "") {
		                oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), obj, "CPGroup3DD", "All", function (oData) {
		                    if (oData && oData.length > 1) {
		                        that.getView().getModel("SchemeSalesAreas").setProperty("/" + oPath + "/CPGroup3Desc", oData[0].Text);
		                    }
		                }, true, "PD", true);
		            }
		        }
		        if (this.Group3DD_Exit) {
		            this.Group3DD_Exit();
		        }
		    },
		exportToExcel: function(oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SchemeSalesAreasTable"),
					uiTable: this.getView().byId("UISchemeSalesAreasTable")
				});
			}
			var table = this.getView().byId("SchemeSalesAreasTable");
			var oModel = this.getView().getModel("SchemeSalesAreas");

			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			//i18n
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();

			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeSalesArea",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.schemes.view.ListPage
		 */
		//	onExit: function() {
		//
		//	}

	});

});