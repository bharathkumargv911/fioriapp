/*
 * Copyright (C) 2015-2016 Arteria Technologies Pvt. Ltd. All rights reserved
 */

sap.ui.define([
	"com/arteriatech/ss/schemes/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ss/utils/js/CommonValueHelp",
	"com/arteriatech/ss/utils/js/UserMapping",
	"sap/m/BusyDialog",
	"com/arteriatech/ss/schemes/util/Formatter"
], function(BaseController,
	JSONModel,
	History,
	oPPCCommon,
	oSSCommon,
	oSSCommonValueHelp,
	oSSUserMapping,
	BusyDialog
) {
	"use strict";
	var aCustomerData = [];
	var oi18n = "",
		oPPCUtili18n = "";
	var oDevice = sap.ui.Device;
	return BaseController.extend("com.arteriatech.ss.schemes.controller.ApproveList", {
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 */
		onInit: function() {
			this.onInitialHookUps();
		},
		onInitialHookUps: function() {
			this._oView = this.getView();
			oPPCCommon.initMsgMangerObjects();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oPPCUtili18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this._oRouter = this.getRouter();
			//Attach event for routing on view patter matched 
			this._oRouter.attachRouteMatched(this.onRouteMatched, this);
			this.setTabCount(0);

			if (this.onInitialHookUps_Exit) {
				this.onInitialHookUps_Exit();
			}
		},
		onRouteMatched: function(oEvent) {
			if (oEvent.getParameter("name") !== "contractapprove" && oEvent.getParameter("name") !== "contractapproveSearch") {
				return;
			}
			this.getView().setBusy(true);
			var that = this;
			var oDataModel = this._oComponent.getModel("PUGW");
			oSSCommon.setODataModel(oDataModel);

			var oHistory = sap.ui.core.routing.History.getInstance();
			if (oHistory.getDirection() !== "Backwards") {
				that.getContractapprove();
				// that.getTasks();
			} else if (oEvent.getParameter("name") === "contractapprove" || oEvent.getParameter("name") === "contractapproveapp") {
				that.getContractapprove();
			} else {
				that.getContractapprove();
			}
		},
		getDateDDValues: function() {
			this.StartDeadLineDifference = "-30";
			this.PreviousSelectedKeyStartDeadLine = this.StartDeadLineDifference;
			var oneMonthBackDate = oPPCCommon.getCurrentDate();
			oneMonthBackDate.setDate(oneMonthBackDate.getDate() + parseInt(this.StartDeadLineDifference));
			this.StartDeadLine = {
				FromDate: oneMonthBackDate,
				ToDate: oPPCCommon.getCurrentDate()
			};
			/*for SO Date*/
			if (this.getView().getModel("StartDeadLineViewSetting")) {
				this.getModel("StartDeadLineViewSetting").setProperty("/", {});
			}
			var oDataDate = [{
				DateKey: "",
				DateDesc: "Any"
			}, {
				DateKey: "0",
				DateDesc: "Today"
			}, {
				DateKey: "-1",
				DateDesc: "Today and Yesterday"
			}, {
				DateKey: "-7",
				DateDesc: "Last Seven Days"
			}, {
				DateKey: "-30",
				DateDesc: "Last One Month"
			}, {
				DateKey: "MS",
				DateDesc: "Manual Selection"
			}];
			oPPCCommon.getDateDropDownValue(oDataDate, this, "FStartDeadLine", "StartDeadLineViewSetting", this.StartDeadLineDifference);
		},
		onStartDeadLineSelectionChanged: function(oEvent) {
			var that = this;
			var oDateSelect = oEvent.getSource();
			var sSelectedKey = oEvent.getParameter("selectedItem").getKey();
			oPPCCommon.openManualDateSelectionDialog(this, sSelectedKey, oDateSelect, this.PreviousSelectedKeyStartDeadLine,
				"StartDeadLineViewSetting",
				oi18n,
				"FStartDeadLine",
				function(date) {
					that.StartDeadLine.FromDate = date.fromDate;
					that.StartDeadLine.ToDate = date.toDate;
				});
			this.PreviousSelectedKeyStartDeadLine = oEvent.getParameter("selectedItem").getKey();
			if (oEvent.getParameter("selectedItem").getKey() !== "MS") {
				this.PreviousSelectedKeyStartDeadLine = oEvent.getParameter("selectedItem").getKey();
			}
		},
		getCurrentUsers: function(sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},
		getContractapprove: function() {
			var oView = this.getView();
			var messageArea = this.getView().byId("MessageAreaId");
			var that = this;
			var ContractitemsListModel = this._oComponent.getModel("PCGW");
			ContractitemsListModel.attachRequestSent(function() {});
			ContractitemsListModel.attachRequestCompleted(function() {});
			ContractitemsListModel.setHeaders({
				"x-arteria-loginid": this.getCurrentUsers("Tasks", "read")
			});
			ContractitemsListModel.read("/Tasks", {
				filters: that.prepareSOApprItemsODataFilter(),
				success: function(oData) {
					if (oData.results.length > 0) {
						that.setContractitemsData(oData);
						oView.setBusy(false);
						/*var aDefaultSorter = [];
						var SONo = new sap.ui.model.Sorter("SONo", true);
						aDefaultSorter.push(SONo);
						var ItemNo = new sap.ui.model.Sorter("ItemNo", false);
						aDefaultSorter.push(ItemNo);
						that.applyTableGrouping("", "", "", aDefaultSorter);
						if (that.sCustomerInpuType === "DD") {
							if (that.getView().byId("customer").getSelectedKey() === "") {
								that.applyTableGrouping("CustomerNo", "CustomerName", "Customer", aDefaultSorter);
							}
						} else if (that.sCustomerInpuType === "VH") {
							if (that.getView().byId("inputCustomerNo").getTokens().length !== 1) {
								that.applyTableGrouping("CustomerNo", "CustomerName", "Customer", aDefaultSorter);
							}
						}*/

					} else {
						that.setNodataFound();
					}
				},
				error: function(error) {
					that.setNodataFound();
					oPPCCommon.dialogErrorMessage(error, oPPCUtili18n.getText("common.Dialog.Error.ServiceError.Header"));
				}
			});
		},
		prepareSOApprItemsODataFilter: function() {
			var CONTRACTItemsFilters = new Array();
			/**
			 * Prepare filter for oDataRead by using Utils method setODataModelReadFilter
			 * Paremeters: 1)view 2)controlID 3)filterArray 4)path 5)operator 6)value array 7)isMultiValue 8)isToken 9)isAnd
			 */
			CONTRACTItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", CONTRACTItemsFilters, "LoginID", "", [this.getCurrentUsers(
				"Tasks", "read")], false, false, false);
			CONTRACTItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", CONTRACTItemsFilters, "EntityType", sap.ui.model.FilterOperator
				.EQ, ["SCM"], true, false, false);

			//CONTRACTItemsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", CONTRACTItemsFilters, "Mobile1", sap.ui.model.FilterOperator.EQ, [this.byId("Mobile1").getValue()], false, false, false);
			if (this.prepareSOApprItemsODataFilter_Exit) {
				CONTRACTItemsFilters = this.prepareSOApprItemsODataFilter_Exit(CONTRACTItemsFilters);
			}
			return CONTRACTItemsFilters;
		},
		setContractitemsData: function(oData) {
			//this.setTableRowCount(oData.results.length);
			for (var i = 0; i < oData.results.length; i++) {
				oData.results[i].EntityValue1 = parseFloat(oData.results[i].EntityValue1);
			}

			var oTasksItemsModel = new sap.ui.model.json.JSONModel();
			oTasksItemsModel.setData(oData.results);
			oTasksItemsModel.setSizeLimit(oData.results.length);
			this._oComponent.setModel(oTasksItemsModel, "Tasks");
			this.setTabCount(oData.results);
		},
		setTabCount: function(Tasks) {
			var oLocalTableCountModel = new sap.ui.model.json.JSONModel();
			oLocalTableCountModel.setData({
				All: 0,
				VeryHigh: 0,
				High: 0,
				Medium: 0,
				Low: 0
			});
			this.getView().setModel(oLocalTableCountModel, "LocalTableCount");
			this.getTabCount(Tasks);
		},
		getTabCount: function(Tasks) {
			var oView = this.getView();
			var countVeryHigh = 0,
				countHigh = 0,
				countMedium = 0,
				countLow = 0;
			for (var i = 0; i < Tasks.length; i++) {
				if (Tasks[i].PriorityNumber === "1" || Tasks[i].PriorityNumber === "2") {
					countVeryHigh++;
				} else if (Tasks[i].PriorityNumber === "3" || Tasks[i].PriorityNumber === "4") {
					countHigh++;
				} else if (Tasks[i].PriorityNumber === "5") {
					countMedium++;
				} else if (Tasks[i].PriorityNumber === "6" || Tasks[i].PriorityNumber === "7" || Tasks[i].PriorityNumber === "8" || Tasks[i].PriorityNumber ===
					"9") {
					countLow++;
				}
			}

			if (countVeryHigh > 0) {
				this.getView().getModel("LocalTableCount").setProperty("/VeryHigh", countVeryHigh);

			}
			if (countHigh > 0) {
				this.getView().getModel("LocalTableCount").setProperty("/High", countHigh);

			}
			if (countMedium > 0) {

				this.getView().getModel("LocalTableCount").setProperty("/Medium", countMedium);

			}
			if (countLow > 0) {
				this.getView().getModel("LocalTableCount").setProperty("/Low", countLow);
			}
			if (Tasks.length > 0) {
				this.getView().getModel("LocalTableCount").setProperty("/All", Tasks.length);
			}
			oView.getModel("LocalTableCount").setProperty("/", {
				All: Tasks.length,
				VeryHigh: countVeryHigh,
				High: countHigh,
				Medium: countMedium,
				Low: countLow
			});
			/*	if (Tasks.length <= 0) {
					oView.byId("ApproveTable_All").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
				}
				if (countVeryHigh <= 0) {
					oView.byId("ApproveTable_VeryHigh").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
				}
				if (countHigh <= 0) {
					oView.byId("ApproveTable_High").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
				}
				if (countMedium <= 0) {
					oView.byId("ApproveTable_Medium").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
				}
				if (countLow <= 0) {
					oView.byId("ApproveTable_Low").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
				}*/
		},
		setNodataFound: function() {
			var oView = this.getView();
			/** Clear Model of the view */
			if (oView.getModel("Tasks") !== undefined) {
				oView.getModel("Tasks").setProperty("/", {});
			}
			oView.setBusy(false);
			this.setTabCount();
			// oView.byId("ApproveTable_All").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
			// oView.byId("ApproveTable_VeryHigh").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
			// oView.byId("ApproveTable_High").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
			// oView.byId("ApproveTable_Medium").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
			// oView.byId("ApproveTable_Low").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
		},
		applyTableGrouping: function(sPropertyKey, sPropertyText, sPropertyLabel, aDefaultSorter) {
			oPPCCommon.setGroupInTable(this.getView(), "ApproveTable_All", sPropertyKey, true, sPropertyLabel, sPropertyText, aDefaultSorter);
		},
		onReset: function() {
			/** Clear all local arrays */

			if (this.getView().getModel("Tasks") !== undefined) {
				this.getView().getModel("Tasks").setProperty("/", {});
			}
		},
		/*------------------------------------------Navigation-------------------------------------------*/
		/** Routing navigation to SO Details with SONumber */
		getContractDetails: function(oEvent) {
			var path = "";
			var oModelContext = oEvent.getSource().getBindingContext("Tasks");
			/**
			 * Check for the Multi-Origin of the service
			 * If true pass Multi-Origin Property in the routing
			 */
			var oPath = oModelContext.getPath().split("/")[1];
			var Guid = oModelContext.oModel.oData[oPath].EntityKey;
			Guid = Guid.substring(0, 8) + "-" + Guid.substring(8, 12) + "-" + Guid.substring(12, 16) + "-" + Guid.substring(16, 20) + "-" +
				Guid.substring(20, Guid.length);
			path = " Schemes(SchemeGUID='"+ Guid +"',InstanceID='"+oModelContext.oModel.oData[oPath].InstanceID+"')";
			
			
			// if (oPPCCommon.isMultiOrigin(oModelContext)) {
			// 	var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
			// 	path = "Contracts(ContractNo='" + oModelContext.getProperty("EntityKeyID") + "',InstanceID='" + oModelContext.getProperty(
			// 			"InstanceID") +
			// 		"'," +
			// 		SAPMultiOriginPropertyName + "='" + oModelContext.getProperty(SAPMultiOriginPropertyName) + "')";
			// } else {
			// 	path = "Contracts(ContractNo='" + oModelContext.getProperty("EntityKeyID") + "',InstanceID='" + oModelContext.getProperty(
			// 			"InstanceID") +
			// 		"')";
			// }
			this._oRouter.navTo("contractApprovedetail", {
				contextPath: path
			}, false);
		},
		
		// getContractDetails: function(oEvent) {
		// 	var path = "";
		// 	var oModelContext = oEvent.getSource().getBindingContext("Tasks");
		// 	/**
		// 	 * Check for the Multi-Origin of the service
		// 	 * If true pass Multi-Origin Property in the routing
		// 	 */
		// 	if (oPPCCommon.isMultiOrigin(oModelContext)) {
		// 		var SAPMultiOriginPropertyName = oPPCCommon.getSAPMultiOriginPropertyName();
		// 		path = "Contracts(ContractNo='" + oModelContext.getProperty("EntityKeyID") + "',InstanceID='" + oModelContext.getProperty(
		// 				"InstanceID") +
		// 			"'," +
		// 			SAPMultiOriginPropertyName + "='" + oModelContext.getProperty(SAPMultiOriginPropertyName) + "')";
		// 	} else {
		// 		path = "Contracts(ContractNo='" + oModelContext.getProperty("EntityKeyID") + "',InstanceID='" + oModelContext.getProperty(
		// 				"InstanceID") +
		// 			"')";
		// 	}
		// 	this._oRouter.navTo("contractApprovedetail", {
		// 		contextPath: path
		// 	}, false);
		// },
		
		/*------------------------------------------DD----------------------------------------*/
		/*setDropdowns: function() {
			this.setStatusDD();

			if (this.setDropdowns_Exit) {
				this.setDropdowns_Exit();
			}
		},
		setStatusDD: function() {
			var that = this;
			var oModelData = this._oComponent.getModel("PCGW");
			var oStatusFilter = new Array();
			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator
				.EQ, ["SOITST"], false, false, false);
			oSSCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", BusyDialog, this.getView(),
				"StatusDD", "",
				function() {
					if (that.contextPath) {
						var sStatusID = oPPCCommon.getPropertyValueFromContextPath(that.contextPath, "StatusID");
						if (sStatusID)
							that.getView().byId("inputStatus").setSelectedKeys(sStatusID.split(";"));
					}
					that.callService();
				});
		},*/

		/*------------------------------------------Table Filter, Sorter & Export to EXCEL-------------------------------------*/
		sorterFilterApprove: function() {
			if (!this._busyDialog) {
				this._busyDialog = sap.ui.xmlfragment("com.arteriatech.sf.so.util.ApproveDialog", this);
			}
			var oModel = this.getView().getModel("PCGW");
			this._busyDialog.setModel(oModel, "PCGW");
			var oi18nModel = this.getView().getModel("i18n");
			this._busyDialog.setModel(oi18nModel, "i18n");
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._busyDialog);
			this._busyDialog.open();
		},

		sortAndFilterTableApprove: function(oEvent) {
			var oView = this.getView();
			var that = this;
			var table = this.getView().byId("ApproveTable_All");
			// var oCustomFilter = new sap.ui.model.Filter("PurDocType", sap.ui.model.FilterOperator.EQ, "PO");
			oPPCCommon.sortAndFilterTable(table, oEvent, function(count, aDefaultSorter) {
				that.setSOTableTitle(count);
				if (count <= 0) {
					oView.byId("ApproveTable_All").setNoDataText(oPPCUtili18n.getText("common.NoResultsFound"));
					oView.byId("UIApproveTable_All").setNoData(oPPCUtili18n.getText("common.NoResultsFound"));
				} else {
					oPPCCommon.setGroupInTable(oView, "ApproveTable_All", "", true, "", "", aDefaultSorter);
				}
			});
			// }, oCustomFilter);
		},

		exportToExcel: function(oEvent) {

			var table1 = this.getView().byId("ApproveTable_All");
			var items;
			items = table1.getItems();
			if (items.length > 0) {
				if (oDevice.system.desktop) {
					oPPCCommon.copyAndApplySortingFilteringFromUITable({
						thisController: this,
						mTable: this.getView().byId("ApproveTable_All"),
						uiTable: this.getView().byId("UIApproveTable_All")
					});
				}
			}
			var table = this.getView().byId("ApproveTable_All"); // oEvent.getSource().getParent().getParent();
			var oModel = this.getView().getModel("Tasks");
			oPPCCommon.exportToExcel(table, oModel, {
				bExportAll: false,
				oController: this,
				bLabelFromMetadata: false,
				sModel: "PCGW",
				sEntityType: "Task",
				oUtilsI18n: oPPCUtili18n,
				sFileName: "Schemes"
			});

		},
		setTableRowCount: function(fItemsCount) {
			if (fItemsCount < 10) {
				this.getView().getModel("LocalViewSetting").setProperty("/tableRowCount", fItemsCount);
			} else {
				this.getView().getModel("LocalViewSetting").setProperty("/tableRowCount", 10);
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 */
		//		onBeforeRendering: function() {

		//		},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 */
		/*onAfterRendering: function() {

		},*/

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 */
		//		onExit: function() {

		//		}

	});
});