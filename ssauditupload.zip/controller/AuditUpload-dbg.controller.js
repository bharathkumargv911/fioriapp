sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/ss/utils/js/Common",
	"com/arteriatech/ss/utils/js/UserMapping",
	"com/arteriatech/ss/utils/js/CommonValueHelp"
], function (Controller, oPPCCommon, oSSCommon, oSSUserMapping, oSSCommonValueHelp) {
	"use strict";
	var aSimulateItem = [];
	var gCount = 0;
	var oi18n, oUtilsI18n;
	return Controller.extend("com.arteriatech.ss.ssauditupload.controller.AuditUpload", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.arteriatech.ss.ssrpdtransfer.view.RPDTransferUpload
		 */
		onInit: function () {
			this.onInitialHookUps();
		},
		onInitialHookUps: function () {
			gLeadCreateView = this.getView();
			this._oView = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.setDefaultSettings();
			this.setItemModel();
		},
		setDefaultSettings: function () {
			var that = this;
			var oModel = new sap.ui.model.json.JSONModel();
			var data = {
				tableRowCount: 0,
				tableRowCount1: 0,
				reviewButton: true,
				editMode: true,
				reviewMode: false,
				messageLength: 0,
				ReviewVisibility: false,
				CreateVisibility: true,
				Today: ""
			};

			oModel.setData(data);
			this.getView().setModel(oModel, "LocalViewSetting");
			that.getCurrentServerDate(that, function (Today) {
				that.getView().getModel("LocalViewSetting").setProperty("/Today", Today);
			});
		},
		setItemModel: function () {
			var oHoldModel = new sap.ui.model.json.JSONModel();
			// var data = [{
			// 	SPNo: "",
			// 	depot: "",
			// 	activity: "",
			// 	date: ""
			// }];

			oHoldModel.setData([]);
			this.getView().setModel(oHoldModel, "AuditItems");
		},

		clearAll: function () {
			this.confirmDialog();
		},

		confirmDialog: function () {
			var that = this;
			var dialog = new sap.m.Dialog({
				title: 'Confirm',
				type: 'Message',
				state: 'Warning',
				icon: 'sap-icon://message-warning',
				content: new sap.m.Text({
					text: oi18n.getText("clear.Popup.confirmation")
				}),
				beginButton: new sap.m.Button({
					text: 'Yes',
					press: function () {
						oPPCCommon.removeAllMsgs();
						oPPCCommon.hideMessagePopover();
						that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);

						that.getView().getModel("AuditItems").setProperty("/", []);
						gAuditUploadPage.byId("fileUploader").setValue("");
						gLeadCreateView.getModel("LocalViewSetting").setProperty("/tableRowCount1", 0);
						dialog.close();
					}
				}),
				endButton: new sap.m.Button({
					text: 'No',
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();

			if (this.confirmDialog_Exit) {
				this.confirmDialog_Exit();
			}
		},

		onBack: function () {
			this.getView().getModel("LocalViewSetting").setProperty("/ReviewVisibility", false);
			this.getView().getModel("LocalViewSetting").setProperty("/CreateVisibility", true);

		},

		// getSalesPersons: function () {
		// 	var that = this;
		// 	var SalesPersonsListModel = this._oComponent.getModel("SFGW_UPLOAD");
		// 	var SalesPersonsFilters = new Array();
		// 	SalesPersonsListModel.attachRequestSent(function () {

		// 	});
		// 	SalesPersonsListModel.attachRequestCompleted(function () {
		// 		busyDialog.close();
		// 	});
		// 	that.getCurrentUsers1("AuditPlanUploads", "read", function (LoginID) {
		// 		SalesPersonsListModel.setHeaders({
		// 			"x-arteria-loginid": LoginID
		// 		});
		// 		SalesPersonsListModel.read("/AuditPlanUploads", {
		// 			// urlParameters: {
		// 			// 	"$select": "SPGUID,FirstName,LastName,VehicleType,VehicleTypeDesc,CapacityCBB,CapacityVolume,GrossVehicleWght"
		// 			// },
		// 			// filters: that.prepareSalesPersonsODataFilter(LoginID),
		// 			success: function (oData) {
		// 				console.log(oData)
		// 				busyDialog.close();
		// 			},
		// 			error: function (error) {
		// 				console.log(oData)
		// 				busyDialog.close();
		// 			}
		// 		});
		// 	});

		// 	if (this.getSalesPersons_Exit) {
		// 		this.getSalesPersons_Exit();
		// 	}
		// },
		getCurrentServerDate: function (oController, callback) {
			var oModelData = oController._oComponent.getModel("PCGW");
			oModelData.read("/Today", {
				dataType: "json",
				success: function (data) {
					if (callback) {
						callback(data.Today.Today);
					}
				},
				error: function (error) {
					if (callback) {
						MessageBox.error(oi18n.getText("SOCreate.ServerDate.CanNot.Load"), {
							styleClass: "sapUiSizeCompact"
						});
					}
				}
			});
		},
		getCurrentUsers1: function (sServiceName, sRequestType, callback) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			if (callback) {
				callback(sLoginID);
			}
		},
		Validate: function () {
			var data = this.getView().getModel("AuditItems").getProperty("/");
			var Today = gLeadCreateView.getModel("LocalViewSetting").getProperty("/Today");
			// Today = Today.getMonth() + 1;
			if (data.length === 0) {
				var msg = oi18n.getText("audit.validate.Atleast");
				oPPCCommon.addMsg_MsgMgr(msg);
			}

			for (var i = 0; i < data.length; i++) {
				if (data[i].ParentNo === "" || data[i].ParentNo === undefined || data[i].ParentNo === null) {
					var msg = "Please enter ParentNo for item - " + (1 + i);
					oPPCCommon.addMsg_MsgMgr(msg);
				}
				// if (data[i].ParentName === "" || data[i].ParentName === undefined || data[i].ParentName === null) {
				// 	var msg = "Please enter Parent Name for item - " + (1 + i);
				// 	oPPCCommon.addMsg_MsgMgr(msg);
				// }

				// if (data[i].ParentType === "" || data[i].ParentType === undefined || data[i].ParentType === null) {
				// 	var msg = "Please enter Parent Type for item - " + (1 + i);
				// 	oPPCCommon.addMsg_MsgMgr(msg);
				// }

				if (data[i].SPNo === "" || data[i].SPNo === undefined || data[i].SPNo === null) {
					var msg = "Please enter SPNo for item - " + (1 + i);
					oPPCCommon.addMsg_MsgMgr(msg);
				}
				// if (data[i].SPName === "" || data[i].SPName === undefined || data[i].SPName === null) {
				// 	var msg = "Please enter SPName for item - " + (1 + i);
				// 	oPPCCommon.addMsg_MsgMgr(msg);
				// }
				if (data[i].VisitDate === "" || data[i].VisitDate === undefined || data[i].VisitDate === null) {
					var msg = "Please enter VisitDate for item - " + (1 + i);
					oPPCCommon.addMsg_MsgMgr(msg);
				} else if (data[i].VisitDate.getTime() < Today.getTime()) {
					var msg = "Visit date Cannot be a Past Date for item - " + (1 + i);
					oPPCCommon.addMsg_MsgMgr(msg);
				}
				// else if ((data[i].VisitDate.getMonth() + 1) < Today.getMonth() + 1) {
				// 	var msg = "Visit date month should be current month for item - " + (1 + i);
				// 	oPPCCommon.addMsg_MsgMgr(msg);
				// } 
				for (var j = i + 1; j < data.length; j++) {
					if (data[i].ParentNo === data[j].ParentNo && data[i].VisitDate.getTime() === data[j].VisitDate.getTime()) {
						var msg = "Parentno and Visit date is duplicate for  item - " + (i + 1);
						oPPCCommon.addMsg_MsgMgr(msg);
					}
					// if (data[i].SPNo === data[j].SPNo && data[i].VisitDate.getTime() === data[j].VisitDate.getTime()) {
					// 	var msg = "SPNo and visit date is duplicate for  item - " + (j);
					// 	oPPCCommon.addMsg_MsgMgr(msg);
					// }
				}
			}
		},
		onReview: function () {
			oPPCCommon.removeAllMsgs();
			this.Validate();
			if (oPPCCommon.doErrMessageExist()) {
				this.postData("X");
			} else {
				this.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);
				oPPCCommon.showMessagePopover(this.getView().byId("ObjectPageLayout_ID"));
				this.getView().setBusy(false);
			}
		},
		onSave: function () {
			var data = this.getView().getModel("AuditItems").getProperty("/");
			this.postData("");
		},
		postData: function (Testrun) {
			var that = this;
			that.getView().setBusy(true);
			var oModelCreate = this.getView().getModel("SFGW_UPLOAD");
			oModelCreate.setUseBatch(true);

			var items = this.getView().getModel("AuditItems").getProperty("/");
			var LoginId = this.getCurrentUsers("UploadHeader", "create");
			var UpldHdrGUID = oPPCCommon.generateUUID().split("-").join("");

			var oHeader = {
				"UpldHdrGUID": UpldHdrGUID,
				"LoginID": LoginId,
				"Testrun": Testrun,
				"UploadTypeset": "SFADUP",
				"SourceID": "PORTAL",
				"AuditPlanUploads": this.AuditPlanItems(UpldHdrGUID)
			};

			oModelCreate.setHeaders({
				"x-arteria-loginid": LoginId
			});
			oModelCreate.create("/UploadHeaders", oHeader, {
				success: function (oData) {
					if (Testrun === "X") {
						that.getView().getModel("LocalViewSetting").setProperty("/ReviewVisibility", true);
						that.getView().getModel("LocalViewSetting").setProperty("/CreateVisibility", false);
					} else {
						that.onCreateSuccessMessage();
					}
					that.getView().setBusy(false);
				},
				error: function (oData) {
					var message = oPPCCommon.getMsgsFromMsgMgr();
					oPPCCommon.removeDuplicateMsgsInMsgMgr();
					that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
						.getData().length);
					oPPCCommon.showMessagePopover(that.getView().byId("ObjectPageLayout_ID"));
					that.getView().setBusy(false);
				}
			});
		},
		AuditPlanItems: function (UpldHdrGUID) {
			var items = this.getView().getModel("AuditItems").getProperty("/");
			var AuditItemArr = [];
			for (var i = 0; i < items.length; i++) {

				items[i].VisitDate = new Date(items[i].VisitDate);
				items[i].VisitDate = oPPCCommon.addHoursAndMinutesToDate({
					dDate: items[i].VisitDate
				});

				var obj = {
					"UpldHdrGUID": UpldHdrGUID,
					"ParentName": items[i].ParentName,
					"ParentNo": items[i].ParentNo,
					"ParentTypeID": items[i].ParentType,
					"SPNo": items[i].SPNo,
					"SPName": items[i].SPName,
					"VisitDate": items[i].VisitDate,
					"SourceID": "PORTAL",
				};
				AuditItemArr.push(obj);
			}
			return AuditItemArr;

		},
		onCreateSuccessMessage: function () {
			var that = this;
			var oComponent = this._oComponent;
			var dialog = new sap.m.Dialog({
				title: 'Success',
				type: 'Message',
				state: 'Success',
				icon: 'sap-icon://message-success',
				content: new sap.m.Text({
					text: "Audit Plan Upload Successfully"
				}),
				beginButton: new sap.m.Button({
					text: 'Upload New',
					press: function () {
						// that.clearAll();

						that.getView().getModel("LocalViewSetting").setProperty("/ReviewVisibility", false);
						that.getView().getModel("LocalViewSetting").setProperty("/CreateVisibility", true);
						gLeadCreateView.getModel("LocalViewSetting").setProperty("/tableRowCount1", 0);
						that.getView().getModel("AuditItems").setProperty("/", []);
						gAuditUploadPage.byId("fileUploader").setValue("");
						dialog.close();
						that.getView().setBusy(false);
					}
				}),
				endButton: new sap.m.Button({
					text: 'Home',
					press: function () {
						window.location = "#";
						dialog.close();
						that.getView().setBusy(false);
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		showPopUp: function () {
			oPPCCommon.showMessagePopover(this.getView().byId("ObjectPageLayout_ID"));
		},

		getCurrentUsers: function (sServiceName, sRequestType) {
			var sLoginID = oSSCommon.getCurrentLoggedUser({
				sServiceName: sServiceName,
				sRequestType: sRequestType
			});
			return sLoginID;
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.arteriatech.ss.ssrpdtransfer.view.RPDTransferUpload
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.arteriatech.ss.ssrpdtransfer.view.RPDTransferUpload
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.arteriatech.ss.ssrpdtransfer.view.RPDTransferUpload
		 */
		//	onExit: function() {
		//
		//	}

	});

});