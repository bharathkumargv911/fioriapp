	sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/m/MessageBox",
		"com/arteriatech/ppc/utils/js/Common",
		"com/arteriatech/ss/utils/js/Common",
		"com/arteriatech/ss/utils/js/CommonValueHelp",
		"com/arteriatech/ss/utils/js/UserMapping",
		"sap/m/BusyDialog"
	], function (Controller, MessageBox, oPPCommon, oSSCommon, oSSCommonValueHelp, oSSUserMapping, BusyDialog) {
		"use strict";
		var aSimulateItem = [];
		var gSimulateItem = [];

		return Controller.extend("com.arteriatech.ss.ssauditupload.controller.UploadPage", {

			onInit: function () {
				this.onInitHookUp();
			},
			onInitHookUp: function () {
				gAuditUploadPage = this.getView();
				this._oView = this.getView();
				this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			},
			onDownloadFormat: function () {
				this.onDownloadFormat1();
			},
			getCurrentUsers: function (sServiceName, sRequestType) {
				var sLoginID = oSSCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			},
			onDownloadFormat1: function (oData) {
				var that = this;
				var getFormatCol = this.getHeaderColumnForLead();
				var rows = [];
				rows.push(getFormatCol.LeadHeader);
				var csvContent = "";
				rows.forEach(function (rowArray) {
					var row = rowArray.join(",");
					csvContent += row + "\r\n";
				});
				var fileName = "AuditPlan.csv";
				var hiddenElement = document.createElement("a");
				hiddenElement.href = "data:text/csv;charset=utf-8," + encodeURI(csvContent);
				hiddenElement.target = "_blank";
				hiddenElement.download = fileName;
				hiddenElement.click();
				that.getView().setBusy(false);
			},
			getHeaderColumnForLead: function () {
				var LeadUploadColumn = {
					LeadHeader: [
						"ParentNo",
						"ParentName",
						// "ParentType",
						"SPNo",
						"SPName",
						"VisitDate"
					]
				};
				return LeadUploadColumn;
			},
			handleUploadCompleteTypeWise: function (e) {
				// initializing 'this'key word to that variable
				oPPCommon.removeAllMsgs();
				var that = this;
				aSimulateItem.splice(0, aSimulateItem.length);
				// Getting file properties
				var file = e.getParameter("files") && e.getParameter("files")[0];
				// Validating and Reading file
				if (file && window.FileReader) {
					// File reader initialization
					var reader = new FileReader();
					var that = this;
					// File reader On Event by loading data
					reader.onload = function (evn) {
						// Getting result to String format
						var strCSV = evn.target.result; //string in CSV
						// Splitting result line by line
						var lines = strCSV.split("\n");
						// Initialization new empty array
						var result = [];
						// splitting header name of line[0]

						if (lines[0].split(":")[0].split("-")[0] === "01") {
							var headers = lines[1].split(",");
						} else {
							var headers = lines[0].split(",");
						}
						// Getting lost index count from header
						var headerLstIndexCnt = headers[headers.length - 1].length;

						// if (regex.test(headers[0]) == true) {
						// 	headers[0] = headers[0].substring(3, 9);
						// }
						// headers[0] = headers[0].substring(3,9);
						// Looping data and storing into 'obj' variable

						if (lines[0].split(":")[0].split("-")[0] === "01") {
							for (var i = 2; i < lines.length - 1; i++) {
								var obj = {};
								// Getting result set from current rows  
								var currentline = lines[i].split(",");
								// Statement for remvoing line break from lost column
								currentline[headers.length - 1] = currentline[headers.length - 1].replace(/(\r\n|\n|\r)/gm, "");
								// Looping data to store result set to header name
								for (var j = 0; j < headers.length; j++) {

									var headerCnt = headers.length;
									// State condition validation, when j is equal to headers.length
									if (j === (headerCnt - 1)) {
										// Getting lost index string from header without double quatation
										headers[j] = headers[headers.length - 1].substring(0, headerLstIndexCnt - 1);
									}
									// Adding result to 'obj' variable with header name and values
									obj[headers[j]] = currentline[j];
								}
								// Array pushing data 
								result.push(obj);
							}

						} else {
							for (var i = 1; i < lines.length - 1; i++) {
								var obj = {};
								// Getting result set from current rows  
								var currentline = lines[i].split(",");
								// Statement for remvoing line break from lost column
								currentline[headers.length - 1] = currentline[headers.length - 1].replace(/(\r\n|\n|\r)/gm, "");
								// Looping data to store result set to header name
								for (var j = 0; j < headers.length; j++) {
									var headerCnt = headers.length;
									// State condition validation, when j is equal to headers.length
									if (j === (headerCnt - 1)) {
										// Getting lost index string from header without double quatation
										headers[j] = headers[headers.length - 1].substring(0, headerLstIndexCnt - 1);
									}
									// Adding result to 'obj' variable with header name and values
									obj[headers[j]] = currentline[j];
								}
								// Array pushing data 
								result.push(obj);
							}
						}

						aSimulateItem = result;

					};

					// Getting as a string from file records
					reader.readAsBinaryString(file);
				}
			},
			// reader.onload = function (evn) {
			// 	// Getting result to String format
			// 	var strCSV = evn.target.result; //string in CSV
			// 	// Splitting result line by line
			// 	var lines = strCSV.split("\n");
			// 	// Initialization new empty array
			// 	var result = [];
			// 	// splitting header name of line[0]
			// 	var headers = lines[1].split(",");
			// 	// Getting lost index count from header
			// 	var headerLstIndexCnt = headers[headers.length - 1].length;
			// 	// Looping data and storing into 'obj' variable
			// 	for (var i = 2; i < lines.length - 1; i++) {
			// 		var obj = {};
			// 		var currentline = lines[i].split(",");
			// 		// if (currentline[8].split("-").length === 3 || currentline[8].split(".").length === 3) {
			// 		// 	currentline[8] = currentline[8];
			// 		// } else {
			// 		// 	currentline[7] = currentline[7] + currentline[8];
			// 		// 	currentline.splice(8, 1);
			// 		// }

			// 		// Statement for remvoing line break from lost column
			// 		currentline[headers.length - 1] = currentline[headers.length - 1].replace(/(\r\n|\n|\r)/gm, "");
			// 		// Looping data to store result set to header name
			// 		for (var j = 0; j < headers.length; j++) {
			// 			var headerCnt = headers.length;
			// 			// State condition validation, when j is equal to headers.length
			// 			if (j === (headerCnt - 1)) {
			// 				// Getting lost index string from header without double quatation
			// 				headers[j] = headers[headers.length - 1].substring(0, headerLstIndexCnt - 1);
			// 			}
			// 			// Adding result to 'obj' variable with header name and values
			// 			obj[headers[j]] = currentline[j];
			// 		}
			// 		// Array pushing data 
			// 		result.push(obj);
			// 	}
			// 	aSimulateItem = result;
			// };
			handleUploadPressTypeWise: function () {
				oPPCommon.removeAllMsgs();
				this.getView().setBusy(true);
				this.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData()
					.length);
				oPPCommon.hideMessagePopover();
				var that = this;
				var count = 0;
				var itemNo;
				var inputValue = that.getView().byId("fileUploader").getValue();
				if (inputValue === "") {
					MessageBox.error(
						"Please select a file", {
							styleClass: "sapUiSizeCompact"
						}
					);
					this.getView().setBusy(false);
					return;
				}

				// var prdTypeSelectedKey = gPSMHeaderCreateView.byId("prdType").getSelectedKey();
				// if (prdTypeSelectedKey === "") {
				// 	MessageBox.error(
				// 		"Please select a Product Type", {
				// 			styleClass: "sapUiSizeCompact"
				// 		}
				// 	);
				// 	return;
				// }
				that.getView().setBusy(true);
				gLeadCreateView.getModel("AuditItems").setProperty("/", []);
				var oFileField = this.getView().byId("fileUploader");
				var fileLength = oFileField.oFileUpload.files.length;
				var allowedExtensions = /(csv)$/i;

				// var loginID = this.getCurrentUsers("UploadHeaders", "create");
				var validExts = ".csv";
				var oFileName = this.getView().byId("fileUploader").getValue().split("(")[0];
				var fileExt = oFileName.substring(oFileName.lastIndexOf('.'));
				if (fileLength > 0) {
					if (!allowedExtensions.exec(fileExt) || fileExt === validExts) {
						// Condition Statement for validating file =  records
						if (aSimulateItem.length > 0) {
							var aValidItems = [];
							// aValidItems = aSimulateItem;
							// for (var i = 0; i < aSimulateItem.length; i++) {
							// 	aSimulateItem[i].Date = that.reverseDate(aSimulateItem[i].Date);
							// 	aSimulateItem[i].Date = new Date(aSimulateItem[i].Date);
							// 	aValidItems.push({
							// 		SPNo: aSimulateItem[i].SPNo,
							// 		depot: aSimulateItem[i].Depot,
							// 		activity: aSimulateItem[i].Activity,
							// 		date: aSimulateItem[i].Date,
							// 		Remarks: aSimulateItem[i].Remarks
							// 	})
							// }
							for (var i = 0; i < aSimulateItem.length; i++) {

								if (aSimulateItem[i].ParentNo !== undefined && aSimulateItem[i].ParentNo !== "" && aSimulateItem[i].ParentNo !== null) {
									aSimulateItem[i].ParentNo = aSimulateItem[i].ParentNo.trim();
								}
								if (aSimulateItem[i].ParentName !== undefined && aSimulateItem[i].ParentName !== "" && aSimulateItem[i].ParentName !== null) {
									aSimulateItem[i].ParentName = aSimulateItem[i].ParentName.trim();
								}
								// if (aSimulateItem[i].ParentType !== undefined && aSimulateItem[i].ParentType !== "" && aSimulateItem[i].ParentType !== null) {
								// 	aSimulateItem[i].ParentType = aSimulateItem[i].ParentType.trim();
								// }
								if (aSimulateItem[i].SPNo !== undefined && aSimulateItem[i].SPNo !== "" && aSimulateItem[i].SPNo !==
									null) {
									aSimulateItem[i].SPNo = aSimulateItem[i].SPNo.trim();
								}
								if (aSimulateItem[i].SPName !== undefined && aSimulateItem[i].SPName !== "" && aSimulateItem[i].SPName !==
									null) {
									aSimulateItem[i].SPName = aSimulateItem[i].SPName.trim();
								}

								if (aSimulateItem[i].VisitDate !== undefined && aSimulateItem[i].VisitDate !== "" && aSimulateItem[i].VisitDate !==
									null) {
									aSimulateItem[i].VisitDate = aSimulateItem[i].VisitDate.trim();
								}

								if (aSimulateItem[i].VisitDate !== "") {
									if (typeof (aSimulateItem[i].VisitDate) !== 'object') {
										aSimulateItem[i].VisitDate = that.reverseDate(aSimulateItem[i].VisitDate);
										aSimulateItem[i].VisitDate = new Date(aSimulateItem[i].VisitDate);
									}
								}
								// if (aSimulateItem[i].ParentType.length === 1) {
								// 	aSimulateItem[i].ParentType = aSimulateItem[i].ParentType.padStart(2, "0");
								// }
								aValidItems.push({
									ParentNo: aSimulateItem[i].ParentNo,
									ParentName: aSimulateItem[i].ParentName,
									ParentType: "01",
									SPNo: aSimulateItem[i].SPNo,
									SPName: aSimulateItem[i].SPName,
									VisitDate: aSimulateItem[i].VisitDate
								})
							}
							this.getView().setBusy(false);
							// Set JSON model to component with alias name [alias name as Odata collection name]
							if (oPPCommon.doErrMessageExist()) {
								this.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData()
									.length);
								oPPCommon.hideMessagePopover(gObjectPageLayout);
								that.getView().getModel("LocalViewSetting").setProperty("/reviewButton", true);
								gLeadCreateView.getModel("AuditItems").setProperty("/", aValidItems);
								gLeadCreateView.getModel("LocalViewSetting").setProperty("/tableRowCount", aValidItems.length);
								if (aValidItems.length > 0) {
									if (aValidItems.length < 10) {
										gLeadCreateView.getModel("LocalViewSetting").setProperty("/tableRowCount1", aValidItems.length);
									} else {
										gLeadCreateView.getModel("LocalViewSetting").setProperty("/tableRowCount1", aValidItems.length);
									}
								} else {
									gLeadCreateView.getModel("LocalViewSetting").setProperty("/tableRowCount1", 0);
								}
							} else {
								this.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData()
									.length);
								oPPCommon.showMessagePopover(gObjectPageLayout);
							}
							// this.setItemNo();

						}
					}
					// else {
					// 	// Calling dialog box function to alert
					// 	var oDialog = this._oDialog('Invalid File!');
					// 	// Alert dialog box open
					// 	oDialog.open();
					// }

				}
				that.getView().setBusy(false);
				// else {
				// 	var oDialog = this._oDialog('File is not Found!');
				// 	oDialog.open();

				// }
			},
			reverseDate: function (dateString) {
				// Split the date string by '-'
				const parts = dateString.split('.');

				// Reverse the order of day, month, and year
				const reversedDate = parts.reverse().join('-');

				return reversedDate;
			},

		});

	});