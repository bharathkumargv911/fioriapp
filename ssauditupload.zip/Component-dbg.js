var gItemView = "";
var gLeadCreateView = "";
var gAuditUploadPage = "";
var gObjectPageLayout = "";
sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/arteriatech/ss/ssauditupload/model/models"
], function (UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("com.arteriatech.ss.ssauditupload.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			jQuery.sap.registerModulePath("com.arteriatech.ppc.utils", "/sap/bc/ui5_ui5/ARTEC/PPCUTIL/utils/");
			jQuery.sap.registerModulePath("com.arteriatech.ss.utils", "/sap/bc/ui5_ui5/ARTEC/SSUTIL/utils/");

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});