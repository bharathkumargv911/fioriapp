sap.ui.define([
	"com/arteriatech/ssfrieghtlist/test/unit/controller/Main.controller"
], function () {
	"use strict";
});