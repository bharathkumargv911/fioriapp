jQuery.sap.require("com.arteriatech.ss.schemes.view.block.SchemeSlabsBlock");
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/BusyDialog",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common",
	"com/arteriatech/prd/utils/js/CommonValueHelp"
], function (Controller, BusyDialog, oPPCCommon, oSSCommon, oSSCommonValueHelp) {
	"use strict";
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oSSCommon = com.arteriatech.ss.utils.js.Common;
	var oSSCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
	var oi18n, oUtilsI18n;
	var oProductCommon;
	return sap.ui.controller("com.arteriatech.ss.schemes.zssschemesb.controller.block.SchemeItemsBlockCustom", {
		onInit: function () {
			this.onInitHookUp();
		},
		onInitHookUp: function () {
			oProductCommon = com.arteriatech.ss.utils.js.Common;
			this._oView = this.getView();
			gSchemeItemsBlock = this.getView();
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this._oView));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			this.getDropDowns();
			//this.setValuehelpProperty();
		},
		getDropDowns: function (selectedCustomer, callService) {
			this.setSchemesModel();
			this.setProductModel();
			this.getSchemeTypeDD(selectedCustomer, callService);
			this.getProductDD(selectedCustomer, callService);
			if (this.getDropDowns_Exit) {
				this.getDropDowns_Exit();
			}
		},

		setSchemesModel: function () {
			var that = this;
			var aSchemeF4Filter = new Array();
			oProductCommon.getCurrentLoggedUser({
				sServiceName: "SchemeItemDetails",
				sRequestType: "read"
			}, function (LoginID) {

				aSchemeF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemeF4Filter, "LoginID", "", [LoginID], false, false, false);
				var oSCGW_Model = that.getView().getModel("SCGW");
				oSCGW_Model.read("/SchemeItemDetails", {
					filters: aSchemeF4Filter,
					urlParameters: {
						"$select": "BrandID,BrandDesc"
					},
					success: function (oData) {
						oData = oPPCCommon.formatItemsOData({
							oData: oData
						});
						var oSchemeModel = new sap.ui.model.json.JSONModel();
						oSchemeModel.setData(oData);
						that._oComponent.setModel(oSchemeModel, "BrandDD");
					},
					error: function (error) {
						that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover();
					}
				});
			});

		},
		getSchemeTypeDD: function (selectedCustomer, callService) {
			var oModelData = this._oComponent.getModel("SCGW");
			var oStatusFilter = new Array();
			var that = this;
			// 			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
			// 				"SCGW"
			// 			], true, false, false);
			// 			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
			// 				"Scheme"
			// 			], false, false, false);
			// 			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
			// 				"SchemeType"
			// 			], false, false, false);
			oProductCommon.getDropdown(oModelData, "SchemeItemDetails", oStatusFilter, "BrandID", "BrandDesc", BusyDialog, this.getView(),
				"BrandDD", "",
				function () {
					if (callService) {
						that.callService();
					}
				}, false, "PD", true);
		},

		setProductModel: function () {
			var that = this;
			var aSchemeF4Filter = new Array();
			oProductCommon.getCurrentLoggedUser({
				sServiceName: "SchemeItemDetails",
				sRequestType: "read"
			}, function (LoginID) {

				aSchemeF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemeF4Filter, "LoginID", "", [LoginID], false, false, false);
				var oSCGW_Model = that.getView().getModel("SCGW");
				oSCGW_Model.read("/SchemeItemDetails", {
					filters: aSchemeF4Filter,
					urlParameters: {
						"$select": "ProductCatID,ProductCatDesc"
					},
					success: function (oData) {
						oData = oPPCCommon.formatItemsOData({
							oData: oData
						});
						var oSchemeModel = new sap.ui.model.json.JSONModel();
						oSchemeModel.setData(oData);
						that._oComponent.setModel(oSchemeModel, "ProductDD");
					},
					error: function (error) {
						that.getView().getModel("LocalViewSetting").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData()
							.length);
						oPPCCommon.showMessagePopover();
					}
				});
			});

		},

		getProductDD: function (selectedCustomer, callService) {
			var oModelData = this._oComponent.getModel("SCGW");
			var oStatusFilter = new Array();
			var that = this;
			// 			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
			// 				"SCGW"
			// 			], true, false, false);
			// 			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
			// 				"Scheme"
			// 			], false, false, false);
			// 			oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
			// 				"SchemeType"
			// 			], false, false, false);
			oProductCommon.getDropdown(oModelData, "SchemeItemDetails", oStatusFilter, "ProductCatID", "ProductCatDesc", BusyDialog, this.getView(),
				"ProductDD", "",
				function () {
					if (callService) {
						that.callService();
					}
				}, false, "PD", true);
		},
		// 		setValuehelpProperty: function () {
		// 			var that = this;
		// 			this.oSchemeTokenInput = this.getView().byId("fBrandIDEdit");
		// 			this.aSchemeKeys = [
		// 				"BrandID",
		// 				"BrandDesc"
		// 			];

		// 			if (this.setValuehelpPropety_Exit) {
		// 				this.setValuehelpPropety_Exit();
		// 			}
		// 		},

		TextAbstract: function (text, key, length) {
			text = text + "(" + key + ")";
			if (text === null) {
				return "";
			}
			if (text.length <= length) {
				return text;
			}
			text = text.substring(0, length);
			// last = text.lastIndexOf(" ");
			// text = text.substring(0, last);
			return text + "...";
		},

		exportToExcel: function (oEvent) {
			if (sap.ui.Device.system.desktop) {
				oPPCCommon.copyAndApplySortingFilteringFromUITable({
					thisController: this,
					mTable: this.getView().byId("SchemeItemsTable"),
					uiTable: this.getView().byId("UISchemeItemsTable")
				});
			}
			var table = this.getView().byId("SchemeItemsTable");
			var oModel = this.getView().getModel("SchemeItems");
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
			oi18n = this._oComponent.getModel("i18n").getResourceBundle();
			oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			oPPCCommon.exportToExcel(table, oModel, {
				sModel: "SCGW",
				sEntityType: "SchemeItemDetail",
				oController: this,
				oUtilsI18n: oUtilsI18n,
				bLabelFromMetadata: true
			});
		},
		getCurrentUsers: function (sServiceName, sRequestType, callBack) {
			if (callBack) {
				oProductCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				}, function (LoginID) {
					callBack(LoginID);
				});
			} else {
				var sLoginID = oProductCommon.getCurrentLoggedUser({
					sServiceName: sServiceName,
					sRequestType: sRequestType
				});
				return sLoginID;
			}
		},
		getSchemeSlabs: function (oEvent) {
			var that = this;
			this.Content = new com.arteriatech.ss.schemes.view.block.SchemeSlabsBlock({
				columnLayout: "4",
				formAdjustment: "BlockColumns"
			});
			var dialog = new sap.m.Dialog({
				title: "Scheme Slabs",
				type: "Message",
				content: this.Content,
				contentWidth: "80%",
				beginButton: new sap.m.Button({
					text: "Save",
					press: function () {
						that.saveCP(dialog);
					}
				}),
				endButton: new sap.m.Button({
					text: "Cancel",
					press: function () {
						dialog.close();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			var oModel = this.getView().getModel("SCGW");
			dialog.setModel(oModel, "SCGW");
			var oDeviceModelData = this.getView().getModel("device").getProperty("/");
			var oDeviceSettingModel = new sap.ui.model.json.JSONModel(oDeviceModelData);
			dialog.setModel(oDeviceSettingModel, "device");
			var oLocalModelModelData = this.getView().getModel("LocalViewSettingDtl").getProperty("/");
			var oViewSettingModel = new sap.ui.model.json.JSONModel(oLocalModelModelData);
			dialog.setModel(oViewSettingModel, "LocalViewSettingDtl");
			if (sap.ui.Device.support.touch === false) {
				dialog.addStyleClass("sapUiSizeCompact");
			}
			dialog.open();
			if (this.AddAlternateBillings_Exit) {
				this.AddAlternateBillings_Exit();
			}
		},
		callDropDown1: function (EntityName, PropertyName, oView, callback) {
			var that = this;
			var totalDD = PropertyName.length;
			gSchemeDetails.setBusy(true);
			for (var i = 0; i < PropertyName.length; i++) {
				if (PropertyName[i] === "Material") {
					EntityName = "SchemeItemDetail";
				}
				var oModelData = gSchemeDetails.getModel("PCGW");
				var oStatusFilter = new Array();
				var model = "SCGW";
				var sloginid = that.getCurrentUsers("ChannelPartners", "read");
				if (EntityName === "ChannelPartner") {
					model = "SSGW_MST";
				}
				var defaultValue = "Select",
					mustAddDefault = true;
				if (PropertyName[i] === "Banner" || PropertyName[i] === "Brand" || PropertyName[i] === "ProductCat" || PropertyName[i] ===
					"OrderMaterialGroup") {
					mustAddDefault = false;
				}
				if (PropertyName[i] === "SubBrand") {
					EntityName = "SchemeItemDetail";
				}
				if (PropertyName[i] === "CPGroup1" || PropertyName[i] === "CPGroup2") {
					defaultValue = "All";
					mustAddDefault = true;
				}
				oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [
					model
				], true, false, false);
				oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [
					EntityName
				], false, false, false);
				oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [
					PropertyName[i]
				], false, false, false);
				oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", new sap.m.BusyDialog(), gSchemeDetails,
					PropertyName[i] + "DD", defaultValue,
					function (addvalue, odata) {
						totalDD = totalDD - 1;
						if (totalDD === 0) {
							if (callback) {
								callback();
							}
						}
						gSchemeDetails.setBusy(false);
					}, false, "PD", {
						bSetSizeLimit: true
					});
			}
		},
		onSaleofcatChange: function (oEvent) {
			var that = this;
			var text = oEvent.getSource().getSelectedItem().getText();
			var selectedKey = oEvent.getSource().getSelectedKey();
			var oItemModel = this.getView().getModel("SchemeItems");
			var oItemModelData = oItemModel.getData();
			var BasketPath = oItemModelData[0].isBasket;
			if (oEvent.getSource().getSelectedKey() === "000006") {
				var EntityName = ["SchemeItemDetail"];
				var PropertyName = ["SubBrand"];
				if (gSchemeDetails.getModel("OnSaleOfCatDD")) {
					gSchemeItemsBlock.setBusy(true);
					sap.ui.controller("com.arteriatech.ss.schemes.controller.block.SchemeItemsBlock").callDropDown1(EntityName, PropertyName);
					gSchemeItemsBlock.setBusy(false);
				}
			}
			for (var i = 0; i < oItemModelData.length; i++) {
				oItemModelData[i].BannerID = "";
				oItemModelData[i].BannerDesc = "";
				oItemModelData[i].BrandID = "";
				oItemModelData[i].BrandDesc = "";
				oItemModelData[i].ItemMin = "0";
				oItemModelData[i].ProductCatID = "";
				oItemModelData[i].ProductCatDesc = "";
				oItemModelData[i].MaterialNo = "";
				oItemModelData[i].MaterialDesc = "";
				oItemModelData[i].MRP = 0;
				oItemModelData[i].MFDFrom = null;
				oItemModelData[i].MFDTo = null;
				oItemModelData[i].SubBrand = "";
				oItemModelData[i].SubBrandDesc = "";
				oItemModelData[i].ExpDateFrom = null;
				oItemModelData[i].ExpDateTo = null;
				oItemModelData[i].OrderMaterialGroupID = "";
				oItemModelData[i].OrderMaterialGroupDesc = "";
				oItemModelData[i].scMaterialTokens = [];
				that.getView().getModel("SchemeItems").setProperty("/" + i + "/OnSaleOfCatDesc", text);
				that.getView().getModel("SchemeItems").setProperty("/" + i + "/OnSaleOfCatID", selectedKey);
				if (BasketPath) {
					for (var SI = 0; SI < oItemModelData[i].results.length; SI++) {
						oItemModelData[i].results[SI].BannerID = "";
						oItemModelData[i].results[SI].BannerDesc = "";
						oItemModelData[i].results[SI].BrandID = "";
						oItemModelData[i].results[SI].BrandDesc = "";
						oItemModelData[i].results[SI].ItemMin = "0";
						oItemModelData[i].results[SI].ProductCatID = "";
						oItemModelData[i].results[SI].ProductCatDesc = "";
						oItemModelData[i].results[SI].MaterialNo = "";
						oItemModelData[i].results[SI].MaterialDesc = "";
						oItemModelData[i].results[SI].MRP = 0;
						oItemModelData[i].results[SI].MFDFrom = null;
						oItemModelData[i].results[SI].MFDTo = null;
						oItemModelData[i].root[SI].SubBrand = "";
						oItemModelData[i].root[SI].SubBrandDesc = "";
						oItemModelData[i].results[SI].ExpDateFrom = null;
						oItemModelData[i].results[SI].ExpDateTo = null;
						oItemModelData[i].results[SI].OrderMaterialGroupID = "";
						oItemModelData[i].results[SI].OrderMaterialGroupDesc = "";
						oItemModelData[i].results[SI].scMaterialTokens = [];
						that.getView().getModel("SchemeItems").setProperty("/" + i + "/results/" + SI + "/OnSaleOfCatDesc", text);
						that.getView().getModel("SchemeItems").setProperty("/" + i + "/results/" + SI + "/OnSaleOfCatID", selectedKey);
					}
				}
			}
		},
		onSaleOfAttributeChange: function (oEvent) {
			var that = this;
			var text = oEvent.getSource().getSelectedItem().getText();
			var selectedKey = oEvent.getSource().getSelectedKey();
			var oItemModel = this.getView().getModel("SchemeItems");
			var oItemModelData = oItemModel.getData();
			var BasketPath = oItemModelData[0].isBasket;
			for (var i = 0; i < oItemModelData.length; i++) {
				oItemModelData[i].MRP = 0;
				oItemModelData[i].MFDFrom = null;
				oItemModelData[i].MFDTo = null;
				oItemModelData[i].ExpDateFrom = null;
				oItemModelData[i].ExpDateTo = null;
				that.getView().getModel("SchemeItems").setProperty("/" + i + "/OnSaleOfAttributeDesc", text);
				that.getView().getModel("SchemeItems").setProperty("/" + i + "/OnSaleOfAttributeID", selectedKey);
				if (BasketPath) {
					for (var SI = 0; SI < oItemModelData[i].results.length; SI++) {
						oItemModelData[i].results[SI].MRP = 0;
						oItemModelData[i].results[SI].MFDFrom = null;
						oItemModelData[i].results[SI].MFDTo = null;
						oItemModelData[i].results[SI].ExpDateFrom = null;
						oItemModelData[i].results[SI].ExpDateTo = null;
						that.getView().getModel("SchemeItems").setProperty("/" + i + "/results/" + SI + "/OnSaleOfAttributeDesc", text);
						that.getView().getModel("SchemeItems").setProperty("/" + i + "/results/" + SI + "/OnSaleOfAttributeID", selectedKey);
					}
				}
			}
		},
		setMaterialModel: function () {
			var that = this;
			var oModelData = gSchemeDetails.getModel("PCGW");
			var defaultValue = "Select";
			var aMaterialF4Filter = new Array();
			aMaterialF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aMaterialF4Filter, "ModelID", sap.ui.model.FilterOperator
				.EQ, ["SCGW"], false, false, false);
			aMaterialF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aMaterialF4Filter, "EntityType", sap.ui.model.FilterOperator
				.EQ, ["SchemeItemDetail"], false, false, false);
			aMaterialF4Filter = oPPCCommon.setODataModelReadFilter(this.getView(), "", aMaterialF4Filter, "PropName", sap.ui.model.FilterOperator
				.EQ, ["Material"], false, false, false);
			oProductCommon.getDropdown(oModelData, "ValueHelps", aMaterialF4Filter, "ID", "Description", new sap.m.BusyDialog(), this.getView(),
				"MaterialDD", defaultValue,
				function (addvalue) {
					var MaterialsModel = new sap.ui.model.json.JSONModel();
					MaterialsModel.setData(addvalue);
					that.getView().setModel(MaterialsModel, "MaterialDD");
					gSchemeDetails.setBusy(false);
				}, false, "PD", {
					bSetSizeLimit: true
				});
		},
		addNew: function (oEvent) {
			this.setMaterialModel();
			var oItem = oEvent.getParameter("item"),
				sItemPath = "";
			while (oItem instanceof sap.m.MenuItem) {
				sItemPath = oItem.getText() + " > " + sItemPath;
				oItem = oItem.getParent();
			}
			sItemPath = sItemPath.substr(0, sItemPath.lastIndexOf(" > "));
			if (sItemPath === "Basket") {
				this.addNewBasket();
			} else {
				this.addNewItem();
			}
			this.getView().byId("UISchemeItemsTable_ADDBtnEdit").setType("Emphasized");
			if (this.addNew_Exit) {
				this.addNew_Exit();
			}
		},
		addNewBasket: function () {
			var oItemModel = this.getView().getModel("SchemeItems");
			var oItemModelData = oItemModel.getData();
			var ItemNo = this.generateMainItemNo(oItemModelData, 100);
			var ItemCatID = "000002";
			var newItem = this.getNewItemEntry(true, ItemNo, ItemCatID);
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			if (oItemModel.getProperty("/").length > 0) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/ItemScheme", false);
			}
			var iTotalLength = this.getView().getModel("SchemeItems").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", iTotalLength);
			}
			if (this.addNewBasket_Exit) {
				this.addNewBasket_Exit();
			}
		},
		addNewItem: function () {
			var oItemModel = this.getView().getModel("SchemeItems");
			var oItemModelData = oItemModel.getData();
			var ItemCatID = "000001";
			var newItem = this.getNewItemEntry(false, 0, ItemCatID);
			oItemModelData.push(newItem);
			oItemModel.setData(oItemModelData);
			oItemModel.refresh();
			this.setItemNo();
			if (oItemModel.getProperty("/").length > 0) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/BasketScheme", false);
			}
			var iTotalLength = this.getView().getModel("SchemeItems").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", iTotalLength);
			}
			if (this.addNewItem_Exit) {
				this.addNewItem_Exit();
			}
		},
		addNewItemToBasket: function (oEvent) {
			oEvent.getSource().setColor("#000");
			var path = oEvent.getSource().getBindingInfo("visible").binding.getContext().getPath();
			var Basket = this.getView().getModel("SchemeItems").getProperty(path);
			var ItemNo = this.generateMainItemNo(Basket, 1);
			var ItemCatID = "000002";
			var newItem = this.getNewItemEntry(false, ItemNo, ItemCatID);
			newItem.HierarchicalRefGUID = Basket.SchemeItemGUID;
			var oItemModel = this.getView().getModel("SchemeItems");
			if (Basket.results) {
				Basket.results.push(newItem);
			} else {
				Basket.results = [newItem];
			}
			oItemModel.refresh();
			var iTotalLength = this.getView().getModel("LocalViewSettingDtl").getProperty("/SchemeSubItemsCount");
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSubItemsCount", iTotalLength + 1);
			}
			if (this.addNewItemToBasket_Exit) {
				this.addNewItemToBasket_Exit();
			}
		},
		deleteItem: function (oEvent) {
			this.ObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");
			var path = oEvent.getSource().getBindingInfo("tooltip").binding.aBindings[0].getContext().getPath();
			var basketPath = path.split("/")[3];
			var mainPath = path.split("/")[1];
			if (mainPath === "0") {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", true);
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", true);
			}
			var Item = this.getView().getModel("SchemeItems").getData();
			if (Item.length === 1) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/BasketScheme", true);
				this.getView().getModel("LocalViewSettingDtl").setProperty("/ItemScheme", true);
			}
			this.getView().getModel("SchemeItems").getProperty(path);
			if (Item[mainPath].isBasket) {
				if (Item[mainPath].results && Item[mainPath].results.length > 0) {
					if (!basketPath) {
						this.confirmBasketDelete(basketPath, mainPath, Item);
					} else {
						this.deleteBasketFromPosition(basketPath, mainPath, Item);
					}
				} else {
					this.deleteItemFromPosition(path[path.length - 1]);
				}
			} else {
				this.deleteItemFromPosition(path[path.length - 1]);
			}
			if (this.deleteItem_Exit) {
				this.deleteItem_Exit();
			}
		},
		handleOrdMatSuggest1: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: [
					"Key",
					"Text"
				],
				sBinding: "suggestionItems"
			});
		},
		handleOrdMatSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: [
					"Key",
					"Text"
				],
				sBinding: "suggestionItems"
			});
		},
		onChangeOrdMat: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var SSInvoiceItem = this.getView().getModel("OrderMaterialGroupDD");
			var aItems = SSInvoiceItem.getProperty("/");
			var bKeyFound = false;
			var bTextFound = false;
			var enteredVal = oEvent.getParameter("value");
			var enteredValId = enteredVal.split("-")[0].trim();
			var enteredText = "";
			var index = oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/");
			var oPath = index[1];
			var BasketPath = index[3];
			var itemNo = "";
			if (BasketPath) {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].results[BasketPath].ItemNo;
			} else {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].ItemNo;
			}
			for (var j = enteredVal.split("-").length - 1; j >= 1; j--) {
				enteredText = enteredVal.split("-")[j] + "-" + enteredText;
			}
			if (enteredText) {
				enteredText = enteredText.substring(0, enteredText.length - 1).trim();
			}
			for (var i = 0; i < aItems.length; i++) {
				if (enteredValId) {
					if (aItems[i].Key.trim() === enteredValId) {
						bKeyFound = true;
						if (aItems[i].Text.trim() === enteredText) {
							bTextFound = true;
							break;
						}
					}
				}
			}
			if (!bKeyFound || !bTextFound) {
				if (enteredVal) {
					var msg = "Please Enter Valid Order Material Group for Item No #" + itemNo;
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fOrderMaterialGroupIDEditSI");
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					if (BasketPath) {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/OrderMaterialGroupID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/OrderMaterialGroupDesc", "");
						oEvent.getSource().setSelectedKey("");
					} else {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/OrderMaterialGroupID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/OrderMaterialGroupDesc", "");
						oEvent.getSource().setSelectedKey("");
					}
				}
			} else {
				if (BasketPath) {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/OrderMaterialGroupDesc",
						enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/OrderMaterialGroupID", enteredValId);
				} else {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/OrderMaterialGroupDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/OrderMaterialGroupID", enteredValId);
				}
			}
		},
		onChangeBanner: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var SSInvoiceItem = this.getView().getModel("BannerDD");
			var aItems = SSInvoiceItem.getProperty("/");
			var bKeyFound = false;
			var bTextFound = false;
			var enteredVal = oEvent.getParameter("value");
			var enteredValId = enteredVal.split("-")[0].trim();
			var enteredText = "";
			var index = oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/");
			var oPath = index[1];
			var BasketPath = index[3];
			var itemNo = "";
			if (BasketPath) {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].results[BasketPath].ItemNo;
			} else {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].ItemNo;
			}
			for (var j = enteredVal.split("-").length - 1; j >= 1; j--) {
				enteredText = enteredVal.split("-")[j] + "-" + enteredText;
			}
			if (enteredText) {
				enteredText = enteredText.substring(0, enteredText.length - 1).trim();
			}
			for (var i = 0; i < aItems.length; i++) {
				if (enteredValId) {
					if (aItems[i].Key.trim() === enteredValId) {
						bKeyFound = true;
						if (aItems[i].Text.trim() === enteredText) {
							bTextFound = true;
							break;
						}
					}
				}
			}
			if (!bKeyFound || !bTextFound) {
				if (enteredVal) {
					var msg = "Please Enter Valid Banner for Item No #" + itemNo;
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fBannerIDEdit");
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					if (BasketPath) {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BannerID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BannerDesc", "");
						oEvent.getSource().setSelectedKey("");
					} else {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BannerID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BannerDesc", "");
						oEvent.getSource().setSelectedKey("");
					}
				}
			} else {
				if (BasketPath) {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BannerDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BannerID", enteredValId);
				} else {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BannerDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BannerID", enteredValId);
				}
			}
		},
		onChangeBrand: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var SSInvoiceItem = this.getView().getModel("BrandDD");
			var aItems = SSInvoiceItem.getProperty("/");
			var items = that.getView().getModel("SchemeItems").getProperty("/");
			var bKeyFound = false;
			var bTextFound = false;
			var enteredVal = oEvent.getParameter("value");
			var enteredValId = enteredVal.split("-")[0].trim();
			var enteredText = "";
			var index = oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/");
			var oPath = index[1];
			var BasketPath = index[3];
			var itemNo = "";
			if (BasketPath) {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].results[BasketPath].ItemNo;
			} else {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].ItemNo;
			}
			for (var j = enteredVal.split("-").length - 1; j >= 1; j--) {
				enteredText = enteredVal.split("-")[j] + "-" + enteredText;
			}
			if (enteredText) {
				enteredText = enteredText.substring(0, enteredText.length - 1).trim();
			}
			for (var i = 0; i < aItems.length; i++) {
				if (enteredValId) {
					if (aItems[i].Key.trim() === enteredValId) {
						bKeyFound = true;
						if (aItems[i].Text.trim() === enteredText) {
							bTextFound = true;
							break;
						}
					}
				}
			}
			if (!bKeyFound || !bTextFound) {
				if (enteredVal) {
					var msg = "Please Enter Valid Brand for Item No #" + itemNo;
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fBrandIDEdit");
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					if (BasketPath) {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BrandID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BrandDesc", "");
						oEvent.getSource().setSelectedKey("");
					} else {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BrandID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BrandDesc", "");
						oEvent.getSource().setSelectedKey("");
					}
				}
			} else {
				if (BasketPath) {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BrandDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/BrandID", enteredValId);
				} else {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BrandDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/BrandID", enteredValId);
				}
			}
		},
		onChangeProduct: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var SSInvoiceItem = this.getView().getModel("ProductCatDD");
			var aItems = SSInvoiceItem.getProperty("/");
			var bKeyFound = false;
			var bTextFound = false;
			var enteredVal = oEvent.getParameter("value");
			var enteredValId = enteredVal.split("-")[0].trim();
			var enteredText = "";
			var index = oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/");
			var oPath = index[1];
			var BasketPath = index[3];
			var itemNo = "";
			if (BasketPath) {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].results[BasketPath].ItemNo;
			} else {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].ItemNo;
			}
			for (var j = enteredVal.split("-").length - 1; j >= 1; j--) {
				enteredText = enteredVal.split("-")[j] + "-" + enteredText;
			}
			if (enteredText) {
				enteredText = enteredText.substring(0, enteredText.length - 1).trim();
			}
			for (var i = 0; i < aItems.length; i++) {
				if (enteredValId) {
					if (aItems[i].Key.trim() === enteredValId) {
						bKeyFound = true;
						if (aItems[i].Text.trim() === enteredText) {
							bTextFound = true;
							break;
						}
					}
				}
			}
			if (!bKeyFound || !bTextFound) {
				if (enteredVal) {
					var msg = "Please Enter Valid Order Material Group for Item No #" + itemNo;
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fProductCatIDEdit");
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					if (BasketPath) {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/ProductCatID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/ProductCatDesc", "");
						oEvent.getSource().setSelectedKey("");
					} else {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/ProductCatID", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/ProductCatDesc", "");
						oEvent.getSource().setSelectedKey("");
					}
				}
			} else {
				if (BasketPath) {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/ProductCatDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/results/" + BasketPath + "/ProductCatID", enteredValId);
				} else {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/ProductCatDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/ProductCatID", enteredValId);
				}
			}
		},
		confirmBasketDelete: function (basketPath, mainPath, Item) {
			var that = this;
			if (Item[mainPath].results) {
				var dialog = new sap.m.Dialog({
					title: "Confirm",
					type: "Message",
					state: "Warning",
					icon: "sap-icon://message-warning",
					content: new sap.m.Text({
						text: goi18n.getText("Change.Message.Basket.Delete", Item[mainPath].results.length)
					}),
					beginButton: new sap.m.Button({
						text: "Yes",
						press: function () {
							that.deleteBasketFromPosition(basketPath, mainPath, Item, dialog);
						}
					}),
					endButton: new sap.m.Button({
						text: "No",
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			} else {
				that.deleteBasketFromPosition(basketPath, mainPath, Item, dialog);
			}
			if (this.confirmDialog_Exit) {
				this.confirmDialog_Exit();
			}
		},
		deleteBasketFromPosition: function (basketPath, mainPath, Item, dialog) {
			var that = this;
			var oItemModel = this.getView().getModel("SchemeItems");
			var oItemModelData = oItemModel.getData();
			var idx = parseInt(mainPath);
			if (oItemModelData.length > 1 && idx === 0) {
				oItemModelData[idx + 1].OnSaleOfCatID = oItemModelData[idx].OnSaleOfCatID;
				oItemModelData[idx + 1].OnSaleOfCatDesc = oItemModelData[idx].OnSaleOfCatDesc.trim();
				oItemModelData[idx + 1].OnSaleOfAttributeID = oItemModelData[idx].OnSaleOfAttributeID;
				oItemModelData[idx + 1].OnSaleOfAttributeDesc = oItemModelData[idx].OnSaleOfAttributeDesc.trim();
				oItemModelData[idx + 1].OnSaleOfItemUOMID = oItemModelData[idx].OnSaleOfItemUOMID;
				oItemModelData[idx + 1].OnSaleOfItemUOMDesc = oItemModelData[idx].OnSaleOfItemUOMDesc.trim();
				oItemModelData[idx + 1].BasketUOMID = oItemModelData[idx].BasketUOMID;
				oItemModelData[idx + 1].BasketUOMDesc = oItemModelData[idx].BasketUOMDesc.trim();
			}
			var subItemsCount = "";
			if (basketPath) {
				oItemModelData[mainPath].results.splice(basketPath, 1);
				subItemsCount = 1;
			} else {
				if (Item[mainPath].results) {
					subItemsCount = Item[mainPath].results.length;
				}
				oItemModelData.splice(mainPath, 1);
			}
			oItemModel.setData(oItemModelData);
			this.setBasketItemNo();
			if (dialog) {
				dialog.close();
			}
			var iTotalLength = this.getView().getModel("SchemeItems").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", iTotalLength);
			}
			var iSubTotalLength = this.getView().getModel("LocalViewSettingDtl").getProperty("/SchemeSubItemsCount");
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSubItemsCount", iSubTotalLength - subItemsCount);
				var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
				for (var i = 0; i < oData.length; i++) {
					var msgObj = oData[i];
					if (msgObj.id.indexOf("-" + mainPath) > -1) {
						oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
					}
				}
				this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
					.getData().length);
				if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
					oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
				}
			}
		},
		deleteItemFromPosition: function (pos) {
			var that = this;
			var idx = parseInt(pos);
			var oItemModel = this.getView().getModel("SchemeItems");
			var oItemModelData = oItemModel.getData();
			if (oItemModelData.length > 1 && idx === 0) {
				oItemModelData[idx + 1].OnSaleOfCatID = oItemModelData[idx].OnSaleOfCatID;
				oItemModelData[idx + 1].OnSaleOfCatDesc = oItemModelData[idx].OnSaleOfCatDesc.trim();
				oItemModelData[idx + 1].OnSaleOfAttributeID = oItemModelData[idx].OnSaleOfAttributeID;
				oItemModelData[idx + 1].OnSaleOfAttributeDesc = oItemModelData[idx].OnSaleOfAttributeDesc.trim();
				oItemModelData[idx + 1].OnSaleOfItemUOMID = oItemModelData[idx].OnSaleOfItemUOMID;
				oItemModelData[idx + 1].OnSaleOfItemUOMDesc = oItemModelData[idx].OnSaleOfItemUOMDesc.trim();
				oItemModelData[idx + 1].BasketUOMID = oItemModelData[idx].BasketUOMID;
				oItemModelData[idx + 1].BasketUOMDesc = oItemModelData[idx].BasketUOMDesc.trim();
			}
			oItemModelData.splice(pos, 1);
			oItemModel.setData(oItemModelData);
			that.setItemNo();
			var iTotalLength = this.getView().getModel("SchemeItems").getProperty("/").length;
			if (this.getView().getModel("LocalViewSettingDtl")) {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", iTotalLength);
			}
			var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
			for (var i = 0; i < oData.length; i++) {
				var msgObj = oData[i];
				if (msgObj.id.indexOf("-" + pos) > -1) {
					oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
				}
			}
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			if (this.getView().getModel("LocalViewSettingDtl").getProperty("/messageLength") === 0) {
				oPPCCommon.hideMessagePopover(this.ObjectPageLayout);
			}
		},
		setItemNo: function () {
			var countOfM = 10;
			var count = 0;
			var aItem = gSchemeDetails.getModel("SchemeItems").getProperty("/");
			for (var i = 0; i < aItem.length; i++) {
				if (i > 9) {
					countOfM = countOfM + 1;
					var itemNo = countOfM * 1;
					itemNo = ("00" + itemNo).slice(-6);
					aItem[i].ItemNo = itemNo;
				} else {
					var itemNo = (count + 1) * 1;
					itemNo = ("000" + itemNo).slice(-6);
					aItem[i].ItemNo = itemNo;
					count = count + 1;
				}
			}
			gSchemeDetails.getModel("SchemeItems").setProperty("/", aItem);
		},
		setBasketItemNo: function () {
			var countOfM = 10;
			var count = 0;
			var aItem = this.getView().getModel("SchemeItems").getProperty("/");
			for (var i = 0; i < aItem.length; i++) {
				var itemNo = (count + 100) * 1;
				itemNo = ("00" + itemNo).slice(-6);
				aItem[i].ItemNo = itemNo;
				var subCount = 0;
				if (aItem[i].results && aItem[i].results.length > 0) {
					for (var j = 0; j < aItem[i].results.length; j++) {
						var rootItemNo = (count + 100 + subCount + 1) * 1;
						rootItemNo = ("00" + rootItemNo).slice(-6);
						aItem[i].results[j].ItemNo = rootItemNo;
						subCount = subCount + 1;
					}
				}
				count = count + 100;
			}
			this.getView().getModel("SchemeItems").setProperty("/", aItem);
		},
		removeMaterialTokenByIndex: function (idx) {
			var dataLength = this.getView().getModel("SchemeItems").getProperty("/").length;
			var items = this.getView().getModel("SchemeItems").getProperty("/");
			var subDataLength = 0;
			if (items[0].isBasket) {
				for (var L = 0; L < dataLength; L++) {
					subDataLength = items[L].results.length + subDataLength;
				}
			} else {
				subDataLength = 0;
			}
			for (var i = 0; i < dataLength + subDataLength; i++) {
				var cells = this.getView().byId("UISchemeItemsTableEdit").getRows()[i].getCells();
				var matCellId = "";
				for (var j = 0; j < cells.length; j++) {
					if (cells[j].getId().indexOf("inputMaterial") !== -1) {
						matCellId = cells[j].getId();
					}
				}
				if (matCellId) {
					this.getView().byId(matCellId).removeAllTokens();
				}
			}
		},
		addTokensTotable: function () {
			var dataLength = this.getView().getModel("SchemeItems").getProperty("/");
			var temparray = [];
			var subDataLength = 0;
			if (dataLength[0].isBasket) {
				for (var L = 0; L < dataLength.length; L++) {
					subDataLength = dataLength[L].results.length + subDataLength;
					temparray.push(dataLength[L]);
					for (var s = 0; s < dataLength[L].results.length; s++) {
						temparray.push(dataLength[L].results[s]);
					}
				}
			} else {
				subDataLength = 0;
			}
			if (dataLength[0].isBasket) {
				for (var i = 0; i < temparray.length; i++) {
					var cells = this.getView().byId("UISchemeItemsTableEdit").getRows()[i].getCells();
					var matCellId = "";
					for (var j = 0; j < cells.length; j++) {
						if (cells[j].getId().indexOf("inputMaterial") !== -1) {
							matCellId = cells[j].getId();
						}
					}
					if (matCellId) {
						if (temparray[i].MaterialNo) {
							var oToken = new sap.m.Token({
								key: temparray[i].MaterialNo,
								text: temparray[i].MaterialDesc + "(" + temparray[i].MaterialNo + ")"
							});
							this.getView().byId(matCellId).addToken(oToken);
						}
					}
				}
			} else {
				for (var i = 0; i < dataLength.length; i++) {
					var cells = this.getView().byId("UISchemeItemsTableEdit").getRows()[i].getCells();
					var matCellId = "";
					for (var j = 0; j < cells.length; j++) {
						if (cells[j].getId().indexOf("inputMaterial") !== -1) {
							matCellId = cells[j].getId();
						}
					}
					if (matCellId) {
						if (dataLength[i].MaterialNo) {
							var oToken = new sap.m.Token({
								key: dataLength[i].MaterialNo,
								text: dataLength[i].MaterialDesc + "(" + dataLength[i].MaterialNo + ")"
							});
							this.getView().byId(matCellId).addToken(oToken);
						}
					}
				}
			}
		},
		PayoutPercformatNumber: function (oEvent) {
			gSchemeDetails.PayoutPercFound = false;
			var item = oEvent.getSource().getBindingContext("SchemeItems").getModel().getProperty("/");
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf("/") + 1));
			if (item[idx].PayoutPerc === "") {
				this.getView().getModel("SchemeItems").setProperty("/" + idx + "/PayoutPerc", "0");
			}
			var PayoutPerc = oEvent.getSource().getBindingContext("SchemeItems").getModel().getProperty("/" + idx + "/PayoutPerc");
			item[idx].PayoutPerc = parseFloat(item[idx].PayoutPerc);
			item[idx].PayoutAmount = parseFloat(item[idx].PayoutAmount);
			if (parseFloat(PayoutPerc) > 0) {
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutAmountValueState", "None");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutAmountValueStateText", "");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutPercValueState", "None");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutPercValueStateText", "");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().refresh();
			}
			for (var i = 0; i < item.length; i++) {
				if (!gSchemeDetails.PayoutPercFound) {
					if (parseFloat(item[i].PayoutPerc) !== 0 && parseFloat(item[i].PayoutAmount) === 0) {
						gSchemeDetails.PayoutPercFound = true;
					}
				}
			}
			if (gSchemeDetails.PayoutPercFound) {
				gSchemeDetails.PayoutAmntFound = false;
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", true);
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", false);
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", true);
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", true);
			}
		},
		PayoutAmntformatNumber: function (oEvent) {
			gSchemeDetails.PayoutAmntFound = false;
			var item = oEvent.getSource().getBindingContext("SchemeItems").getModel().getProperty("/");
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var idx = parseInt(path.substring(path.lastIndexOf("/") + 1));
			if (item[idx].PayoutPerc === "") {
				this.getView().getModel("SchemeItems").setProperty("/" + idx + "/PayoutAmount", "0");
			}
			var PayoutAmount = oEvent.getSource().getBindingContext("SchemeItems").getModel().getProperty("/" + idx + "/PayoutAmount");
			item[idx].PayoutPerc = parseFloat(item[idx].PayoutPerc);
			item[idx].PayoutAmount = parseFloat(item[idx].PayoutAmount);
			if (parseFloat(PayoutAmount) > 0) {
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutAmountValueState", "None");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutAmountValueStateText", "");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutPercValueState", "None");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().setProperty("/" + idx + "/PayoutPercValueStateText", "");
				oEvent.getSource().getBindingContext("SchemeItems").getModel().refresh();
			}
			for (var i = 0; i < item.length; i++) {
				if (!gSchemeDetails.PayoutAmntFound) {
					if (parseFloat(item[i].PayoutPerc) === 0 && parseFloat(item[i].PayoutAmount) !== 0) {
						gSchemeDetails.PayoutAmntFound = true;
					}
				}
			}
			if (gSchemeDetails.PayoutAmntFound) {
				gSchemeDetails.PayoutPercFound = false;
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", false);
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", true);
			} else {
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", true);
				this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", true);
			}
		},
		getNewItemEntry: function (isBasket, ItemNo, ItemCatID) {
			gSchemeDetails.PayoutPercFound = false;
			gSchemeDetails.PayoutAmntFound = false;
			var newItem = {
				"AllocatedFund": 0,
				"AmountPerUnit": 0,
				"ARPAmount": 0,
				"BannerDesc": "",
				"BannerID": "",
				"BasketUOMID": "",
				"BasketUOMDesc": "",
				"BranchDesc": "",
				"BranchID": "",
				"BrandDesc": "",
				"BrandID": "",
				"BTAmount": 0,
				"PayoutAmount": "0",
				"PayoutPerc": "0",
				"ChangedAt": "PT00H00M00S",
				"ChangedBy": "",
				"ChangedOn": null,
				"City": "",
				"CreatedAt": "PT18H57M31S",
				"CreatedBy": "",
				"CreatedOn": null,
				"Currency": this.getView().getModel("Schemes").getProperty("/CurrencyID"),
				"CustomerName": "",
				"CustomerNo": "",
				"Envoucher": "",
				"ETPerc": 0,
				"SubBrand": "",
				"SubBrandDesc": "",
				"ExternalRefID": "",
				"ExternalRefKey": "",
				"HierarchicalRefGUID": null,
				"IsStockQty": "",
				"ItemCatDesc": "",
				"ItemCatID": ItemCatID,
				"ItemMin": 0,
				"ItemNo": ItemNo,
				"LoginID": "",
				"MaterialDesc": "",
				"MaterialGroupDesc": "",
				"MaterialGroupID": "",
				"MaterialNo": "",
				"MaterialSeriesDesc": "",
				"MaterialSeriesID": "",
				"MFDFrom": null,
				"MFDTo": null,
				"ExpDateFrom": null,
				"ExpDateTo": null,
				"MRP": 0,
				"OctroiAmount": 0,
				"OnSaleOfAttributeDesc": "",
				"OnSaleOfAttributeID": "",
				"OnSaleOfCatDesc": "",
				"OnSaleOfCatID": "",
				"OnSaleOfItemUOMID": "",
				"OnSaleOfItemUOMDesc": "",
				"OrderMaterialGroupDesc": "",
				"OrderMaterialGroupID": "",
				"OtherStateVAT": 0,
				"Partner": "",
				"PayoutPerPoint": 0,
				"PercMonthTarget": "0.00",
				"PointsPerUnit": 0,
				"PRCode": "",
				"PreviousPrice": 0,
				"ProductCatDesc": "",
				"ProductCatID": "",
				"PurchasingGroupDesc": "",
				"PurchasingGroupID": "",
				"QtyToBeBilled": 0,
				"RatePerQty": 0,
				"RevisedPrice": 0,
				"RSIAmount": 0,
				"Rule": "",
				"SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID"),
				"SchemeItemGUID": oPPCCommon.generateUUID(),
				"SeriesGroup": "",
				"SKUGroupDesc": "",
				"SKUGroupID": "",
				"Source": "",
				"SPCPrice": 0,
				"SpecialSPCPrice": 0,
				"StateVATPerc": 0,
				"StockCat": "",
				"StockLogic": "",
				"StockQtyDesc": "",
				"StockQtyID": "0.00",
				"TargetQty": 0,
				"TargetValue": 0,
				"TransactionBaseDesc": "",
				"TransactionBaseID": "",
				"UnitAmount": "0",
				"UOM": this.getView().getModel("Schemes").getProperty("/UOM"),
				"ValidFrom": null,
				"ValidTo": null,
				"isBasket": isBasket,
				"BasketState": "#000",
				"scMaterialTokens": []
			};
			if (isBasket) {
				newItem.results = [];
			}
			return newItem;
		},
		onChangeSubBrand: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			var SSInvoiceItem = this.getView().getModel("SubBrandDD");
			var aItems = SSInvoiceItem.getProperty("/");
			var bKeyFound = false;
			var bTextFound = false;
			var enteredVal = oEvent.getParameter("value");
			var enteredValId = enteredVal.split("-")[0].trim();
			var enteredText = "";
			var index = oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/");
			var oPath = index[1];
			var BasketPath = index[3];
			var itemNo = "";
			if (BasketPath) {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].root[BasketPath].ItemNo;
			} else {
				itemNo = oEvent.getSource().getBindingContext("SchemeItems").getModel().getData()[oPath].ItemNo;
			}
			for (var j = enteredVal.split("-").length - 1; j >= 1; j--) {
				enteredText = enteredVal.split("-")[j] + "-" + enteredText;
			}
			if (enteredText) {
				enteredText = enteredText.substring(0, enteredText.length - 1).trim();
			}
			for (var i = 0; i < aItems.length; i++) {
				if (enteredValId) {
					if (aItems[i].Key.trim() === enteredValId) {
						bKeyFound = true;
						if (aItems[i].Text.trim() === enteredText) {
							bTextFound = true;
							break;
						}
					}
				}
			}
			if (!bKeyFound || !bTextFound) {
				if (enteredVal) {
					var msg = "Please Enter Valid Sub Brand for Item No #" + itemNo;
					oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/fOrderMaterialGroupIDEditSI");
					oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					if (BasketPath) {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/root/" + BasketPath + "/SubBrand", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/root/" + BasketPath + "/SubBrandDesc", "");
						oEvent.getSource().setSelectedKey("");
					} else {
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/SubBrand", "");
						that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/SubBrandDesc", "");
						oEvent.getSource().setSelectedKey("");
					}
				}
			} else {
				if (BasketPath) {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/root/" + BasketPath + "/SubBrandDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/root/" + BasketPath + "/SubBrand", enteredValId);
				} else {
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/SubBrandDesc", enteredText);
					that.getView().getModel("SchemeItems").setProperty("/" + oPath + "/SubBrand", enteredValId);
				}
			}
		},
		generateMainItemNo: function (aItems, iIncreament) {
			var sItemNo = "";
			if (aItems.isBasket) {
				if (aItems.results && aItems.results.length > 0) {
					aItems = aItems.results;
					var lastItemNo = aItems[aItems.length - 1].ItemNo;
					if (lastItemNo && !isNaN(lastItemNo)) {
						iIncreament = parseInt(lastItemNo) + iIncreament;
					}
				} else {
					iIncreament = parseInt(aItems.ItemNo) + iIncreament;
				}
			} else if (aItems && aItems.length > 0) {
				lastItemNo = aItems[aItems.length - 1].ItemNo;
				if (lastItemNo && !isNaN(lastItemNo)) {
					iIncreament = parseInt(lastItemNo) + iIncreament;
				}
			}
			if (iIncreament < 10) {
				sItemNo = "0000" + iIncreament;
			} else if (iIncreament < 100) {
				sItemNo = "000" + iIncreament;
			} else if (iIncreament < 1000) {
				sItemNo = "00" + iIncreament;
			} else if (iIncreament < 10000) {
				sItemNo = "0" + iIncreament;
			}
			return sItemNo;
		},
		handleMaterialSuggest: function (oEvent) {
			oPPCCommon.handleSuggest({
				oEvent: oEvent,
				aProperties: [
					"Key",
					"Text"
				],
				sBinding: "suggestionItems"
			});
		},
		suggestionItemSelected: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var that = this;
			that.MaterialTokenInput = oEvent.getSource();
			var SSInvoiceItem = this.getView().getModel("SchemeItems");
			var aItems = SSInvoiceItem.getProperty("/");
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeItems");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionItemSelected({
				oEvent: oEvent,
				thisController: this,
				sModelName: "MaterialDD",
				sKey: "Key",
				sDescription: "Text"
			}, function (key, desc, jData) {
				if (jData) {
					var bValidMaterial = that.validateMaterial(jData, oEvent.getSource(), itemIndex);
					if (bValidMaterial) {
						that.setSelectedMaterialToTable(jData, oBindingContext, aItems, itemIndex);
					} else {
						that.MaterialTokenInput.removeAllTokens();
						that.MaterialTokenInput.setValue(jData.MaterialNo);
						that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
							.getData().length);
						oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
					}
				}
			});
		},
		onChangeMaterial: function (oEvent) {
			var index = oEvent.getSource().getId().slice(-1);
			var itemIndex = parseInt(index);
			var that = this;
			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			var SSInvoiceItem = this.getView().getModel("SchemeItems");
			var aItems = SSInvoiceItem.getProperty("/");
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeItems");
			var sPath = oBindingContext.getPath();
			var itemIndex = parseInt(sPath.split("/")[1]);
			oPPCCommon.suggestionOnChange({
				oEvent: oEvent,
				thisController: this,
				sModelName: "MaterialDD",
				sKey: "Key",
				sDescription: "Text"
			}, function (enteredVal, bFound, key, desc, jData) {
				if (enteredVal !== "") {
					if (bFound) {
						if (jData) {
							var bValidMaterial = that.validateMaterial(jData, oEvent.getSource(), itemIndex);
							if (bValidMaterial) {
								that.setSelectedMaterialToTable(jData, oBindingContext, aItems, itemIndex);
							} else {
								that.MaterialTokenInput.removeAllTokens();
								that.MaterialTokenInput.setValue(jData.MaterialNo);
								that.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
									.getData().length);
								oPPCCommon.showMessagePopover(gSchemeDetails.byId("ObjectPageLayout"));
							}
						}
					}
				}
			});
		},
		suggestionMaterialItemSelected: function (oEvent) {
			var selectedObject = oEvent.getParameter("selectedItem").getBindingContext("MaterialDD").getObject();
			selectedObject.ID = selectedObject.Key;
			selectedObject.Description = selectedObject.Text;
			selectedObject.isNew = true;
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var aItem = this.getView().getModel("SchemeItems").getProperty(path);
			var scTotalToken = aItem.scMaterialTokens;
			scTotalToken.push(selectedObject);
			this.setSelectedMaterialToTable(scTotalToken, path);
		},
		handleMaterialTokenRemove: function (oEvent) {
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var type = oEvent.getParameter("type");
			if (type === "removed") {
				var jData = [];
				var tokens = oEvent.getSource().getTokens();
				tokens.forEach(function (eachToken) {
					jData.push(eachToken.getBindingContext("SchemeItems").getObject());
				});
				this.setSelectedMaterialToTable(jData, path);
			}
		},
		setValueHelp: function (mParameters, requestCompleted) {
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.title,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.aKeys[0],
				descriptionKey: mParameters.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					if (requestCompleted) {
						requestCompleted(oControlEvent);
					}
					oValueHelpDialog.close();
				},
				cancel: function () {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			oSSCommonValueHelp.setValueHelpColumns(oValueHelpDialog, mParameters);
			oSSCommonValueHelp.setValueHelpFilterBar(oValueHelpDialog, mParameters);
			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}
			oValueHelpDialog.open();
		},
		MaterialNoF4: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			this.aMaterialKeys = [
				"ID",
				"Description"
			];
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/")[1]);
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var itemIndex = parseInt(index);
			var SSInvoiceItem = this.getView().getModel("SchemeItems");
			var aItems = SSInvoiceItem.getProperty("/");
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeItems");
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			this.setValueHelp({
				title: "Material",
				oController: this,
				controlID: "inputMaterial",
				idLabel: oi18n.getText("SchemeItemsBlock.ValueHelp.Material"),
				descriptionLabel: oi18n.getText("SchemeItemsBlock.ValueHelp.MaterialName"),
				oUtilsI18n: oUtilsI18n,
				modelID: "SCGW",
				entityType: "SchemeItemDetail",
				propName: "Material",
				tokenInput: this.MaterialTokenInput,
				aKeys: this.aMaterialKeys,
				defaultVisible: false,
				bMultiSelect: true,
				idVisible: true,
				groupTitle: "Material",
				fireOnLoad: false
			}, function (oControlEvent) {
				var jData = [];
				var tokens = oControlEvent.getParameter("tokens");
				tokens.forEach(function (eachToken) {
					jData.push(eachToken.getCustomData()[0].getValue());
				});
				jData.forEach(function (jdataToken) {
					jdataToken.isNew = true;
				});
				that.setSelectedMaterialToTable(jData, path);
			});
		},
		validateMaterial: function (jData, oMaterial, itemIndex) {
			oMaterial.setValueState(sap.ui.core.ValueState.None);
			oMaterial.setValueStateText("");
			oPPCCommon.removeMsgsInMsgMgrById("/UI/MaterialNo");
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			var bValidMaterial = true;
			var MaterialNo = jData.MaterialNo;
			if (MaterialNo) {
				var SSInvoiceItem = this.getView().getModel("SchemeItems");
				var aItems = SSInvoiceItem.getProperty("/");
				aItems[itemIndex].MaterialNo = jData.MaterialNo;
				for (var i = 0; i < aItems.length; i++) {
					if (itemIndex !== i) {
						if (aItems[i].MaterialNo === MaterialNo) {
							bValidMaterial = false;
							break;
						}
					}
				}
			}
			if (!bValidMaterial) {
				oMaterial.setValueState(sap.ui.core.ValueState.Error);
				var msg = oi18n.getText("SchemeItemsBlock.Message.MaterialRepeat");
				oMaterial.setValueStateText(msg);
				oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/MaterialNo");
			}
			return bValidMaterial;
		},
		setSelectedMaterialToTable: function (jData, path) {
			var aItem = this.getView().getModel("SchemeItems").getProperty(path);
			aItem.scMaterialTokens = jData;
			this.getView().getModel("SchemeItems").setProperty(path, aItem);
		},

		setValueHelpBrand: function (mParameters, requestCompleted) {
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.title,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.aKeys[0],
				descriptionKey: mParameters.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					if (requestCompleted) {
						requestCompleted(oControlEvent);
					}
					oValueHelpDialog.close();
				},
				cancel: function () {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			this.BrandF4FilterBar(oValueHelpDialog, mParameters);
			this.BrandF4Columns(oValueHelpDialog, mParameters);
			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}
			oValueHelpDialog.open();
		},

		BrandNoF4: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			this.aMaterialKeys = [
				"BrandID",
				"BrandDesc"
			];
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/")[1]);
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var itemIndex = parseInt(index);
			var SSInvoiceItem = this.getView().getModel("SchemeItems");
			var aItems = SSInvoiceItem.getProperty("/");
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeItems");
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			this.setValueHelpBrand({
				title: "Brand",
				oController: this,
				controlID: "fBrandIDEdit",
				idLabel: oi18n.getText("SchemeItemsBlock.ValueHelp.Material"),
				descriptionLabel: oi18n.getText("SchemeItemsBlock.ValueHelp.MaterialName"),
				oUtilsI18n: oUtilsI18n,
				modelID: "SCGW",
				entityType: "SchemeItemDetail",
				propName: "BrandID",
				tokenInput: this.MaterialTokenInput,
				aKeys: this.aMaterialKeys,
				defaultVisible: false,
				bMultiSelect: true,
				idVisible: true,
				groupTitle: "Material",
				fireOnLoad: false
			}, function (oControlEvent) {
				var jData = [];
				var tokens = oControlEvent.getParameter("tokens");
				tokens.forEach(function (eachToken) {
					jData.push(eachToken.getCustomData()[0].getValue());
				});
				jData.forEach(function (jdataToken) {
					jdataToken.isNew = true;
				});
				that.setSelectedMaterialToTable(jData, path);
			});
		},

		setValueHelpProduct: function (mParameters, requestCompleted) {
			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
				basicSearchText: mParameters.tokenInput.getValue(),
				title: mParameters.title,
				supportMultiselect: mParameters.bMultiSelect,
				supportRanges: false,
				supportRangesOnly: false,
				key: mParameters.aKeys[0],
				descriptionKey: mParameters.aKeys[1],
				stretch: sap.ui.Device.system.phone,
				ok: function (oControlEvent) {
					if (requestCompleted) {
						requestCompleted(oControlEvent);
					}
					oValueHelpDialog.close();
				},
				cancel: function () {
					oValueHelpDialog.close();
				},
				afterClose: function () {
					oValueHelpDialog.destroy();
				}
			});
			this.ProductF4FilterBar(oValueHelpDialog, mParameters);
			this.ProductF4Columns(oValueHelpDialog, mParameters);
			if (sap.ui.Device.support.touch === false) {
				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
			}
			oValueHelpDialog.open();
		},

		ProductNoF4: function (oEvent) {
			var that = this;
			oPPCCommon.removeAllMsgs();
			that.MaterialTokenInput = oEvent.getSource();
			if (!this.MaterialTokenInput.getValue()) {
				this.MaterialTokenInput.setValueState(sap.ui.core.ValueState.None);
				this.MaterialTokenInput.setValueStateText("");
			}
			this.aMaterialKeys = [
				"ProductCatID",
				"ProductCatDesc"
			];
			var index = oEvent.getSource().getId().slice(-1);
			index = parseInt(oEvent.getSource().getBindingContext("SchemeItems").getPath().split("/")[1]);
			var path = oEvent.getSource().getBindingContext("SchemeItems").getPath();
			var itemIndex = parseInt(index);
			var SSInvoiceItem = this.getView().getModel("SchemeItems");
			var aItems = SSInvoiceItem.getProperty("/");
			var oBindingContext = oEvent.getSource().getBindingContext("SchemeItems");
			oPPCCommon.removeAllMsgs();
			oPPCCommon.hideMessagePopover();
			this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel()
				.getData().length);
			this.setValueHelpProduct({
				title: "Product",
				oController: this,
				controlID: "fProductCatIDEdit",
				idLabel: "ProductCat ID",
				descriptionLabel: "ProductCat Desc",
				oUtilsI18n: oUtilsI18n,
				modelID: "SCGW",
				entityType: "SchemeItemDetail",
				propName: "ProductCatID",
				tokenInput: this.MaterialTokenInput,
				aKeys: this.aMaterialKeys,
				defaultVisible: false,
				bMultiSelect: true,
				idVisible: true,
				groupTitle: "Material",
				fireOnLoad: false
			}, function (oControlEvent) {
				var jData = [];
				var tokens = oControlEvent.getParameter("tokens");
				tokens.forEach(function (eachToken) {
					jData.push(eachToken.getCustomData()[0].getValue());
				});
				jData.forEach(function (jdataToken) {
					jdataToken.isNew = true;
				});
				that.setSelectedMaterialToTable(jData, path);
			});
		},

		// 		BrandF4: function (oEvent) {
		// 			debugger;
		// 			var that = this;
		// 			var tokenTextLength = that.getView().getModel("LocalViewSetting").getProperty("/tokenTextLength");
		// 			if (!this.getView().getModel("SchemeTypeDD")) {
		// 				var oModelData = this._oComponent.getModel("PCGW");
		// 				var oSchemeTypeFilter = new Array();
		// 				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "ModelID", sap.ui.model.FilterOperator
		// 					.EQ, ["SCGW"], true, false, false);
		// 				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "EntityType", sap.ui.model.FilterOperator
		// 					.EQ, ["SchemeItemDetail"], false, false, false);
		// 				oSchemeTypeFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oSchemeTypeFilter, "PropName", sap.ui.model.FilterOperator
		// 					.EQ, ["BrandID"], false, false, false);
		// 				oProductCommon.getDropdown(oModelData, "SchemeItemDetails", oSchemeTypeFilter, "BrandID", "BrandDesc", BusyDialog, this.getView(),
		// 					"SchemeTypeDD", "",
		// 					function () {
		// 						that.BrandDataF4({
		// 							oController: that,
		// 							oi18n: oi18n,
		// 							oUtilsI18n: oUtilsI18n,
		// 							controlID: "fBrandIDEdit",
		// 							bCPTypeText: true,
		// 							bCPGUIDKey: true,
		// 							bApprovedNTRequired: true
		// 						}, function (oTokens) {
		// 							oTokens.forEach(function (eachElement) {
		// 								eachElement.mProperties.text = that.TextAbstract(eachElement.getTooltip().split("(")[0].trim(), eachElement.mProperties.key,
		// 									tokenTextLength);
		// 							});
		// 							// 			that.getView().byId("inputCreatedOnDate").setSelectedKey("");
		// 							// 			that.CreatedOnDate.FromDate = null;
		// 							// 			that.CreatedOnDate.ToDate = null;
		// 						});
		// 					});
		// 			} else {
		// 				that.BrandDataF4({
		// 					oController: this,
		// 					oi18n: oi18n,
		// 					oUtilsI18n: oUtilsI18n,
		// 					controlID: "fBrandIDEdit",
		// 					bCPTypeText: true,
		// 					bCPGUIDKey: true,
		// 					bApprovedNTRequired: true
		// 				}, function (oTokens) {
		// 					oTokens.forEach(function (eachElement) {
		// 						eachElement.mProperties.text = that.TextAbstract(eachElement.getTooltip().split("(")[0].trim(), eachElement.mProperties.key,
		// 							tokenTextLength);
		// 					});
		// 					// 	that.getView().byId("inputCreatedOnDate").setSelectedKey("");
		// 					// 	that.CreatedOnDate.FromDate = null;
		// 					// 	that.CreatedOnDate.ToDate = null;
		// 				});
		// 			}
		// 		},

		// 		BrandDataF4: function (mParameters, requestCompleted) {
		// 			var that = this;
		// 			if (mParameters.bMultiSelect === undefined || mParameters.bMultiSelect === null) {
		// 				mParameters.bMultiSelect = true;
		// 			}
		// 			var sF4Heading = "";
		// 			// 			if (mParameters.si18nPropertyName) {
		// 			// 				sF4Heading = mParameters.oi18n.getText(mParameters.si18nPropertyName + ".Header");
		// 			// 			} else {
		// 			// 				sF4Heading = mParameters.oi18n.getText("ValueHelp.Scheme.Header");
		// 			// 			}
		// 			sF4Heading = oPPCCommon.getLableFromMetadata({
		// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
		// 				sEntityType: "SchemeItemDetail",
		// 				sPropertyName: "BrandID",
		// 				oUtilsI18n: mParameters.oUtilsI18n
		// 			});

		// 			var oValueHelpDialog = new sap.ui.comp.valuehelpdialog.ValueHelpDialog({
		// 				basicSearchText: mParameters.oController.oSchemeTokenInput.getValue(),
		// 				title: sF4Heading,
		// 				supportMultiselect: mParameters.bMultiSelect,
		// 				supportRanges: false,
		// 				supportRangesOnly: false,
		// 				key: mParameters.oController.aSchemeKeys[0],
		// 				descriptionKey: mParameters.oController.aSchemeKeys[1],
		// 				stretch: sap.ui.Device.system.phone,
		// 				ok: function (oControlEvent) {
		// 					var tokens = oControlEvent.getParameter("tokens");
		// 					if (mParameters.bCPGUIDKey) {
		// 						var oToken = tokens;
		// 						var sText = "";
		// 						for (var i = 0; i < oToken.length; i++) {
		// 							var Text1 = oToken[i].mProperties.text.split("(")[0].trim();
		// 							sText = oToken[i].getCustomData()[0].mProperties.value.BrandID;
		// 							oToken[i].mProperties.text = sText + " (" + Text1 + ")";
		// 							oToken[i].setTooltip(sText + " (" + Text1 + ")");
		// 						}
		// 						//this.getView().byId("inputInvoiceNo").setTokens(oToken);
		// 						mParameters.oController.oSchemeTokenInput.setTokens(oToken);
		// 						mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
		// 						mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
		// 					} else {
		// 						mParameters.oController.oSchemeTokenInput.setTokens(oControlEvent.getParameter("tokens"));
		// 						mParameters.oController.getView().byId(mParameters.controlID).setValueState(sap.ui.core.ValueState.None);
		// 						mParameters.oController.getView().byId(mParameters.controlID).setValueStateText("");
		// 						oPPCCommon.removeMsgsInMsgMgrByMsgCode(mParameters.controlID);
		// 						var tokens = oControlEvent.getParameter("tokens");
		// 						mParameters.oController.oSchemeTokenInput.removeAllTokens();
		// 						mParameters.oController.oSchemeTokenInput.setValue("");
		// 						var aToken = [];
		// 						for (var j = 0; j < tokens.length; j++) {
		// 							if (tokens[j] && tokens[j].getCustomData() && tokens[j].getCustomData().length >= 0) {
		// 								var sDesc = tokens[j].getCustomData()[0].getValue().SchemeID + " (" + tokens[j].getCustomData()[0].getValue().SchemeName +
		// 									")";
		// 								aToken.push(new sap.m.Token({
		// 									key: tokens[j].getCustomData()[0].getValue().SchemeGUID,
		// 									text: sDesc
		// 								}));
		// 							}
		// 						}
		// 						mParameters.oController.oSchemeTokenInput.setTokens(aToken);
		// 					}

		// 					if (requestCompleted) {
		// 						requestCompleted(tokens);
		// 					}
		// 					oValueHelpDialog.close();
		// 				},
		// 				cancel: function (oControlEvent) {
		// 					oValueHelpDialog.close();
		// 				},
		// 				afterClose: function () {
		// 					oValueHelpDialog.destroy();
		// 				}
		// 			});

		// 			if (mParameters.showSelectedItemPanel === undefined || mParameters.showSelectedItemPanel) {
		// 				oPPCCommon.setVHSelectedItemAreaVisibility({
		// 					oValueHelpDialog: oValueHelpDialog
		// 				});
		// 			}
		// 			that.BrandF4Columns(oValueHelpDialog, mParameters);
		// 			that.BrandF4FilterBar(oValueHelpDialog, mParameters);

		// 			if (sap.ui.Device.support.touch === false) {
		// 				oValueHelpDialog.addStyleClass("sapUiSizeCompact");
		// 			}

		// 			oValueHelpDialog.open();
		// 			if (mParameters.oController.oSchemeTokenInput) {
		// 				oValueHelpDialog.setTokens(mParameters.oController.oSchemeTokenInput.getTokens());
		// 			}
		// 		},

		BrandF4FilterBar: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var SchemesType = "";

			var SchemeNoLabel = "",
				SchemeNameLabel = "",
				SchemesTypeLabel = "";

			SchemeNoLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "BrandDesc",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "BrandID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			// 			SchemeNameLabel = oPPCCommon.getLableFromMetadata({
			// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
			// 				sEntityType: "Scheme",
			// 				sPropertyName: "SchemeName",
			// 				oUtilsI18n: mParameters.oUtilsI18n
			// 			});
			// 			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
			// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
			// 				sEntityType: "Scheme",
			// 				sPropertyName: "SchemeTypeID",
			// 				oUtilsI18n: mParameters.oUtilsI18n
			// 			});
			// initialising the filter group items
			var SchemeTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "gn2",
				name: "n6",
				label: "",
				control: new sap.m.Text({
					text: ""
				})
			});
			var oTokenInputValue = "";
			if (mParameters.oController.oSchemeTokenInput) {
				oTokenInputValue = mParameters.oController.oSchemeTokenInput.getValue();
			}
			var code = new sap.m.Input({
				value: {
					path: "BrandF4FilterBar>/BrandID",
					type: 'sap.ui.model.type.String'
				},

				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SCGW"),
					sEntityType: "SchemeItemDetail",
					sPropertyName: "BrandID",
					oUtilsI18n: mParameters.oUtilsI18n
				})
			});
			code.attachValidationError(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setValueState("Error");
				if (oElement.getValue().trim() === "") {
					oElement.setTooltip("");
					oElement.setValueState("None");
				}
			});
			code.attachValidationSuccess(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setTooltip("");
				oElement.setValueState("None");
			});
			var SchemeName = new sap.m.Input({
				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SCGW"),
					sEntityType: "SchemeItemDetail",
					sPropertyName: "BrandDesc",
					oUtilsI18n: mParameters.oUtilsI18n
				})

			});
			//if (mParameters.bSchemesType !== undefined && mParameters.bSchemesType !== "") {
			// mParameters.bSchemesType=true;
			//	if (mParameters.bSchemesType) {
			var oSchemesTypeItemTemplate = new sap.ui.core.Item({
				key: "{Key}",
				text: "{Key}{Seperator}{Text}",
				tooltip: "{Key}{Seperator}{Text}"
			});
			SchemesType = new sap.m.MultiComboBox({
				items: {
					path: "/",
					template: oSchemesTypeItemTemplate
				}
			});
			SchemesType.setModel(mParameters.oController.getView().getModel("BrandDD"));
			SchemeTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "gn2",
				name: "n4",
				label: SchemesTypeLabel,
				control: SchemesType
			});

			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					// 	new sap.ui.comp.filterbar.FilterGroupItem({
					// 		groupName: "gn1",
					// 		name: "n1",
					// 		label: parentlabel,
					// 		control: SchemeParentValue
					// 	}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn1",
						name: "n2",
						label: SchemeNoLabel,
						control: code
					}),
					// 	new sap.ui.comp.filterbar.FilterGroupItem({
					// 		groupName: "gn1",
					// 		name: "n3",
					// 		label: SchemeNameLabel,
					// 		control: SchemeName
					// 	}),
					SchemeTypeFilter
				],
				search: function (oEvent) {
					var codeValue = code.getValue();
					var SchemeNameValue = SchemeName.getValue();
					var isCPNoValid = true;
					if (isCPNoValid) {
						var aSchemesF4Filter = new Array();
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemesF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
							sServiceName: "SchemeItemDetail",
							sRequestType: "read"
						})], false, false, false);
						/*var customer = "";
						if (mParameters.bCustomerDD) {
							customer = SchemeParentValue.getSelectedKey();
						} else {
							customer = mParameters.sCPParentCode;
						}*/
						/*aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "VendorCode",
							sap.ui.model
							.FilterOperator.EQ, [customer], false, false, false);*/

						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "BrandID",
							"", [
								codeValue
							], false, false, false);
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "BrandDesc",
							"", [
								SchemeNameValue
							], false, false, false);
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter,
							"BrandDD", sap.ui
							.model.FilterOperator.EQ, SchemesType.getSelectedKeys(), true, false, false);

						var SCGWModel = mParameters.oController._oComponent.getModel("SCGW");
						SCGWModel.attachRequestSent(function () {
							busyDialog.open();
						});
						SCGWModel.attachRequestCompleted(function () {
							busyDialog.close();
						});
						SCGWModel.read("/SchemeItemDetails", {
							filters: aSchemesF4Filter,
							success: function (oData) {
								var oSchemesModel = new sap.ui.model.json.JSONModel();
								if (oValueHelpDialog.getTable().bindRows) {
									oValueHelpDialog.getTable().clearSelection();
									oSchemesModel.setData(oData.results);
									oValueHelpDialog.getTable().setModel(oSchemesModel);
									oValueHelpDialog.getTable().bindRows("/");
									if (oData.results.length === 0) {
										oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									}
								} else {
									var oRowsModel = new sap.ui.model.json.JSONModel();
									oRowsModel.setData(oData.results);
									oValueHelpDialog.getTable().setModel(oRowsModel);
									if (oValueHelpDialog.getTable().bindItems) {
										var oTable = oValueHelpDialog.getTable();
										oTable.bindAggregation("items", "/", function () {
											var aCols = oTable.getModel("columns").getData().cols;
											return new sap.m.ColumnListItem({
												cells: aCols.map(function (column) {
													var colname = column.template;
													return new sap.m.Text({
														text: "{" + colname + "}",
														wrapping: true
													});
												})
											});
										});
									}
									if (oData.results.length === 0) {
										oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									}
								}
								oValueHelpDialog.update();
							},
							error: function (error) {
								oValueHelpDialog.getTable().clearSelection();
								if (oValueHelpDialog.getTable().getModel() !== undefined) {
									oValueHelpDialog.getTable().getModel().setProperty("/", {});
								}
								oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
								oPPCCommon.dialogErrorMessage(error, "No Data Found");
							}
						});
					}
				},
				reset: function () {}
			}));
			var SchemeF4FilterBarMdl = new sap.ui.model.json.JSONModel();
			SchemeF4FilterBarMdl.setData({
				SchemeID: "",
				SchemeName: ""
			});
			oValueHelpDialog.setModel(SchemeF4FilterBarMdl, "SchemeF4FilterBar");
		},

		BrandF4Columns: function (oValueHelpDialog, mParameters) {
			var SchemeNoLabel = "",
				SchemeNameLabel = "",
				SchemesTypeLabel = "";

			SchemeNoLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "BrandID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemeNameLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "BrandDesc",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			// 			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
			// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
			// 				sEntityType: "Scheme",
			// 				sPropertyName: "SchemeTypeID",
			// 				oUtilsI18n: mParameters.oUtilsI18n
			// 			});

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
							label: SchemeNoLabel,
							template: "BrandID"
						}, {
							label: SchemeNameLabel,
							template: "BrandDesc"
						},
						// 	{
						// 		label: SchemesTypeLabel,
						// 		template: "SchemeTypeID",
						// 		demandPopin: true
						// 	}
					]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

				//Setting Visibility of Customer Column...................
				/*if (!mParameters.bCustomerDD) {
					if (mParameters.sCPParentCode === "") {
						oValueHelpDialog.getTable().getColumns()[3].setVisible(true);
					} else {
						oValueHelpDialog.getTable().getColumns()[3].setVisible(false);
					}
				}*/
			} else {

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemeNoLabel
					}),
					template: new sap.m.Text({
						text: "{BrandID}"
					}),
					sortProperty: "BrandID",
					filterProperty: "BrandID"
				}));
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemeNameLabel
					}),
					template: new sap.m.Text({
						text: "{BrandDesc}"
					}),
					sortProperty: "BrandDesc",
					filterProperty: "BrandDesc"
				}));

				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}
		},

		ProductF4FilterBar: function (oValueHelpDialog, mParameters) {
			var busyDialog = new sap.m.BusyDialog();
			var SchemesType = "";

			var SchemeNoLabel = "",
				SchemeNameLabel = "",
				SchemesTypeLabel = "";

			SchemeNoLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "ProductCatID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "ProductCatDesc",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			// 			SchemeNameLabel = oPPCCommon.getLableFromMetadata({
			// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
			// 				sEntityType: "Scheme",
			// 				sPropertyName: "SchemeName",
			// 				oUtilsI18n: mParameters.oUtilsI18n
			// 			});
			// 			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
			// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
			// 				sEntityType: "Scheme",
			// 				sPropertyName: "SchemeTypeID",
			// 				oUtilsI18n: mParameters.oUtilsI18n
			// 			});
			// initialising the filter group items
			var SchemeTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "gn2",
				name: "n6",
				label: "",
				control: new sap.m.Text({
					text: ""
				})
			});
			var oTokenInputValue = "";
			// 			if (mParameters.oController.oSchemeTokenInput) {
			// 				oTokenInputValue = mParameters.oController.oSchemeTokenInput.getValue();
			// 			}
			var code = new sap.m.Input({
				value: {
					path: "ProductF4FilterBar>/ProductCatID",
					type: 'sap.ui.model.type.String'
				},

				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SCGW"),
					sEntityType: "SchemeItemDetail",
					sPropertyName: "ProductCatID",
					oUtilsI18n: mParameters.oUtilsI18n
				})
			});
			code.attachValidationError(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setValueState("Error");
				if (oElement.getValue().trim() === "") {
					oElement.setTooltip("");
					oElement.setValueState("None");
				}
			});
			code.attachValidationSuccess(function (oEvent) {
				var oElement = oEvent.getParameter("element");
				oElement.setTooltip("");
				oElement.setValueState("None");
			});
			var SchemeName = new sap.m.Input({
				maxLength: oPPCCommon.getMaxLengthFromMetadata({
					oDataModel: mParameters.oController.getView().getModel("SCGW"),
					sEntityType: "SchemeItemDetail",
					sPropertyName: "ProductCatDesc",
					oUtilsI18n: mParameters.oUtilsI18n
				})

			});
			//if (mParameters.bSchemesType !== undefined && mParameters.bSchemesType !== "") {
			// mParameters.bSchemesType=true;
			//	if (mParameters.bSchemesType) {
			var oSchemesTypeItemTemplate = new sap.ui.core.Item({
				key: "{Key}",
				text: "{Key}{Seperator}{Text}",
				tooltip: "{Key}{Seperator}{Text}"
			});
			SchemesType = new sap.m.MultiComboBox({
				items: {
					path: "/",
					template: oSchemesTypeItemTemplate
				}
			});
			SchemesType.setModel(mParameters.oController.getView().getModel("ProductDD"));
			SchemeTypeFilter = new sap.ui.comp.filterbar.FilterGroupItem({
				groupName: "gn2",
				name: "n4",
				label: SchemesTypeLabel,
				control: SchemesType
			});

			oValueHelpDialog.setFilterBar(new sap.ui.comp.filterbar.FilterBar({
				advancedMode: true,
				filterGroupItems: [
					// 	new sap.ui.comp.filterbar.FilterGroupItem({
					// 		groupName: "gn1",
					// 		name: "n1",
					// 		label: parentlabel,
					// 		control: SchemeParentValue
					// 	}),
					new sap.ui.comp.filterbar.FilterGroupItem({
						groupName: "gn1",
						name: "n2",
						label: SchemeNoLabel,
						control: code
					}),
					// 	new sap.ui.comp.filterbar.FilterGroupItem({
					// 		groupName: "gn1",
					// 		name: "n3",
					// 		label: SchemeNameLabel,
					// 		control: SchemeName
					// 	}),
					SchemeTypeFilter
				],
				search: function (oEvent) {
					var codeValue = code.getValue();
					var SchemeNameValue = SchemeName.getValue();
					var isCPNoValid = true;
					if (isCPNoValid) {
						var aSchemesF4Filter = new Array();
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter("", "", aSchemesF4Filter, "LoginID", "", [oSSCommon.getCurrentLoggedUser({
							sServiceName: "SchemeItemDetail",
							sRequestType: "read"
						})], false, false, false);
						/*var customer = "";
						if (mParameters.bCustomerDD) {
							customer = SchemeParentValue.getSelectedKey();
						} else {
							customer = mParameters.sCPParentCode;
						}*/
						/*aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter, "VendorCode",
							sap.ui.model
							.FilterOperator.EQ, [customer], false, false, false);*/

						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter,
							"ProductCatID",
							"", [
								codeValue
							], false, false, false);
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter,
							"ProductCatDesc",
							"", [
								SchemeNameValue
							], false, false, false);
						aSchemesF4Filter = oPPCCommon.setODataModelReadFilter(mParameters.oController.getView(), "", aSchemesF4Filter,
							"ProductDD", sap.ui
							.model.FilterOperator.EQ, SchemesType.getSelectedKeys(), true, false, false);

						var SCGWModel = mParameters.oController._oComponent.getModel("SCGW");
						SCGWModel.attachRequestSent(function () {
							busyDialog.open();
						});
						SCGWModel.attachRequestCompleted(function () {
							busyDialog.close();
						});
						SCGWModel.read("/SchemeItemDetails", {
							filters: aSchemesF4Filter,
							success: function (oData) {
								var oSchemesModel = new sap.ui.model.json.JSONModel();
								if (oValueHelpDialog.getTable().bindRows) {
									oValueHelpDialog.getTable().clearSelection();
									oSchemesModel.setData(oData.results);
									oValueHelpDialog.getTable().setModel(oSchemesModel);
									oValueHelpDialog.getTable().bindRows("/");
									if (oData.results.length === 0) {
										oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									}
								} else {
									var oRowsModel = new sap.ui.model.json.JSONModel();
									oRowsModel.setData(oData.results);
									oValueHelpDialog.getTable().setModel(oRowsModel);
									if (oValueHelpDialog.getTable().bindItems) {
										var oTable = oValueHelpDialog.getTable();
										oTable.bindAggregation("items", "/", function () {
											var aCols = oTable.getModel("columns").getData().cols;
											return new sap.m.ColumnListItem({
												cells: aCols.map(function (column) {
													var colname = column.template;
													return new sap.m.Text({
														text: "{" + colname + "}",
														wrapping: true
													});
												})
											});
										});
									}
									if (oData.results.length === 0) {
										oValueHelpDialog.getTable().setNoDataText(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
									}
								}
								oValueHelpDialog.update();
							},
							error: function (error) {
								oValueHelpDialog.getTable().clearSelection();
								if (oValueHelpDialog.getTable().getModel() !== undefined) {
									oValueHelpDialog.getTable().getModel().setProperty("/", {});
								}
								oValueHelpDialog.getTable().setNoData(mParameters.oUtilsI18n.getText("common.NoResultsFound"));
								oPPCCommon.dialogErrorMessage(error, "No Data Found");
							}
						});
					}
				},
				reset: function () {}
			}));
			var SchemeF4FilterBarMdl = new sap.ui.model.json.JSONModel();
			SchemeF4FilterBarMdl.setData({
				SchemeID: "",
				SchemeName: ""
			});
			oValueHelpDialog.setModel(SchemeF4FilterBarMdl, "SchemeF4FilterBar");
		},

		ProductF4Columns: function (oValueHelpDialog, mParameters) {
			var SchemeNoLabel = "",
				SchemeNameLabel = "",
				SchemesTypeLabel = "";

			SchemeNoLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "ProductCatID",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			SchemeNameLabel = oPPCCommon.getLableFromMetadata({
				oDataModel: mParameters.oController.getView().getModel("SCGW"),
				sEntityType: "SchemeItemDetail",
				sPropertyName: "ProductCatDesc",
				oUtilsI18n: mParameters.oUtilsI18n
			});
			// 			SchemesTypeLabel = oPPCCommon.getLableFromMetadata({
			// 				oDataModel: mParameters.oController.getView().getModel("SCGW"),
			// 				sEntityType: "Scheme",
			// 				sPropertyName: "SchemeTypeID",
			// 				oUtilsI18n: mParameters.oUtilsI18n
			// 			});

			if (oValueHelpDialog.getTable().bindItems) {
				var oColModel = new sap.ui.model.json.JSONModel();
				oColModel.setData({
					cols: [{
							label: SchemeNoLabel,
							template: "ProductCatID"
						}, {
							label: SchemeNameLabel,
							template: "ProductCatDesc"
						},
						// 	{
						// 		label: SchemesTypeLabel,
						// 		template: "SchemeTypeID",
						// 		demandPopin: true
						// 	}
					]
				});
				oValueHelpDialog.getTable().setModel(oColModel, "columns");

				//Setting Visibility of Customer Column...................
				/*if (!mParameters.bCustomerDD) {
					if (mParameters.sCPParentCode === "") {
						oValueHelpDialog.getTable().getColumns()[3].setVisible(true);
					} else {
						oValueHelpDialog.getTable().getColumns()[3].setVisible(false);
					}
				}*/
			} else {

				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemeNoLabel
					}),
					template: new sap.m.Text({
						text: "{ProductCatID}"
					}),
					sortProperty: "ProductCatID",
					filterProperty: "ProductCatID"
				}));
				oValueHelpDialog.getTable().addColumn(new sap.ui.table.Column({
					label: new sap.m.Text({
						text: SchemeNameLabel
					}),
					template: new sap.m.Text({
						text: "{ProductCatDesc}"
					}),
					sortProperty: "ProductCatDesc",
					filterProperty: "ProductCatDesc"
				}));

				oValueHelpDialog.getTable().setNoData(
					mParameters.oUtilsI18n.getText("common.NoItemSelected"));
			}
		},
	});
});