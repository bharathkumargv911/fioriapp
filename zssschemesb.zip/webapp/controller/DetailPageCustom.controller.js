sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ss/schemes/util/SchemeFormatter",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"com/arteriatech/ppc/utils/js/Common",
	"com/arteriatech/prd/utils/js/Common"
], function (Controller, JSONModel, History) {
	"use strict";
	var oBusyDialog = new sap.m.BusyDialog();
	var oi18n, oUtilsI18n;
	var Device = sap.ui.Device;
	var oPPCCommon = com.arteriatech.ppc.utils.js.Common;
	var oProductCommon = com.arteriatech.ss.utils.js.Common;
	var oCommonValueHelp;
	var product = "PD";
	var contextPath = "";
	var HeaderData = [];
	var eZoneArray = [];
	var eRegionArray = [];
	var eAreaArray = [];
	var eHQArray = [];
	var eDepotArray = [];
	gRemarks = "";
	return sap.ui.controller("com.arteriatech.ss.schemes.zssschemesb.controller.DetailPageCustom", {
		//    onInit: function () {
		//        this.onInitHookUp();
		//    },
		//    onInitHookUp: function () {
		//        this._oView = this.getView();
		//        gSchemeDetails = this._oView;
		//        gObjectPageLayout = gSchemeDetails.byId("ObjectPageLayout");
		//        this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
		//        oProductCommon = com.arteriatech.ss.utils.js.Common;
		//        oCommonValueHelp = com.arteriatech.ss.utils.js.CommonValueHelp;
		//        oi18n = this._oComponent.getModel("i18n").getResourceBundle();
		//        oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
		//        this.setDefaultSettings();
		//        this.DynamicSideContent = this.getView().byId("ObjectPageLayout");
		//        this._oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		//        this._oRouter.attachRouteMatched(this.onRouteMatched, this);
		//        if (this.onInitHookUp_Exit) {
		//            this.onInitHookUp_Exit();
		//        }
		//    },
		//    onRouteMatched: function (oEvent) {
		//        if (oEvent.getParameter("name") !== "DetailPage" && oEvent.getParameter("name") !== "ChangePage" && oEvent.getParameter("name") !== "contractApprovedetail") {
		//            return;
		//        }
		//        oPPCCommon.removeAllMsgs();
		//        oPPCCommon.hideMessagePopover(this.DynamicSideContent);
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//        var oHistory = sap.ui.core.routing.History.getInstance();
		//        if (oEvent.getParameter("name") === "DetailPage") {
		//            this.setDefaultSettings();
		//            if (oPPCCommon.getFLPTileAction().split("&")[0] === "ApplicableSchemes") {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AplicableSchemes", true);
		//            }
		//            gSchemeDetails.setBusy(true);
		//            if (oHistory.getDirection() !== "Backwards") {
		//                contextPath = oEvent.getParameter("arguments").contextPath;
		//                this.getSchemeDetails();
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", true);
		//            } else {
		//                gSchemeDetails.setBusy(false);
		//            }
		//        } else if (oEvent.getParameter("name") === "contractApprovedetail") {
		//            this.setDefaultSettings();
		//            if (oPPCCommon.getFLPTileAction().split("&")[0] === "ApplicableSchemes") {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AplicableSchemes", true);
		//            }
		//            contextPath = oEvent.getParameter("arguments").contextPath;
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/ApproveHistory", true);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveButton", true);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/rejectButton", true);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editApproveButton", true);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editMode", false);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/detailMode", true);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editButton", false);
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveVisible", true);
		//            this.getSchemeDetails();
		//            this.getTasks();
		//        } else if (oHistory.getDirection() === "Unknown" && oEvent.getParameter("name") === "ChangePage") {
		//            contextPath = oEvent.getParameter("arguments").contextPath;
		//            this._oRouter.navTo("DetailPage", { contextPath: contextPath }, true);
		//        }
		//        var that = this;
		//        var oDataModel = this._oComponent.getModel("PUGW");
		//        oProductCommon.setODataModel(oDataModel);
		//        oProductCommon.getCustomerInputType(function (customerInputType) {
		//            that.sCustomerInputType = customerInputType;
		//            if (customerInputType === "DD") {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/CustomerDD", true);
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/CustomerVH", false);
		//            } else {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/CustomerDD", false);
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/CustomerVH", true);
		//            }
		//        });
		//    },
		//    onPrintPress: function () {
		//        var oDataModel = this.getView().getModel("SCGW");
		//        var sGuid = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
		//        oPPCCommon.PrintPDF({
		//            sServiceUrl: oDataModel.sServiceUrl + "/SchemeItemDetails(guid'" + sGuid + "')/$value",
		//            sApplication: "PD"
		//        });
		//    },
		//    getSchemeDetails: function () {
		//        var that = this;
		//        var view = this.getView();
		//        var oSSGW_MSTModel = view.getModel("SCGW");
		//        oSSGW_MSTModel.attachRequestCompleted(function () {
		//        });
		//        oSSGW_MSTModel.setHeaders({ "x-arteria-loginid": this.getCurrentUsers("ChannelPartners", "read") });
		//        var SchemeGUID = oPPCCommon.getPropertyValueFromContextPath(contextPath, "SchemeGUID");
		//        oSSGW_MSTModel.read("/Schemes(guid'" + SchemeGUID + "')", {
		//            urlParameters: { "$expand": "SchemeSalesAreas,SchemeHolds,SchemeGeographies,SchemeCPs,SchemeCostObjects,SchemeItemDetails,SchemeSlabs,SchemePartnerTypes,SchemePaymentModes" },
		//            success: function (oData) {
		//                if (oData.SchemeGeographies.results.length > 0) {
		//                    if (oData.SchemeGeographies.results[0].GeographyTypeID === "0000000005" || oData.SchemeGeographies.results[0].GeographyTypeDesc === "Depot") {
		//                        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AreaOrDepot", "Depots");
		//                    }
		//                }
		//                if (oData.SchemeSalesAreas.results.length > 0) {
		//                    for (var i = 0; i < oData.SchemeSalesAreas.results.length; i++) {
		//                        if (oData.SchemeSalesAreas.results[i].CPGroup1Desc === "") {
		//                            oData.SchemeSalesAreas.results[i].CPGroup1Desc = "(All)";
		//                        }
		//                        if (oData.SchemeSalesAreas.results[i].CPGroup2Desc === "" && oData.SchemeSalesAreas.results[i].CPGroup1Desc !== "(All)") {
		//                            oData.SchemeSalesAreas.results[i].CPGroup2Desc = "(All)";
		//                        }
		//                        if (oData.SchemeSalesAreas.results[i].CPGroup3Desc === "" && oData.SchemeSalesAreas.results[i].CPGroup2Desc !== "(All)" && oData.SchemeSalesAreas.results[i].CPGroup1Desc !== "(All)") {
		//                            oData.SchemeSalesAreas.results[i].CPGroup3Desc = "(All)";
		//                        }
		//                    }
		//                }
		//                that.setSchemeDetails(oData);
		//                that.SchemeHoldDetails(oData);
		//                that.getDocumentStore(that, function (DocumentStore) {
		//                    that.getContractDocumentss(DocumentStore);
		//                });
		//            },
		//            error: function (error) {
		//                gSchemeDetails.setBusy(false);
		//                that.handleoDataError(error);
		//            }
		//        });
		//        if (this.getRetailerDetails_Exit) {
		//            this.getRetailerDetails_Exit();
		//        }
		//    },
		//    getDocumentStore: function (oController, callback) {
		//        var that = this;
		//        var view = this.getView();
		//        var busyDialog = new sap.m.BusyDialog();
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oStatusFilter = new Array();
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(view, "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["PC"], false, false, false);
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(view, "", oStatusFilter, "Types", sap.ui.model.FilterOperator.EQ, ["DMSSTORE"], false, false, false);
		//        oPPCCommon.getDropdown(oModelData, "ConfigTypsetTypeValues", oStatusFilter, "TypeValue", "Types", busyDialog, this.getView(), "DocumentStore", "", function (aDDValue) {
		//            if (callback) {
		//                callback(aDDValue[0].Key);
		//            }
		//        });
		//    },
		//    SchemeHoldDetails: function (oData) {
		//        var oTasksItemsModel = new sap.ui.model.json.JSONModel();
		//        oTasksItemsModel.setData(oData.SchemeHolds.results);
		//        gHoldBlockView.setModel(oTasksItemsModel, "SchemeHold");
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/HoldCount", oData.SchemeHolds.results.length);
		//    },
		//    getContractDocumentss: function (DocumentStore) {
		//        var that = this;
		//        var SchemeDetails = gSchemeDetails;
		//        var view = this.getView();
		//        var controllerthis = this;
		//        var ContractDocumentsModel = view.getModel("SCGW");
		//        var LoginID = controllerthis.getCurrentUsers("SchemeDocuments", "read");
		//        ContractDocumentsModel.attachRequestSent(function () {
		//        });
		//        ContractDocumentsModel.attachRequestCompleted(function () {
		//        });
		//        ContractDocumentsModel.setHeaders({ "x-arteria-loginid": LoginID });
		//        ContractDocumentsModel.read("/SchemeDocuments", {
		//            filters: controllerthis.prepareContractDocumentsODataFilter(DocumentStore),
		//            success: function (oData) {
		//                if (oData.results.length > 0) {
		//                    var DocsModel = new sap.ui.model.json.JSONModel();
		//                    for (var i = 0; i < oData.results.length; i++) {
		//                        var sServiceURL = SchemeDetails.getModel("SCGW").sServiceUrl;
		//                        var SchemeGuid = "guid'" + oData.results[i].SchemeGUID + "'";
		//                        var sUrl = sServiceURL + "/SchemeDocuments(SchemeGUID=" + SchemeGuid + ",DocumentID='" + oData.results[i].DocumentID + "',DocumentStore='" + oData.results[i].DocumentStore + "')/$value";
		//                        oData.results[i].DocumentUrl = oPPCCommon.getDocumentURL({
		//                            sServiceUrl: sUrl,
		//                            sApplication: "PD"
		//                        });
		//                    }
		//                    DocsModel.setData(oData.results);
		//                    SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AttachmentCount", oData.results.length);
		//                    if (that._oComponent.getModel("SchemeCPDocuments")) {
		//                        that._oComponent.getModel("SchemeCPDocuments").setProperty("/", {});
		//                    }
		//                    that._oComponent.setModel(DocsModel, "SchemeCPDocuments");
		//                } else {
		//                    if (that._oComponent.getModel("SchemeCPDocuments")) {
		//                        that._oComponent.getModel("SchemeCPDocuments").setProperty("/", {});
		//                        SchemeDetails.getModel("LocalViewSettingDt1").setProperty("/AttachmentCount", 0);
		//                    }
		//                }
		//            },
		//            error: function (error) {
		//                if (that._oComponent.getModel("SchemeDocuments")) {
		//                    that._oComponent.getModel("SchemeDocuments").setProperty("/", {});
		//                }
		//            }
		//        });
		//    },
		//    prepareContractDocumentsODataFilter: function (DocumentStore) {
		//        var schemeGUID = gSchemeDetails.getModel("Schemes").getProperty("/SchemeGUID").toUpperCase();
		//        var that = this;
		//        var LoginID = this.getCurrentUsers("SchemeDocuments", "read");
		//        var view = this.getView();
		//        var oModelData = view.getModel("SCGW");
		//        var ContractDocumentsFilters = new Array();
		//        ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "LoginID", "", [LoginID], false, false, false);
		//        ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "SchemeGUID", sap.ui.model.FilterOperator.EQ, [schemeGUID], true, false, false);
		//        ContractDocumentsFilters = oPPCCommon.setODataModelReadFilter(this.getView(), "", ContractDocumentsFilters, "DocumentStore", sap.ui.model.FilterOperator.EQ, [DocumentStore], true, false, false);
		//        return ContractDocumentsFilters;
		//    },
		//    getTasks: function () {
		//        var that = this;
		//        var view = this.getView();
		//        var oPCGWModel = view.getModel("PCGW");
		//        oPCGWModel.attachRequestSent(function () {
		//        });
		//        oPCGWModel.attachRequestCompleted(function () {
		//        });
		//        oPCGWModel.setHeaders({ "x-arteria-loginid": this.getCurrentUsers("Tasks", "read") });
		//        oPCGWModel.read("/Tasks(InstanceID='" + oPPCCommon.getPropertyValueFromContextPath(contextPath, "InstanceID") + "',EntityType='SCM')", {
		//            urlParameters: { "$expand": "TaskDecisions,TaskHistorys" },
		//            success: function (oData) {
		//                that.setTasksData(oData);
		//            },
		//            error: function (error) {
		//                gSchemeDetails.setBusy(false);
		//                that.handleoDataError(error);
		//            }
		//        });
		//        if (this.getTasks_Exit) {
		//            this.getTasks_Exit();
		//        }
		//    },
		//    setTasksData: function (oData) {
		//        this.EntityKeyID = oData.EntityKeyID;
		//        this.setTaskDecisions(oData);
		//        this.setTaskHistorys(oData);
		//        if (this.setTasksData_Exit) {
		//            this.setTasksData_Exit();
		//        }
		//    },
		//    setTaskDecisions: function (oData) {
		//        var aTaskDecisions = oData.TaskDecisions.results;
		//        var oTaskDecisionsModel = new sap.ui.model.json.JSONModel();
		//        oTaskDecisionsModel.setData(oData.TaskDecisions.results);
		//        this._oComponent.setModel(oTaskDecisionsModel, "TaskDecisions");
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveButton", false);
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/rejectButton", false);
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editApproveButton", false);
		//        for (var i = 0; i < aTaskDecisions.length; i++) {
		//            if (aTaskDecisions[i].DecisionKey === "01") {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveButton", true);
		//                if (aTaskDecisions[i].DecisionType === "Positive") {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveButtonType", "Accept");
		//                } else if (aTaskDecisions[i].DecisionType === "Negative") {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveButtonType", "Reject");
		//                } else {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/approveButtonType", "Default");
		//                }
		//            }
		//            if (aTaskDecisions[i].DecisionKey === "02") {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/rejectButton", true);
		//                if (aTaskDecisions[i].DecisionType === "Positive") {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/rejectButtonType", "Accept");
		//                } else if (aTaskDecisions[i].DecisionType === "Negative") {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/rejectButtonType", "Reject");
		//                } else {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/rejectButtonType", "Default");
		//                }
		//            }
		//            if (aTaskDecisions[i].DecisionKey === "03") {
		//                gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editApproveButton", true);
		//                if (aTaskDecisions[i].DecisionType === "Positive") {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editApproveButtonType", "Accept");
		//                } else if (aTaskDecisions[i].DecisionType === "Negative") {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editApproveButtonType", "Reject");
		//                } else {
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/editApproveButtonType", "Default");
		//                }
		//            }
		//        }
		//        if (this.setTaskDecisions_Exit) {
		//            this.setTaskDecisions_Exit();
		//        }
		//    },
		//    setTaskHistorys: function (oData) {
		//        var oTaskHistorysModel = new sap.ui.model.json.JSONModel();
		//        oTaskHistorysModel.setData(oData.TaskHistorys.results);
		//        this._oComponent.setModel(oTaskHistorysModel, "TaskHistorys");
		//        if (this.setTaskHistorys_Exit) {
		//            this.setTaskHistorys_Exit();
		//        }
		//    },
		//    setSchemeDetails: function (oData) {
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/newBlockValidation", false);
		//        this.getFreeArticaleTS();
		//        this.getSchemeCatDD(oData);
		//        this.getScratchCardTS();
		//        var oSchemeSalesAreasModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeSalesAreas = oPPCCommon.formatItemsOData({ oData: oData.SchemeSalesAreas });
		//        for (var d = 0; d < oData.SchemeSalesAreas.length; d++) {
		//            delete oData.SchemeSalesAreas[d].__metadata;
		//        }
		//        oSchemeSalesAreasModel.setData(oData.SchemeSalesAreas);
		//        this._oComponent.setModel(oSchemeSalesAreasModel, "SchemeSalesAreas");
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSalesAreasCount", oData.SchemeSalesAreas.length);
		//        var oSchemePartnerTypesModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemePartnerTypes = oPPCCommon.formatItemsOData({ oData: oData.SchemePartnerTypes });
		//        this.partnerTypes = [];
		//        var desc = "";
		//        for (var v = 0; v < oData.SchemePartnerTypes.length; v++) {
		//            delete oData.SchemePartnerTypes[v].__metadata;
		//            this.partnerTypes.push(oData.SchemePartnerTypes[v].PartnerTypeID);
		//            desc = oData.SchemePartnerTypes[v].PartnerTypeDesc + "," + desc;
		//        }
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeApplicable", this.partnerTypes);
		//        oSchemePartnerTypesModel.setData(oData.SchemePartnerTypes);
		//        this._oComponent.setModel(oSchemePartnerTypesModel, "SchemePartnerTypes");
		//        if (desc !== "") {
		//            desc = desc.substring(0, desc.length - 1);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/PartnerType", desc);
		//        }
		//        var oSchemePaymentModesModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemePaymentModes = oPPCCommon.formatItemsOData({ oData: oData.SchemePaymentModes });
		//        this.SchemePaymentModes = [];
		//        var BillingModeDesc = "";
		//        for (var c = 0; c < oData.SchemePaymentModes.length; c++) {
		//            delete oData.SchemePaymentModes[c].__metadata;
		//            this.SchemePaymentModes.push(oData.SchemePaymentModes[c].PaymtModeKey);
		//            BillingModeDesc = oData.SchemePaymentModes[c].PaymtModeDsc + "," + BillingModeDesc;
		//        }
		//        oSchemePaymentModesModel.setData(oData.SchemePaymentModes);
		//        this._oComponent.setModel(oSchemePaymentModesModel, "SchemePaymentModes");
		//        if (BillingModeDesc !== "") {
		//            BillingModeDesc = BillingModeDesc.substring(0, BillingModeDesc.length - 1);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/PaymentMode", BillingModeDesc);
		//        }
		//        var oSchemeGeographysModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeGeographies = oPPCCommon.formatItemsOData({ oData: oData.SchemeGeographies });
		//        for (d = 0; d < oData.SchemeGeographies.length; d++) {
		//            delete oData.SchemeGeographies[d].__metadata;
		//        }
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeGeographiesCount", oData.SchemeGeographies.length);
		//        var SchemeGeographiesEditModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeGeographies = oPPCCommon.formatItemsOData({ oData: oData.SchemeGeographies });
		//        SchemeGeographiesEditModel.setData(oData.SchemeGeographies);
		//        for (var i = 0; i < oData.SchemeGeographies.length; i++) {
		//            oData.SchemeGeographies[i].Name = oData.SchemeGeographies[i].GeographyValueDesc;
		//        }
		//        this._oComponent.setModel(SchemeGeographiesEditModel, "SchemeGeographiesEdit");
		//        if (oData.SchemeGeographies[0].GeographyTypeID) {
		//            if (oData.SchemeGeographies[0].GeographyTypeID !== "0000000005") {
		//                oData.SchemeGeographies = this.formatGeography(oData.SchemeGeographies);
		//            }
		//        }
		//        oSchemeGeographysModel.setData(oData.SchemeGeographies);
		//        this._oComponent.setModel(oSchemeGeographysModel, "SchemeGeographies");
		//        gTempSchemeGeographiesBlock.byId("UISchemeGeographiesTable").expandToLevel(4);
		//        var oSchemeCPsModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeCPs = oPPCCommon.formatItemsOData({ oData: oData.SchemeCPs });
		//        oSchemeCPsModel.setData(oData.SchemeCPs);
		//        this._oComponent.setModel(oSchemeCPsModel, "SchemeCPs");
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeCPsCount", oData.SchemeCPs.length);
		//        var aDistributor = [];
		//        var aRetailer = [];
		//        for (var i = 0; i < oData.SchemeCPs.length; i++) {
		//            delete oData.SchemeCPs[i].__metadata;
		//            if (oData.SchemeCPs[i].CPTypeID === "01") {
		//                aDistributor.push(oData.SchemeCPs[i]);
		//            } else if (oData.SchemeCPs[i].CPTypeID === "10" || oData.SchemeCPs[i].CPTypeID === "20") {
		//                aRetailer.push(oData.SchemeCPs[i]);
		//            }
		//        }
		//        var oDistributorModel = new sap.ui.model.json.JSONModel();
		//        oDistributorModel.setData(aDistributor);
		//        this._oComponent.setModel(oDistributorModel, "Distributors");
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/DistributorsCount", aDistributor.length);
		//        var oRetailerModel = new sap.ui.model.json.JSONModel();
		//        oRetailerModel.setData(aRetailer);
		//        this._oComponent.setModel(oRetailerModel, "Retailers");
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/RetailersCount", aRetailer.length);
		//        var oSchemeCostObjectsModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeCostObjects = oPPCCommon.formatItemsOData({ oData: oData.SchemeCostObjects });
		//        for (var iSCO = 0; iSCO < oData.SchemeCostObjects.length; iSCO++) {
		//            delete oData.SchemeCostObjects[iSCO].__metadata;
		//            if (oData.SchemeCostObjects[iSCO].PercOfAlloction) {
		//                oData.SchemeCostObjects[iSCO].PercOfAlloction = parseFloat(oData.SchemeCostObjects[iSCO].PercOfAlloction);
		//            }
		//        }
		//        oSchemeCostObjectsModel.setData(oData.SchemeCostObjects);
		//        this._oComponent.setModel(oSchemeCostObjectsModel, "SchemeCostObjects");
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeCostObjectsCount", oData.SchemeCostObjects.length);
		//        var oSchemeItemDetailsModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeItemDetails = oPPCCommon.formatItemsOData({ oData: oData.SchemeItemDetails });
		//        var oSchemeItemDetailsEditModel = new sap.ui.model.json.JSONModel();
		//        oSchemeItemDetailsEditModel.setData(oData.SchemeItemDetails);
		//        this._oComponent.setModel(oSchemeItemDetailsEditModel, "SchemeItemDetailsEdit");
		//        for (var iSID = 0; iSID < oData.SchemeItemDetails.length; iSID++) {
		//            delete oData.SchemeItemDetails[iSID].__metadata;
		//            delete oData.SchemeItemDetails[iSID].SchemeSlabs;
		//            var subRootArray = [];
		//            for (var iSub = 0; iSub < oData.SchemeItemDetails.length; iSub++) {
		//                if (oData.SchemeItemDetails[iSID].SchemeItemGUID === oData.SchemeItemDetails[iSub].HierarchicalRefGUID) {
		//                    subRootArray.push(oData.SchemeItemDetails[iSub]);
		//                }
		//            }
		//            if (subRootArray.length > 0) {
		//                oData.SchemeItemDetails[iSID].isBasket = true;
		//                oData.SchemeItemDetails[iSID].BasketState = "#000";
		//                oData.SchemeItemDetails[iSID].results = subRootArray;
		//            } else {
		//                oData.SchemeItemDetails[iSID].isBasket = false;
		//                oData.SchemeItemDetails[iSID].BasketState = "#000";
		//            }
		//            if (oData.SchemeItemDetails[iSID].MRP) {
		//                oData.SchemeItemDetails[iSID].MRP = parseFloat(oData.SchemeItemDetails[iSID].MRP);
		//            }
		//            if (oData.SchemeItemDetails[iSID].ItemMin) {
		//                oData.SchemeItemDetails[iSID].ItemMin = parseFloat(oData.SchemeItemDetails[iSID].ItemMin);
		//            }
		//        }
		//        var subItem = 0;
		//        var mainArray = [];
		//        for (var g = 0; g < oData.SchemeItemDetails.length; g++) {
		//            if (oData.SchemeItemDetails[g].results) {
		//                mainArray.push(oData.SchemeItemDetails[g]);
		//            } else {
		//                subItem = subItem + 1;
		//            }
		//        }
		//        if (mainArray.length > 0) {
		//            oSchemeItemDetailsModel.setData(mainArray);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", mainArray.length);
		//        } else {
		//            subItem = 0;
		//            oSchemeItemDetailsModel.setData(oData.SchemeItemDetails);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", oData.SchemeItemDetails.length);
		//        }
		//        this._oComponent.setModel(oSchemeItemDetailsModel, "SchemeItems");
		//        if (this._oComponent.getModel("SchemeItems")) {
		//            if (this._oComponent.getModel("SchemeItems").getProperty("/PayoutAmount") > 0) {
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", true);
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", false);
		//                gSchemeDetails.PayoutAmntFound = true;
		//                gSchemeDetails.PayoutPercFound = false;
		//            }
		//            if (this._oComponent.getModel("SchemeItems").getProperty("/PayoutPerc") > 0) {
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", true);
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", false);
		//                gSchemeDetails.PayoutPercFound = true;
		//                gSchemeDetails.PayoutAmntFound = false;
		//            }
		//        }
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSubItemsCount", subItem);
		//        var oTreeTable = gSchemeItemsBlock.byId("UISchemeItemsTable");
		//        oTreeTable.expandToLevel(1);
		//        var oEditTreeTable = gSchemeItemsBlock.byId("UISchemeItemsTableEdit");
		//        oEditTreeTable.expandToLevel(1);
		//        var oSchemeSlabsModel = new sap.ui.model.json.JSONModel();
		//        oData.SchemeSlabs = oPPCCommon.formatItemsOData({ oData: oData.SchemeSlabs });
		//        for (var iSSLB = 0; iSSLB < oData.SchemeSlabs.length; iSSLB++) {
		//            delete oData.SchemeSlabs[iSSLB].__metadata;
		//            if (oData.SchemeSlabs[iSSLB].FromQty) {
		//                oData.SchemeSlabs[iSSLB].FromQty = parseFloat(oData.SchemeSlabs[iSSLB].FromQty);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].ToQty) {
		//                oData.SchemeSlabs[iSSLB].ToQty = parseFloat(oData.SchemeSlabs[iSSLB].ToQty);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].FromValue) {
		//                oData.SchemeSlabs[iSSLB].FromValue = parseFloat(oData.SchemeSlabs[iSSLB].FromValue);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].ToValue) {
		//                oData.SchemeSlabs[iSSLB].ToValue = parseFloat(oData.SchemeSlabs[iSSLB].ToValue);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].PayoutPerc) {
		//                oData.SchemeSlabs[iSSLB].PayoutPerc = parseFloat(oData.SchemeSlabs[iSSLB].PayoutPerc);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].PayoutAmount) {
		//                oData.SchemeSlabs[iSSLB].PayoutAmount = parseFloat(oData.SchemeSlabs[iSSLB].PayoutAmount);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].ReimburseAmount) {
		//                oData.SchemeSlabs[iSSLB].ReimburseAmount = parseFloat(oData.SchemeSlabs[iSSLB].ReimburseAmount);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].ReimbursePerc) {
		//                oData.SchemeSlabs[iSSLB].ReimbursePerc = parseFloat(oData.SchemeSlabs[iSSLB].ReimbursePerc);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].RatePerQty) {
		//                oData.SchemeSlabs[iSSLB].RatePerQty = parseFloat(oData.SchemeSlabs[iSSLB].RatePerQty);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].FreeQty) {
		//                oData.SchemeSlabs[iSSLB].FreeQty = parseFloat(oData.SchemeSlabs[iSSLB].FreeQty);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].OtherAmount) {
		//                oData.SchemeSlabs[iSSLB].OtherAmount = parseFloat(oData.SchemeSlabs[iSSLB].OtherAmount);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].Sequence) {
		//                oData.SchemeSlabs[iSSLB].Sequence = parseInt(oData.SchemeSlabs[iSSLB].Sequence);
		//            }
		//            if (oData.SchemeSlabs[iSSLB].NoOfCards) {
		//                oData.SchemeSlabs[iSSLB].NoOfCards = parseInt(oData.SchemeSlabs[iSSLB].NoOfCards);
		//            }
		//        }
		//        oSchemeSlabsModel.setData(oData.SchemeSlabs);
		//        this._oComponent.setModel(oSchemeSlabsModel, "SchemeSlabs");
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeSlabsCount", oData.SchemeSlabs.length);
		//        var oSchemesModel = new sap.ui.model.json.JSONModel();
		//        delete oData.__metadata;
		//        delete oData.SchemeSalesAreas;
		//        delete oData.SchemeCPs;
		//        delete oData.SchemeCostObjects;
		//        delete oData.SchemeItemDetails;
		//        delete oData.SchemeSlabs;
		//        delete oData.SchemeGeographies;
		//        oSchemesModel.setData(oData);
		//        if (oData.CalculateOnID) {
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/calculateOn", true);
		//        }
		//        this._oComponent.setModel(oSchemesModel, "Schemes");
		//        gSchemeDetails.setBusy(false);
		//        if (this.setSchemeDetails_Exit) {
		//            this.setSchemeDetails_Exit();
		//        }
		//    },
		//    getSchemeCatDD: function (oData) {
		//        var that = this;
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oStatusIdFilter = new Array();
		//        oStatusIdFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusIdFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["SCHMAR"], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusIdFilter, "Types", "TypesName", new sap.m.BusyDialog(), this.getView(), "schemeCategoryDD", "Select", function (response) {
		//            var flag = false;
		//            for (var i = 1; i < response.length; i++) {
		//                if (response[i].Key === oData.SchemeTypeID) {
		//                    flag = true;
		//                    that.getView().getModel("LocalViewSettingDtl").setProperty("/newBlockValidation", true);
		//                }
		//            }
		//            if (flag === true) {
		//                that.getView().getModel("LocalViewSettingDtl").setProperty("/otherSlabblocks", false);
		//            } else if (oData.SchemeTypeID === "000013" || oData.SchemeTypeID === "000014") {
		//                that.getView().getModel("LocalViewSettingDtl").setProperty("/otherSlabblocks", false);
		//            } else {
		//                that.getView().getModel("LocalViewSettingDtl").setProperty("/otherSlabblocks", true);
		//            }
		//        });
		//        if (this.getMaterialUOMs_Exit) {
		//            this.getMaterialUOMs_Exit();
		//        }
		//    },
		//    GeoGraphicEdit: function (SchemeGeographiesEdit) {
		//        var oZoneSelectedListsEdit = SchemeGeographiesEdit;
		//        gSchemeGeographiesBlock.getModel("oZoneSelectedLists").setData(oZoneSelectedListsEdit);
		//    },
		//    onReject: function () {
		//        var title = oi18n.getText("DetailPage.Dialog.Reject.comments");
		//        this.onApprovalDialog("", "X", title);
		//    },
		//    onApprove: function () {
		//        var title = oi18n.getText("DetailPage.Dialog.Approve.comments");
		//        this.onApprovalDialog("X", "", title);
		//    },
		//    onEditApprove: function () {
		//        oPPCCommon.removeAllMsgs();
		//        oPPCCommon.hideMessagePopover(gObjectPageLayout);
		//        var oView = this.getView();
		//        var Approve = "Yes";
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/EditAndApprove", true);
		//        this.onEdit(Approve);
		//    },
		//    onDeactive: function () {
		//        this.deactivateConfirmDialog();
		//        if (this.onDeactive_Exit) {
		//            this.onDeactive_Exit();
		//        }
		//    },
		//    deactivateConfirmDialog: function () {
		//        var that = this;
		//        var dialog = new sap.m.Dialog({
		//            title: "Confirm",
		//            type: "Message",
		//            state: "Warning",
		//            content: new sap.m.Text({ text: oi18n.getText("Deactivate.Popup.confirmation") }),
		//            beginButton: new sap.m.Button({
		//                text: "Yes",
		//                press: function () {
		//                    var Deactivate = "Do";
		//                    that.updateScheme("", Deactivate);
		//                    dialog.close();
		//                }
		//            }),
		//            endButton: new sap.m.Button({
		//                text: "No",
		//                press: function () {
		//                    dialog.close();
		//                }
		//            }),
		//            afterClose: function () {
		//                dialog.destroy();
		//            }
		//        });
		//        dialog.open();
		//        if (this.confirmDialog_Exit) {
		//            this.confirmDialog_Exit();
		//        }
		//    },
		//    onApprovalDialog: function (apprFlag, rejFlag, title) {
		//        var that = this;
		//        var dialog = new sap.m.Dialog({
		//            title: title,
		//            type: "Message",
		//            content: [new sap.m.TextArea("confirmDialogTextarea", {
		//                    width: "100%",
		//                    maxLength: oPPCCommon.getMaxLengthFromMetadata({
		//                        oDataModel: this._oComponent.getModel("PCGW"),
		//                        sEntityType: "Task",
		//                        sPropertyName: "Comments"
		//                    }),
		//                    placeholder: "Add note (optional)"
		//                })],
		//            beginButton: new sap.m.Button({
		//                text: "Submit",
		//                press: function () {
		//                    var sText = sap.ui.getCore().byId("confirmDialogTextarea").getValue();
		//                    var apprflag = "X";
		//                    that.onApproval(apprFlag, rejFlag, sText);
		//                    dialog.close();
		//                }
		//            }),
		//            endButton: new sap.m.Button({
		//                text: "Cancel",
		//                press: function () {
		//                    dialog.close();
		//                }
		//            }),
		//            afterClose: function () {
		//                dialog.destroy();
		//            }
		//        });
		//        dialog.open();
		//    },
		//    onApproval: function (apprFlag, rejFlag, sText) {
		//        var that = this;
		//        oPPCCommon.removeAllMsgs();
		//        oPPCCommon.hideMessagePopover(gObjectPageLayout);
		//        gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//        if (oPPCCommon.doErrMessageExist()) {
		//            oBusyDialog.open();
		//            that.getView().setBusy(true);
		//            var oModelUpdate = this._oComponent.getModel("PCGW");
		//            oModelUpdate.setUseBatch(true);
		//            var loginID = oProductCommon.getCurrentUsers("Tasks", "update");
		//            var oDecisionKey = "";
		//            var oInstanceID = oPPCCommon.getPropertyValueFromContextPath(contextPath, "InstanceID");
		//            var SchemeGUID = oPPCCommon.getPropertyValueFromContextPath(contextPath, "SchemeGUID");
		//            if (apprFlag === "X") {
		//                oDecisionKey = "01";
		//            } else {
		//                oDecisionKey = "02";
		//            }
		//            var oHeader = {};
		//            oHeader.InstanceID = oInstanceID;
		//            oHeader.EntityType = "SCM";
		//            oHeader.DecisionKey = oDecisionKey;
		//            oHeader.LoginID = loginID;
		//            oHeader.EntityKey = "guid'" + SchemeGUID + "'";
		//            oHeader.Comments = sText;
		//            oHeader.EntityKeyID = this.EntityKeyID;
		//            oModelUpdate.setDeferredBatchGroups(["updateTask"]);
		//            oModelUpdate.setHeaders({ "x-arteria-loginid": loginID });
		//            oModelUpdate.update("/Tasks(InstanceID='" + oHeader.InstanceID + "',EntityType='SCM')", oHeader, { groupId: "updateTask" });
		//            oModelUpdate.setHeaders({ "x-arteria-loginid": loginID });
		//            oModelUpdate.sDefaultUpdateMethod = "PUT";
		//            oModelUpdate.submitChanges({
		//                groupId: "updateTask",
		//                success: function (oData) {
		//                    oBusyDialog.close();
		//                    that.getView().setBusy(false);
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//                    var message = oPPCCommon.getMsgsFromMsgMgr();
		//                    that.onApprovalSuccess(message, oData);
		//                },
		//                error: function (response) {
		//                    oBusyDialog.close();
		//                    that.getView().setBusy(false);
		//                    oPPCCommon.removeDuplicateMsgsInMsgMgr();
		//                    gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//                    if (gSchemeDetails.getModel("LocalViewSettingDtl").getProperty("/messageLength") > 0) {
		//                        oPPCCommon.showMessagePopover(that.DynamicSideContent);
		//                    }
		//                }
		//            });
		//        } else {
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//            oPPCCommon.showMessagePopover(gObjectPageLayout);
		//        }
		//    },
		//    onApprovalSuccess: function (message, oData) {
		//        var that = this;
		//        var dialog = new sap.m.Dialog({
		//            title: "Success",
		//            type: "Message",
		//            state: "Success",
		//            content: new sap.m.Text({ text: message }),
		//            endButton: new sap.m.Button({
		//                text: "OK",
		//                press: function () {
		//                    that.backToList();
		//                    dialog.close();
		//                }
		//            }),
		//            afterClose: function () {
		//                dialog.destroy();
		//            }
		//        });
		//        dialog.open();
		//    },
		//    handleoDataError: function (error) {
		//        var message = oPPCCommon.parseoDataErrorMessage(error);
		//        if (message.trim() === "Not Found") {
		//            this.clearModel();
		//            this._oRouter.navTo("NoMatching");
		//        } else {
		//            var that = this;
		//            oPPCCommon.dialogErrorMessage(error, "Service error", function () {
		//                that.navigateBack();
		//            });
		//        }
		//        if (this.handleoDataError_Exit) {
		//            this.handleoDataError_Exit();
		//        }
		//    },
		//    onClone: function (oEvent) {
		//        var that = this;
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/Cloning", true);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/clonestatus", "");
		//        var Clone = "Clone";
		//        that.onEdit(Clone);
		//    },
		//    applicableFor: function () {
		//        var that = this;
		//        var view = this.getView();
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oSalesGroupFilter = new Array();
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CPTypeID"], false, false, false);
		//        oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), view, "PartnerTypeDD1", "", function (aDDValues) {
		//        }, false, "PD", { bSetSizeLimit: true });
		//    },
		//    getBillMode: function () {
		//        var that = this;
		//        var view = this.getView();
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oSalesGroupFilter = new Array();
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SCGW"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["Scheme"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["BillMode"], false, false, false);
		//        oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), view, "BillModeDD", "", function (aDDValues) {
		//            if (that.SchemePaymentModes.length > 0) {
		//                gBasicDataBlock.byId("fSchemePaymentModeEdit").setSelectedKeys(that.SchemePaymentModes);
		//            }
		//        }, false, "PD", { bSetSizeLimit: true });
		//    },
		//    getCalculatedOn: function () {
		//        var that = this;
		//        var view = this.getView();
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oSalesGroupFilter = new Array();
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SCGW"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["Scheme"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CalculateOn"], false, false, false);
		//        oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), view, "CalculateOnDD", "Select", function (addValues) {
		//            if (addValues.length === 2) {
		//                addValues.splice(0, 1);
		//                that.getView().getModel("CalculateOnDD").setData(addValues);
		//            }
		//        }, false, "PD", { bSetSizeLimit: true });
		//    },
		//    onEdit: function (Approve) {
		//        var that = this;
		//        this.Remarks = "";
		//        this.getLoggedUser();
		//        if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/DDLoaded")) {
		//            this.applicableFor();
		//            this.getBillMode();
		//            this.getDropDowns();
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/DDLoaded", true);
		//        }
		//        this.headerMandatory();
		//        var oView = this.getView();
		//        oView.getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
		//        oView.getModel("LocalViewSettingDtl").setProperty("/editButton", false);
		//        if (Approve === "Yes") {
		//            oView.getModel("LocalViewSettingDtl").setProperty("/approveButton", false);
		//            oView.getModel("LocalViewSettingDtl").setProperty("/rejectButton", false);
		//            oView.getModel("LocalViewSettingDtl").setProperty("/editApproveButton", false);
		//        }
		//        oView.getModel("LocalViewSettingDtl").setProperty("/editMode", true);
		//        oView.getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
		//        oView.getModel("LocalViewSettingDtl").setProperty("/pageHeader", oi18n.getText("Change.Page.header"));
		//        this._oSchemes = {};
		//        if (this.getView().getModel("Schemes")) {
		//            this._oSchemes = jQuery.extend({}, this.getView().getModel("Schemes").getData());
		//        }
		//        gRemarks = this._oComponent.getModel("Schemes").getProperty("/Remarks");
		//        this._oComponent.getModel("Schemes").setProperty("/Remarks", "");
		//        if (Approve === "Clone") {
		//            if (this._oComponent.getModel("SchemeCPDocuments")) {
		//                this._oComponent.getModel("SchemeCPDocuments").setProperty("/", {});
		//            }
		//            oView.getModel("LocalViewSettingDtl").setProperty("/pageHeader", oi18n.getText("Clone.Page.header"));
		//            this.getView().getModel("Schemes").setProperty("/SchemeID", "");
		//            var CloneGuid = oPPCCommon.generateUUID().toUpperCase();
		//            this._oComponent.getModel("Schemes").setProperty("/SchemeGUID", CloneGuid);
		//        } else {
		//            oView.getModel("LocalViewSettingDtl").setProperty("/pageHeader", oi18n.getText("Change.Page.header"));
		//        }
		//        this._oSchemeSalesAreas = [];
		//        if (this.getView().getModel("SchemeSalesAreas")) {
		//            this._oSchemeSalesAreas = jQuery.extend(true, [], this.getView().getModel("SchemeSalesAreas").getData());
		//        }
		//        this._oSchemePartnerTypes = [];
		//        if (this.getView().getModel("SchemePartnerTypes")) {
		//            this._oSchemePartnerTypes = jQuery.extend(true, [], this.getView().getModel("SchemePartnerTypes").getData());
		//        }
		//        this._oSchemePaymentModes = [];
		//        if (this.getView().getModel("SchemePaymentModes")) {
		//            this._oSchemePaymentModes = jQuery.extend(true, [], this.getView().getModel("SchemePaymentModes").getData());
		//        }
		//        this._oSchemeGeographies = [];
		//        if (this.getView().getModel("SchemeGeographies")) {
		//            this._oSchemeGeographies = jQuery.extend(true, [], this.getView().getModel("SchemeGeographies").getData());
		//        }
		//        this._oSchemeGeographiesEdit = [];
		//        if (this.getView().getModel("SchemeGeographiesEdit")) {
		//            this._oSchemeGeographiesEdit = jQuery.extend(true, [], this.getView().getModel("SchemeGeographiesEdit").getData());
		//        }
		//        var MainModel = this._oComponent.getModel("GeoGraphy");
		//        if (this._oSchemeGeographiesEdit[0].GeographyTypeID === "0000000005" || this._oSchemeGeographiesEdit[0].GeographyTypeDesc === "Depot") {
		//            eDepotArray = [];
		//            for (var k = 0; k < this._oSchemeGeographiesEdit.length; k++) {
		//                eDepotArray.push(this._oSchemeGeographiesEdit[k].GeographyValueID);
		//            }
		//            var DepotData = gTempSchemeGeographiesBlock.getModel("DepotDD").getProperty("/");
		//            if (eDepotArray.length === DepotData.length - 1) {
		//                eDepotArray.unshift("");
		//            }
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/selectedDepot", true);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/selectedArea", false);
		//            gTempSchemeGeographiesBlock.byId("fDepotIDEdit").setSelectedKeys(eDepotArray);
		//        } else {
		//            eZoneArray = [];
		//            eRegionArray = [];
		//            eAreaArray = [];
		//            eHQArray = [];
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/selectedDepot", false);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/selectedArea", true);
		//            for (var l = 0; l < this._oSchemeGeographiesEdit.length; l++) {
		//                if (this._oSchemeGeographiesEdit[l].GeographyTypeID === "0000000001" || this._oSchemeGeographiesEdit[l].GeographyTypeDesc === "Zone") {
		//                    eZoneArray.push(this._oSchemeGeographiesEdit[l].GeographyValueID);
		//                }
		//                if (this._oSchemeGeographiesEdit[l].GeographyTypeID === "0000000002" || this._oSchemeGeographiesEdit[l].GeographyTypeDesc === "REGION") {
		//                    eRegionArray.push(this._oSchemeGeographiesEdit[l].GeographyValueID);
		//                }
		//                if (this._oSchemeGeographiesEdit[l].GeographyTypeID === "0000000003" || this._oSchemeGeographiesEdit[l].GeographyTypeDesc === "AREA") {
		//                    eAreaArray.push(this._oSchemeGeographiesEdit[l].GeographyValueID);
		//                }
		//                if (this._oSchemeGeographiesEdit[l].GeographyTypeID === "0000000004" || this._oSchemeGeographiesEdit[l].GeographyTypeDesc === "HQ") {
		//                    eHQArray.push(this._oSchemeGeographiesEdit[l].GeographyValueID);
		//                }
		//            }
		//            gTempSchemeGeographiesBlock.byId("fZoneIDEdit").setSelectedKeys(eZoneArray);
		//            sap.ui.controller("com.arteriatech.ss.schemes.controller.block.TempSchemeGeographiesBlock").onZoneChange("", eZoneArray);
		//            if (eRegionArray.length > 0) {
		//                gTempSchemeGeographiesBlock.byId("fRegionIDEdit").setSelectedKeys(eRegionArray);
		//            }
		//            sap.ui.controller("com.arteriatech.ss.schemes.controller.block.TempSchemeGeographiesBlock").onRegionChange("", eRegionArray);
		//        }
		//        if (eAreaArray.length > 0) {
		//            gTempSchemeGeographiesBlock.byId("fAreaIDEdit").setSelectedKeys(eAreaArray);
		//        }
		//        sap.ui.controller("com.arteriatech.ss.schemes.controller.block.TempSchemeGeographiesBlock").onAreaChange("", eAreaArray);
		//        var HQData = gTempSchemeGeographiesBlock.getModel("HeadQuarterDD").getProperty("/");
		//        if (eHQArray.length > 0) {
		//            if (eHQArray.length === HQData.length - 1) {
		//                eHQArray.unshift("");
		//            }
		//            gTempSchemeGeographiesBlock.byId("fHeadQuarterIDEdit").setSelectedKeys(eHQArray);
		//        }
		//        this._oSchemeCPs = [];
		//        if (this.getView().getModel("SchemeCPs")) {
		//            this._oSchemeCPs = jQuery.extend(true, [], this.getView().getModel("SchemeCPs").getData());
		//        }
		//        this._oDistributors = [];
		//        if (this.getView().getModel("Distributors")) {
		//            this._oDistributors = jQuery.extend(true, [], this.getView().getModel("Distributors").getData());
		//        }
		//        this._oRetailers = [];
		//        if (this.getView().getModel("Retailers")) {
		//            this._oRetailers = jQuery.extend(true, [], this.getView().getModel("Retailers").getData());
		//        }
		//        this._oSchemeCostObjects = [];
		//        if (this.getView().getModel("SchemeCostObjects")) {
		//            this._oSchemeCostObjects = jQuery.extend(true, [], this.getView().getModel("SchemeCostObjects").getData());
		//        }
		//        this._oSchemeItems = [];
		//        if (this.getView().getModel("SchemeItems")) {
		//            for (var z = 0; z < this.getView().getModel("SchemeItems").getProperty("/").length; z++) {
		//                var PayoutPerc = this.getView().getModel("SchemeItems").getProperty("/" + z + "/PayoutPerc");
		//                var PayoutAmount = this.getView().getModel("SchemeItems").getProperty("/" + z + "/PayoutAmount");
		//                if (PayoutPerc > 0) {
		//                    this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", true);
		//                    this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", false);
		//                }
		//                if (PayoutAmount > 0) {
		//                    this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutPerc", false);
		//                    this.getView().getModel("LocalViewSettingDtl").setProperty("/PayoutAmnt", true);
		//                }
		//                this.getView().getModel("SchemeItems").setProperty("/" + z + "/PayoutPerc", parseFloat(PayoutPerc));
		//                this.getView().getModel("SchemeItems").setProperty("/" + z + "/PayoutAmount", parseFloat(PayoutAmount));
		//            }
		//            this._oSchemeItems = jQuery.extend(true, [], this.getView().getModel("SchemeItems").getData());
		//        }
		//        this._oSchemeItemsEdit = [];
		//        if (this.getView().getModel("SchemeItemDetailsEdit")) {
		//            this._oSchemeItemsEdit = jQuery.extend(true, [], this.getView().getModel("SchemeItemDetailsEdit").getData());
		//            if (this._oSchemeItemsEdit[0].isBasket) {
		//                oView.getModel("LocalViewSettingDtl").setProperty("/BasketScheme", true);
		//                oView.getModel("LocalViewSettingDtl").setProperty("/ItemScheme", false);
		//            } else {
		//                oView.getModel("LocalViewSettingDtl").setProperty("/BasketScheme", false);
		//                oView.getModel("LocalViewSettingDtl").setProperty("/ItemScheme", true);
		//            }
		//        }
		//        this._oSchemeSlabs = [];
		//        if (this.getView().getModel("SchemeSlabs")) {
		//            this._oSchemeSlabs = jQuery.extend(true, [], this.getView().getModel("SchemeSlabs").getData());
		//            that.getFreearticleVH();
		//            that.getScratchCardVH();
		//        }
		//        for (var i = 0; i < this._oSchemeSlabs.length; i++) {
		//            this.getView().getModel("SchemeSlabs").setProperty("/" + i + "/FromValue", parseFloat(this._oSchemeSlabs[i].FromValue).toFixed(3));
		//            this.getView().getModel("SchemeSlabs").setProperty("/" + i + "/ToValue", parseFloat(this._oSchemeSlabs[i].ToValue).toFixed(3));
		//            this.getView().getModel("SchemeSlabs").setProperty("/" + i + "/FromQty", parseFloat(this._oSchemeSlabs[i].FromQty).toFixed(3));
		//            this.getView().getModel("SchemeSlabs").setProperty("/" + i + "/ToQty", parseFloat(this._oSchemeSlabs[i].ToQty).toFixed(3));
		//            var rows = gSchemeSlabsBlock.byId("UISchemeSlabsTableEdit").getRows();
		//            for (var j = 0; j < rows.length; j++) {
		//                var MatId = "";
		//                var freeMatId = "";
		//                var FreeArticleId = "";
		//                var ScratchCard = "";
		//                var cells = rows[j].getCells();
		//                for (var m = 0; m < cells.length; m++) {
		//                    if (cells[m].getId().indexOf("inputMaterial") > 0) {
		//                        MatId = gSchemeSlabsBlock.byId(cells[m].getId());
		//                    }
		//                    if (cells[m].getId().indexOf("inputFreeMat") > 0) {
		//                        freeMatId = gSchemeSlabsBlock.byId(cells[m].getId());
		//                    }
		//                    if (cells[m].getId().indexOf("fFreeArticleEdit") > 0) {
		//                        FreeArticleId = gSchemeSlabsBlock.byId(cells[m].getId());
		//                    }
		//                    if (cells[m].getId().indexOf("fCardTitleEdit") > 0) {
		//                        ScratchCard = gSchemeSlabsBlock.byId(cells[m].getId());
		//                    }
		//                }
		//                var Token = new sap.m.Token({
		//                    key: this._oSchemeSlabs[j].MaterialNo,
		//                    text: this._oSchemeSlabs[j].MaterialDesc + " (" + this._oSchemeSlabs[j].MaterialNo + ")"
		//                });
		//                var Token2 = new sap.m.Token({
		//                    key: this._oSchemeSlabs[j].SKUGroupID,
		//                    text: this._oSchemeSlabs[j].SKUGroupDesc + " (" + this._oSchemeSlabs[j].SKUGroupCode + ")"
		//                });
		//                var Token3 = new sap.m.Token({
		//                    key: this._oSchemeSlabs[j].FreeArticle,
		//                    text: this._oSchemeSlabs[j].FreeArticleDesc + " (" + this._oSchemeSlabs[j].FreeArticle + ")"
		//                });
		//                var Token4 = new sap.m.Token({
		//                    key: this._oSchemeSlabs[j].CardTitle,
		//                    text: this._oSchemeSlabs[j].ScratchCardDesc + " (" + this._oSchemeSlabs[j].CardTitle + ")"
		//                });
		//                if (freeMatId) {
		//                    freeMatId.removeAllTokens();
		//                    freeMatId.addToken(Token2);
		//                    freeMatId.setTooltip(this._oSchemeSlabs[j].SKUGroupDesc);
		//                }
		//                if (MatId) {
		//                    MatId.removeAllTokens();
		//                    MatId.addToken(Token);
		//                    MatId.setTooltip(this._oSchemeSlabs[j].MaterialDesc);
		//                }
		//                if (FreeArticleId) {
		//                    FreeArticleId.removeAllTokens();
		//                    FreeArticleId.addToken(Token3);
		//                    FreeArticleId.setTooltip(this._oSchemeSlabs[j].FreeArticleDesc);
		//                }
		//                if (ScratchCard) {
		//                    ScratchCard.removeAllTokens();
		//                    ScratchCard.addToken(Token4);
		//                    ScratchCard.setTooltip(this._oSchemeSlabs[j].ScratchCardDesc);
		//                }
		//            }
		//        }
		//        for (var t = 0; t < this._oSchemeItemsEdit.length; t++) {
		//            this._oSchemeItemsEdit[t].scMaterialTokens = [];
		//            var aTokens = {
		//                "ID": this._oSchemeItemsEdit[t].MaterialNo,
		//                "Description": this._oSchemeItemsEdit[t].MaterialDesc,
		//                "isNew": false
		//            };
		//            this._oSchemeItemsEdit[t].scMaterialTokens.push(aTokens);
		//        }
		//        this.getView().getModel("SchemeItems").setData(this._oSchemeItemsEdit);
		//        this._oRouter.navTo("ChangePage", { contextPath: contextPath }, false);
		//        if (this.onEdit_Exit) {
		//            this.onEdit_Exit();
		//        }
		//    },
		//    getFreearticleVH: function () {
		//        var that = this;
		//        var oModelData = gSchemeSlabsBlock.getModel("PCGW");
		//        var oStatusFilter = new Array();
		//        var model = "SCGW";
		//        var parentIDs = gSchemeSlabsBlock.getModel("FreearticleTS").getProperty("/");
		//        var sloginid = that.getCurrentUsers("ChannelPartners", "read");
		//        var loginid = sloginid;
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [model], true, false, false);
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["SchemeSlab"], false, false, false);
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["Freearticle"], false, false, false);
		//        if (parentIDs.length > 0) {
		//            for (var i = 0; i < parentIDs.length; i++) {
		//                oStatusFilter.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentIDs[i].Key));
		//            }
		//        }
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "LoginID", sap.ui.model.FilterOperator.EQ, [loginid], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", new sap.m.BusyDialog(), gSchemeSlabsBlock, "FreearticleVH", "", function (aDDValues) {
		//        }, false, "PD", false);
		//    },
		//    getScratchCardVH: function () {
		//        var that = this;
		//        var oModelData = gSchemeSlabsBlock.getModel("PCGW");
		//        var oStatusFilter = new Array();
		//        var busyDialog = new sap.m.BusyDialog();
		//        var model = "SCGW";
		//        var parentIDs = gSchemeSlabsBlock.getModel("ScratchCardTS").getProperty("/");
		//        var sloginidSC = that.getCurrentUsers("ChannelPartners", "read");
		//        var sloginid = sloginidSC;
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [model], true, false, false);
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["SchemeSlab"], false, false, false);
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["ScratchCard"], false, false, false);
		//        if (parentIDs.length > 0) {
		//            for (var i = 0; i < parentIDs.length; i++) {
		//                oStatusFilter.push(new sap.ui.model.Filter("ParentID", sap.ui.model.FilterOperator.EQ, parentIDs[i].Key));
		//            }
		//        }
		//        oStatusFilter = oPPCCommon.setODataModelReadFilter(gSchemeDetails, "", oStatusFilter, "LoginID", sap.ui.model.FilterOperator.EQ, [sloginid], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", new sap.m.BusyDialog(), gSchemeSlabsBlock, "ScratchCardVH", "", function (aDDValues) {
		//            gSchemeDetails.setBusy(false);
		//        }, false, "PD", false);
		//    },
		//    getScratchCardTS: function (callBack) {
		//        var that = this;
		//        var view = gSchemeSlabsBlock;
		//        var busyDialog = new sap.m.BusyDialog();
		//        var oModelData = gSchemeSlabsBlock.getModel("PCGW");
		//        var oStatusIdFilter = new Array();
		//        oStatusIdFilter = oPPCCommon.setODataModelReadFilter(view, "", oStatusIdFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["SCRHCD"], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusIdFilter, "Types", "TypesName", busyDialog, gSchemeSlabsBlock, "ScratchCardTS", "", function () {
		//            busyDialog.close();
		//        });
		//        if (callBack) {
		//            callBack();
		//        }
		//        if (this.getScratchCardTS_Exit) {
		//            this.getScratchCardTS_Exit();
		//        }
		//    },
		//    getFreeArticaleTS: function (callBack) {
		//        var that = this;
		//        var view = gSchemeSlabsBlock;
		//        var oModelData = gSchemeSlabsBlock.getModel("PCGW");
		//        var oStatusIdFilter = new Array();
		//        oStatusIdFilter = oPPCCommon.setODataModelReadFilter(view, "", oStatusIdFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["FREATY"], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusIdFilter, "Types", "TypesName", new sap.m.BusyDialog(), gSchemeSlabsBlock, "FreearticleTS", "", function () {
		//        });
		//        if (callBack) {
		//            callBack();
		//        }
		//        if (this.getFreeArticaleTS_Exit) {
		//            this.getFreeArticaleTS_Exit();
		//        }
		//    },
		//    formatSchemeArray: function (oSelectedSchemes) {
		//        var aData = oSelectedSchemes;
		//        for (var i = 0; i < aData.length; i++) {
		//            aData[i].ID = aData[i].GeographyValueID;
		//            aData[i].Level = 1;
		//            aData[i].CurrencyCode = "EUR";
		//            aData[i].Path = "/" + i;
		//            aData[i].Position = i;
		//            if (aData[i].results) {
		//                aData[i].HaveChild = true;
		//                for (var j = 0; j < aData[i].results.length; j++) {
		//                    aData[i].results[j].ID = aData[i].results[j].GeographyValueID;
		//                    aData[i].results[j].Level = 2;
		//                    aData[i].results[j].CurrencyCode = "EUR";
		//                    aData[i].results[j].CrumbName = "Regions";
		//                    aData[i].results[j].Path = "/" + i + "/results";
		//                    aData[i].results[j].Position = j;
		//                    aData[i].results[j].ParentPath = "/" + i + "/results";
		//                    aData[i].results[j].ParentID = aData[i].results[j].GeographyParentTypeValueID;
		//                    aData[i].results[j].SuperParentID = "";
		//                    aData[i].results[j].GeographyTypeID = aData[i].results[j].GeographyTypeID;
		//                    aData[i].results[j].GeographyParentTypeID = aData[i].results[j].GeographyParentTypeID;
		//                    if (aData[i].results[j].results) {
		//                        aData[i].results[j].HaveChild = true;
		//                        for (var k = 0; k < aData[i].results[j].results.length; k++) {
		//                            aData[i].results[j].results[k].ID = aData[i].results[j].results[k].GeographyValueID;
		//                            aData[i].results[j].results[k].Level = 3;
		//                            aData[i].results[j].results[k].CrumbName = "Areas";
		//                            aData[i].results[j].results[k].HaveChild = true;
		//                            aData[i].results[j].results[k].Path = "/" + i + "/results/" + j + "/results";
		//                            aData[i].results[j].results[k].Position = k;
		//                            aData[i].results[j].results[k].ParentPath = "/" + i + "/results/" + j + "/results";
		//                            aData[i].results[j].results[k].ParentID = aData[i].results[j].results[k].GeographyParentTypeValueID;
		//                            aData[i].results[j].results[k].SuperParentID = aData[i].ID;
		//                            aData[i].results[j].results[k].GeographyTypeID = aData[i].results[j].results[k].GeographyTypeID;
		//                            aData[i].results[j].results[k].GeographyParentTypeID = aData[i].results[j].results[k].GeographyParentTypeID;
		//                        }
		//                    }
		//                }
		//            }
		//        }
		//        return aData;
		//    },
		//    formatGeography: function (oMainData) {
		//        var oData = jQuery.extend(true, [], oMainData);
		//        oData = this.formatGeographies(oData, oData, "4");
		//        oData = this.formatGeographies(oData, oData, "3");
		//        oData = this.formatGeographies(oData, oData, "2");
		//        oData = this.formatGeographies(oData, oData, "1");
		//        oData = this.removeFromTopLevel(oData);
		//        return oData;
		//    },
		//    formatGeographies: function (oMainData, oData, sLevelID) {
		//        var childArray = [];
		//        for (var i = 0; i < oData.length; i++) {
		//            childArray = [];
		//            if (oData[i].GeographyLevelID === sLevelID) {
		//                for (var j = 0; j < oMainData.length; j++) {
		//                    if (parseInt(oMainData[j].GeographyLevelID) === parseInt(sLevelID) + 1 && oMainData[j].GeographyParentTypeID !== "") {
		//                        if (oData[i].GeographyValueID === oMainData[j].GeographyParentTypeValueID) {
		//                            childArray.push(oMainData[j]);
		//                        }
		//                    }
		//                }
		//                oData[i].results = childArray;
		//            }
		//        }
		//        return oData;
		//    },
		//    setDefaultSettings: function () {
		//        var oRejectButton, oEditApproveButton, oEditButton, oApproveButton, oApproveHistory, oApproveButtonType, oRejectButtonType, oEditApproveButtonType;
		//        var oLocalData;
		//        if (this.getView().getModel("LocalViewSettingDtl")) {
		//            oLocalData = this.getView().getModel("LocalViewSettingDtl").getData();
		//            if (oLocalData.editApproveButton === true && oLocalData.editButton === true && oLocalData.rejectButton === true) {
		//                oEditApproveButton = true;
		//                oRejectButton = true;
		//                oApproveButton = true;
		//                oEditButton = false;
		//                oApproveHistory = true;
		//                oApproveButtonType = "Accept";
		//                oRejectButtonType = "Reject";
		//                oEditApproveButtonType = "Accept";
		//            } else {
		//                oEditApproveButton = false;
		//                oEditButton = true;
		//                oRejectButton = false;
		//                oApproveButton = false;
		//                oApproveHistory = false;
		//                oApproveButtonType = "Accept";
		//                oRejectButtonType = "Reject";
		//                oEditApproveButtonType = "Accept";
		//            }
		//        } else {
		//            oEditApproveButton = false;
		//            oEditButton = true;
		//            oRejectButton = false;
		//            oApproveButton = false;
		//            oApproveHistory = false;
		//        }
		//        var oViewSettingModel = new sap.ui.model.json.JSONModel({
		//            SchemeSalesAreasCount: 0,
		//            SchemeGeographiesCount: 0,
		//            SchemeCPsCount: 0,
		//            DistributorsCount: 0,
		//            RetailersCount: 0,
		//            SchemeItemsCount: 0,
		//            SchemeSubItemsCount: 0,
		//            SchemeCostObjectsCount: 0,
		//            SchemeSlabsCount: 0,
		//            editMode: false,
		//            detailMode: true,
		//            reviewMode: false,
		//            messageLength: 0,
		//            ApproveHistory: oApproveHistory,
		//            HeaderObjectApprovalVisibility: false,
		//            approveButton: oApproveButton,
		//            rejectButton: oRejectButton,
		//            editApproveButton: oEditApproveButton,
		//            editButton: oEditButton,
		//            approveButtonType: oApproveButtonType,
		//            rejectButtonType: oRejectButtonType,
		//            editApproveButtonType: oEditApproveButtonType,
		//            DateFormat: oProductCommon.getDateFormat(),
		//            TableRowCount: 0,
		//            TableRowCountClassification: 0,
		//            pageHeader: oi18n.getText("Detail.title"),
		//            AreaOrDepot: oi18n.getText("Geography.Area"),
		//            DDLoaded: false,
		//            SchemeCp: false,
		//            Selected: false,
		//            Cloning: false,
		//            EditAndApprove: false,
		//            otherSlabblocks: false,
		//            clonestatus: "Status",
		//            selectedDepot: false,
		//            selectedArea: true,
		//            PayoutPerc: true,
		//            PayoutAmnt: true,
		//            AplicableSchemes: false,
		//            PartnerType: "",
		//            PaymentMode: "",
		//            calculateOn: false,
		//            backPress: false,
		//            newBlockValidation: false
		//        });
		//        this.getView().setModel(oViewSettingModel, "LocalViewSettingDtl");
		//        if (this._oSchemeSalesAreas) {
		//            this.setBackDetailData();
		//            this.toDisplay();
		//        }
		//        if (this.setDefaultSettings_Exit) {
		//            this.setDefaultSettings_Exit();
		//        }
		//    },
		//    getCurrentUsers: function (sServiceName, sRequestType, callBack) {
		//        if (callBack) {
		//            oProductCommon.getCurrentLoggedUser({
		//                sServiceName: sServiceName,
		//                sRequestType: sRequestType
		//            }, function (LoginID) {
		//                callBack(LoginID);
		//            });
		//        } else {
		//            var sLoginID = oProductCommon.getCurrentLoggedUser({
		//                sServiceName: sServiceName,
		//                sRequestType: sRequestType
		//            });
		//            return sLoginID;
		//        }
		//    },
		//    navigateBack: function () {
		//        var oView = this.getView();
		//        if (oView.getModel("LocalViewSettingDtl").getProperty("/reviewMode")) {
		//            this._oComponent.getModel("SchemeItems").setData(this._createSchemeItem);
		//            this.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", this._createSchemeItem.length);
		//            this._oComponent.getModel("Schemes").setProperty("/Remarks", this.Remarks);
		//            oView.getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
		//            oView.getModel("LocalViewSettingDtl").setProperty("/editButton", false);
		//            oView.getModel("LocalViewSettingDtl").setProperty("/editMode", true);
		//            oView.getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
		//        } else if (oView.getModel("LocalViewSettingDtl").getProperty("/editMode")) {
		//            this.confirmDialog();
		//        } else {
		//            this.backToList();
		//        }
		//        if (this.navigateBack_Exit) {
		//            this.navigateBack_Exit();
		//        }
		//    },
		//    backtoDetail: function () {
		//        this.confirmDialog();
		//        if (this.backtoDetail_Exit) {
		//            this.backtoDetail_Exit();
		//        }
		//    },
		//    confirmDialog: function () {
		//        var that = this;
		//        var dialog = new sap.m.Dialog({
		//            title: "Confirm",
		//            type: "Message",
		//            state: "Warning",
		//            icon: "sap-icon://message-warning",
		//            content: new sap.m.Text({ text: oi18n.getText("DetailHeaderEdit.Popup.confirmation") }),
		//            beginButton: new sap.m.Button({
		//                text: "Yes",
		//                press: function () {
		//                    that.clearAllErrors();
		//                    oPPCCommon.removeAllMsgs();
		//                    oPPCCommon.hideMessagePopover(this.DynamicSideContent);
		//                    window.history.go(-1);
		//                    that.setBackDetailData();
		//                    that.toDisplay();
		//                    dialog.close();
		//                }
		//            }),
		//            endButton: new sap.m.Button({
		//                text: "No",
		//                press: function () {
		//                    dialog.close();
		//                }
		//            }),
		//            afterClose: function () {
		//                dialog.destroy();
		//            }
		//        });
		//        dialog.open();
		//        if (this.confirmDialog_Exit) {
		//            this.confirmDialog_Exit();
		//        }
		//    },
		//    toDisplay: function () {
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/pageHeader", oi18n.getText("Detail.title"));
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/newBlockValidation", false);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/detailMode", true);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", true);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/editMode", false);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/reviewMode", false);
		//        var schemeCat = this.getView().getModel("schemeCategoryDD").getProperty("/");
		//        var schemeTypeId = this.getView().getModel("Schemes").getProperty("/SchemeTypeID");
		//        var OrgScopeID = this.getView().getModel("Schemes").getProperty("/OrgScopeID");
		//        var flag = false;
		//        for (var i = 0; i < schemeCat.length; i++) {
		//            if (schemeCat[i].Key === schemeTypeId) {
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/newBlockValidation", true);
		//                flag = true;
		//            }
		//        }
		//    },
		//    setBackDetailData: function () {
		//        var SchemeDetails = gSchemeDetails;
		//        if (SchemeDetails.getModel("Schemes")) {
		//            SchemeDetails.getModel("Schemes").setData(this._oSchemes);
		//        }
		//        if (SchemeDetails.getModel("SchemeSalesAreas")) {
		//            SchemeDetails.getModel("SchemeSalesAreas").setData(this._oSchemeSalesAreas);
		//        }
		//        if (SchemeDetails.getModel("SchemeGeographiesEdit")) {
		//            SchemeDetails.getModel("SchemeGeographiesEdit").setData(this._oSchemeGeographiesEdit);
		//        }
		//        if (SchemeDetails.getModel("SchemeGeographies")) {
		//            SchemeDetails.getModel("SchemeGeographies").setData(this._oSchemeGeographies);
		//        }
		//        if (SchemeDetails.getModel("SchemeCPs")) {
		//            SchemeDetails.getModel("SchemeCPs").setData(this._oSchemeCPs);
		//        }
		//        if (SchemeDetails.getModel("Distributors")) {
		//            SchemeDetails.getModel("Distributors").setData(this._oDistributors);
		//        }
		//        if (SchemeDetails.getModel("Retailers")) {
		//            SchemeDetails.getModel("Retailers").setData(this._oRetailers);
		//        }
		//        if (SchemeDetails.getModel("SchemeCostObjects")) {
		//            SchemeDetails.getModel("SchemeCostObjects").setData(this._oSchemeCostObjects);
		//        }
		//        if (SchemeDetails.getModel("SchemeItems")) {
		//            SchemeDetails.getModel("SchemeItems").setData(this._oSchemeItems);
		//        }
		//        if (SchemeDetails.getModel("SchemeItemDetailsEdit")) {
		//            SchemeDetails.getModel("SchemeItemDetailsEdit").setData(this._oSchemeItemsEdit);
		//        }
		//        if (SchemeDetails.getModel("SchemeSlabs")) {
		//            SchemeDetails.getModel("SchemeSlabs").setData(this._oSchemeSlabs);
		//        }
		//        this.setTableCounts();
		//    },
		//    setTableCounts: function () {
		//        var SchemeDetails = gSchemeDetails;
		//        if (SchemeDetails.getModel("LocalViewSettingDtl")) {
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeSalesAreasCount", this._oSchemeSalesAreas.length);
		//            if (this._oSchemeGeographiesEdit) {
		//                SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeGeographiesCount", this._oSchemeGeographiesEdit.length);
		//            } else {
		//                SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeGeographiesCount", this._oSchemeGeographies.length);
		//            }
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeCPsCount", this._oSchemeCPs.length);
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/DistributorsCount", this._oDistributors.length);
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/RetailersCount", this._oRetailers.length);
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeCostObjectsCount", this._oSchemeCostObjects.length);
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", this._oSchemeItems.length);
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeSubItemsCount", this._oSchemeItems.length);
		//            SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/SchemeSlabsCount", this._oSchemeSlabs.length);
		//        }
		//    },
		//    clearAllErrors: function () {
		//        var SchemeDetails = gSchemeDetails;
		//        this.clearHeaderValueState();
		//        this.clearItemValueState();
		//        var oData = sap.ui.getCore().getMessageManager().getMessageModel().getData();
		//        for (var i = 0; i < oData.length; i++) {
		//            var msgObj = oData[i];
		//            if (msgObj.id.indexOf("/UI/") > -1) {
		//                oPPCCommon.removeMsgsInMsgMgrById(msgObj.id);
		//            }
		//        }
		//        oPPCCommon.removeAllMsgs();
		//        SchemeDetails.getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//        if (!this.DynamicSideContent) {
		//            this.DynamicSideContent = SchemeDetails.byId("ObjectPageLayout");
		//        }
		//        oPPCCommon.hideMessagePopover(this.DynamicSideContent);
		//        if (this.clearAllErrors_Exit) {
		//            this.clearAllErrors_Exit();
		//        }
		//    },
		//    clearHeaderValueState: function () {
		//        var SchemesMandatory = this.getView().getModel("SchemesMandatory").getProperty("/");
		//        for (var key in SchemesMandatory) {
		//            if (SchemesMandatory.hasOwnProperty(key)) {
		//                var aFieldId = "f" + key + "Edit";
		//                var view = this.getValidViewForField(aFieldId);
		//                if (this.checkFieldForValueState(view, aFieldId)) {
		//                    view.byId(aFieldId).setValueState("None");
		//                    view.byId(aFieldId).setValueStateText();
		//                } else {
		//                    aFieldId = "f" + key;
		//                    view = this.getValidViewForField(aFieldId);
		//                    if (this.checkFieldForValueState(view, aFieldId)) {
		//                        view.byId(aFieldId).setValueState("None");
		//                        view.byId(aFieldId).setValueStateText();
		//                    }
		//                }
		//            }
		//        }
		//        if (this.clearHeaderValueState_Exit) {
		//            this.clearHeaderValueState_Exit();
		//        }
		//    },
		//    clearItemValueState: function () {
		//        var itemModels = [
		//            "SchemeCostObjects",
		//            "SchemeSalesAreas",
		//            "Distributors",
		//            "Retailers",
		//            "SchemeItems",
		//            "SchemeSlabs"
		//        ];
		//        for (var mdl = 0; mdl < itemModels.length; mdl++) {
		//            var oModel = this.getView().getModel(itemModels[mdl]);
		//            if (oModel) {
		//                var oData = oModel.getProperty("/");
		//                for (var data = 0; data < oData.length; data++) {
		//                    for (var key in oData[data]) {
		//                        if (oData[data].hasOwnProperty(key)) {
		//                            if (key.indexOf("ValueState") >= 0) {
		//                                delete oData[data][key];
		//                            }
		//                        }
		//                    }
		//                    if (oData[data].results) {
		//                        var root = oData[data].results;
		//                        for (var dataChild = 0; dataChild < root.length; dataChild++) {
		//                            for (var childKey in root[dataChild]) {
		//                                if (root[dataChild].hasOwnProperty(childKey)) {
		//                                    if (childKey.indexOf("ValueState") >= 0) {
		//                                        delete root[dataChild][childKey];
		//                                    }
		//                                }
		//                            }
		//                        }
		//                    }
		//                }
		//                oModel.refresh();
		//            }
		//        }
		//    },
		//    checkFieldForValueState: function (view, aFieldId) {
		//        if (view && (view.byId(aFieldId) instanceof sap.m.Input || view.byId(aFieldId) instanceof sap.m.MultiInput || view.byId(aFieldId) instanceof sap.m.DatePicker || view.byId(aFieldId) instanceof sap.m.Select && parseFloat(sap.ui.version) >= 1.4)) {
		//            return true;
		//        } else {
		//            return false;
		//        }
		//    },
		//    getDDKey: function (controlID, view) {
		//        var key = "";
		//        if (view.byId(controlID)) {
		//            key = view.byId(controlID).getSelectedKey();
		//        } else {
		//            view = this.getValidViewForField(controlID);
		//            if (view) {
		//                key = view.byId(controlID).getSelectedKey();
		//            }
		//        }
		//        if (this.getDDKey_Exit) {
		//            key = this.getDDKey_Exit(controlID, view);
		//        }
		//        return key;
		//    },
		//    getDDDescrption: function (controlID, view) {
		//        if (view.byId(controlID)) {
		//            view = view;
		//        } else {
		//            view = this.getValidViewForField(controlID);
		//        }
		//        var desc = "";
		//        if (view && view.byId(controlID)) {
		//            if (view.byId(controlID).getSelectedKey() !== "") {
		//                if (view.byId(controlID).getSelectedItem()) {
		//                    if (view.byId(controlID).getSelectedItem().getText().split("-").length > 1) {
		//                        desc = view.byId(controlID).getSelectedItem().getText().split("-")[1].trim();
		//                    } else {
		//                        desc = view.byId(controlID).getSelectedItem().getText().split("-")[0].trim();
		//                    }
		//                }
		//            }
		//        }
		//        if (this.getDDDescrption_Exit) {
		//            desc = this.getDDDescrption_Exit(controlID, view);
		//        }
		//        return desc;
		//    },
		//    getTokenKey: function (controlID, view) {
		//        if (view.byId(controlID)) {
		//            view = view;
		//        } else {
		//            view = this.getValidViewForField(controlID);
		//        }
		//        var key = "";
		//        if (view && view.byId(controlID) && view.byId(controlID).getTokens() !== undefined) {
		//            if (view.byId(controlID).getTokens().length !== 0) {
		//                key = view.byId(controlID).getTokens()[0].getProperty("key");
		//            }
		//        }
		//        if (this.getTokenKey_Exit) {
		//            key = this.getTokenKey_Exit(controlID, view);
		//        }
		//        return key;
		//    },
		//    getTokenDesc: function (controlID, view) {
		//        if (view.byId(controlID)) {
		//            view = view;
		//        } else {
		//            view = this.getValidViewForField(controlID);
		//        }
		//        var desc = "";
		//        if (view && view.byId(controlID) && view.byId(controlID).getTokens().length !== 0) {
		//            desc = view.byId(controlID).getTokens()[0].getProperty("text").split("(")[0];
		//        }
		//        if (this.getTokenDesc_Exit) {
		//            desc = this.getTokenDesc_Exit(controlID, view);
		//        }
		//        return desc;
		//    },
		//    backToList: function () {
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/backPress", true);
		//        var oHistory = sap.ui.core.routing.History.getInstance();
		//        var sPreviousHash = oHistory.getPreviousHash();
		//        if (oPPCCommon.isUshell()) {
		//            if (this.getView().getModel("LocalViewSettingDtl").getProperty("/savedSuccessfully")) {
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/savedSuccessfully", false);
		//                if (sPreviousHash.match(/contractApproveDetails/g)) {
		//                    this.clearModels();
		//                    this._oRouter.navTo("contractapprove");
		//                } else {
		//                    this.clearModels();
		//                    window.history.go(-1);
		//                    window.history.go(-1);
		//                }
		//            } else {
		//                if (sPreviousHash && sPreviousHash.match(/contractApproveDetails/g)) {
		//                    this.clearModels();
		//                    this._oRouter.navTo("contractapprove");
		//                } else {
		//                    this.clearModels();
		//                    window.history.go(-1);
		//                }
		//            }
		//        } else {
		//            if (sPreviousHash !== undefined) {
		//                if (sPreviousHash.match(/contractApproveDetails/g)) {
		//                    this.clearModels();
		//                    this._oRouter.navTo("contractapprove");
		//                } else {
		//                    this.clearModels();
		//                    window.history.go(-1);
		//                }
		//            } else {
		//                if (document.referrer !== "") {
		//                    this.clearModels();
		//                    window.history.go(-1);
		//                } else {
		//                    this.clearModels();
		//                    this._oRouter.navTo("View");
		//                }
		//            }
		//        }
		//        if (this.backToList_Exit) {
		//            this.backToList_Exit();
		//        }
		//    },
		//    clearModels: function () {
		//        this._oSchemes = {};
		//        this._oSchemeSalesAreas = [];
		//        this._oSchemeGeographies = [];
		//        this._oSchemeCPs = [];
		//        this._oDistributors = [];
		//        this._oRetailers = [];
		//        this._oSchemeCostObjects = [];
		//        this._oSchemeItems = [];
		//        this._oSchemeSlabs = [];
		//        this.setBackDetailData();
		//    },
		//    removeFromTopLevel: function (oData) {
		//        for (var i = 0; i < oData.length; i++) {
		//            if (oData[i].GeographyLevelID !== "1") {
		//                oData.splice(i, 1);
		//                i = i - 1;
		//            }
		//        }
		//        return oData;
		//    },
		//    getDropDowns: function () {
		//        this.iTotalDDs = 2;
		//        this.getView().setBusy(true);
		//        this.getHeaderDropDowns();
		//        this.getCompanyCodeDD();
		//        this.getItemDropDowns();
		//        this.getMaterialUOMs();
		//        this.getCalculatedOn();
		//    },
		//    getCompanyCodeDD: function () {
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oFilter = new Array();
		//        oFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["COMP"], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ConfigTypesetTypes", oFilter, "Types", "TypesName", new sap.m.BusyDialog(), this.getView(), "CompanyCodeDD", "Select", function () {
		//        }, false, "PD", true);
		//    },
		//    getMaterialUOMs: function () {
		//        var that = this;
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oStatusIdFilter = new Array();
		//        oStatusIdFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusIdFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["FMUOM"], false, false, false);
		//        oProductCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusIdFilter, "Types", "TypesName", new sap.m.BusyDialog(), this.getView(), "MaterialUOMDD", "Select", function () {
		//        });
		//        if (this.getMaterialUOMs_Exit) {
		//            this.getMaterialUOMs_Exit();
		//        }
		//    },
		//    getHeaderDropDowns: function () {
		//        var EntityName = [
		//            "Scheme",
		//            "Scheme",
		//            "Scheme",
		//            "Scheme",
		//            "Scheme"
		//        ];
		//        var PropertyName = [
		//            "SchemeType",
		//            "InvoiceEligibility",
		//            "DocToBeConsidered",
		//            "SchemeGroup1",
		//            "SchemeCat"
		//        ];
		//        this.callDropDown(EntityName, PropertyName, [
		//            gBasicDataBlock,
		//            gSchemeGroupsBlock,
		//            gClaimDataBlock,
		//            gOtherDataBlock
		//        ]);
		//        this.SchemeFreeMatGrpMaterialsDD();
		//        var that = this;
		//        var view = this.getView();
		//        var oModelData = this._oComponent.getModel("PCGW");
		//        var oSalesGroupFilter = new Array();
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		//        oSalesGroupFilter = oPPCCommon.setODataModelReadFilter(view, "", oSalesGroupFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CPTypeID"], false, false, false);
		//        oPPCCommon.getDropdown(oModelData, "ValueHelps", oSalesGroupFilter, "ID", "Description", new sap.m.BusyDialog(), view, "ChannelPartnerType", "Select", function () {
		//        }, false, "PD", true);
		//    },
		//    getItemDropDowns: function () {
		//        var PropertyName = [
		//            "SalesOrg",
		//            "Division",
		//            "DistChannel",
		//            "CPGroup1",
		//            "CPGroup4",
		//            "CPGroup5",
		//            "SchemeScope",
		//            "SchemeLevel",
		//            "SchemeType1111",
		//            "SchemeValue",
		//            "CostObjType",
		//            "GLCode",
		//            "Material",
		//            "PurchasingGroup",
		//            "MaterialGroup",
		//            "Branch",
		//            "TransactionBase",
		//            "MaterialSeries",
		//            "OnSaleOfCat",
		//            "OnSaleOfAttribute",
		//            "Banner",
		//            "ItemCat",
		//            "ItemMin",
		//            "OperandType",
		//            "SlabType",
		//            "SlabRule",
		//            "DiscountOn",
		//            "SlabCat",
		//            "SaleUnit",
		//            "ReimbursementMode",
		//            "DMSDiv",
		//            "Brand",
		//            "ProductCat",
		//            "SKUGroup",
		//            "OrderMaterialGroup"
		//        ];
		//        var EntityName = [
		//            "SchemeSalesArea",
		//            "SchemeSalesArea",
		//            "SchemeSalesArea",
		//            "SchemeSalesArea",
		//            "SchemeSalesArea",
		//            "SchemeSalesArea",
		//            "SchemeGeo",
		//            "SchemeGeo",
		//            "SchemeGeo",
		//            "SchemeGeo",
		//            "SchemeCostObject",
		//            "SchemeCostObject",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeSlab",
		//            "SchemeSlab",
		//            "SchemeSlab",
		//            "SchemeSlab",
		//            "SchemeSlab",
		//            "SchemeSlab",
		//            "SchemeSlab",
		//            "ChannelPartner",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail",
		//            "SchemeItemDetail"
		//        ];
		//        this.callDropDown(EntityName, PropertyName, [
		//            gSchemeSalesAreaBlock,
		//            gRetailerCategoryBlock,
		//            gOtherDataBlock,
		//            gSchemeGeographiesBlock,
		//            gSchemeCPsBlock,
		//            gSchemeItemsBlock,
		//            gSchemeSlabsBlock,
		//            gSchemeCostObjectBlock
		//        ]);
		//    },
		//    callDropDown: function (EntityName, PropertyName, oView) {
		//        var that = this;
		//        var totalDD = PropertyName.length;
		//        for (var i = 0; i < PropertyName.length; i++) {
		//            var oModelData = this._oComponent.getModel("PCGW");
		//            var oStatusFilter = new Array();
		//            var model = "SCGW";
		//            if (EntityName[i] === "ChannelPartner") {
		//                model = "SSGW_MST";
		//            }
		//            var mustAddDefault = true;
		//            var defaultValue = "Select";
		//            if (PropertyName[i] === "Banner" || PropertyName[i] === "Brand" || PropertyName[i] === "ProductCat" || PropertyName[i] === "OrderMaterialGroup") {
		//                mustAddDefault = false;
		//            }
		//            if (PropertyName[i] === "CPGroup1" || PropertyName[i] === "CPGroup2") {
		//                defaultValue = "All";
		//            }
		//            oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "ModelID", sap.ui.model.FilterOperator.EQ, [model], true, false, false);
		//            oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "EntityType", sap.ui.model.FilterOperator.EQ, [EntityName[i]], false, false, false);
		//            oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "PropName", sap.ui.model.FilterOperator.EQ, [PropertyName[i]], false, false, false);
		//            oProductCommon.getDropdown(oModelData, "ValueHelps", oStatusFilter, "ID", "Description", new sap.m.BusyDialog(), this.getView(), PropertyName[i] + "DD", defaultValue, function () {
		//                totalDD = totalDD - 1;
		//                if (totalDD === 0) {
		//                    that.iTotalDDs = that.iTotalDDs - 1;
		//                    if (that.iTotalDDs <= 0) {
		//                        that.Group2DD();
		//                        that.Group3DD();
		//                        that.CostObjectDD();
		//                        that.closeBusyDialog(totalDD);
		//                    }
		//                }
		//            }, false, "PD", mustAddDefault, { bSetSizeLimit: true });
		//            if (PropertyName[i] === "CPGroup5") {
		//                this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(gSchemeDetails));
		//                var oModelData = gSchemeDetails.getModel("PCGW");
		//                var oStatusFilter = new Array();
		//                oStatusFilter = oPPCCommon.setODataModelReadFilter(this.getView(), "", oStatusFilter, "Typeset", sap.ui.model.FilterOperator.EQ, ["CPGRP5"], false, false, false);
		//                oPPCCommon.getDropdown(oModelData, "ConfigTypesetTypes", oStatusFilter, "Types", "TypesName", oBusyDialog, gRetailerCategoryBlock, "CPGroup5DD", "Select", function (aDDValue) {
		//                });
		//                if (this.getStatusDD_Exit) {
		//                    this.getStatusDD_Exit();
		//                }
		//            }
		//        }
		//    },
		//    closeBusyDialog: function (totalDD) {
		//        if (totalDD === 0) {
		//            this.getView().setBusy(false);
		//        }
		//    },
		//    CostObjectDD: function () {
		//        var view = gSchemeCostObjectBlock;
		//        var oTable = view.byId("UISchemeCostObjectsTableEdit");
		//        if (oTable) {
		//            var aRows = oTable.getRows();
		//            for (var row = 0; row < aRows.length; row++) {
		//                var aCells = aRows[row].getCells();
		//                for (var cell = 0; cell < aCells.length; cell++) {
		//                    var cellId = aCells[cell].getId();
		//                    if (cellId.indexOf("fCostObjTypeIDEdit") > -1) {
		//                        var id = view.byId(cellId).getSelectedKey();
		//                    }
		//                    if (cellId.indexOf("fCostObjIDEdit") > -1) {
		//                        var obj = view.byId(cellId);
		//                        var oModelData = this._oComponent.getModel("PCGW");
		//                        var oFilter = new Array();
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SCGW"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["SchemeCostObject"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CostObject"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ID", sap.ui.model.FilterOperator.EQ, [id], false, false, false);
		//                        if (id && id !== "" && id.trim() !== "") {
		//                            oPPCCommon.getDropdown(oModelData, "ValueHelps", oFilter, "ID", "Description", new sap.m.BusyDialog(), obj, "CostObjectDD", "Select", function () {
		//                            }, false, "PD", true);
		//                        }
		//                    }
		//                }
		//            }
		//        }
		//        if (this.CostObjectDD_Exit) {
		//            this.CostObjectDD_Exit();
		//        }
		//    },
		//    Group2DD: function () {
		//        var view = gRetailerCategoryBlock;
		//        var oTable = view.byId("UISchemeSalesAreasTableEdit");
		//        if (oTable) {
		//            var aRows = oTable.getRows();
		//            for (var row = 0; row < aRows.length; row++) {
		//                var aCells = aRows[row].getCells();
		//                for (var cell = 0; cell < aCells.length; cell++) {
		//                    var cellId = aCells[cell].getId();
		//                    if (cellId.indexOf("fCPGroup1IDEdit") > -1) {
		//                        var id = view.byId(cellId).getSelectedKey();
		//                    }
		//                    if (cellId.indexOf("fCPGroup2IDEdit") > -1) {
		//                        var obj = view.byId(cellId);
		//                        var oModelData = this._oComponent.getModel("PCGW");
		//                        var oFilter = new Array();
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CPGRP2"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ID", sap.ui.model.FilterOperator.EQ, [id], false, false, false);
		//                        if (id && id !== "" && id.trim() !== "") {
		//                            oPPCCommon.getDropdown(oModelData, "ValueHelps", oFilter, "ID", "Description", new sap.m.BusyDialog(), obj, "CPGroup2DD", "All", function () {
		//                            }, false, "PD", true);
		//                        }
		//                    }
		//                }
		//            }
		//        }
		//        if (this.Group2DD_Exit) {
		//            this.Group3DD_Exit();
		//        }
		//    },
		//    Group3DD: function () {
		//        var view = gRetailerCategoryBlock;
		//        var oTable = view.byId("UISchemeSalesAreasTableEdit");
		//        if (oTable) {
		//            var aRows = oTable.getRows();
		//            for (var row = 0; row < aRows.length; row++) {
		//                var aCells = aRows[row].getCells();
		//                for (var cell = 0; cell < aCells.length; cell++) {
		//                    var cellId = aCells[cell].getId();
		//                    if (cellId.indexOf("fCPGroup2IDEdit") > -1) {
		//                        var id = view.byId(cellId).getSelectedKey();
		//                    }
		//                    if (cellId.indexOf("fCPGroup3IDEdit") > -1) {
		//                        var obj = view.byId(cellId);
		//                        var oModelData = this._oComponent.getModel("PCGW");
		//                        var oFilter = new Array();
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ModelID", sap.ui.model.FilterOperator.EQ, ["SSGW_MST"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "EntityType", sap.ui.model.FilterOperator.EQ, ["ChannelPartner"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "PropName", sap.ui.model.FilterOperator.EQ, ["CPGRP3"], false, false, false);
		//                        oFilter = oPPCCommon.setODataModelReadFilter(view, "", oFilter, "ID", sap.ui.model.FilterOperator.EQ, [id], false, false, false);
		//                        if (id && id !== "" && id.trim() !== "") {
		//                            oPPCCommon.getDropdown(oModelData, "ValueHelps", oFilter, "ID", "Description", new sap.m.BusyDialog(), obj, "CPGroup3DD", "All", function () {
		//                            }, false, "PD", true);
		//                        }
		//                    }
		//                }
		//            }
		//        }
		//        if (this.Group3DD_Exit) {
		//            this.Group3DD_Exit();
		//        }
		//    },
		//    SchemeFreeMatGrpMaterialsDD: function () {
		//        var oModelData = this._oComponent.getModel("SCGW");
		//        var oStatusFilter = new Array();
		//        var defaultValue = "Select";
		//        this.getDropdown(oModelData, "SchemeFreeMatGrpMaterials", oStatusFilter, "SchFreeMatGrpGUID", "MaterialGrpDesc", new sap.m.BusyDialog(), this.getView(), "SchemeFreeMatGrpMaterialsDD", defaultValue, function () {
		//        }, false, "PD", true);
		//    },
		//    getDropdown: function (oModel, sEntitySet, oFilters, sKey, sText, busyDialog, view, modelName, defaultValue, requestCompleted, bLoginIDOptional, appKey, bMustAddNone, mParameters) {
		//        var aDDValue = new Array();
		//        oPPCCommon.getCurrentLoggedUser({
		//            sServiceName: sEntitySet,
		//            sRequestType: "read",
		//            Application: appKey
		//        }, function (LoginID) {
		//            oFilters = oPPCCommon.setODataModelReadFilter("", "", oFilters, "LoginID", "", [LoginID], false, false, false);
		//            oModel.read("/" + sEntitySet, {
		//                filters: oFilters,
		//                success: function (oData) {
		//                    if (oData.results.length > 0) {
		//                        if (defaultValue !== null && defaultValue !== undefined && defaultValue !== "" && (oData.results.length !== 1 || (defaultValue === "None" || defaultValue === "Select") && bMustAddNone)) {
		//                            aDDValue.push({
		//                                Key: "",
		//                                Text: "(" + defaultValue + ")"
		//                            });
		//                        }
		//                        for (var i = 0; i < oData.results.length; i++) {
		//                            aDDValue.push({
		//                                Key: oData.results[i]["SchFreeMatGrpGUID"],
		//                                Text: oData.results[i]["MaterialGrp"] + " - " + oData.results[i]["MaterialGrpDesc"],
		//                                Seperator: ""
		//                            });
		//                        }
		//                        var oDDModel = new sap.ui.model.json.JSONModel();
		//                        oDDModel.setData(aDDValue);
		//                        if (mParameters) {
		//                            if (mParameters.bSetSizeLimit) {
		//                                oDDModel.setSizeLimit(aDDValue.length);
		//                            }
		//                        }
		//                        view.setModel(oDDModel, modelName);
		//                    }
		//                    if (requestCompleted)
		//                        requestCompleted(aDDValue);
		//                },
		//                error: function (error) {
		//                    busyDialog.close();
		//                    oPPCCommon.showServiceErrorPopup(error);
		//                }
		//            });
		//        });
		//    },
		//    getValidViewForField: function (aFieldId) {
		//        var view;
		//        if (gSchemeDetails.byId(aFieldId)) {
		//            view = gSchemeDetails;
		//        } else if (gHeaderBlock.byId(aFieldId)) {
		//            view = gHeaderBlock;
		//        } else if (gBasicDataBlock.byId(aFieldId)) {
		//            view = gBasicDataBlock;
		//        } else if (gSchemeGroupsBlock.byId(aFieldId)) {
		//            view = gSchemeGroupsBlock;
		//        } else if (gSchemeSalesAreaBlock.byId(aFieldId)) {
		//            view = gSchemeSalesAreaBlock;
		//        } else if (gSchemeAttachments.byId(aFieldId)) {
		//            view = gSchemeAttachments;
		//        } else if (gSchemeGeographiesBlock.byId(aFieldId)) {
		//            view = gSchemeGeographiesBlock;
		//        } else if (gSchemeCPsBlock.byId(aFieldId)) {
		//            view = gSchemeCPsBlock;
		//        } else if (gSchemeItemsBlock.byId(aFieldId)) {
		//            view = gSchemeItemsBlock;
		//        } else if (gSchemeCostObjectBlock.byId(aFieldId)) {
		//            view = gSchemeCostObjectBlock;
		//        } else if (gSchemeSlabsBlock.byId(aFieldId)) {
		//            view = gSchemeSlabsBlock;
		//        } else if (gSchemeAttachments.byId(aFieldId)) {
		//            view = gSchemeAttachments;
		//        }
		//        return view;
		//    },
		//    onReview: function () {
		//        this.validate();
		//        if (oPPCCommon.doErrMessageExist()) {
		//            if (gBasicDataBlock.byId("fDocToBeConsideredIDEdit").getSelectedKey()) {
		//                var DocToBeConsideredID = gBasicDataBlock.byId("fDocToBeConsideredIDEdit").getSelectedKey();
		//                var DocToBeConsideredDesc = gBasicDataBlock.byId("fDocToBeConsideredIDEdit").getSelectedItem().getText().split("-")[1].trim();
		//                this.getView().getModel("Schemes").setProperty("/DocToBeConsideredDesc", DocToBeConsideredDesc);
		//                this.getView().getModel("Schemes").setProperty("/DocToBeConsideredID", DocToBeConsideredID);
		//            }
		//            if (gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedKeys().length > 0) {
		//                if (gBasicDataBlock.byId("fCalculateOnIDEdit").getSelectedKey()) {
		//                    var CalculateOnID = gBasicDataBlock.byId("fCalculateOnIDEdit").getSelectedKey();
		//                    var CalculateOnDesc = gBasicDataBlock.byId("fCalculateOnIDEdit").getSelectedItem().getText().split("-")[1].trim();
		//                    this.getView().getModel("Schemes").setProperty("/CalculateOnID", CalculateOnID);
		//                    this.getView().getModel("Schemes").setProperty("/CalculateOnDesc", CalculateOnDesc);
		//                }
		//            } else {
		//                this.getView().getModel("Schemes").setProperty("/CalculateOnID", "");
		//                this.getView().getModel("Schemes").setProperty("/CalculateOnDesc", "");
		//            }
		//            this.MergeGeography();
		//            this.copyGeoDetails();
		//            this.updateScheme("X");
		//        } else {
		//            this.showError();
		//        }
		//        if (this.onReview_Exit) {
		//            this.onReview_Exit();
		//        }
		//    },
		//    MergeGeography: function () {
		//        var aTempArray = [];
		//        var MainModel = gTempSchemeGeographiesBlock.getModel("GeoGraphy").getProperty("/");
		//        var zoneData = gTempSchemeGeographiesBlock.byId("fZoneIDEdit").getSelectedKeys();
		//        var RegionData = gTempSchemeGeographiesBlock.byId("fRegionIDEdit").getSelectedKeys();
		//        var AreaData = gTempSchemeGeographiesBlock.byId("fAreaIDEdit").getSelectedKeys();
		//        var HQData = gTempSchemeGeographiesBlock.byId("fHeadQuarterIDEdit").getSelectedKeys();
		//        var DepotData = gTempSchemeGeographiesBlock.byId("fDepotIDEdit").getSelectedKeys();
		//        for (var i = 0; i < MainModel.length; i++) {
		//            if (zoneData.length > 0) {
		//                for (var j = 0; j < zoneData.length; j++) {
		//                    if (MainModel[i].GeographyValueID === zoneData[j] && MainModel[i].GeographyTypeID === "0000000001") {
		//                        aTempArray.push(MainModel[i]);
		//                    }
		//                }
		//            }
		//            if (RegionData.length > 0) {
		//                for (var j = 0; j < RegionData.length; j++) {
		//                    if (MainModel[i].GeographyValueID === RegionData[j] && MainModel[i].GeographyTypeID === "0000000002") {
		//                        aTempArray.push(MainModel[i]);
		//                    }
		//                }
		//            }
		//            if (AreaData.length > 0) {
		//                for (var j = 0; j < AreaData.length; j++) {
		//                    if (MainModel[i].GeographyValueID === AreaData[j] && MainModel[i].GeographyTypeID === "0000000003") {
		//                        aTempArray.push(MainModel[i]);
		//                    }
		//                }
		//            }
		//            if (HQData.length > 0) {
		//                for (var j = 0; j < HQData.length; j++) {
		//                    if (MainModel[i].GeographyValueID === HQData[j] && MainModel[i].GeographyTypeID === "0000000004") {
		//                        aTempArray.push(MainModel[i]);
		//                    }
		//                }
		//            }
		//            if (DepotData.length > 0) {
		//                for (var j = 0; j < DepotData.length; j++) {
		//                    if (MainModel[i].GeographyValueID === DepotData[j] && MainModel[i].GeographyTypeID === "0000000005") {
		//                        aTempArray.push(MainModel[i]);
		//                    }
		//                }
		//            }
		//        }
		//        if (zoneData.length > 0 && zoneData[0] !== "") {
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AreaOrDepot", "Areas");
		//        } else {
		//            gSchemeDetails.getModel("LocalViewSettingDtl").setProperty("/AreaOrDepot", "Depots");
		//        }
		//        var json = new sap.ui.model.json.JSONModel(aTempArray);
		//        this.getView().setModel(aTempArray, "TemPGeoData");
		//    },
		//    copyGeoDetails: function () {
		//        var view = gSchemeDetails;
		//        var _aSelectedGeo = jQuery.extend(true, [], this.getView().getModel("TemPGeoData"));
		//        _aSelectedGeo = this.addGeoProperties(_aSelectedGeo);
		//        var oItemModel = view.getModel("SchemeGeographies");
		//        var oItemModelData = oItemModel.getData();
		//        oItemModelData = [];
		//        for (var g = 0; g < _aSelectedGeo.length; g++) {
		//            if (!_aSelectedGeo[g].ParentID) {
		//                _aSelectedGeo[g].ParentID = "";
		//            }
		//            var newItem = {
		//                "GeographyGUID": oPPCCommon.generateUUID(),
		//                "SchemeGUID": null,
		//                "LoginID": "",
		//                "GeographyScopeID": "",
		//                "GeographyScopeDesc": "",
		//                "GeographyLevelID": _aSelectedGeo[g].Level + "",
		//                "GeographyLevelDesc": "",
		//                "GeographyTypeID": _aSelectedGeo[g].GeographyTypeID,
		//                "GeographyTypeDesc": _aSelectedGeo[g].GeographyTypeDesc,
		//                "GeographyValueID": _aSelectedGeo[g].GeographyValueID,
		//                "GeographyValueDesc": _aSelectedGeo[g].GeographyValueDesc,
		//                "GeographyParentTypeID": _aSelectedGeo[g].GeographyParentTypeID,
		//                "GeographyParentTypeDesc": "",
		//                "GeographyParentTypeValueID": _aSelectedGeo[g].GeographyParentTypeValueID,
		//                "GeographyParentTypeValueDesc": "",
		//                "CreatedBy": "",
		//                "CreatedOn": null,
		//                "CreatedAt": "PT18H57M31S",
		//                "ChangedBy": "",
		//                "ChangedOn": null,
		//                "ChangedAt": "PT20H17M07S",
		//                "Source": "",
		//                "ExternalRefID": "",
		//                "ExternalRefKey": ""
		//            };
		//            oItemModelData.push(newItem);
		//        }
		//        if (oItemModelData.length > 0) {
		//            if (oItemModelData[0].GeographyLevelID !== "") {
		//                oItemModelData = this.formatGeography(oItemModelData);
		//            }
		//        }
		//        oItemModel.setData(oItemModelData);
		//        oItemModel.refresh();
		//        view.getModel("LocalViewSettingDtl").setProperty("/SchemeGeographiesCount", _aSelectedGeo.length);
		//    },
		//    addGeoProperties: function (_aSelectedGeo) {
		//        var SelectedGeo = _aSelectedGeo;
		//        for (var f = 0; f < SelectedGeo.length; f++) {
		//            if (SelectedGeo[f].GeographyTypeID === "0000000001") {
		//                SelectedGeo[f].Level = "1";
		//            }
		//            if (SelectedGeo[f].GeographyTypeID === "0000000002") {
		//                SelectedGeo[f].Level = "2";
		//            }
		//            if (SelectedGeo[f].GeographyTypeID === "0000000003") {
		//                SelectedGeo[f].Level = "3";
		//            }
		//            if (SelectedGeo[f].GeographyTypeID === "0000000004") {
		//                SelectedGeo[f].Level = "4";
		//            }
		//            if (SelectedGeo[f].GeographyTypeID === "0000000005") {
		//                SelectedGeo[f].Level = "";
		//            }
		//        }
		//        return SelectedGeo;
		//    },
		//    updateScheme: function (isTestRun, Approve) {
		//        var view = gSchemeDetails;
		//        var that = this;
		//        this.oUpdateModel = this._oComponent.getModel("SCGW");
		//        this.oUpdateModel.setDeferredBatchGroups(["update"]);
		//        var sloginid = that.getCurrentUsers("ChannelPartners", "read");
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            var HeaderData1 = this.updateHeader(isTestRun, Approve);
		//            if (isTestRun === "X") {
		//                HeaderData = HeaderData1;
		//                delete HeaderData.ClaimStatus;
		//                delete HeaderData.ClaimStatusDesc;
		//                delete HeaderData.PartnerID;
		//                HeaderData.SchemeCostObjects = this.updateCOSTOBJECTS(sloginid);
		//                for (var i = 0; i < HeaderData.SchemeCostObjects.length; i++) {
		//                    HeaderData.SchemeCostObjects[i].SchemeGUID = HeaderData.SchemeGUID;
		//                    HeaderData.SchemeCostObjects[i].CreatedBy = "";
		//                    HeaderData.SchemeCostObjects[i].ChangedBy = "";
		//                    HeaderData.SchemeCostObjects[i].CreatedAt = "PT18H57M31S";
		//                    HeaderData.SchemeCostObjects[i].ChangedAt = "PT00H00M00S";
		//                    HeaderData.SchemeCostObjects[i].CostObjGUID = oPPCCommon.generateUUID().toUpperCase();
		//                }
		//                HeaderData.SchemeGeographies = this.updateGEOGRAPHYDETAILS(sloginid);
		//                for (var j = 0; j < HeaderData.SchemeGeographies.length; j++) {
		//                    HeaderData.SchemeGeographies[j].SchemeGUID = HeaderData.SchemeGUID;
		//                    HeaderData.SchemeGeographies[j].CreatedBy = "";
		//                    HeaderData.SchemeGeographies[j].ChangedBy = "";
		//                    HeaderData.SchemeGeographies[j].CreatedAt = "PT18H57M31S";
		//                    HeaderData.SchemeGeographies[j].ChangedAt = "PT20H17M07S";
		//                    HeaderData.SchemeGeographies[j].GeographyGUID = oPPCCommon.generateUUID().toUpperCase();
		//                }
		//                HeaderData.SchemePartnerTypes = this.updateClonePartnerTypes(sloginid);
		//                if (gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedKeys().length > 0) {
		//                    HeaderData.SchemePaymentModes = this.updateClonePaymentModes(sloginid);
		//                } else {
		//                    this.getView().getModel("LocalViewSettingDtl").setProperty("/PaymentMode", "");
		//                }
		//                HeaderData.SchemeSalesAreas = this.updateRETAILERCATEGORY(sloginid);
		//                for (var k = 0; k < HeaderData.SchemeSalesAreas.length; k++) {
		//                    HeaderData.SchemeSalesAreas[k].SchemeGUID = HeaderData.SchemeGUID;
		//                    HeaderData.SchemeSalesAreas[k].CreatedBy = "";
		//                    HeaderData.SchemeSalesAreas[k].ChangedBy = "CFA_USR01";
		//                    HeaderData.SchemeSalesAreas[k].CreatedAt = "PT18H37M35S";
		//                    HeaderData.SchemeSalesAreas[k].ChangedAt = "PT12H08M26S";
		//                    HeaderData.SchemeSalesAreas[k].CreatedOn = null;
		//                    HeaderData.SchemeSalesAreas[k].SalesAreaGUID = oPPCCommon.generateUUID().toUpperCase();
		//                }
		//                HeaderData.SchemeCPs = this.cloneSCHEMECPS(sloginid);
		//                for (var l = 0; l < HeaderData.SchemeCPs.length; l++) {
		//                    delete HeaderData.SchemeCPs[l].RegistrationTypeID;
		//                    delete HeaderData.SchemeCPs[l].RegistrationTypeDesc;
		//                    delete HeaderData.SchemeCPs[l].WindowLength;
		//                    delete HeaderData.SchemeCPs[l].WindowBreadth;
		//                    delete HeaderData.SchemeCPs[l].WindowHeight;
		//                    delete HeaderData.SchemeCPs[l].WindowUOM;
		//                    HeaderData.SchemeCPs[l].SchemeGUID = HeaderData.SchemeGUID;
		//                    HeaderData.SchemeCPs[l].CreatedBy = "";
		//                    HeaderData.SchemeCPs[l].ChangedBy = "";
		//                    HeaderData.SchemeCPs[l].CreatedAt = "PT18H37M35S";
		//                    HeaderData.SchemeCPs[l].CreatedOn = null;
		//                    HeaderData.SchemeCPs[l].ChangedAt = "PT12H08M26S";
		//                    HeaderData.SchemeCPs[l].SchemeCPGUID = oPPCCommon.generateUUID().toUpperCase();
		//                    HeaderData.SchemeCPs[l].LoginID = sloginid;
		//                }
		//                HeaderData.SchemeItemDetails = this.updateSALESCRITERIA(sloginid);
		//                for (var m = 0; m < HeaderData.SchemeItemDetails.length; m++) {
		//                    HeaderData.SchemeItemDetails[m].SchemeGUID = HeaderData.SchemeGUID;
		//                    HeaderData.SchemeItemDetails[m].CreatedBy = "";
		//                    HeaderData.SchemeItemDetails[m].ChangedBy = "";
		//                    HeaderData.SchemeItemDetails[m].CreatedAt = "PT00H00M00S";
		//                    HeaderData.SchemeItemDetails[m].ChangedAt = "PT18H57M31S";
		//                    HeaderData.SchemeItemDetails[m].CreatedOn = null;
		//                    delete HeaderData.SchemeItemDetails[m].FreeMatCritria;
		//                    delete HeaderData.SchemeItemDetails[m].FreeMatCritriaTxt;
		//                    var ExistGuid = HeaderData.SchemeItemDetails[m].SchemeItemGUID.toUpperCase();
		//                    HeaderData.SchemeItemDetails[m].SchemeItemGUID = oPPCCommon.generateUUID().toUpperCase();
		//                    var NewGuid = HeaderData.SchemeItemDetails[m].SchemeItemGUID.toUpperCase();
		//                    for (var EG = 0; EG < HeaderData.SchemeItemDetails.length; EG++) {
		//                        if (HeaderData.SchemeItemDetails[EG].HierarchicalRefGUID) {
		//                            if (ExistGuid === HeaderData.SchemeItemDetails[EG].HierarchicalRefGUID.toUpperCase()) {
		//                                HeaderData.SchemeItemDetails[EG].HierarchicalRefGUID = NewGuid;
		//                            }
		//                        }
		//                    }
		//                }
		//                HeaderData.SchemeSlabs = this.updateSLABS(sloginid);
		//                for (var n = 0; n < HeaderData.SchemeSlabs.length; n++) {
		//                    if (HeaderData.SchemeSlabs[n].PointsPerUnit) {
		//                        HeaderData.SchemeSlabs[n].PointsPerUnit = parseFloat(HeaderData.SchemeSlabs[n].PointsPerUnit);
		//                    }
		//                    HeaderData.SchemeSlabs[n].SchemeGUID = HeaderData.SchemeGUID;
		//                    HeaderData.SchemeSlabs[n].CreatedBy = "";
		//                    HeaderData.SchemeSlabs[n].ChangedBy = "";
		//                    HeaderData.SchemeSlabs[n].CreatedAt = "PT00H00M00S";
		//                    HeaderData.SchemeSlabs[n].ChangedAt = "PT00H00M00S";
		//                    HeaderData.SchemeSlabs[n].CreatedOn = null;
		//                    if (HeaderData.SchemeSlabs[n].FreeArticleDesc !== "") {
		//                        HeaderData.SchemeSlabs[n].FreeArticleDesc = "";
		//                    }
		//                    if (HeaderData.SchemeSlabs[n].ScratchCardDesc !== "") {
		//                        HeaderData.SchemeSlabs[n].ScratchCardDesc = "";
		//                    }
		//                    HeaderData.SchemeSlabs[n].SchemeItemGUID = "00000000-0000-0000-0000-000000000000";
		//                    delete HeaderData.SchemeSlabs[n].FreeQtyUOM;
		//                    HeaderData.SchemeSlabs[n].SlabGUID = oPPCCommon.generateUUID().toUpperCase();
		//                }
		//                this.removeDataFromClone(HeaderData);
		//            }
		//            oBusyDialog.open();
		//            view.setBusy(true);
		//            if (isTestRun === "" || isTestRun === undefined) {
		//                HeaderData.TestRun = "";
		//            }
		//            var SchemeHolds = gHoldBlockView.getModel("SchemeHold").getData();
		//            for (var z = 0; z < SchemeHolds.length; z++) {
		//                delete SchemeHolds[z].holdFromMinDate;
		//                delete SchemeHolds[z].holdToMinDate;
		//            }
		//            HeaderData.SchemeHolds = gHoldBlockView.getModel("SchemeHold").getData();
		//            HeaderData.LoginID = that.getCurrentUsers("Schemes", "read");
		//            this.oUpdateModel.create("/Schemes", HeaderData, {
		//                success: function (aData) {
		//                    oPPCCommon.removeDuplicateMsgsInMsgMgr();
		//                    if (oPPCCommon.doErrMessageExist()) {
		//                        if (isTestRun) {
		//                            sap.ui.controller("com.arteriatech.ss.schemes.controller.block.SchemeItemsBlock").setItemNo();
		//                            var desc = "";
		//                            if (that._oUpdateSchemePartnerTypes.length > 0) {
		//                                for (var j = 0; j < that._oUpdateSchemePartnerTypes.length; j++) {
		//                                    desc = that._oUpdateSchemePartnerTypes[j].PartnerTypeDesc + "," + desc;
		//                                }
		//                                if (desc !== "") {
		//                                    desc = desc.substring(0, desc.length - 1);
		//                                }
		//                                that.getView().getModel("LocalViewSettingDtl").setProperty("/PartnerType", desc);
		//                            }
		//                            var BillingModeDesc = "";
		//                            if (that._oUpdateSchemePaymentModes) {
		//                                if (that._oUpdateSchemePaymentModes.length > 0) {
		//                                    for (var c = 0; c < that._oUpdateSchemePaymentModes.length; c++) {
		//                                        BillingModeDesc = that._oUpdateSchemePaymentModes[c].PaymtModeDsc + "," + BillingModeDesc;
		//                                    }
		//                                    if (BillingModeDesc !== "") {
		//                                        BillingModeDesc = BillingModeDesc.substring(0, BillingModeDesc.length - 1);
		//                                    }
		//                                    that.getView().getModel("LocalViewSettingDtl").setProperty("/PaymentMode", BillingModeDesc);
		//                                }
		//                            }
		//                            oBusyDialog.close();
		//                            view.setBusy(false);
		//                            that.gotoSave();
		//                            that.getView().getModel("Schemes").setProperty("/ValidFrom", aData.ValidFrom);
		//                            that.getView().getModel("Schemes").setProperty("/ValidTo", aData.ValidTo);
		//                            that.getView().getModel("Schemes").setProperty("/RollOutDate", aData.RollOutDate);
		//                        } else {
		//                            that.updatedSuccessfully(aData.SchemeGUID);
		//                            oBusyDialog.close();
		//                            view.setBusy(false);
		//                        }
		//                    } else {
		//                        oBusyDialog.close();
		//                        view.setBusy(false);
		//                        that.showError();
		//                    }
		//                },
		//                error: function () {
		//                    oBusyDialog.close();
		//                    view.setBusy(false);
		//                    that.showError();
		//                }
		//            });
		//        } else {
		//            this.updateHeader(isTestRun, Approve, sloginid);
		//            this.updateCOSTOBJECTS(sloginid);
		//            this.updateGEOGRAPHYDETAILS(sloginid);
		//            this.updateRETAILERCATEGORY(sloginid);
		//            this.updateSCHEMECPS(sloginid);
		//            this.updateSALESCRITERIA(sloginid, Approve);
		//            this.updateHold(sloginid);
		//            if (gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedKeys().length > 0) {
		//                this.updatePaymentModes(sloginid);
		//            } else {
		//                this.getView().getModel("LocalViewSettingDtl").setProperty("/PaymentMode", "");
		//            }
		//            this.updatePartnerTypes(sloginid);
		//            this.updateSLABS(sloginid);
		//            oBusyDialog.open();
		//            view.setBusy(true);
		//            this.oUpdateModel.submitChanges({
		//                groupId: "update",
		//                success: function (oData) {
		//                    oPPCCommon.removeDuplicateMsgsInMsgMgr();
		//                    if (oPPCCommon.doErrMessageExist()) {
		//                        if (isTestRun) {
		//                            gSchemeAttachments.byId("fRemarksEdit").setValueState("None");
		//                            gSchemeAttachments.byId("fRemarksEdit").setValueStateText("");
		//                            var serverDate = oPPCCommon.getCurrentServerDate(that);
		//                            serverDate = that.convertDate(serverDate);
		//                            var desc = "";
		//                            if (that._oUpdateSchemePartnerTypes.length > 0) {
		//                                for (var x = 0; x < that._oUpdateSchemePartnerTypes.length; x++) {
		//                                    desc = that._oUpdateSchemePartnerTypes[x].PartnerTypeDesc + "," + desc;
		//                                }
		//                                if (desc !== "") {
		//                                    desc = desc.substring(0, desc.length - 1);
		//                                }
		//                                that.getView().getModel("LocalViewSettingDtl").setProperty("/PartnerType", desc);
		//                            }
		//                            var BillingModeDesc = "";
		//                            if (that._oUpdateSchemePaymentModes) {
		//                                if (that._oUpdateSchemePaymentModes.length > 0) {
		//                                    for (var c = 0; c < that._oUpdateSchemePaymentModes.length; c++) {
		//                                        BillingModeDesc = that._oUpdateSchemePaymentModes[c].PaymtModeDsc + "," + BillingModeDesc;
		//                                    }
		//                                    if (BillingModeDesc !== "") {
		//                                        BillingModeDesc = BillingModeDesc.substring(0, BillingModeDesc.length - 1);
		//                                    }
		//                                    that.getView().getModel("LocalViewSettingDtl").setProperty("/PaymentMode", BillingModeDesc);
		//                                }
		//                            }
		//                            oBusyDialog.close();
		//                            view.setBusy(false);
		//                            that.gotoSave();
		//                            sap.ui.controller("com.arteriatech.ss.schemes.controller.block.SchemeItemsBlock").setItemNo();
		//                        } else {
		//                            if (gSchemeDetails.getModel("LocalViewSettingDtl").getProperty("/EditAndApprove")) {
		//                                var title = oi18n.getText("DetailPage.Dialog.Approve.comments");
		//                                that.onApprovalDialog("X", "", title);
		//                            } else {
		//                                that.updatedSuccessfully();
		//                                oBusyDialog.close();
		//                                view.setBusy(false);
		//                            }
		//                        }
		//                    } else {
		//                        oBusyDialog.close();
		//                        view.setBusy(false);
		//                        that.showError();
		//                    }
		//                },
		//                error: function () {
		//                    oBusyDialog.close();
		//                    gSchemeDetails.setBusy(false);
		//                    that.showError();
		//                }
		//            });
		//        }
		//    },
		//    updateHold: function (sloginid) {
		//        this._oUpdateSchemeHold = jQuery.extend(true, [], gHoldBlockView.getModel("SchemeHold").getData());
		//        for (var i = 0; i < this._oUpdateSchemeHold.length; i++) {
		//            delete this._oUpdateSchemeHold[i].holdFromMinDate;
		//            delete this._oUpdateSchemeHold[i].holdToMinDate;
		//            this._oUpdateSchemeHold[i].SchemeHoldGUID = this._oUpdateSchemeHold[i].SchemeHoldGUID.toUpperCase();
		//            this._oUpdateSchemeHold[i].SchemeGUID = this._oUpdateSchemeHold[i].SchemeGUID.toUpperCase();
		//            this._oUpdateSchemeHold[i].HoldFrom = oPPCCommon.addHoursAndMinutesToDate({ dDate: this._oUpdateSchemeHold[i].HoldFrom });
		//            this._oUpdateSchemeHold[i].HoldTo = oPPCCommon.addHoursAndMinutesToDate({ dDate: this._oUpdateSchemeHold[i].HoldTo });
		//            if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                    this.oUpdateModel.update("/SchemeHolds(guid'" + this._oUpdateSchemeHold[i].SchemeHoldGUID + "')", this._oUpdateSchemeHold[i], { groupId: "update" });
		//                }
		//            }
		//        }
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            return this._oUpdateSchemeHold;
		//        }
		//    },
		//    updateClonePaymentModes: function (LoginID) {
		//        var CPTypes1 = [];
		//        this._oUpdateSchemePaymentModes = [];
		//        CPTypes1 = gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedKeys();
		//        if (CPTypes1.length > 0) {
		//            for (var i = 0; i < CPTypes1.length; i++) {
		//                var aTemp = {
		//                    "PymdGuid": oPPCCommon.generateUUID().toUpperCase(),
		//                    "LoginID": LoginID,
		//                    "SchGuid": this.getView().getModel("Schemes").getProperty("/SchemeGUID").toUpperCase(),
		//                    "PaymtModeKey": CPTypes1[i],
		//                    "PaymtModeDsc": gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedItems()[i].getTooltip(),
		//                    "CreatedBy": "",
		//                    "ChangedBy": "",
		//                    "CreatedAt": "PT18H57M31S",
		//                    "ChangedAt": "PT20H17M07S",
		//                    "CreatedOn": null,
		//                    "ChangedOn": null,
		//                    "Source": ""
		//                };
		//                this._oUpdateSchemePaymentModes.push(aTemp);
		//            }
		//        }
		//        return this._oUpdateSchemePaymentModes;
		//    },
		//    updatePaymentModes: function (LoginID) {
		//        var CPTypes1 = [];
		//        var TempArray = [];
		//        this._oUpdateSchemePaymentModes = this._oComponent.getModel("SchemePaymentModes").getData();
		//        CPTypes1 = gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedKeys();
		//        if (CPTypes1.length === 0) {
		//            for (var i = 0; i < this._oUpdateSchemePaymentModes.length; i++) {
		//                CPTypes1.push(this._oUpdateSchemePaymentModes[i].PaymtModeKey);
		//            }
		//        }
		//        if (CPTypes1.length > 0) {
		//            for (var i = 0; i < CPTypes1.length; i++) {
		//                var aTemp = {
		//                    "PymdGuid": oPPCCommon.generateUUID().toUpperCase(),
		//                    "LoginID": "",
		//                    "SchGuid": this.getView().getModel("Schemes").getProperty("/SchemeGUID").toUpperCase(),
		//                    "PaymtModeKey": CPTypes1[i],
		//                    "PaymtModeDsc": "",
		//                    "CreatedBy": "",
		//                    "ChangedBy": "",
		//                    "CreatedAt": "PT18H57M31S",
		//                    "ChangedAt": "PT00H00M00S",
		//                    "CreatedOn": null,
		//                    "ChangedOn": null,
		//                    "Source": ""
		//                };
		//                TempArray.push(aTemp);
		//                if (gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedItems()[i]) {
		//                    TempArray[i].PaymtModeDsc = gBasicDataBlock.byId("fSchemePaymentModeEdit").getSelectedItems()[i].getTooltip();
		//                } else {
		//                    TempArray[i].PaymtModeDsc = this._oUpdateSchemePaymentModes[i].PaymtModeDsc;
		//                }
		//            }
		//        }
		//        for (var CT = 0; CT < TempArray.length; CT++) {
		//            for (var SCT = 0; SCT < this._oUpdateSchemePaymentModes.length; SCT++) {
		//                TempArray[CT].SchGuid = this._oUpdateSchemePaymentModes[0].SchGuid;
		//                TempArray[CT].CreatedBy = this._oUpdateSchemePaymentModes[0].CreatedBy;
		//                TempArray[CT].ChangedBy = this._oUpdateSchemePaymentModes[0].ChangedBy;
		//                TempArray[CT].CreatedAt = this._oUpdateSchemePaymentModes[0].CreatedAt;
		//                TempArray[CT].ChangedAt = this._oUpdateSchemePaymentModes[0].ChangedAt;
		//                TempArray[CT].CreatedOn = this._oUpdateSchemePaymentModes[0].CreatedOn;
		//                TempArray[CT].ChangedOn = this._oUpdateSchemePaymentModes[0].ChangedOn;
		//                TempArray[CT].Source = this._oUpdateSchemePaymentModes[0].Source;
		//                if (TempArray[CT].PaymtModeKey === this._oUpdateSchemePaymentModes[SCT].PaymtModeKey) {
		//                    TempArray[CT].PymdGuid = this._oUpdateSchemePaymentModes[SCT].PymdGuid;
		//                    TempArray[CT].Source = this._oUpdateSchemePaymentModes[SCT].Source;
		//                }
		//            }
		//        }
		//        this._oUpdateSchemePaymentModes = TempArray;
		//        if (this._oUpdateSchemePaymentModes.length > 0) {
		//            for (var i = 0; i < this._oUpdateSchemePaymentModes.length; i++) {
		//                this._oUpdateSchemePaymentModes[i].LoginID = LoginID;
		//                this._oUpdateSchemePaymentModes[i].PymdGuid = this._oUpdateSchemePaymentModes[i].PymdGuid.toUpperCase();
		//                this._oUpdateSchemePaymentModes[i].SchGuid = this._oUpdateSchemePaymentModes[i].SchGuid.toUpperCase();
		//                var PymdGuid = "guid'" + this._oUpdateSchemePaymentModes[i].PymdGuid + "'";
		//                var SchGuid = "guid'" + this._oUpdateSchemePaymentModes[i].SchGuid + "'";
		//                this.oUpdateModel.update("/SchemePaymentModes(PymdGuid=" + PymdGuid + ",SchGuid=" + SchGuid + ")", this._oUpdateSchemePaymentModes[i], { groupId: "update" });
		//            }
		//        }
		//    },
		//    updateClonePartnerTypes: function (LoginID) {
		//        var CPTypes1 = [];
		//        this._oUpdateSchemePartnerTypes = [];
		//        CPTypes1 = gBasicDataBlock.byId("fPartnerTypeIDEdit").getSelectedKeys();
		//        if (CPTypes1.length > 0) {
		//            for (var i = 0; i < CPTypes1.length; i++) {
		//                if (CPTypes1[i] !== "") {
		//                    var aTemp = {
		//                        "PartnerTypeGUID": oPPCCommon.generateUUID().toUpperCase(),
		//                        "LoginID": LoginID,
		//                        "SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID").toUpperCase(),
		//                        "PartnerTypeID": CPTypes1[i],
		//                        "PartnerTypeDesc": gBasicDataBlock.byId("fPartnerTypeIDEdit").getSelectedItems()[i].getTooltip(),
		//                        "CreatedBy": "",
		//                        "ChangedBy": "",
		//                        "CreatedAt": "PT18H57M31S",
		//                        "ChangedAt": "PT20H17M07S",
		//                        "CreatedOn": null,
		//                        "ChangedOn": null,
		//                        "Source": ""
		//                    };
		//                }
		//                this._oUpdateSchemePartnerTypes.push(aTemp);
		//            }
		//        }
		//        return this._oUpdateSchemePartnerTypes;
		//    },
		//    updatePartnerTypes: function (LoginID) {
		//        var CPTypes1 = [];
		//        var TempArray = [];
		//        this._oUpdateSchemePartnerTypes = this._oComponent.getModel("SchemePartnerTypes").getData();
		//        CPTypes1 = gBasicDataBlock.byId("fPartnerTypeIDEdit").getSelectedKeys();
		//        if (CPTypes1.length === 0) {
		//            for (var i = 0; i < this._oUpdateSchemePartnerTypes.length; i++) {
		//                CPTypes1.push(this._oUpdateSchemePartnerTypes[i].PartnerTypeID);
		//            }
		//        }
		//        if (CPTypes1.length > 0) {
		//            for (var i = 0; i < CPTypes1.length; i++) {
		//                var aTemp = {
		//                    "PartnerTypeGUID": oPPCCommon.generateUUID().toUpperCase(),
		//                    "LoginID": "",
		//                    "SchemeGUID": this.getView().getModel("Schemes").getProperty("/SchemeGUID").toUpperCase(),
		//                    "PartnerTypeID": CPTypes1[i],
		//                    "PartnerTypeDesc": "",
		//                    "CreatedBy": "",
		//                    "ChangedBy": "",
		//                    "CreatedAt": "PT18H57M31S",
		//                    "ChangedAt": "PT00H00M00S",
		//                    "CreatedOn": null,
		//                    "ChangedOn": null,
		//                    "Source": ""
		//                };
		//                TempArray.push(aTemp);
		//                if (gBasicDataBlock.byId("fPartnerTypeIDEdit").getSelectedItems()[i]) {
		//                    TempArray[i].PartnerTypeDesc = gBasicDataBlock.byId("fPartnerTypeIDEdit").getSelectedItems()[i].getTooltip();
		//                } else {
		//                    if (this._oUpdateSchemePartnerTypes[0].PartnerTypeDesc) {
		//                        TempArray[i].PartnerTypeDesc = this._oUpdateSchemePartnerTypes[0].PartnerTypeDesc;
		//                    }
		//                }
		//            }
		//        }
		//        for (var CT = 0; CT < TempArray.length; CT++) {
		//            for (var SCT = 0; SCT < this._oUpdateSchemePartnerTypes.length; SCT++) {
		//                TempArray[CT].SchemeGUID = this._oUpdateSchemePartnerTypes[0].SchemeGUID;
		//                TempArray[CT].CreatedBy = this._oUpdateSchemePartnerTypes[0].CreatedBy;
		//                TempArray[CT].ChangedBy = this._oUpdateSchemePartnerTypes[0].ChangedBy;
		//                TempArray[CT].CreatedAt = this._oUpdateSchemePartnerTypes[0].CreatedAt;
		//                TempArray[CT].ChangedAt = this._oUpdateSchemePartnerTypes[0].ChangedAt;
		//                TempArray[CT].CreatedOn = this._oUpdateSchemePartnerTypes[0].CreatedOn;
		//                TempArray[CT].ChangedOn = this._oUpdateSchemePartnerTypes[0].ChangedOn;
		//                TempArray[CT].Source = this._oUpdateSchemePartnerTypes[0].Source;
		//                if (TempArray[CT].PartnerTypeID === this._oUpdateSchemePartnerTypes[SCT].PartnerTypeID) {
		//                    TempArray[CT].PartnerTypeGUID = this._oUpdateSchemePartnerTypes[SCT].PartnerTypeGUID;
		//                    TempArray[CT].Source = this._oUpdateSchemePartnerTypes[SCT].Source;
		//                }
		//            }
		//        }
		//        this._oUpdateSchemePartnerTypes = TempArray;
		//        if (this._oUpdateSchemePartnerTypes.length > 0) {
		//            for (var i = 0; i < this._oUpdateSchemePartnerTypes.length; i++) {
		//                this._oUpdateSchemePartnerTypes[i].LoginID = LoginID;
		//                this._oUpdateSchemePartnerTypes[i].PartnerTypeGUID = this._oUpdateSchemePartnerTypes[i].PartnerTypeGUID.toUpperCase();
		//                this._oUpdateSchemePartnerTypes[i].SchemeGUID = this._oUpdateSchemePartnerTypes[i].SchemeGUID.toUpperCase();
		//                var partnerTypeGuid = "guid'" + this._oUpdateSchemePartnerTypes[i].PartnerTypeGUID + "'";
		//                var SchemeGuid = "guid'" + this._oUpdateSchemePartnerTypes[i].SchemeGUID + "'";
		//                this.oUpdateModel.update("/SchemePartnerTypes(PartnerTypeGUID=" + partnerTypeGuid + ",SchemeGUID=" + SchemeGuid + ")", this._oUpdateSchemePartnerTypes[i], { groupId: "update" });
		//            }
		//        }
		//    },
		//    removeDataFromClone: function (HeaderData) {
		//        HeaderData.ApprovedOn = null;
		//        HeaderData.ApprovedBy = "";
		//        HeaderData.CreatedOn = null;
		//        HeaderData.CreatedAt = null;
		//        HeaderData.CreatedBy = "";
		//        HeaderData.StatusID = "";
		//        HeaderData.StatusDesc = "";
		//        HeaderData.ApprovalStatusID = "";
		//        HeaderData.ApprovalStatusDesc = "";
		//        HeaderData.ChangedAt = "PT20H17M07S";
		//        HeaderData.IsHeaderBasedSlab = "";
		//        HeaderData.ClaimInd = "";
		//        HeaderData.VendorName = "";
		//        HeaderData.ValidFromTime = null;
		//        HeaderData.ValidToTime = null;
		//        HeaderData.SchemeCostObjects.CreatedOn = null;
		//    },
		//    getLoggedUser: function () {
		//        var that = this;
		//        var sLoginID = that.getCurrentUsers("UserLogins", "read");
		//        this.LoginName = "";
		//        var contextPath = "UserProfiles(Application='PD')";
		//        var oDataModel = this._oComponent.getModel("PUGW");
		//        oDataModel.setHeaders({ "x-arteria-loginid": sLoginID });
		//        oDataModel.read("/" + contextPath, {
		//            success: function (oData) {
		//                that.LoginName = oData.LoginName;
		//            }
		//        });
		//    },
		//    updateHeader: function (isTestRun, Approve, sloginid) {
		//        var that = this;
		//        this._oSchemes = jQuery.extend({}, this._oComponent.getModel("Schemes").getData());
		//        delete this._oSchemes.SchemePartnerTypes;
		//        delete this._oSchemes.SchemePaymentModes;
		//        delete this._oSchemes.SchemeHolds;
		//        this._oSchemes.LoginID = that.getCurrentUsers("Schemes", "read");
		//        if (Approve === "Do") {
		//            this._oSchemes.StatusID = "02";
		//            this._oSchemes.StatusDesc = "Inactive";
		//        }
		//        this._oSchemes.TestRun = isTestRun;
		//        if (!isTestRun) {
		//            this._oSchemes.TestRun = "";
		//        }
		//        if (window.location.hash.indexOf("InstanceID") !== -1) {
		//            if (!isTestRun) {
		//                this._oSchemes.TestRun = "E";
		//            }
		//        }
		//        this._oSchemes.ValidFrom = oPPCCommon.addHoursAndMinutesToDate({ dDate: this._oSchemes.ValidFrom });
		//        this._oSchemes.ValidTo = oPPCCommon.addHoursAndMinutesToDate({ dDate: this._oSchemes.ValidTo });
		//        this._oSchemes.RollOutDate = oPPCCommon.addHoursAndMinutesToDate({ dDate: this._oSchemes.RollOutDate });
		//        if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            this.oUpdateModel.update("/Schemes(guid'" + this._oSchemes.SchemeGUID + "')", this._oSchemes, { groupId: "update" });
		//        } else {
		//            return this._oSchemes;
		//        }
		//    },
		//    convertDate: function (serverDate) {
		//        var d = serverDate;
		//        return [
		//            this.pad(d.getDate()),
		//            this.pad(d.getMonth() + 1),
		//            d.getFullYear()
		//        ].join("/");
		//    },
		//    pad: function (s) {
		//        return s < 10 ? "0" + s : s;
		//    },
		//    updateCOSTOBJECTS: function (sloginid) {
		//        this._oUpdateSchemeCostObjects = jQuery.extend([], this._oComponent.getModel("SchemeCostObjects").getData());
		//        if (this._oUpdateSchemeCostObjects.length <= 0) {
		//            var aTemp = {
		//                "CostObjGUID": oPPCCommon.generateUUID(),
		//                "LoginID": "",
		//                "SchemeGUID": null,
		//                "GLCode": "",
		//                "GLCodeDesc": "",
		//                "CostObjID": "",
		//                "CostObjDesc": "",
		//                "CostObjTypeID": "",
		//                "CostObjTypeDesc": "",
		//                "PercOfAlloction": "0.00",
		//                "CreatedBy": "",
		//                "CreatedOn": null,
		//                "CreatedAt": "PT18H57M31S",
		//                "ChangedBy": "",
		//                "ChangedOn": null,
		//                "ChangedAt": "PT00H00M00S",
		//                "Source": "",
		//                "ExternalRefID": "",
		//                "ExternalRefKey": ""
		//            };
		//            this._oUpdateSchemeCostObjects.push(aTemp);
		//        }
		//        for (var i = 0; i < this._oUpdateSchemeCostObjects.length; i++) {
		//            this._oUpdateSchemeCostObjects[i].LoginID = sloginid;
		//            this._oUpdateSchemeCostObjects[i].CostObjGUID = this._oUpdateSchemeCostObjects[i].CostObjGUID.toUpperCase();
		//            this._oUpdateSchemeCostObjects[i].SchemeGUID = this._oUpdateSchemeCostObjects[i].SchemeGUID.toUpperCase();
		//            if (this._oUpdateSchemeCostObjects[i].PercOfAlloction && !isNaN(this._oUpdateSchemeCostObjects[i].PercOfAlloction)) {
		//                this._oUpdateSchemeCostObjects[i].PercOfAlloction = this._oUpdateSchemeCostObjects[i].PercOfAlloction.toString();
		//            } else {
		//                this._oUpdateSchemeCostObjects[i].PercOfAlloction = this._oUpdateSchemeCostObjects[i].PercOfAlloction.toString();
		//            }
		//            if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                this.oUpdateModel.update("/SchemeCostObjects(guid'" + this._oUpdateSchemeCostObjects[i].CostObjGUID + "')", this._oUpdateSchemeCostObjects[i], { groupId: "update" });
		//            }
		//        }
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            return this._oUpdateSchemeCostObjects;
		//        }
		//    },
		//    updateGEOGRAPHYDETAILS: function (sloginid) {
		//        this._oUpdateSchemeGeographies = jQuery.extend(true, [], this._oComponent.getModel("SchemeGeographies").getData());
		//        if (this._oUpdateSchemeGeographies.length <= 0) {
		//            var aTemp = {
		//                "GeographyGUID": oPPCCommon.generateUUID(),
		//                "SchemeGUID": null,
		//                "LoginID": "",
		//                "GeographyScopeID": "",
		//                "GeographyScopeDesc": "",
		//                "GeographyLevelID": "",
		//                "GeographyLevelDesc": "",
		//                "GeographyTypeID": "",
		//                "GeographyTypeDesc": "",
		//                "GeographyValueID": "",
		//                "GeographyValueDesc": "",
		//                "GeographyParentTypeID": "",
		//                "GeographyParentTypeDesc": "",
		//                "GeographyParentTypeValueID": "",
		//                "GeographyParentTypeValueDesc": "",
		//                "CreatedBy": "",
		//                "CreatedOn": null,
		//                "CreatedAt": "PT18H57M31S",
		//                "ChangedBy": "",
		//                "ChangedOn": null,
		//                "ChangedAt": "PT20H17M07S",
		//                "Source": "",
		//                "ExternalRefID": "",
		//                "ExternalRefKey": ""
		//            };
		//            this._oUpdateSchemeGeographies.push(aTemp);
		//        }
		//        for (var g = 0; g < this._oUpdateSchemeGeographies.length; g++) {
		//            delete this._oUpdateSchemeGeographies[g].Name;
		//            this._oUpdateSchemeGeographies[g].LoginID = sloginid;
		//            this._oUpdateSchemeGeographies[g].GeographyGUID = this._oUpdateSchemeGeographies[g].GeographyGUID.toUpperCase();
		//            this._oUpdateSchemeGeographies[g].SchemeGUID = this._oComponent.getModel("Schemes").getProperty("/SchemeGUID");
		//            if (this._oUpdateSchemeGeographies[g].SchemeGUID) {
		//                this._oUpdateSchemeGeographies[g].SchemeGUID = this._oUpdateSchemeGeographies[g].SchemeGUID.toUpperCase();
		//            }
		//            if (this._oUpdateSchemeGeographies[g].results) {
		//                for (var j = 0; j < this._oUpdateSchemeGeographies[g].results.length; j++) {
		//                    this._oUpdateSchemeGeographies.push(this._oUpdateSchemeGeographies[g].results[j]);
		//                }
		//            }
		//        }
		//        for (var i = 0; i < this._oUpdateSchemeGeographies.length; i++) {
		//            delete this._oUpdateSchemeGeographies[i].results;
		//            if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                this.oUpdateModel.update("/SchemeGeographies(guid'" + this._oUpdateSchemeGeographies[i].GeographyGUID + "')", this._oUpdateSchemeGeographies[i], { groupId: "update" });
		//            }
		//        }
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            return this._oUpdateSchemeGeographies;
		//        }
		//    },
		//    updateRETAILERCATEGORY: function (sloginid) {
		//        this._oUpdateSchemeSalesAreas = jQuery.extend([], this._oComponent.getModel("SchemeSalesAreas").getData());
		//        if (this._oUpdateSchemeSalesAreas.length > 0) {
		//            for (var i = 0; i < this._oUpdateSchemeSalesAreas.length; i++) {
		//                this._oUpdateSchemeSalesAreas[i].LoginID = sloginid;
		//                this._oUpdateSchemeSalesAreas[i].SalesAreaGUID = this._oUpdateSchemeSalesAreas[i].SalesAreaGUID.toUpperCase();
		//                this._oUpdateSchemeSalesAreas[i].SchemeGUID = this._oUpdateSchemeSalesAreas[i].SchemeGUID.toUpperCase();
		//                if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                    this.oUpdateModel.update("/SchemeSalesAreas(guid'" + this._oUpdateSchemeSalesAreas[i].SalesAreaGUID + "')", this._oUpdateSchemeSalesAreas[i], { groupId: "update" });
		//                }
		//            }
		//        }
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            return this._oUpdateSchemeSalesAreas;
		//        }
		//    },
		//    cloneSCHEMECPS: function (sloginid) {
		//        this._oUpdateDistributors = jQuery.extend([], this._oComponent.getModel("Distributors").getData());
		//        for (var k = 0; k < this._oUpdateDistributors.length; k++) {
		//            this._oUpdateDistributors[k].LoginID = sloginid;
		//            this._oUpdateDistributors[k].SchemeCPGUID = this._oUpdateDistributors[k].SchemeCPGUID.toUpperCase();
		//            this._oUpdateDistributors[k].CPGUID = this._oUpdateDistributors[k].CPGUID.toUpperCase();
		//            if (this._oUpdateDistributors[k].SchemeGUID) {
		//                this._oUpdateDistributors[k].SchemeGUID = this._oUpdateDistributors[k].SchemeGUID.toUpperCase();
		//            }
		//        }
		//        this._oUpdateRetailers = jQuery.extend([], this._oComponent.getModel("Retailers").getData());
		//        for (var j = 0; j < this._oUpdateRetailers.length; j++) {
		//            this._oUpdateRetailers[j].LoginID = sloginid;
		//            this._oUpdateRetailers[j].SchemeCPGUID = this._oUpdateRetailers[j].SchemeCPGUID.toUpperCase();
		//            this._oUpdateRetailers[j].CPGUID = this._oUpdateRetailers[j].CPGUID.toUpperCase();
		//            if (this._oUpdateRetailers[j].SchemeGUID) {
		//                this._oUpdateRetailers[j].SchemeGUID = this._oUpdateRetailers[j].SchemeGUID.toUpperCase();
		//            }
		//        }
		//        if (this._oUpdateDistributors.length <= 0 && this._oUpdateRetailers.length <= 0) {
		//            var aTemp = {
		//                "SchemeCPGUID": oPPCCommon.generateUUID(),
		//                "SchemeGUID": null,
		//                "LoginID": "",
		//                "CPTypeID": "01",
		//                "CPTypeDesc": "Distributors",
		//                "CPGUID": "",
		//                "CPNo": "",
		//                "CPName": "",
		//                "IsExcluded": "",
		//                "EnrollmentDate": null,
		//                "RegistrationDate": null,
		//                "Remarks": "",
		//                "CreatedBy": "",
		//                "CreatedOn": null,
		//                "CreatedAt": "PT18H37M35S",
		//                "ChangedBy": "",
		//                "ChangedOn": null,
		//                "ChangedAt": "PT12H08M26S",
		//                "Source": "",
		//                "ExternalRefID": "",
		//                "ExternalRefKey": ""
		//            };
		//            this._oUpdateRetailers.push(aTemp);
		//        }
		//        for (var j = 0; j < this._oUpdateDistributors.length; j++) {
		//            this._oUpdateRetailers.push(this._oUpdateDistributors[j]);
		//        }
		//        return this._oUpdateRetailers;
		//    },
		//    updateSCHEMECPS: function (sloginid) {
		//        this._oUpdateDistributors = jQuery.extend([], this._oComponent.getModel("Distributors").getData());
		//        if (this._oUpdateDistributors.length > 0) {
		//            for (var i = 0; i < this._oUpdateDistributors.length; i++) {
		//                this._oUpdateDistributors[i].LoginID = sloginid;
		//                this._oUpdateDistributors[i].SchemeCPGUID = this._oUpdateDistributors[i].SchemeCPGUID.toUpperCase();
		//                this._oUpdateDistributors[i].CPGUID = this._oUpdateDistributors[i].CPGUID.toUpperCase();
		//                if (this._oUpdateDistributors[i].SchemeGUID) {
		//                    this._oUpdateDistributors[i].SchemeGUID = this._oUpdateDistributors[i].SchemeGUID.toUpperCase();
		//                }
		//                if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                    this.oUpdateModel.update("/SchemeCPs(guid'" + this._oUpdateDistributors[i].SchemeCPGUID + "')", this._oUpdateDistributors[i], { groupId: "update" });
		//                }
		//            }
		//        }
		//        this._oUpdateRetailers = jQuery.extend([], this._oComponent.getModel("Retailers").getData());
		//        for (var j = 0; j < this._oUpdateRetailers.length; j++) {
		//            this._oUpdateRetailers[j].LoginID = sloginid;
		//            this._oUpdateRetailers[j].SchemeCPGUID = this._oUpdateRetailers[j].SchemeCPGUID.toUpperCase();
		//            this._oUpdateRetailers[j].CPGUID = this._oUpdateRetailers[j].CPGUID.toUpperCase();
		//            if (this._oUpdateRetailers[j].SchemeGUID) {
		//                this._oUpdateRetailers[j].SchemeGUID = this._oUpdateRetailers[j].SchemeGUID.toUpperCase();
		//            }
		//        }
		//        if (this._oUpdateDistributors.length <= 0 && this._oUpdateRetailers.length <= 0) {
		//            var aTemp = {
		//                "SchemeCPGUID": oPPCCommon.generateUUID(),
		//                "SchemeGUID": null,
		//                "LoginID": "",
		//                "CPTypeID": "10",
		//                "CPTypeDesc": "Distributors",
		//                "CPGUID": "",
		//                "CPNo": "",
		//                "CPName": "",
		//                "IsExcluded": "",
		//                "EnrollmentDate": null,
		//                "RegistrationDate": null,
		//                "Remarks": "",
		//                "CreatedBy": "",
		//                "CreatedOn": null,
		//                "CreatedAt": "PT18H37M35S",
		//                "ChangedBy": "",
		//                "ChangedOn": null,
		//                "ChangedAt": "PT12H08M26S",
		//                "Source": "",
		//                "ExternalRefID": "",
		//                "ExternalRefKey": ""
		//            };
		//            this._oUpdateRetailers.push(aTemp);
		//        }
		//        if (this._oUpdateRetailers.length > 0) {
		//            for (var j = 0; j < this._oUpdateRetailers.length; j++) {
		//                if (this._oUpdateRetailers[j].SchemeCPGUID) {
		//                    this._oUpdateRetailers[j].SchemeCPGUID = this._oUpdateRetailers[j].SchemeCPGUID.toUpperCase();
		//                }
		//                this.oUpdateModel.update("/SchemeCPs(guid'" + this._oUpdateRetailers[j].SchemeCPGUID + "')", this._oUpdateRetailers[j], { groupId: "update" });
		//            }
		//        }
		//    },
		//    updateSALESCRITERIA: function (sloginid, TestRun) {
		//        var that = this;
		//        var finalSaleCriRows = [];
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/reviewMode") || TestRun === "Do") {
		//            var TempfinalSaleCriRows = this._oComponent.getModel("SchemeItems").getData();
		//            var LoginID = this.getCurrentUsers("SchemeDocuments", "read");
		//            TempfinalSaleCriRows.forEach(function (eachRow) {
		//                var SubBrand = eachRow.SubBrand;
		//                var SubBrandDesc = eachRow.SubBrandDesc;
		//                eachRow.LoginID = LoginID;
		//                eachRow.SchemeItemGUID = eachRow.SchemeItemGUID.toUpperCase();
		//                eachRow = that.convertNumberToString(eachRow, [
		//                    "AllocatedFund",
		//                    "AmountPerUnit",
		//                    "ARPAmount",
		//                    "BTAmount",
		//                    "ETPerc",
		//                    "OctroiAmount",
		//                    "OtherStateVAT",
		//                    "PayoutAmount",
		//                    "PayoutPerc",
		//                    "PayoutPerPoint",
		//                    "PreviousPrice",
		//                    "QtyToBeBilled",
		//                    "RevisedPrice",
		//                    "RSIAmount",
		//                    "SPCPrice",
		//                    "SpecialSPCPrice",
		//                    "StateVATPerc",
		//                    "TargetQty",
		//                    "TargetValue",
		//                    "ItemMin",
		//                    "MRP",
		//                    "RatePerQty"
		//                ]);
		//                delete eachRow.scMaterialTokens;
		//                delete eachRow.isBasket;
		//                delete eachRow.BasketState;
		//                delete eachRow.results;
		//                finalSaleCriRows.push(eachRow);
		//            });
		//        } else {
		//            this._oUpdateSchemeItems = this._oComponent.getModel("SchemeItems").getData();
		//            this._createSchemeItem = jQuery.extend(true, [], this._oComponent.getModel("SchemeItems").getData());
		//            var flag = true;
		//            this._oUpdateSchemeItems.forEach(function (eachRow) {
		//                eachRow.MaterialNo = "";
		//                eachRow.MaterialDesc = "";
		//                if (eachRow.scMaterialTokens) {
		//                    if (eachRow.scMaterialTokens.length) {
		//                        var newEachRow = null;
		//                        flag = false;
		//                        eachRow.scMaterialTokens.forEach(function (eachTokenData) {
		//                            newEachRow = jQuery.extend(true, {}, eachRow);
		//                            newEachRow.MaterialNo = eachTokenData.ID;
		//                            newEachRow.MaterialDesc = eachTokenData.Description;
		//                            if (eachTokenData.isNew) {
		//                                newEachRow.SchemeItemGUID = oPPCCommon.generateUUID().toUpperCase();
		//                            }
		//                            delete newEachRow.scMaterialTokens;
		//                            delete newEachRow.isBasket;
		//                            delete newEachRow.BasketState;
		//                            if (newEachRow.results) {
		//                                for (var j = 0; j < newEachRow.results.length; j++) {
		//                                    delete newEachRow.results[j].isBasket;
		//                                    delete newEachRow.results[j].BasketState;
		//                                    finalSaleCriRows.push(newEachRow.results[j]);
		//                                }
		//                                delete newEachRow.results;
		//                            }
		//                            newEachRow.Partner = "1000";
		//                            newEachRow.LoginID = sloginid;
		//                            newEachRow.SchemeItemGUID = newEachRow.SchemeItemGUID.toUpperCase();
		//                            newEachRow.SchemeGUID = newEachRow.SchemeGUID.toUpperCase();
		//                            newEachRow = that.convertNumberToString(newEachRow, [
		//                                "AllocatedFund",
		//                                "AmountPerUnit",
		//                                "ARPAmount",
		//                                "BTAmount",
		//                                "ETPerc",
		//                                "OctroiAmount",
		//                                "OtherStateVAT",
		//                                "PayoutAmount",
		//                                "PayoutPerc",
		//                                "PayoutPerPoint",
		//                                "PreviousPrice",
		//                                "QtyToBeBilled",
		//                                "RevisedPrice",
		//                                "RSIAmount",
		//                                "SPCPrice",
		//                                "SpecialSPCPrice",
		//                                "StateVATPerc",
		//                                "TargetQty",
		//                                "TargetValue",
		//                                "ItemMin",
		//                                "MRP",
		//                                "RatePerQty"
		//                            ]);
		//                            finalSaleCriRows.push(newEachRow);
		//                        });
		//                    }
		//                }
		//                if (flag) {
		//                    delete eachRow.scMaterialTokens;
		//                    delete eachRow.isBasket;
		//                    delete eachRow.BasketState;
		//                    if (newEachRow) {
		//                        delete newEachRow.results;
		//                    }
		//                    var SubBrand = eachRow.SubBrand;
		//                    var SubBrandDesc = eachRow.SubBrandDesc;
		//                    eachRow.Partner = "1000";
		//                    eachRow.LoginID = sloginid;
		//                    eachRow.SchemeItemGUID = eachRow.SchemeItemGUID.toUpperCase();
		//                    eachRow.SchemeGUID = eachRow.SchemeGUID.toUpperCase();
		//                    if (eachRow.results) {
		//                        for (var j = 0; j < eachRow.results.length; j++) {
		//                            delete eachRow.results[j].isBasket;
		//                            delete eachRow.results[j].BasketState;
		//                            finalSaleCriRows.push(eachRow.results[j]);
		//                        }
		//                        delete eachRow.results;
		//                    }
		//                    eachRow = that.convertNumberToString(eachRow, [
		//                        "AllocatedFund",
		//                        "AmountPerUnit",
		//                        "ARPAmount",
		//                        "BTAmount",
		//                        "ETPerc",
		//                        "OctroiAmount",
		//                        "OtherStateVAT",
		//                        "PayoutAmount",
		//                        "PayoutPerc",
		//                        "PayoutPerPoint",
		//                        "PreviousPrice",
		//                        "QtyToBeBilled",
		//                        "RevisedPrice",
		//                        "RSIAmount",
		//                        "SPCPrice",
		//                        "SpecialSPCPrice",
		//                        "StateVATPerc",
		//                        "TargetQty",
		//                        "TargetValue",
		//                        "ItemMin",
		//                        "MRP",
		//                        "RatePerQty"
		//                    ]);
		//                    finalSaleCriRows.push(eachRow);
		//                }
		//            });
		//            that._oComponent.getModel("SchemeItems").setData(finalSaleCriRows);
		//            that.getView().getModel("LocalViewSettingDtl").setProperty("/SchemeItemsCount", finalSaleCriRows.length);
		//        }
		//        for (var i = 0; i < finalSaleCriRows.length; i++) {
		//            if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                this.oUpdateModel.update("/SchemeItemDetails(guid'" + finalSaleCriRows[i].SchemeItemGUID + "')", finalSaleCriRows[i], { groupId: "update" });
		//            }
		//        }
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            return finalSaleCriRows;
		//        }
		//    },
		//    convertNumberToString: function (oData, aProperties) {
		//        for (var g = 0; g < aProperties.length; g++) {
		//            if (!isNaN(oData[aProperties[g]])) {
		//                oData[aProperties[g]] = oData[aProperties[g]].toString();
		//            } else if (!oData[aProperties[g]] || oData[aProperties[g]] === "") {
		//                oData[aProperties[g]] = "0";
		//            }
		//        }
		//        return oData;
		//    },
		//    updateSLABS: function (sloginid) {
		//        this._oUpdateSchemeSlabs = jQuery.extend(true, [], this._oComponent.getModel("SchemeSlabs").getData());
		//        for (var i = 0; i < this._oUpdateSchemeSlabs.length; i++) {
		//            this._oUpdateSchemeSlabs[i].LoginID = sloginid;
		//            this._oUpdateSchemeSlabs[i].SlabGUID = this._oUpdateSchemeSlabs[i].SlabGUID.toUpperCase();
		//            this._oUpdateSchemeSlabs[i].SchemeGUID = this._oUpdateSchemeSlabs[i].SchemeGUID.toUpperCase();
		//            if (this._oUpdateSchemeSlabs[i].FromValue === "") {
		//                this._oUpdateSchemeSlabs[i].FromValue = "0";
		//            }
		//            if (this._oUpdateSchemeSlabs[i].FromQty === "") {
		//                this._oUpdateSchemeSlabs[i].FromQty = "0";
		//            }
		//            if (this._oUpdateSchemeSlabs[i].ToValue === "") {
		//                this._oUpdateSchemeSlabs[i].ToValue = "0";
		//            }
		//            if (this._oUpdateSchemeSlabs[i].ToQty === "") {
		//                this._oUpdateSchemeSlabs[i].ToQty = "0";
		//            }
		//            if (this._oUpdateSchemeSlabs[i].FreeArticleDesc !== "") {
		//                this._oUpdateSchemeSlabs[i].FreeArticleDesc = "";
		//            }
		//            if (this._oUpdateSchemeSlabs[i].ScratchCardDesc !== "") {
		//                this._oUpdateSchemeSlabs[i].ScratchCardDesc = "";
		//            }
		//            var SKUGroupID = this._oUpdateSchemeSlabs[i].SKUGroupID;
		//            if (SKUGroupID) {
		//                SKUGroupID = SKUGroupID.replace("-", "");
		//                SKUGroupID = SKUGroupID.replace("-", "");
		//                SKUGroupID = SKUGroupID.replace("-", "");
		//                SKUGroupID = SKUGroupID.replace("-", "");
		//            }
		//            this._oUpdateSchemeSlabs[i] = this.convertNumberToString(this._oUpdateSchemeSlabs[i], [
		//                "FromQty",
		//                "ToQty",
		//                "FromValue",
		//                "ToValue",
		//                "PayoutPerc",
		//                "PayoutAmount",
		//                "ReimbursePerc",
		//                "ReimburseAmount",
		//                "FreeQty",
		//                "OtherAmount",
		//                "RatePerQty"
		//            ]);
		//            if (!this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                this.oUpdateModel.update("/SchemeSlabs(guid'" + this._oUpdateSchemeSlabs[i].SlabGUID + "')", this._oUpdateSchemeSlabs[i], { groupId: "update" });
		//            }
		//        }
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            return this._oUpdateSchemeSlabs;
		//        }
		//    },
		//    gotoSave: function () {
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//        oPPCCommon.hideMessagePopover(this.DynamicSideContent);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/editMode", false);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/detailMode", false);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/editButton", false);
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/reviewMode", true);
		//    },
		//    validate: function () {
		//        this.clearAllErrors();
		//        this.validateHeader();
		//        var schemeType = this.getView().getModel("Schemes").getProperty("/SchemeTypeID");
		//        var vFlag = this.getView().getModel("LocalViewSettingDtl").getProperty("/newBlockValidation");
		//        this.validateGEOGRAPHYDETAILS();
		//        this.validateRETAILERCATEGORY();
		//        this.validateSCHEMECPS();
		//        this.validateSALESCRITERIA(schemeType);
		//        if (schemeType !== "000013" && vFlag === false && schemeType !== "000014") {
		//            this.validateSLABS();
		//        }
		//    },
		//    validateHeader: function () {
		//        var aBasicDataBlock = gBasicDataBlock;
		//        var Schemes = this.getView().getModel("Schemes").getProperty("/");
		//        var selectedKeys = gBasicDataBlock.byId("fPartnerTypeIDEdit").getSelectedKeys();
		//        var SchemesMandatory = this.getView().getModel("SchemesMandatory").getProperty("/");
		//        if (this.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//            SchemesMandatory.Remarks = false;
		//        }
		//        if (selectedKeys.length === 0 || selectedKeys[0] === "") {
		//            var i18nProperty = "common.message.pleaseEnterValid";
		//            this.addErrorMessages(aBasicDataBlock, "fPartnerTypeIDEdit", oi18n.getText(i18nProperty, "Scheme Applicable For"));
		//        } else {
		//            gBasicDataBlock.byId("fPartnerTypeIDEdit").setValueState("None");
		//            gBasicDataBlock.byId("fPartnerTypeIDEdit").setValueStateText("");
		//        }
		//        for (var key in SchemesMandatory) {
		//            if (SchemesMandatory.hasOwnProperty(key)) {
		//                if (SchemesMandatory[key]) {
		//                    var error = false;
		//                    var i18nProperty = "common.message.pleaseEnterValid";
		//                    if (Schemes[key] === "" || Schemes[key] === undefined || Schemes[key] === null) {
		//                        error = true;
		//                    } else if (typeof Schemes[key] === "string" && Schemes[key].trim() === "") {
		//                        error = true;
		//                    } else if (typeof Schemes[key] === "number" && Schemes[key] <= 0) {
		//                        error = true;
		//                    } else if (key === "ValidFrom" || key === "RollOutDate") {
		//                        if (!oPPCCommon.isPastDate(Schemes[key])) {
		//                            i18nProperty = "common.message.canNotBePartDate";
		//                            error = true;
		//                        }
		//                    }
		//                    if (error) {
		//                        var label = key;
		//                        var view = this.getValidViewForField("l" + key);
		//                        if (view && view.byId("l" + key)) {
		//                            label = view.byId("l" + key).getText();
		//                        } else {
		//                            view = this.getValidViewForField("l" + key + "Edit");
		//                            if (view && view.byId("l" + key + "Edit")) {
		//                                label = view.byId("l" + key + "Edit").getText();
		//                            }
		//                        }
		//                        this.addErrorMessages(view, "f" + key + "Edit", oi18n.getText(i18nProperty, label));
		//                    }
		//                }
		//            }
		//        }
		//    },
		//    validateCOSTOBJECTS: function () {
		//        var view = gSchemeCostObjectBlock;
		//        var oModel = this.getView().getModel("SchemeCostObjects");
		//        var oData = oModel.getProperty("/");
		//        if (oData.length > 0) {
		//            view.byId("UISchemeCostObjectsTable_ADDBtnEdit").setType("Emphasized");
		//            this.SchemeCostObjectsMandatory = [
		//                "CostObjID",
		//                "PercOfAlloction"
		//            ];
		//            for (var i = 0; i < oData.length; i++) {
		//                for (var v = 0; v < this.SchemeCostObjectsMandatory.length; v++) {
		//                    var propertyId = this.SchemeCostObjectsMandatory[v];
		//                    this.validateTableProperty(oModel, oData[i], i, view, propertyId, "SchemeCostObjects");
		//                }
		//            }
		//        } else {
		//            view.byId("UISchemeCostObjectsTable_ADDBtnEdit").setType("Reject");
		//            oPPCCommon.addMsg_MsgMgr(oi18n.getText("common.message.atleastOneEntry", "COST OBJECTS"), "error", "/UI/SchemeCostObjectsCount", oi18n.getText("common.message.atleastOneEntry", "COST OBJECTS"));
		//        }
		//    },
		//    validateGEOGRAPHYDETAILS: function () {
		//    },
		//    validateSALESAREAS: function () {
		//        var view = gSchemeSalesAreaBlock;
		//        var oModel = this.getView().getModel("SchemeSalesAreas");
		//        var oData = oModel.getProperty("/");
		//        if (oData.length > 0) {
		//            view.byId("UISchemeSalesAreasTable_ADDBtnEdit").setType("Emphasized");
		//            this.SchemeSalesAreasMandatory = [
		//                "SalesOrgID",
		//                "DistributionChannelID",
		//                "DivisionID"
		//            ];
		//            for (var i = 0; i < oData.length; i++) {
		//                for (var v = 0; v < this.SchemeSalesAreasMandatory.length; v++) {
		//                    var propertyId = this.SchemeSalesAreasMandatory[v];
		//                    this.validateTableProperty(oModel, oData[i], i, view, propertyId, "SchemeSalesAreas");
		//                }
		//            }
		//        } else {
		//            view.byId("UISchemeSalesAreasTable_ADDBtnEdit").setType("Reject");
		//            oPPCCommon.addMsg_MsgMgr(oi18n.getText("common.message.atleastOneEntry", "SALES AREA"), "error", "/UI/SchemeSalesAreasCount", oi18n.getText("common.message.atleastOneEntry", "SALES AREA"));
		//        }
		//    },
		//    validateRETAILERCATEGORY: function () {
		//        var view = gRetailerCategoryBlock;
		//        var oModel = this.getView().getModel("SchemeSalesAreas");
		//        var oData = oModel.getProperty("/");
		//        this.validateDuplicateRETAILERCATEGORY(oData);
		//        if (oData.length > 0) {
		//            view.byId("UISchemeSalesAreasTable_ADDBtnEdit").setType("Emphasized");
		//            this.RetailerCategorysMandatory = ["DMSDivisionID"];
		//            for (var i = 0; i < oData.length; i++) {
		//                for (var v = 0; v < this.RetailerCategorysMandatory.length; v++) {
		//                    var propertyId = this.RetailerCategorysMandatory[v];
		//                    this.validateTableProperty(oModel, oData[i], i, view, propertyId, "SchemeSalesAreas", "Retailer Category");
		//                }
		//            }
		//        } else {
		//            if (this.getView().getModel("Schemes") && this.getView().getModel("Schemes").getProperty("/OrgScopeID") === "000002") {
		//                var oDistLength = this.getView().getModel("Distributors").getProperty("/").length;
		//                var oRetailerLength = this.getView().getModel("Retailers").getProperty("/").length;
		//                if (oDistLength + oRetailerLength <= 0) {
		//                    view.byId("UISchemeSalesAreasTable_ADDBtnEdit").setType("Reject");
		//                    oPPCCommon.addMsg_MsgMgr(oi18n.getText("common.message.atleastOneEntry", "RETAILER CATEGORY"), "error", "/UI/SchemeSalesAreasCount", oi18n.getText("common.message.atleastOneEntry", "RETAILER CATEGORY or SCHEME CPS"));
		//                }
		//            }
		//        }
		//    },
		//    validateDuplicateRETAILERCATEGORY: function (oModelData) {
		//        for (var g = 0; g < oModelData.length; g++) {
		//            for (var i = g + 1; i < oModelData.length; i++) {
		//                if (oModelData[g].DMSDivisionID === oModelData[i].DMSDivisionID && oModelData[g].CPGroup1ID === oModelData[i].CPGroup1ID && oModelData[g].CPGroup2ID === oModelData[i].CPGroup2ID && oModelData[g].CPGroup3ID === oModelData[i].CPGroup3ID && oModelData[g].CPGroup4ID === oModelData[i].CPGroup4ID) {
		//                    oPPCCommon.addMsg_MsgMgr("RETAILER CATEGORY: Duplicated at " + (g + 1) + " and " + (i + 1) + " Rows", "error", "/UI/SchemeSalesAreasCount/" + g, "RETAILER CATEGORY: Duplicated at " + (g + 1) + " and " + (i + 1) + " Rows");
		//                    break;
		//                }
		//            }
		//        }
		//    },
		//    validateSCHEMECPS: function () {
		//        this.validateDistributors();
		//        this.validateRetailers();
		//    },
		//    validateDistributors: function () {
		//        var view = gSchemeCPsBlock;
		//        var oModel = this.getView().getModel("Distributors");
		//        var oData = oModel.getProperty("/");
		//        if (oData.length > 0) {
		//            view.byId("UIDistributorsTable_ADDBtnEdit").setType("Emphasized");
		//            this.DistributorsMandatory = ["CPNo"];
		//            for (var i = 0; i < oData.length; i++) {
		//                for (var v = 0; v < this.DistributorsMandatory.length; v++) {
		//                    var propertyId = this.DistributorsMandatory[v];
		//                    this.validateTableProperty(oModel, oData[i], i, view, propertyId, "Distributors");
		//                }
		//            }
		//        } else {
		//            if (this.getView().getModel("Schemes") && this.getView().getModel("Schemes").getProperty("/OrgScopeID") === "000001") {
		//                view.byId("UIDistributorsTable_ADDBtnEdit").setType("Reject");
		//                oPPCCommon.addMsg_MsgMgr(oi18n.getText("common.message.atleastOneEntry", "Distributor"), "error", "/UI/DistributorsCount", oi18n.getText("common.message.atleastOneEntry", "Distributor"));
		//            }
		//        }
		//    },
		//    validateRetailers: function () {
		//        var view = gSchemeCPsBlock;
		//        var oModel = this.getView().getModel("Retailers");
		//        var oData = oModel.getProperty("/");
		//        if (oData.length > 0) {
		//            view.byId("UIRetailersTable_ADDBtnEdit").setType("Emphasized");
		//            this.RetailersMandatory = ["CPNo"];
		//            for (var i = 0; i < oData.length; i++) {
		//                for (var v = 0; v < this.RetailersMandatory.length; v++) {
		//                    var propertyId = this.RetailersMandatory[v];
		//                    this.validateTableProperty(oModel, oData[i], i, view, propertyId, "Retailers");
		//                }
		//            }
		//        }
		//    },
		//    validateSALESCRITERIA: function (schemeType) {
		//        var view = gSchemeItemsBlock;
		//        var oModel = this.getView().getModel("SchemeItems");
		//        var oData = oModel.getProperty("/");
		//        var isBasketExist = false;
		//        if (oData.length > 0) {
		//            view.byId("UISchemeItemsTable_ADDBtnEdit").setType("Emphasized");
		//            this.SchemeItemsMandatory = [];
		//            this.validateTableProperty(oModel, oData[0], null, view, "OnSaleOfCatID", "SchemeItems");
		//            if (oData[0].OnSaleOfCatID === "000006") {
		//                this.SchemeItemsMandatory.push("SubBrand");
		//            } else if (oData[0].OnSaleOfCatID === "000001") {
		//                this.SchemeItemsMandatory.push("BannerID");
		//            } else if (oData[0].OnSaleOfCatID === "000002") {
		//                this.SchemeItemsMandatory.push("BrandID");
		//            } else if (oData[0].OnSaleOfCatID === "000003") {
		//                this.SchemeItemsMandatory.push("ProductCatID");
		//            } else if (oData[0].OnSaleOfCatID === "000006") {
		//                this.SchemeItemsMandatory.push("SubBrand");
		//            } else if (oData[0].OnSaleOfCatID === "000004") {
		//                this.SchemeItemsMandatory.push("OrderMaterialGroupID");
		//            }
		//            if (schemeType === "000013") {
		//                if (!gSchemeDetails.PayoutPercFound && !gSchemeDetails.PayoutAmntFound) {
		//                    this.SchemeItemsMandatory.push("PayoutPerc");
		//                    this.SchemeItemsMandatory.push("PayoutAmount");
		//                }
		//            }
		//            if (gSchemeDetails.PayoutPercFound && schemeType === "000013") {
		//                this.SchemeItemsMandatory.push("PayoutPerc");
		//            }
		//            if (gSchemeDetails.PayoutAmntFound && schemeType === "000013") {
		//                this.SchemeItemsMandatory.push("PayoutAmount");
		//            }
		//            if (schemeType !== "000013") {
		//                this.validateTableProperty(oModel, oData[0], null, view, "OnSaleOfItemUOMID", "SchemeItems");
		//            }
		//            for (var i = 0; i < oData.length; i++) {
		//                oData[i].PayoutAmount = parseFloat(oData[i].PayoutAmount);
		//                oData[i].PayoutPerc = parseFloat(oData[i].PayoutPerc);
		//                var pos = i;
		//                for (var g = 0; g < i; g++) {
		//                    if (oData[g].results) {
		//                        pos = pos + oData[g].results.length;
		//                    }
		//                }
		//                if (oData[i].isBasket) {
		//                    isBasketExist = true;
		//                    var ItemMin = "ItemMin";
		//                    this.validateTableProperty(oModel, oData[i], i, view, ItemMin, "SchemeItems", null, pos);
		//                    if (oData[i].results && oData[i].results.length > 0) {
		//                        for (var j = 0; j < oData[i].results.length; j++) {
		//                            var rootPos = pos + j + 1;
		//                            for (var v = 0; v < this.SchemeItemsMandatory.length; v++) {
		//                                var propertyId = this.SchemeItemsMandatory[v];
		//                                this.validateTableProperty(oModel, oData[i].results[j], i + "/results/" + j, view, propertyId, "SchemeItems", null, rootPos);
		//                            }
		//                        }
		//                    } else {
		//                        pos = pos + 1;
		//                        oModel.setProperty("/" + i + "/BasketState", "#F00");
		//                        oPPCCommon.addMsg_MsgMgr("Row #" + pos + ": Please add atlease one item to Basket", "error", "/UI/" + i + "/SchemeSalesAreasBasketEmpty", "Sales Criteria Row #" + pos + ": Please add atlease one item to Basket");
		//                    }
		//                } else {
		//                    for (v = 0; v < this.SchemeItemsMandatory.length; v++) {
		//                        propertyId = this.SchemeItemsMandatory[v];
		//                        this.validateTableProperty(oModel, oData[i], i, view, propertyId, "SchemeItems", null, pos);
		//                    }
		//                }
		//            }
		//            if (isBasketExist) {
		//                this.validateTableProperty(oModel, oData[0], null, view, "BasketUOMID", "SchemeItems");
		//            }
		//        } else {
		//            view.byId("UISchemeItemsTable_ADDBtnEdit").setType("Reject");
		//            oPPCCommon.addMsg_MsgMgr(oi18n.getText("common.message.atleastOneEntry", "SALES CRITERIA"), "error", "/UI/SchemeSalesAreasCount", oi18n.getText("common.message.atleastOneEntry", "SALES CRITERIA"));
		//        }
		//    },
		//    validateSLABS: function () {
		//        var view = gSchemeSlabsBlock;
		//        var oModel = this.getView().getModel("SchemeSlabs");
		//        var oData = oModel.getProperty("/");
		//        if (oData.length > 0) {
		//            view.byId("UISchemeSlabsTable_ADDBtnEdit").setType("Emphasized");
		//            this.SchemeSlabsMandatory = [];
		//            this.validateTableProperty(oModel, oData[0], null, view, "SlabRuleID", "SchemeSlabs");
		//            this.validateTableProperty(oModel, oData[0], null, view, "SlabTypeID", "SchemeSlabs");
		//            this.validateTableProperty(oModel, oData[0], null, view, "SaleUnitID", "SchemeSlabs");
		//            if (oData[0].SaleUnitID === "000002") {
		//                this.getView().getModel("Schemes").setProperty("/TargetBasedID", "02");
		//                this.SchemeSlabsMandatory.push("FromValue");
		//                this.SchemeSlabsMandatory.push("ToValue");
		//            } else {
		//                this.getView().getModel("Schemes").setProperty("/TargetBasedID", "01");
		//                this.SchemeSlabsMandatory.push("FromQty");
		//                this.SchemeSlabsMandatory.push("ToQty");
		//            }
		//            if (oData[0].SlabRuleID === "000001") {
		//                this.SchemeSlabsMandatory.push("FreeQty");
		//                this.SchemeSlabsMandatory.push("MaterialNo");
		//                this.SchemeSlabsMandatory.push("ReimbursementModeID");
		//                this.SchemeSlabsMandatory.push("FreeQtyUOM");
		//            } else if (oData[0].SlabRuleID === "000002") {
		//                this.SchemeSlabsMandatory.push("FreeQty");
		//                this.SchemeSlabsMandatory.push("OrderMaterialGroupDesc");
		//                this.SchemeSlabsMandatory.push("FreeQtyUOM");
		//            } else if (oData[0].SlabRuleID === "000003") {
		//                this.SchemeSlabsMandatory.push("PayoutPerc");
		//            } else if (oData[0].SlabRuleID === "000004") {
		//                this.SchemeSlabsMandatory.push("PayoutAmount");
		//            } else if (oData[0].SlabRuleID === "000005") {
		//                this.SchemeSlabsMandatory.push("NoOfCards");
		//                this.SchemeSlabsMandatory.push("CardTitle");
		//            } else if (oData[0].SlabRuleID === "000006") {
		//                this.SchemeSlabsMandatory.push("FreeQty");
		//                this.SchemeSlabsMandatory.push("FreeArticle");
		//                this.SchemeSlabsMandatory.push("FreeQtyUOM");
		//            } else if (oData[0].SlabRuleID === "000007") {
		//                this.SchemeSlabsMandatory.push("FreeQty");
		//                this.SchemeSlabsMandatory.push("SKUGroupID");
		//                this.SchemeSlabsMandatory.push("FreeQtyUOM");
		//            }
		//            for (var i = 0; i < oData.length; i++) {
		//                var pos = i;
		//                for (var g = 0; g < i; g++) {
		//                    if (oData[g].results) {
		//                        pos = pos + oData[g].results.length;
		//                    }
		//                }
		//                if (oData[i].results && oData[i].results.length > 0) {
		//                    for (var j = 0; j < oData[i].results.length; j++) {
		//                        var rootPos = pos + j + 1;
		//                        for (var v = 0; v < this.SchemeSlabsMandatory.length; v++) {
		//                            var propertyId = this.SchemeSlabsMandatory[v];
		//                            this.validateTableProperty(oModel, oData[i].results[j], i + "/results/" + j, view, propertyId, "SchemeSlabs", null, rootPos);
		//                        }
		//                    }
		//                } else {
		//                    for (v = 0; v < this.SchemeSlabsMandatory.length; v++) {
		//                        propertyId = this.SchemeSlabsMandatory[v];
		//                        this.validateTableProperty(oModel, oData[i], i, view, propertyId, "SchemeSlabs", null, pos);
		//                    }
		//                }
		//            }
		//        } else {
		//            view.byId("UISchemeSlabsTable_ADDBtnEdit").setType("Reject");
		//            oPPCCommon.addMsg_MsgMgr(oi18n.getText("common.message.atleastOneEntry", "SALES SLABS"), "error", "/UI/SchemeSalesAreasCount", oi18n.getText("common.message.atleastOneEntry", "SALES SLABS"));
		//        }
		//    },
		//    validateTableProperty: function (oModel, oData, pos, view, propertyId, oModelName, sTableTitle, posText) {
		//        if (!oData[propertyId] || typeof oData[propertyId] === "number" && oData[propertyId] <= 0 || typeof oData[propertyId] === "string" && oData[propertyId].trim() === "") {
		//            var labelText = propertyId;
		//            if (view.byId("l" + propertyId)) {
		//                if (view.byId("l" + propertyId) instanceof sap.m.ObjectStatus) {
		//                    labelText = view.byId("l" + propertyId).getTitle();
		//                } else {
		//                    labelText = view.byId("l" + propertyId).getText();
		//                }
		//            }
		//            if (view.byId("l" + propertyId + "Edit")) {
		//                if (view.byId("l" + propertyId + "Edit") instanceof sap.m.ObjectStatus) {
		//                    labelText = view.byId("l" + propertyId + "Edit").getTitle();
		//                } else {
		//                    labelText = view.byId("l" + propertyId + "Edit").getText();
		//                }
		//            }
		//            var rowText = "";
		//            if (pos === null) {
		//                rowText = "";
		//                pos = 0;
		//            } else {
		//                if (posText) {
		//                    posText = parseInt(posText) + 1;
		//                } else {
		//                    posText = parseInt(pos) + 1;
		//                }
		//                rowText = " Row #" + posText + ": ";
		//            }
		//            var tableTitle = oi18n.getText(oModelName + ".Table.Title");
		//            if (sTableTitle && sTableTitle !== null) {
		//                tableTitle = sTableTitle;
		//            }
		//            this.addItemErrorMessages(view, "/" + pos + "/" + propertyId + "ValueState", "/" + pos + "/" + propertyId + "ValueStateText", rowText + oi18n.getText("common.message.pleaseEnterValid", labelText), tableTitle + rowText + oi18n.getText("common.message.pleaseEnterValid", labelText), oModel, oModelName);
		//        }
		//    },
		//    addErrorMessages: function (view, controlID, msg) {
		//        if (view && view.byId(controlID)) {
		//            view = view;
		//        } else {
		//            view = this.getValidViewForField(controlID);
		//        }
		//        msg = msg.replace(":", "");
		//        if (view && view.byId(controlID) && view.byId(controlID).getVisible()) {
		//            if (!(view.byId(controlID) instanceof sap.m.Select && parseFloat(sap.ui.version) < 1.4)) {
		//                view.byId(controlID).setValueState("Error");
		//                view.byId(controlID).setValueStateText(msg);
		//            }
		//            oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/" + controlID, msg);
		//        }
		//        if (this.addErrorMessages_Exit) {
		//            this.addErrorMessages_Exit();
		//        }
		//    },
		//    addItemErrorMessages: function (view, valueStateProperty, valueStateTextProperty, msg, msgDesc, oModel, sTableID) {
		//        var valueStateMsg = msg;
		//        if (msg && msg.split(":").length > 1) {
		//            valueStateMsg = msg.split(":")[1].trim();
		//        }
		//        oModel.setProperty(valueStateProperty, "Error");
		//        oModel.setProperty(valueStateTextProperty, valueStateMsg);
		//        oPPCCommon.addMsg_MsgMgr(msg, "error", "/UI/" + sTableID + "/" + valueStateProperty, msgDesc);
		//        if (this.addItemErrorMessages_Exit) {
		//            this.addItemErrorMessages_Exit();
		//        }
		//    },
		//    showError: function () {
		//        this.getView().getModel("LocalViewSettingDtl").setProperty("/messageLength", sap.ui.getCore().getMessageManager().getMessageModel().getData().length);
		//        if (sap.ui.getCore().getMessageManager().getMessageModel().getData().length > 0) {
		//            oPPCCommon.showMessagePopover(this.DynamicSideContent);
		//        }
		//    },
		//    showPopUp: function () {
		//        if (sap.ui.getCore().getMessageManager().getMessageModel().getData().length > 0) {
		//            oPPCCommon.showMessagePopover(this.DynamicSideContent);
		//        }
		//    },
		//    headerMandatory: function () {
		//        var oSchemesMandatory = {
		//            "SchemeGUID": false,
		//            "LoginID": false,
		//            "SchemeName": true,
		//            "SchemeTypeID": true,
		//            "SchemeID": false,
		//            "SchemeGroupID": false,
		//            "InternalSchemeRefNo": false,
		//            "ExternalSchemeRefNo": false,
		//            "PayoutTypeID": false,
		//            "Budget": true,
		//            "ValidFrom": true,
		//            "ValidTo": false,
		//            "MonthID": false,
		//            "Year": false,
		//            "ClaimRecipientID": true,
		//            "InvoiceEligibilityID": false,
		//            "PartnerTypeID": false,
		//            "Conditions": false,
		//            "SendSMSNotif": false,
		//            "SendEmailNotif": false,
		//            "RollOutDate": true,
		//            "ValidFromTime": false,
		//            "ValidToTime": false,
		//            "ApprovalStrategyID": false,
		//            "SchemeSalesCatID": false,
		//            "DisbursementTypeID": false,
		//            "DisbursementDate": false,
		//            "DisbursementFreqID": false,
		//            "DisbursementFreqDesc": false,
		//            "DocToBeConsideredID": false,
		//            "DocToBeConsideredDesc": false,
		//            "DefaultInd": false,
		//            "CompanyCodeID": false,
		//            "InterBranchSalesID": false,
		//            "ChargeTypeID": false,
		//            "InclOrExclTaxID": false,
		//            "IsTransBased": false,
		//            "QuantityOrValueBasedID": false,
		//            "RuleID": false,
		//            "InternalOrderNo": false,
		//            "SchemeSubCatID": false,
		//            "VendorNo": false,
		//            "IsHeaderBasedSlab": false,
		//            "TargetBasedID": false,
		//            "TargetValue": false,
		//            "TargetQuantity": false,
		//            "UOM": false,
		//            "ValidityBasedID": false,
		//            "PlantID": false,
		//            "Remarks": true
		//        };
		//        var oSchemesMandatoryModel = new sap.ui.model.json.JSONModel();
		//        oSchemesMandatoryModel.setData(oSchemesMandatory);
		//        this._oComponent.setModel(oSchemesMandatoryModel, "SchemesMandatory");
		//    },
		//    onSave: function () {
		//        this.updateScheme();
		//    },
		//    updatedSuccessfully: function (GUID) {
		//        var that = this;
		//        setTimeout(function () {
		//            if (!that.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                sap.m.MessageToast.show(oi18n.getText("Detail.message.changessuccessfully"));
		//            }
		//        }, 500);
		//        setTimeout(function () {
		//            if (that.getView().getModel("LocalViewSettingDtl").getProperty("/Cloning")) {
		//                that.setDefaultSettings();
		//                that.getSchemeDetails();
		//                that.onCreateSuccess(GUID);
		//                that.onEdit();
		//                that.getView().getModel("LocalViewSettingDtl").setProperty("/DDLoaded", true);
		//            }
		//            that.setDefaultSettings();
		//            that.getSchemeDetails();
		//            that.getView().getModel("LocalViewSettingDtl").setProperty("/DDLoaded", true);
		//        }, 1500);
		//    },
		//    onCreateSuccess: function (GUID) {
		//        var that = this;
		//        var dialog = new sap.m.Dialog({
		//            title: "Success",
		//            type: "Standard",
		//            state: "Success",
		//            draggable: true,
		//            content: [new sap.m.Text({ text: oPPCCommon.getMsgsFromMsgMgr() })],
		//            buttons: [
		//                new sap.m.Button({
		//                    text: oi18n.getText("view"),
		//                    press: function () {
		//                        that.gotoDetail(GUID);
		//                        dialog.close();
		//                    }
		//                }),
		//                new sap.m.Button({
		//                    text: oi18n.getText("Ok"),
		//                    press: function () {
		//                        window.location = "#";
		//                        window.location.reload();
		//                        dialog.close();
		//                    }
		//                })
		//            ],
		//            afterClose: function () {
		//                dialog.destroy();
		//            }
		//        });
		//        dialog.open();
		//        if (this.onCreateSuccess_Exit) {
		//            this.onCreateSuccess_Exit();
		//        }
		//    },
		//    gotoDetail: function (GUID) {
		//        var path = "Schemes(SchemeGUID='" + GUID + "')";
		//        oPPCCommon.crossAppNavigation("ssschemecreate", "ssschemes", "Display", "", "", "/View/" + path);
		//        if (this.gotoCPDetail_Exit) {
		//            this.gotoCPDetail_Exit();
		//        }
		//    }
	});
});