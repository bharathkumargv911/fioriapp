jQuery.sap.declare("com.arteriatech.ss.schemes.zssschemesb.Component");

// use the load function for getting the optimized preload file if present
sap.ui.component.load({
	name: "com.arteriatech.ss.schemes",
	// Use the below URL to run the extended application when SAP-delivered application is deployed on cloud
	// Remove the url parameter once your application is deployed to productive account
	url: jQuery.sap.getModulePath("com.arteriatech.ss.schemes.zssschemesb") + "/parent"
		// we use a URL relative to our own component
		// extension application is deployed with customer namespace
});

this.com.arteriatech.ss.schemes.Component.extend("com.arteriatech.ss.schemes.zssschemesb.Component", {
	metadata: {
		manifest: "json"
	}
});