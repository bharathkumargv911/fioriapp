sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("pyopcnfglist.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  