/* global QUnit */

sap.ui.require(["pyopcnfglist/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
