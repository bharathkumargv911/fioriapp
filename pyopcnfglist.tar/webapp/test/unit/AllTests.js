sap.ui.define([
	"pyopcnfglist/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
