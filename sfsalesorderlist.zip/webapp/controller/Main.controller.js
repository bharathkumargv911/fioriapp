sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/arteriatech/ppc/utils/js/Common"
], function (Controller, oPPCCommon) {
	"use strict";

	return Controller.extend("com.arteriatech.sf.salesorderlist.sfsalesorderlist.controller.Main", {
		onInit: function () {
			this.onInitHookUp();
		},
		onInitHookUp: function () {
			this._oComponent = sap.ui.component(sap.ui.core.Component.getOwnerIdFor(this.getView()));
			var oDataModel = this._oComponent.getModel("PCGW");
			var oUtilsI18n = this._oComponent.getModel("ppcutili18n").getResourceBundle();
			// oPPCCommon.loadProductFeatures({
			// 	Typeset: "PD",
			// 	oDataModel: oDataModel,
			// 	oUtilsI18n: oUtilsI18n
			// });
			oPPCCommon.initMsgMangerObjects();

			if (sap.ui.Device.support.touch === false) {
				this.getView().addStyleClass("sapUiSizeCompact");
			}

			if (this.onInitHookUp_Exit) {
				this.onInitHookUp();
			}
		}
	});
});