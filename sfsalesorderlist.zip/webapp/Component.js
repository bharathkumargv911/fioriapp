sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/arteriatech/sf/salesorderlist/sfsalesorderlist/model/models",
	"com/arteriatech/sf/salesorderlist/sfsalesorderlist/Component"
], function (UIComponent, Device, models, Component) {
	"use strict";
	var gListPageView;
	var gSODetailView;
	var gSOItemDetailHeaderView;
	var gSODetailItemEditView;
	var gSODetailHeaderEditView;
	var gSODetailView;

	return UIComponent.extend("com.arteriatech.sf.salesorderlist.sfsalesorderlist.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			//Common Utils
			jQuery.sap.registerModulePath("com.arteriatech.ppc.utils", "/sap/bc/ui5_ui5/ARTEC/PPCUTIL/utils/");

			//Product Utils
			jQuery.sap.registerModulePath("com.arteriatech.prd.utils", "/sap/bc/ui5_ui5/ARTEC/SSUTIL/utils/");
			jQuery.sap.registerModulePath("com.arteriatech.ss.utils", "/sap/bc/ui5_ui5/ARTEC/SSUTIL/utils/");

			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			var Device = sap.ui.Device;
			var DeviceModel = new sap.ui.model.json.JSONModel(Device);
			DeviceModel.setDefaultBindingMode("OneWay");
			this.setModel(DeviceModel, "device");

			// enable routing
			this.getRouter().initialize();

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
		}
	});
});