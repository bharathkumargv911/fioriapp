sap.ui.define([
	"com/arteriatech/sf/salesorderlist/sfsalesorderlist/test/unit/controller/Main.controller"
], function () {
	"use strict";
});